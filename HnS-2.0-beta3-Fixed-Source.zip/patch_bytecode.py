import os, struct, zipfile
from tools import classfile

JAR_IN = "/tmp/hns_inspect/hackersandslashers-2.0-beta3.jar"
OUT_DIR = "/tmp/hns_build/classes_patched"

def encode_mutf8(s: str) -> bytes:
    out = bytearray()
    for ch in s:
        cp = ord(ch)
        if cp == 0:
            out += b"\xc0\x80"
        elif cp <= 0x7F:
            out.append(cp)
        elif cp <= 0x7FF:
            out.append(0xC0 | ((cp >> 6) & 0x1F))
            out.append(0x80 | (cp & 0x3F))
        else:
            out.append(0xE0 | ((cp >> 12) & 0x0F))
            out.append(0x80 | ((cp >> 6) & 0x3F))
            out.append(0x80 | (cp & 0x3F))
    return bytes(out)

class MutableClass:
    def __init__(self, data: bytes):
        self.data = bytearray(data)
        self.cf = classfile.parse(data)
        # Walk header to find exact byte spans
        r = classfile.Reader(data, "patch")
        r.skip(8) # magic, minor, major
        self.cp_count_off = r.p
        cp_count = r.u2()
        self.cp_start = r.p
        i = 1
        while i < cp_count:
            tag = r.u1()
            if tag == 1:
                r.skip(r.u2())
            elif tag in (3, 4):
                r.skip(4)
            elif tag in (5, 6):
                r.skip(8)
                i += 1
            elif tag in (7, 8, 16, 19, 20):
                r.skip(2)
            elif tag in (9, 10, 11, 12, 17, 18):
                r.skip(4)
            elif tag == 15:
                r.skip(3)
            i += 1
        self.cp_end = r.p
        self.cp_count = cp_count
        self.extra_cp = bytearray()

        # Skip access, this, super, interfaces
        r.skip(6)
        icount = r.u2()
        r.skip(icount * 2)
        # Skip fields
        fcount = r.u2()
        for _ in range(fcount):
            r.skip(6)
            ac = r.u2()
            for _ in range(ac):
                r.skip(2)
                r.skip(r.u4())
        self.methods_count_off = r.p
        self.mcount = r.u2()
        self.methods = []
        for _ in range(self.mcount):
            m_start = r.p
            acc = r.u2()
            n_idx = r.u2()
            d_idx = r.u2()
            ac = r.u2()
            attrs = []
            for _ in range(ac):
                a_start = r.p
                an_idx = r.u2()
                alen = r.u4()
                ad_off = r.p
                r.skip(alen)
                attrs.append((a_start, an_idx, ad_off, alen, r.p))
            self.methods.append({
                "start": m_start, "end": r.p,
                "access": acc, "name": self.cf.utf8(n_idx), "desc": self.cf.utf8(d_idx),
                "attrs": attrs
            })
        self.methods_end = r.p

    def _add_cp(self, entry: bytes) -> int:
        idx = self.cp_count
        self.extra_cp += entry
        self.cp_count += 1
        return idx

    def ensure_utf8(self, s: str) -> int:
        for idx, e in enumerate(self.cf.cp):
            if e and e[0] == 1 and e[1] == s:
                return idx
        # Also check extra
        b = encode_mutf8(s)
        return self._add_cp(b"\x01" + struct.pack(">H", len(b)) + b)

    def ensure_class(self, internal_name: str) -> int:
        for idx, e in enumerate(self.cf.cp):
            if e and e[0] == 7 and self.cf.utf8(e[1]) == internal_name:
                return idx
        ni = self.ensure_utf8(internal_name)
        return self._add_cp(b"\x07" + struct.pack(">H", ni))

    def ensure_nat(self, name: str, desc: str) -> int:
        for idx, e in enumerate(self.cf.cp):
            if e and e[0] == 12 and self.cf.utf8(e[1][0]) == name and self.cf.utf8(e[1][1]) == desc:
                return idx
        ni = self.ensure_utf8(name)
        di = self.ensure_utf8(desc)
        return self._add_cp(b"\x0c" + struct.pack(">HH", ni, di))

    def ensure_methodref(self, owner: str, name: str, desc: str) -> int:
        for idx, e in enumerate(self.cf.cp):
            if e and e[0] == 10:
                ci, nati = e[1]
                if self.cf.class_name(ci) == owner:
                    ni, di = self.cf.cp[nati][1]
                    if self.cf.utf8(ni) == name and self.cf.utf8(di) == desc:
                        return idx
        ci = self.ensure_class(owner)
        nati = self.ensure_nat(name, desc)
        return self._add_cp(b"\x0a" + struct.pack(">HH", ci, nati))

    def find_method(self, name: str, desc: str = None):
        for m in self.methods:
            if m["name"] == name and (desc is None or m["desc"] == desc):
                return m
        raise RuntimeError(f"Method {name}{desc or ''} not found in {self.cf.name}")

    def find_code_attr(self, m):
        for a in m["attrs"]:
            if self.cf.utf8(a[1]) == "Code":
                return a
        raise RuntimeError(f"No Code attr on {m['name']}")

    def patch_code_bytes_inplace(self, m, bci: int, expected_op: int, new_bytes: bytes):
        _, _, ad_off, alen, _ = self.find_code_attr(m)
        clen = struct.unpack(">I", self.data[ad_off+4:ad_off+8])[0]
        code_off = ad_off + 8
        assert bci + len(new_bytes) <= clen
        actual_op = self.data[code_off + bci]
        assert actual_op == expected_op, f"{self.cf.name}.{m['name']} bci {bci}: expected 0x{expected_op:02x}, got 0x{actual_op:02x}"
        self.data[code_off + bci : code_off + bci + len(new_bytes)] = new_bytes

    def replace_method_code(self, m, max_stack: int, max_locals: int, new_code: bytes):
        a_start, an_idx, ad_off, alen, a_end = self.find_code_attr(m)
        new_attr_body = struct.pack(">HHI", max_stack, max_locals, len(new_code)) + new_code + struct.pack(">HH", 0, 0)
        new_attr = struct.pack(">HI", an_idx, len(new_attr_body)) + new_attr_body
        self._splat(a_start, a_end, new_attr)

    def append_method(self, access: int, name: str, desc: str, max_stack: int, max_locals: int, code: bytes):
        n_idx = self.ensure_utf8(name)
        d_idx = self.ensure_utf8(desc)
        code_n_idx = self.ensure_utf8("Code")
        body = struct.pack(">HHI", max_stack, max_locals, len(code)) + code + struct.pack(">HH", 0, 0)
        m_bytes = struct.pack(">HHHHHI", access, n_idx, d_idx, 1, code_n_idx, len(body)) + body
        self.mcount += 1
        struct.pack_into(">H", self.data, self.methods_count_off, self.mcount)
        pos = self.methods_end
        self.data[pos:pos] = m_bytes
        self.methods_end += len(m_bytes)

    def _splat(self, start: int, end: int, replacement: bytes):
        delta = len(replacement) - (end - start)
        self.data[start:end] = replacement
        self.methods_end += delta
        # Update subsequent method offsets if needed (callers do one or refresh)

    def build(self) -> bytes:
        out = bytearray(self.data)
        struct.pack_into(">H", out, self.cp_count_off, self.cp_count)
        if self.extra_cp:
            out[self.cp_end:self.cp_end] = self.extra_cp
        # Verify structural validity
        classfile.parse(bytes(out), self.cf.name)
        return bytes(out)

BRIDGE = "net/dndats/hackersandslashers/compat/punchy/PunchyTrailBridge"
os.makedirs(OUT_DIR, exist_ok=True)

with zipfile.ZipFile(JAR_IN) as z:
    def save(rel, b):
        p = os.path.join(OUT_DIR, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "wb") as f:
            f.write(b)
        print("PATCHED OK:", rel)

    # 1. DynamicAnimationHandler.updatePlayerPose bci 1505
    rel = "net/dndats/api/animations/DynamicAnimationHandler.class"
    mc = MutableClass(z.read(rel))
    mr = mc.ensure_methodref(BRIDGE, "isFirstPersonPoseAllowed", "(Lnet/minecraft/client/CameraType;)Z")
    mc.patch_code_bytes_inplace(mc.find_method("updatePlayerPose"), 1505, 0xb6, b"\xb8" + struct.pack(">H", mr))
    save(rel, mc.build())

    # 2. ItemInHandLayerMixin.HnS$renderWithCustomItemBone bci 176
    rel = "net/dndats/hackersandslashers/mixin/combat/ItemInHandLayerMixin.class"
    mc = MutableClass(z.read(rel))
    mr = mc.ensure_methodref(BRIDGE, "isFirstPersonPoseAllowed", "(Lnet/minecraft/client/CameraType;)Z")
    mc.patch_code_bytes_inplace(mc.find_method("HnS$renderWithCustomItemBone"), 176, 0xb6, b"\xb8" + struct.pack(">H", mr))
    save(rel, mc.build())

    # 3. TrailSystem.onRenderLevel bci 467
    rel = "net/dndats/hackersandslashers/impl/combat/mechanics/combo/TrailSystem.class"
    mc = MutableClass(z.read(rel))
    mr = mc.ensure_methodref(BRIDGE, "getFirstPersonProjectionMatrix", "(Lnet/minecraft/client/renderer/GameRenderer;D)Lorg/joml/Matrix4f;")
    mc.patch_code_bytes_inplace(mc.find_method("onRenderLevel"), 467, 0xb6, b"\xb8" + struct.pack(">H", mr))
    save(rel, mc.build())

    # 4. ComboManager.powerAttackBehavior (957) & comboBehavior (1900)
    rel = "net/dndats/hackersandslashers/impl/combat/mechanics/combo/ComboManager.class"
    mc = MutableClass(z.read(rel))
    mr = mc.ensure_methodref(BRIDGE, "playAttackAnimationAndSwing", "(Lnet/minecraft/world/entity/player/Player;Ljava/lang/String;FZ)V")
    mc.patch_code_bytes_inplace(mc.find_method("powerAttackBehavior"), 957, 0xb8, b"\xb8" + struct.pack(">H", mr))
    mc.patch_code_bytes_inplace(mc.find_method("comboBehavior"), 1900, 0xb8, b"\xb8" + struct.pack(">H", mr))
    save(rel, mc.build())

    # 5. ParryManager.canParry bci 103
    rel = "net/dndats/hackersandslashers/impl/combat/mechanics/defense/parry/ParryManager.class"
    mc = MutableClass(z.read(rel))
    mr = mc.ensure_methodref(BRIDGE, "canParryWithMallardAndOffhand", "(Lnet/minecraft/world/entity/player/Player;)Z")
    mc.patch_code_bytes_inplace(mc.find_method("canParry"), 103, 0xb8, b"\xb8" + struct.pack(">H", mr))
    save(rel, mc.build())

    # 6. CombatParkourHandler$Client.onClientTick bci 782
    rel = "net/dndats/hackersandslashers/handlers/movement/CombatParkourHandler$Client.class"
    mc = MutableClass(z.read(rel))
    mr = mc.ensure_methodref(BRIDGE, "getGrappleEnergyCostPerTick", "()F")
    mc.patch_code_bytes_inplace(mc.find_method("onClientTick"), 782, 0x13, b"\xb8" + struct.pack(">H", mr))
    save(rel, mc.build())

    # 7. CombatParkourManager: startGrapple, calculateDodgeVector, canGrappleTarget
    rel = "net/dndats/hackersandslashers/impl/combat/mechanics/movement/parkour/CombatParkourManager.class"
    mc = MutableClass(z.read(rel))
    mr_start = mc.ensure_methodref(BRIDGE, "canStartGrapple", "(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/LivingEntity;Lnet/dndats/hackersandslashers/impl/combat/mechanics/combo/ClientCombatState;)Z")
    # bci 0..12 (13 bytes): aload_0, aload_1, aload_2, invokestatic, ifne +7 (13), goto +3 (12), return
    mc.patch_code_bytes_inplace(
        mc.find_method("startGrapple"), 0, 0x2a,
        b"\x2a\x2b\x2c\xb8" + struct.pack(">H", mr_start) + b"\x9a\x00\x07\xa7\x00\x03\xb1"
    )
    mr_dodge = mc.ensure_methodref(BRIDGE, "calculateDodgeVector", "(Lnet/minecraft/world/entity/player/Player;Z)Lnet/minecraft/world/phys/Vec3;")
    mc.replace_method_code(
        mc.find_method("calculateDodgeVector"), 2, 2,
        b"\x2a\x1b\xb8" + struct.pack(">H", mr_dodge) + b"\xb0"
    )
    # Re-parse offsets before appending method cleanly
    mc = MutableClass(mc.build())
    mr_tgt = mc.ensure_methodref(BRIDGE, "canGrappleTarget", "(Lnet/minecraft/world/entity/LivingEntity;)Z")
    mc.append_method(0x0009, "canGrappleTarget", "(Lnet/minecraft/world/entity/LivingEntity;)Z", 1, 1, b"\x2a\xb8" + struct.pack(">H", mr_tgt) + b"\xac")
    save(rel, mc.build())

    # 8. PlayerAnimator.determineFirstPersonMode
    rel = "net/dndats/api/animations/PlayerAnimator.class"
    mc = MutableClass(z.read(rel))
    mr_fp = mc.ensure_methodref(BRIDGE, "determineFirstPersonMode", "(ZZZZ)Lcom/zigythebird/playeranimcore/api/firstPerson/FirstPersonMode;")
    mc.replace_method_code(
        mc.find_method("determineFirstPersonMode"), 4, 4,
        b"\x1a\x1b\x1c\x1d\xb8" + struct.pack(">H", mr_fp) + b"\xb0"
    )
    save(rel, mc.build())
