package net.dndats.api.animations;

import com.zigythebird.playeranim.api.PlayerAnimationAccess;
import com.zigythebird.playeranimcore.animation.layered.IAnimation;
import com.zigythebird.playeranimcore.animation.layered.modifier.AbstractFadeModifier;
import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonConfiguration;
import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonMode;
import com.zigythebird.playeranimcore.easing.EasingType;
import net.dndats.hackersandslashers.compat.punchy.PunchyClientBridge;
import net.dndats.hackersandslashers.datapacks.enums.WeaponHandedness;
import net.dndats.hackersandslashers.datapacks.models.StancesData;
import net.dndats.hackersandslashers.datapacks.models.WeaponStatOverride;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.ClientCombatState;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.ComboManager;
import net.dndats.hackersandslashers.utils.helper.Animator;
import net.dndats.hackersandslashers.utils.helper.CombatHelper;
import net.dndats.hackersandslashers.utils.helper.ItemHelper;
import net.dndats.hackersandslashers.utils.helper.PlayerHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

@EventBusSubscriber(modid = "hackersandslashers", value = {Dist.CLIENT})
public class DynamicAnimationHandler {
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            return;
        }
        for (AbstractClientPlayer player : mc.level.players()) {
            updatePlayerPose(player);
            sanitizeOrphanedLayers(player);
        }
    }

    @SubscribeEvent
    public static void onItemUseStop(LivingEntityUseItemEvent.Stop event) {
        handleItemUseEnd(event.getEntity(), event.getItem());
    }

    @SubscribeEvent
    public static void onItemUseFinish(LivingEntityUseItemEvent.Finish event) {
        handleItemUseEnd(event.getEntity(), event.getItem());
    }

    private static void handleItemUseEnd(LivingEntity entity, ItemStack item) {
        if (entity instanceof Player player && player.level().isClientSide()) {
            StancesData stances = ItemHelper.getStances(item);
            if (stances != null) {
                String anim = stances.getOnItemRelease(player);
                if (anim != null) {
                    Animator.playAnimation(player, anim, 1.0F, false);
                } else {
                    Animator.cancelAnimation(player, PlayerAnimator.ACTION_LAYER);
                }
            } else {
                Animator.cancelAnimation(player, PlayerAnimator.ACTION_LAYER);
            }
        }
    }

    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) {
            StancesData stances = ItemHelper.getStances(event.getItemStack());
            if (stances != null) {
                String anim = stances.getOnRightClickItem(player);
                if (anim != null) {
                    Animator.playAnimation(player, anim, 1.0F, false);
                }
            }
        }
    }

    public static void restartIdleAnimation(AbstractClientPlayer player) {
        HnSPlayerPoseController poseController = (HnSPlayerPoseController) PlayerAnimationAccess.getPlayerAnimationLayer(
                player, PlayerAnimator.POSE_LAYER);
        if (poseController != null) {
            poseController.currentPoseAnim = null;
        }
        HnSPlayerFirstPersonPoseController fpPoseController = (HnSPlayerFirstPersonPoseController) PlayerAnimationAccess.getPlayerAnimationLayer(
                player, PlayerAnimator.FIRST_PERSON_POSE_LAYER);
        if (fpPoseController != null) {
            fpPoseController.currentPoseAnim = null;
        }
    }

    public static void updatePlayerPose(AbstractClientPlayer player) {
        HnSPlayerPoseController poseController = (HnSPlayerPoseController) PlayerAnimationAccess.getPlayerAnimationLayer(
                player, PlayerAnimator.POSE_LAYER);
        HnSPlayerFirstPersonPoseController fpPoseController = (HnSPlayerFirstPersonPoseController) PlayerAnimationAccess.getPlayerAnimationLayer(
                player, PlayerAnimator.FIRST_PERSON_POSE_LAYER);
        HnSPlayerAttackController attackController = (HnSPlayerAttackController) PlayerAnimationAccess.getPlayerAnimationLayer(
                player, PlayerAnimator.ATTACK_LAYER);
        IAnimation actionLayer = PlayerAnimationAccess.getPlayerAnimationLayer(
                player, PlayerAnimator.ACTION_LAYER);
        if (poseController == null || attackController == null || fpPoseController == null) {
            return;
        }

        poseController.setFirstPersonConfiguration(new FirstPersonConfiguration().setShowArmor(false));

        ItemStack mainHand = player.getMainHandItem();
        boolean offhandOnlyCombat = ItemHelper.isHoldingCombatItem(player) && mainHand.isEmpty();
        boolean showLeftArm = ItemHelper.getHandedness(mainHand).equals(WeaponHandedness.TWO_HANDED)
                || ItemHelper.isMeleeWeapon(player.getOffhandItem())
                || offhandOnlyCombat;

        PunchyClientBridge.applySyncedFirstPersonConfig(
                fpPoseController,
                new FirstPersonConfiguration()
                        .setShowArmor(false)
                        .setShowRightArm(!mainHand.isEmpty() || offhandOnlyCombat)
                        .setShowLeftArm(showLeftArm));

        String tpPoseName = "idle";
        String fpPoseName = "idle";

        ClientCombatState state = ComboManager.getState(player);
        WeaponStatOverride stats = ItemHelper.resolvePresetStats(mainHand, player);
        boolean isMoving = PlayerHelper.isWalkingOrRunning(player);
        boolean isCrouching = player.isCrouching();
        boolean isUsingItem = PunchyClientBridge.isUsingOrMallardGuarding(player);

        boolean isDefending = false;
        IAnimation defenseLayer = PlayerAnimationAccess.getPlayerAnimationLayer(player, PlayerAnimator.DEFENSE_LAYER);
        if (defenseLayer instanceof HnSPlayerDefenseController defenseController) {
            isDefending = defenseController.isActive()
                    && defenseController.currentAnim != null
                    && !defenseController.currentAnim.getPath().equals("idle");
            if (stats != null && stats.handling != null) {
                defenseController.cameraModifier.handlingData = stats.handling;
            } else {
                defenseController.cameraModifier.handlingData = new WeaponStatOverride.WeaponHandlingData();
            }
        }

        boolean isActing = false;
        if (actionLayer instanceof HnSPlayerActionController actionController
                && actionController.isActive()
                && actionController.currentAnim != null) {
            String actionPath = actionController.currentAnim.getPath();
            isActing = !actionPath.equals("idle") && !actionPath.contains("dash") && !actionPath.contains("roll");
        }

        boolean isSprinting = player.isSprinting() && !isDefending && !isActing && !isUsingItem;

        StancesData stances = null;
        boolean isGrappling = false;
        boolean isVaulting = false;
        boolean isDodging = false;

        if (stats != null && stats.stances != null) {
            stances = stats.stances;
            isGrappling = state != null && state.grappledEntity != null;
            isVaulting = state != null && state.vaultAnimStartTick != -1;
            isDodging = PlayerHelper.isDodging(player);

            if (isGrappling) {
                boolean isLargeTarget = (double) state.grappledEntity.getBbHeight() >= (double) player.getBbHeight() + 1.0D;
                boolean isGrappleMoving = isLargeTarget
                        ? isMoving
                        : (player instanceof LocalPlayer lp && (lp.input.left || lp.input.right));
                if (isGrappleMoving && stances.getOnGrappleMove(player, false) != null) {
                    tpPoseName = stances.getOnGrappleMove(player, false);
                    fpPoseName = stances.getOnGrappleMove(player, true);
                } else if (stances.getOnGrappleHold(player, false) != null) {
                    tpPoseName = stances.getOnGrappleHold(player, false);
                    fpPoseName = stances.getOnGrappleHold(player, true);
                } else {
                    tpPoseName = stances.getOnIdle(player, false);
                    fpPoseName = stances.getOnIdle(player, true);
                }
            } else if (isVaulting) {
                tpPoseName = stances.getOnVault(player, false);
                fpPoseName = stances.getOnVault(player, true);
            } else if (isDodging) {
                boolean isInAir = !player.onGround();
                String dashTp = isInAir ? stances.getOnAirDash(player, false) : stances.getOnDash(player, false);
                if (dashTp == null && isInAir) {
                    dashTp = stances.getOnDash(player, false);
                }
                tpPoseName = Animator.isRegisteredAnimation(dashTp)
                        ? dashTp
                        : Animator.resolveDashAnimation(player);

                String dashFp = isInAir ? stances.getOnAirDash(player, true) : stances.getOnDash(player, true);
                if (dashFp == null && isInAir) {
                    dashFp = stances.getOnDash(player, true);
                }
                if (Animator.isRegisteredAnimation(dashFp)) {
                    fpPoseName = dashFp;
                } else {
                    String idleFp = stances.getOnIdle(player, true);
                    fpPoseName = idleFp != null ? idleFp : Animator.resolveDashAnimation(player);
                }
            } else if (isUsingItem) {
                tpPoseName = stances.getOnItemUse(player, false) != null ? stances.getOnItemUse(player, false) : "idle";
                fpPoseName = stances.getOnItemUse(player, true) != null
                        ? stances.getOnItemUse(player, true)
                        : stances.getOnIdle(player, true);
            } else if (isCrouching) {
                if (state != null && state.isLeaningLeft) {
                    tpPoseName = "hns_lean_left";
                } else if (state != null && state.isLeaningRight) {
                    tpPoseName = "hns_lean_right";
                } else {
                    String sneakAnim = stances.getOnSneak(player, false);
                    if (sneakAnim != null) {
                        tpPoseName = sneakAnim;
                    } else if (isMoving) {
                        tpPoseName = stances.getOnWalk(player, false);
                    } else {
                        tpPoseName = stances.getOnIdle(player, false);
                    }
                }
                fpPoseName = stances.getOnIdle(player, true);
            } else if (isSprinting) {
                tpPoseName = stances.getOnSprint(player, false);
                fpPoseName = stances.getOnSprint(player, true);
            } else if (isMoving) {
                tpPoseName = stances.getOnWalk(player, false);
                fpPoseName = stances.getOnWalk(player, true);
            } else {
                tpPoseName = stances.getOnIdle(player, false);
                fpPoseName = stances.getOnIdle(player, true);
            }
        } else if (isUsingItem) {
            tpPoseName = "idle";
            fpPoseName = "idle";
        } else if (isCrouching) {
            if (state != null && state.isLeaningLeft) {
                tpPoseName = "hns_lean_left";
            } else if (state != null && state.isLeaningRight) {
                tpPoseName = "hns_lean_right";
            } else {
                tpPoseName = "idle";
            }
            fpPoseName = "idle";
        } else if ((ItemHelper.isMeleeWeapon(mainHand) || ItemHelper.isRangedWeapon(mainHand))
                && ItemHelper.getHandedness(mainHand).equals(WeaponHandedness.TWO_HANDED)) {
            tpPoseName = "hns_greatsword_idle";
            fpPoseName = "hns_greatsword_idle";
        }

        if (isCrouching && attackController != null && attackController.isActive()) {
            tpPoseName = "idle";
            fpPoseName = "idle";
        } else if (isCrouching && isDefending) {
            tpPoseName = "idle";
            fpPoseName = "idle";
        } else if (isDefending) {
            fpPoseName = "idle";
        }

        if (tpPoseName == null) {
            tpPoseName = "idle";
        }

        ResourceLocation tpPoseLoc = tpPoseName.contains(":")
                ? ResourceLocation.parse(tpPoseName)
                : ResourceLocation.fromNamespaceAndPath("hackersandslashers", tpPoseName);
        ResourceLocation fpPoseLoc = fpPoseName == null
                ? null
                : (fpPoseName.contains(":")
                        ? ResourceLocation.parse(fpPoseName)
                        : ResourceLocation.fromNamespaceAndPath("hackersandslashers", fpPoseName));

        int fadeDuration = 5;
        AbstractFadeModifier fade = AbstractFadeModifier.standardFadeIn(fadeDuration, EasingType.EASE_IN_OUT_QUAD);
        boolean isPoseIdle = tpPoseName.equals("idle");
        poseController.combatModifier.enabled = !isPoseIdle;
        poseController.aimModifier.enabled = isUsingItem && !isPoseIdle;
        poseController.speedModifier.setDynamicSpeed(1.0F);

        boolean itemChanged = !ItemStack.isSameItem(poseController.lastMainHandItem, mainHand);
        if (itemChanged || !tpPoseLoc.equals(poseController.currentPoseAnim)) {
            poseController.lastMainHandItem = mainHand.copy();
            poseController.currentPoseAnim = tpPoseLoc;
            poseController.replaceAnimationWithFade(fade, tpPoseLoc);
        }

        if (stats != null && stats.handling != null) {
            fpPoseController.cameraModifier.handlingData = stats.handling;
        } else {
            fpPoseController.cameraModifier.handlingData = new WeaponStatOverride.WeaponHandlingData();
        }

        boolean isFirstPersonCamera = Minecraft.getInstance().options.getCameraType().isFirstPerson();
        boolean isLocalPlayer = player == Minecraft.getInstance().player;
        boolean shouldPlayFirstPersonPose = isFirstPersonCamera
                && isLocalPlayer
                && fpPoseLoc != null
                && !fpPoseName.equals("idle")
                && PunchyClientBridge.shouldAllowFirstPersonPose(player, stances, isGrappling, isVaulting, isDodging);

        if (shouldPlayFirstPersonPose) {
            fpPoseController.setFirstPersonMode(FirstPersonMode.THIRD_PERSON_MODEL);
            fpPoseController.speedModifier.setDynamicSpeed(1.0F);
            if (itemChanged || !fpPoseLoc.equals(fpPoseController.currentPoseAnim)) {
                AbstractFadeModifier fpFade = fpPoseController.currentPoseAnim == null
                        ? AbstractFadeModifier.standardFadeIn(0, EasingType.LINEAR)
                        : fade;
                fpPoseController.lastMainHandItem = mainHand.copy();
                fpPoseController.currentPoseAnim = fpPoseLoc;
                fpPoseController.replaceAnimationWithFade(fpFade, fpPoseLoc);
            }
        } else if (fpPoseController.currentPoseAnim != null) {
            fpPoseController.currentPoseAnim = null;
            fpPoseController.setFirstPersonMode(FirstPersonMode.NONE);
            fpPoseController.stop();
        }

        PunchyClientBridge.onFirstPersonTickEnd(player, shouldPlayFirstPersonPose);
    }

    private static void sanitizeOrphanedLayers(AbstractClientPlayer player) {
        IAnimation actionAnim = PlayerAnimationAccess.getPlayerAnimationLayer(player, PlayerAnimator.ACTION_LAYER);
        if (actionAnim instanceof HnSPlayerActionController actionController && actionController.isActive()) {
            if (actionController.currentAnim == null) {
                if (actionController.fadeOutTicks > 0) {
                    actionController.fadeOutTicks--;
                } else {
                    actionController.setFirstPersonConfiguration(new FirstPersonConfiguration().setShowArmor(false));
                    actionController.setFirstPersonMode(FirstPersonMode.NONE);
                    actionController.stop();
                }
            } else if (actionController.currentAnim.getPath().contains("charge") && !CombatHelper.isChargingAttack(player)) {
                Animator.cancelAnimation(player, PlayerAnimator.ACTION_LAYER);
            }
        }

        IAnimation defenseAnim = PlayerAnimationAccess.getPlayerAnimationLayer(player, PlayerAnimator.DEFENSE_LAYER);
        if (defenseAnim instanceof HnSPlayerDefenseController defenseController
                && defenseController.isActive()
                && defenseController.currentAnim == null) {
            if (defenseController.fadeOutTicks > 0) {
                defenseController.fadeOutTicks--;
            } else {
                defenseController.setFirstPersonConfiguration(new FirstPersonConfiguration().setShowArmor(false));
                defenseController.setFirstPersonMode(FirstPersonMode.NONE);
                defenseController.stop();
            }
        }

        IAnimation attackAnim = PlayerAnimationAccess.getPlayerAnimationLayer(player, PlayerAnimator.ATTACK_LAYER);
        if (attackAnim instanceof HnSPlayerAttackController attackController
                && player == Minecraft.getInstance().player) {
            ClientCombatState state = ComboManager.getState(player);
            boolean attackStateIdle = state.currentMoveId == null && state.attackSlowdownTicks <= 0;
            if (attackController.isActive() && attackController.currentAnim == null && attackStateIdle) {
                if (attackController.fadeOutTicks > 0) {
                    attackController.fadeOutTicks--;
                } else {
                    attackController.setFirstPersonConfiguration(new FirstPersonConfiguration().setShowArmor(false));
                    attackController.setFirstPersonMode(FirstPersonMode.NONE);
                    attackController.stop();
                }
            }
        }

        IAnimation parkourAnim = PlayerAnimationAccess.getPlayerAnimationLayer(player, PlayerAnimator.PARKOUR_LAYER);
        if (parkourAnim instanceof HnSPlayerParkourController parkourController
                && parkourController.isActive()
                && parkourController.currentAnim == null) {
            if (parkourController.fadeOutTicks > 0) {
                parkourController.fadeOutTicks--;
            } else {
                parkourController.setFirstPersonConfiguration(new FirstPersonConfiguration().setShowArmor(false));
                parkourController.setFirstPersonMode(FirstPersonMode.NONE);
                parkourController.stop();
            }
        }
    }
}
