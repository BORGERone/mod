package net.dndats.api.animations;

import com.zigythebird.playeranimcore.animation.AnimationController;
import com.zigythebird.playeranimcore.animation.layered.modifier.AbstractModifier;
import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonMode;
import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
import net.dndats.hackersandslashers.client.utils.InventoryRenderFlag;
import net.dndats.hackersandslashers.client.utils.ShaderHelper;
import net.dndats.hackersandslashers.datapacks.enums.WeaponHandedness;
import net.dndats.hackersandslashers.utils.helper.ItemHelper;
import net.dndats.hackersandslashers.utils.helper.PlayerHelper;
import net.minecraft.client.CameraType;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShieldItem;

public class OffhandShieldPoseModifier extends AbstractModifier {
    private static final float DEG_TO_RAD = (float) (Math.PI / 180.0);

    // Lowered idle stance: bottom-left screen placement, forward-left facing
    private static final float IDLE_ARM_ROT_X = -38.0F * DEG_TO_RAD;
    private static final float IDLE_ARM_ROT_Y = 12.0F * DEG_TO_RAD;
    private static final float IDLE_ARM_ROT_Z = -4.0F * DEG_TO_RAD;
    private static final float IDLE_ARM_POS_X = 3.8F;
    private static final float IDLE_ARM_POS_Y = -4.6F;
    private static final float IDLE_ARM_POS_Z = -3.5F;

    // Raised blocking stance: upright front-left defensive guard, clear of crosshair
    private static final float BLOCK_ARM_ROT_X = -45.0F * DEG_TO_RAD;
    private static final float BLOCK_ARM_ROT_Y = 24.0F * DEG_TO_RAD;
    private static final float BLOCK_ARM_ROT_Z = 0.0F;
    private static final float BLOCK_ARM_POS_X = 4.2F;
    private static final float BLOCK_ARM_POS_Y = 1.8F;
    private static final float BLOCK_ARM_POS_Z = -3.1F;

    // Aligns vanilla shield.json ([0, 90, 0], [10, 6, 12]) to shield_blocking.json ([45, 135, 0], [13.51, 3, 5])
    // so there is zero orientation pop when Minecraft swaps shield <-> shield_blocking models.
    private static final float IDLE_ITEM_ROT_X = -54.73561032F * DEG_TO_RAD;
    private static final float IDLE_ITEM_ROT_Y = 35.26438968F * DEG_TO_RAD;
    private static final float IDLE_ITEM_ROT_Z = 30.0F * DEG_TO_RAD;
    private static final float IDLE_ITEM_POS_X = -2.04628F;
    private static final float IDLE_ITEM_POS_Y = -0.24264F;
    private static final float IDLE_ITEM_POS_Z = 0.24264F;

    private static final float CROUCH_DROP_OFFSET = -2.0F;
    private static final float BLOCK_RAISE_SPEED = 0.78F;
    private static final float BLOCK_LOWER_SPEED = 0.56F;
    private static final float CROUCH_SMOOTH_SPEED = 0.65F;

    private static float smoothBlockBlend = 0.0F;
    private static float smoothCrouchOffset = 0.0F;
    private static long lastFrameStamp = Long.MIN_VALUE;
    private static long lastStepNanos = 0L;
    private static int lastPlayerId = Integer.MIN_VALUE;

    private final AbstractClientPlayer player;

    public OffhandShieldPoseModifier(AbstractClientPlayer player) {
        this.player = player;
    }

    private static boolean isShieldLike(ItemStack stack) {
        return stack != null && !stack.isEmpty() && (stack.getItem() instanceof ShieldItem || ItemHelper.isShield(stack));
    }

    private static float safeFinite(float v) {
        return Float.isNaN(v) || Float.isInfinite(v) ? 0.0F : v;
    }

    private static void updateSmoothedState(Player p, boolean blocking, float partialTick) {
        float targetBlock = blocking ? 1.0F : 0.0F;
        float targetCrouch = p.isCrouching() ? CROUCH_DROP_OFFSET : 0.0F;
        int playerId = p.getId();
        long nowNs = System.nanoTime();
        long frameStamp = (((long) p.tickCount) << 32) ^ (((long) Float.floatToRawIntBits(partialTick)) & 0xFFFFFFFFL);

        if (lastPlayerId != playerId || lastStepNanos == 0L || (nowNs - lastStepNanos) > 2_000_000_000L) {
            lastPlayerId = playerId;
            lastFrameStamp = frameStamp;
            lastStepNanos = nowNs;
            smoothBlockBlend = targetBlock;
            smoothCrouchOffset = targetCrouch;
            return;
        }

        if (frameStamp == lastFrameStamp) {
            return;
        }
        lastFrameStamp = frameStamp;

        float dtTicks = nowNs > lastStepNanos ? Mth.clamp((float) (nowNs - lastStepNanos) / 50_000_000.0F, 0.0F, 1.5F) : 0.0F;
        lastStepNanos = nowNs;

        float blockSpeed = targetBlock > smoothBlockBlend ? BLOCK_RAISE_SPEED : BLOCK_LOWER_SPEED;
        float blockAlpha = 1.0F - (float) Math.exp((double) (-dtTicks * blockSpeed));
        smoothBlockBlend = Mth.lerp(blockAlpha, smoothBlockBlend, targetBlock);
        if (Math.abs(smoothBlockBlend - targetBlock) < 0.001F) {
            smoothBlockBlend = targetBlock;
        }

        float crouchAlpha = 1.0F - (float) Math.exp((double) (-dtTicks * CROUCH_SMOOTH_SPEED));
        smoothCrouchOffset = Mth.lerp(crouchAlpha, smoothCrouchOffset, targetCrouch);
        if (Math.abs(smoothCrouchOffset - targetCrouch) < 0.001F) {
            smoothCrouchOffset = targetCrouch;
        }
    }

    private static void applyShieldArmPose(PlayerAnimBone bone, Player p, float partialTick, boolean isLeftHand) {
        float eased = smoothBlockBlend * smoothBlockBlend * (3.0F - 2.0F * smoothBlockBlend);
        float swayScale = 1.0F - 0.65F * eased;

        float swayPitch = Mth.clamp(safeFinite(FirstPersonCameraModifier.currentVelocityPitch) * 0.18F, -0.045F, 0.045F) * swayScale;
        float swayYaw = Mth.clamp(safeFinite(FirstPersonCameraModifier.currentVelocityYaw) * 0.18F, -0.045F, 0.045F) * swayScale;
        float strafeRoll = Mth.clamp(safeFinite(FirstPersonCameraModifier.currentStrafe) * 0.03F, -0.035F, 0.035F) * swayScale;
        float idleBobY = (1.0F - eased) * 0.10F * Mth.sin(((float) p.tickCount + partialTick) * 0.11F);

        float rotX = Mth.lerp(eased, IDLE_ARM_ROT_X, BLOCK_ARM_ROT_X) + swayPitch;
        float rotY = Mth.lerp(eased, IDLE_ARM_ROT_Y, BLOCK_ARM_ROT_Y) + swayYaw;
        float rotZ = Mth.lerp(eased, IDLE_ARM_ROT_Z, BLOCK_ARM_ROT_Z) + strafeRoll;

        float posX = Mth.lerp(eased, IDLE_ARM_POS_X, BLOCK_ARM_POS_X);
        float posY = Mth.lerp(eased, IDLE_ARM_POS_Y, BLOCK_ARM_POS_Y) + smoothCrouchOffset + idleBobY;
        float posZ = Mth.lerp(eased, IDLE_ARM_POS_Z, BLOCK_ARM_POS_Z);

        if (!isLeftHand) {
            rotY = -rotY;
            rotZ = -rotZ;
            posX = -posX;
        }

        bone.setRotX(rotX);
        bone.setRotY(rotY);
        bone.setRotZ(rotZ);
        bone.setPosX(posX);
        bone.setPosY(posY);
        bone.setPosZ(posZ);
        bone.setScaleX(1.0F);
        bone.setScaleY(1.0F);
        bone.setScaleZ(1.0F);
    }

    private static void applyShieldItemPose(PlayerAnimBone bone, boolean blocking, boolean isLeftHand) {
        if (blocking) {
            bone.setRotX(0.0F);
            bone.setRotY(0.0F);
            bone.setRotZ(0.0F);
            bone.setPosX(0.0F);
            bone.setPosY(0.0F);
            bone.setPosZ(0.0F);
        } else {
            float rotY = isLeftHand ? IDLE_ITEM_ROT_Y : -IDLE_ITEM_ROT_Y;
            float rotZ = isLeftHand ? IDLE_ITEM_ROT_Z : -IDLE_ITEM_ROT_Z;
            float posX = isLeftHand ? IDLE_ITEM_POS_X : -IDLE_ITEM_POS_X;

            bone.setRotX(IDLE_ITEM_ROT_X);
            bone.setRotY(rotY);
            bone.setRotZ(rotZ);
            bone.setPosX(posX);
            bone.setPosY(IDLE_ITEM_POS_Y);
            bone.setPosZ(IDLE_ITEM_POS_Z);
        }
        bone.setScaleX(1.0F);
        bone.setScaleY(1.0F);
        bone.setScaleZ(1.0F);
    }

    @Override
    public PlayerAnimBone get3DTransform(PlayerAnimBone bone) {
        bone = super.get3DTransform(bone);
        if (bone == null || this.player == null) {
            return bone;
        }
        if (!FirstPersonMode.isFirstPersonPass()) {
            return bone;
        }
        if (InventoryRenderFlag.isRenderingInventory || ShaderHelper.isShadowPass()) {
            return bone;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.options == null) {
            return bone;
        }
        CameraType cameraType = mc.options.getCameraType();
        if (cameraType == null || !cameraType.isFirstPerson()) {
            return bone;
        }
        if (this.player != mc.player || mc.getCameraEntity() != this.player) {
            return bone;
        }

        Player p = this.player;
        ItemStack offhand = p.getOffhandItem();
        if (!isShieldLike(offhand)) {
            return bone;
        }

        boolean isLeftHand = p.getMainArm() == HumanoidArm.RIGHT;
        String boneName = bone.getName();
        boolean isArm = isLeftHand ? "left_arm".equals(boneName) : "right_arm".equals(boneName);
        boolean isItem = isLeftHand ? "left_item".equals(boneName) : "right_item".equals(boneName);
        if (!isArm && !isItem) {
            return bone;
        }

        if (PlayerHelper.isGrappling(p)) {
            return bone;
        }

        ItemStack mainhand = p.getMainHandItem();
        ItemStack useItem = p.getUseItem();
        boolean isUsing = p.isUsingItem() && useItem != null && !useItem.isEmpty();
        boolean usingMainhand = isUsing && useItem == mainhand;
        if (usingMainhand) {
            return bone;
        }

        boolean usingOffhandShield = isUsing && (useItem == offhand || isShieldLike(useItem));
        boolean blocking = usingOffhandShield || (!isUsing && p.isBlocking());

        if (!blocking) {
            if (ItemHelper.getHandedness(mainhand) == WeaponHandedness.TWO_HANDED) {
                return bone;
            }
            AnimationController ctrl = getController();
            if (ctrl instanceof HnSPlayerActionController actionCtrl) {
                ResourceLocation anim = actionCtrl.currentAnim;
                if (anim != null && anim.getPath().contains("bash")) {
                    if (isArm) {
                        return bone;
                    }
                } else {
                    return bone;
                }
            } else if (ctrl instanceof HnSPlayerAttackController attackCtrl) {
                ResourceLocation anim = attackCtrl.currentAnim;
                if (anim != null && anim.getPath().contains("bash") && isArm) {
                    return bone;
                }
            }
        }

        DeltaTracker timer = mc.getTimer();
        float partialTick = timer != null ? timer.getGameTimeDeltaPartialTick(true) : 0.0F;
        updateSmoothedState(p, blocking, partialTick);

        if (isArm) {
            applyShieldArmPose(bone, p, partialTick, isLeftHand);
        } else {
            applyShieldItemPose(bone, blocking, isLeftHand);
        }
        return bone;
    }
}
