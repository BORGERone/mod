package net.dndats.api.animations.modifiers;

import com.zigythebird.playeranimcore.animation.AnimationData;
import com.zigythebird.playeranimcore.animation.layered.modifier.AbstractModifier;
import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
import net.dndats.hackersandslashers.config.ClientConfig;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.ClientCombatState;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.ComboManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;

public class CameraHeightSyncModifier extends AbstractModifier {
    private final AbstractClientPlayer player;
    private float bodyOffset = 0.0F;
    private float torsoOffset = 0.0F;

    public CameraHeightSyncModifier(AbstractClientPlayer player) {
        this.player = player;
    }

    @Override
    public void setupAnim(AnimationData state) {
        super.setupAnim(state);
        this.bodyOffset = 0.0F;
        this.torsoOffset = 0.0F;
    }

    @Override
    public PlayerAnimBone get3DTransform(PlayerAnimBone bone) {
        super.get3DTransform(bone);
        String name = bone.getName();
        if (name.equals("body")) {
            ClientCombatState state = ComboManager.getState(this.player);
            if (ClientConfig.isFirstPersonAnimationsDisabled() && this.player == Minecraft.getInstance().player) {
                if (state != null) {
                    state.currentCameraYOffset = 0.0F;
                    state.currentCameraZOffset = 0.0F;
                }
                return bone;
            }
            float posY = bone.getPosY();
            if (Minecraft.getInstance().options.getCameraType().isFirstPerson() && state != null) {
                posY -= state.fpCameraYOffset;
            }
            float y = posY / 16.0F;
            float z = -bone.getPosZ() / 16.0F;
            float rotX = bone.getRotX();
            float pivotScale = 0.75F;
            float rotYOff = (float) (Math.cos(rotX) - 1.0) * pivotScale;
            float rotZOff = (float) Math.sin(rotX) * pivotScale;
            if (state != null) {
                if (state.currentRootMotionAnim != null) {
                    state.currentCameraYOffset = 0.0F;
                    state.currentCameraZOffset = 0.0F;
                } else {
                    float rawY = (y + rotYOff) * 0.35F;
                    float rawZ = (z + rotZOff) * 0.65F;
                    state.currentCameraYOffset = Mth.clamp(rawY, -0.2F, 0.2F);
                    state.currentCameraZOffset = Mth.clamp(rawZ, -0.25F, 0.45F);
                    state.lastCameraOffsetUpdateTick = this.player.tickCount;
                }
            }
        }
        return bone;
    }
}
