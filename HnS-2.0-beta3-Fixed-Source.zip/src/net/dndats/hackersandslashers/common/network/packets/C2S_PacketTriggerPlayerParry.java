package net.dndats.hackersandslashers.common.network.packets;

import java.util.Objects;
import net.dndats.api.assets.SoundEffects;
import net.dndats.hackersandslashers.common.data.IsParryingData;
import net.dndats.hackersandslashers.common.setup.ModDataAttachments;
import net.dndats.hackersandslashers.handlers.MallardGuardCompatHandler;
import net.dndats.hackersandslashers.utils.TickScheduler;
import net.dndats.hackersandslashers.utils.helper.PlayerHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import org.jetbrains.annotations.NotNull;

public record C2S_PacketTriggerPlayerParry(IsParryingData data, int duration) implements CustomPacketPayload {
    public static final Type<C2S_PacketTriggerPlayerParry> TYPE = new Type<>(
        ResourceLocation.fromNamespaceAndPath("hackersandslashers", "player_trigger_parry_sync")
    );
    public static final StreamCodec<RegistryFriendlyByteBuf, C2S_PacketTriggerPlayerParry> STREAM_CODEC = StreamCodec.of((buffer, packet) -> {
        buffer.writeNbt(packet.data().serializeNBT(buffer.registryAccess()));
        buffer.writeInt(packet.duration());
    }, buffer -> {
        IsParryingData data = new IsParryingData();
        data.deserializeNBT(buffer.registryAccess(), Objects.requireNonNull(buffer.readNbt()));
        int duration = buffer.readInt();
        return new C2S_PacketTriggerPlayerParry(data, duration);
    });

    public static void handleData(C2S_PacketTriggerPlayerParry message, IPayloadContext context) {
        if (context.flow().isServerbound() && message.data() != null) {
            context.enqueueWork(() -> {
                Player player = context.player();
                if (message.data.getIsParrying() && (MallardGuardCompatHandler.isParryDisabledByShield(player) || MallardGuardCompatHandler.isParryReplacedByMallardGuard())) {
                    PlayerHelper.removeSpeedModifier(player);
                    IsParryingData currentData = player.getData(ModDataAttachments.IS_PARRYING);
                    currentData.setIsParrying(false);
                    currentData.setParryWindow(false);
                    currentData.syncData(player);
                    return;
                }
                player.getData(ModDataAttachments.IS_PARRYING)
                    .deserializeNBT(player.registryAccess(), message.data().serializeNBT(player.registryAccess()));
                player.setData(ModDataAttachments.IS_PARRYING, message.data());
                if (message.data.getIsParrying()) {
                    long now = player.level().getGameTime();
                    player.getData(ModDataAttachments.IS_PARRYING).setGuardHardCapEnd((int) (now + 200L));
                    SoundEffects.playParrySwingSound(player);
                    PlayerHelper.addSpeedModifier(player, player.getMainHandItem());
                    int startupFrames = 1;
                    TickScheduler.schedule(() -> {
                        IsParryingData currentData = player.getData(ModDataAttachments.IS_PARRYING);
                        if (currentData.getIsParrying()) {
                            currentData.setParryWindow(true);
                            currentData.syncData(player);
                            TickScheduler.schedule(() -> {
                                if (currentData.isParryWindow()) {
                                    currentData.setParryWindow(false);
                                    currentData.syncData(player);
                                }
                            }, message.duration());
                        }
                    }, startupFrames);
                } else {
                    PlayerHelper.removeSpeedModifier(player);
                    Objects.requireNonNull(player.setData(ModDataAttachments.IS_PARRYING, message.data())).setIsParrying(false);
                    player.getData(ModDataAttachments.IS_PARRYING).setParryWindow(false);
                    player.getData(ModDataAttachments.IS_PARRYING).syncData(player);
                }
            }).exceptionally(e -> {
                context.connection().disconnect(Component.literal(e.getMessage()));
                return null;
            });
        }
        if (context.flow().isClientbound() && message.data() != null) {
            context.enqueueWork(() -> handleClientData(message)).exceptionally(e -> {
                context.connection().disconnect(Component.literal(e.getMessage()));
                return null;
            });
        }
    }

    @OnlyIn(Dist.CLIENT)
    private static void handleClientData(C2S_PacketTriggerPlayerParry message) {
        Player player = Minecraft.getInstance().player;
        if (player != null) {
            IsParryingData parryingData = player.getData(ModDataAttachments.IS_PARRYING);
            parryingData.deserializeNBT(player.registryAccess(), message.data().serializeNBT(player.registryAccess()));
            player.setData(ModDataAttachments.IS_PARRYING, parryingData);
        }
    }

    @Override
    @NotNull
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
