package net.dndats.hackersandslashers.common.setup;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;

public class ModKeybinds {
    public static final KeyMapping PARRY = new KeyMapping(
            "key.hackersandslashers.parry",
            InputConstants.Type.MOUSE,
            1,
            "key.categories.hackersandslashers");

    public static final KeyMapping ULTIMATE = new KeyMapping(
            "key.hackersandslashers.ultimate",
            InputConstants.Type.KEYSYM,
            82,
            "key.categories.hackersandslashers");

    public static final KeyMapping DASH = new KeyMapping(
            "key.hackersandslashers.dash",
            InputConstants.Type.KEYSYM,
            88,
            "key.categories.hackersandslashers");
}
