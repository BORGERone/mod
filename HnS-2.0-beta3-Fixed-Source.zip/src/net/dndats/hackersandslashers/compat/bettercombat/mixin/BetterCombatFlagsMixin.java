package net.dndats.hackersandslashers.compat.bettercombat.mixin;

import net.bettercombat.api.CombatFlags;
import net.dndats.hackersandslashers.utils.helper.ItemHelper;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = CombatFlags.class, remap = false)
public class BetterCombatFlagsMixin {
    @Inject(method = {"isAttackDisabled(Lnet/minecraft/world/entity/player/Player;)Z"}, at = {@At("HEAD")}, cancellable = true, remap = false)
    private static void hns$disableBetterCombatForHnsWeapons(Player player, CallbackInfoReturnable<Boolean> cir) {
        if (player != null && ItemHelper.isHoldingCombatItem(player)) {
            cir.setReturnValue(Boolean.TRUE);
        }
    }
}
