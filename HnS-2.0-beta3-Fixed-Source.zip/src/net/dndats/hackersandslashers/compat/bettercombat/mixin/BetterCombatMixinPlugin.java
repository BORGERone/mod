package net.dndats.hackersandslashers.compat.bettercombat.mixin;

import java.util.List;
import java.util.Set;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

public class BetterCombatMixinPlugin implements IMixinConfigPlugin {
    private boolean hasBetterCombat;

    @Override
    public void onLoad(String mixinPackage) {
        this.hasBetterCombat = BetterCombatMixinPlugin.class.getClassLoader().getResource("net/bettercombat/api/CombatFlags.class") != null;
    }

    @Override public String getRefMapperConfig() { return null; }
    @Override public boolean shouldApplyMixin(String targetClassName, String mixinClassName) { return this.hasBetterCombat; }
    @Override public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {}
    @Override public List<String> getMixins() { return null; }
    @Override public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
    @Override public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
}
