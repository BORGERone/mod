package net.dndats.hackersandslashers.compat.bettercombat.mixin;

import net.bettercombat.api.AttackHand;
import net.bettercombat.logic.PlayerAttackHelper;
import net.bettercombat.logic.Pose;
import net.dndats.hackersandslashers.utils.helper.ItemHelper;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = PlayerAttackHelper.class, remap = false)
public class BetterCombatPlayerAttackHelperMixin {
    @Inject(method = {"poseForPlayer(Lnet/minecraft/world/entity/player/Player;)Lnet/bettercombat/logic/Pose;"}, at = {@At("HEAD")}, cancellable = true, remap = false)
    private static void hns$suppressBetterCombatPose(Player player, CallbackInfoReturnable<Pose> cir) {
        if (player != null && ItemHelper.isHoldingCombatItem(player)) {
            cir.setReturnValue(new Pose("", ""));
        }
    }

    @Inject(method = {"isDualWielding(Lnet/minecraft/world/entity/player/Player;)Z"}, at = {@At("HEAD")}, cancellable = true, remap = false)
    private static void hns$suppressDualWielding(Player player, CallbackInfoReturnable<Boolean> cir) {
        if (player != null && ItemHelper.isHoldingCombatItem(player)) {
            cir.setReturnValue(Boolean.FALSE);
        }
    }

    @Inject(method = {"isTwoHandedWielding(Lnet/minecraft/world/entity/player/Player;)Z"}, at = {@At("HEAD")}, cancellable = true, remap = false)
    private static void hns$suppressTwoHandedWielding(Player player, CallbackInfoReturnable<Boolean> cir) {
        if (player != null && ItemHelper.isHoldingCombatItem(player)) {
            cir.setReturnValue(Boolean.FALSE);
        }
    }

    @Inject(method = {"shouldAttackWithOffHand(Lnet/minecraft/world/entity/player/Player;I)Z"}, at = {@At("HEAD")}, cancellable = true, remap = false)
    private static void hns$suppressOffhandAttack(Player player, int comboCount, CallbackInfoReturnable<Boolean> cir) {
        if (player != null && ItemHelper.isHoldingCombatItem(player)) {
            cir.setReturnValue(Boolean.FALSE);
        }
    }

    @Inject(method = {"getCurrentAttack(Lnet/minecraft/world/entity/player/Player;I)Lnet/bettercombat/api/AttackHand;"}, at = {@At("HEAD")}, cancellable = true, remap = false)
    private static void hns$suppressCurrentAttack(Player player, int comboCount, CallbackInfoReturnable<AttackHand> cir) {
        if (player != null && ItemHelper.isHoldingCombatItem(player)) {
            cir.setReturnValue(null);
        }
    }

    @Inject(method = {"getRangeWithWeapon(Lnet/minecraft/world/entity/player/Player;D)D"}, at = {@At("HEAD")}, cancellable = true, remap = false)
    private static void hns$suppressBetterCombatRange(Player player, double baseRange, CallbackInfoReturnable<Double> cir) {
        if (player != null && ItemHelper.isHoldingCombatItem(player)) {
            cir.setReturnValue(baseRange);
        }
    }
}
