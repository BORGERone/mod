package net.dndats.hackersandslashers.compat.mallardguard;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.Map;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.fml.ModList;

public final class MallardGuardBridge {
    private static final String GUARD_STATE = "dev.zeli.mallardguard.GuardState";
    private static final String GUARD_CONFIG = "dev.zeli.mallardguard.GuardConfig";

    public static final int PHASE_IDLE = 0;
    public static final int PHASE_PERFECT = 1;
    public static final int PHASE_PARRY = 2;
    public static final int PHASE_BLOCK = 3;
    public static final int PHASE_SHIELD_BLOCK = 4;

    private static boolean initialized;
    private static boolean available;
    private static boolean vanillaShieldRuleApplied;
    private static boolean failureReported;

    private static Method guardingMethod;
    private static Method inputMethod;
    private static Field statesField;
    private static Field phaseField;

    private MallardGuardBridge() {}

    public static boolean isLoaded() {
        try {
            ModList list = ModList.get();
            return list != null && list.isLoaded("mallardguard");
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static synchronized boolean isAvailable() {
        if (!initialized) {
            initialized = true;
            if (isLoaded()) {
                try {
                    ClassLoader loader = MallardGuardBridge.class.getClassLoader();
                    Class<?> guardState = Class.forName(GUARD_STATE, false, loader);
                    guardingMethod = guardState.getMethod("guarding", Player.class);
                    inputMethod = guardState.getMethod("input", ServerPlayer.class, boolean.class, boolean.class);
                    statesField = guardState.getDeclaredField("STATES");
                    statesField.setAccessible(true);
                    phaseField = guardState.getDeclaredField("phase");
                    phaseField.setAccessible(true);
                    available = true;
                } catch (Throwable failure) {
                    available = false;
                    report(failure);
                }
            }
        }
        return available;
    }

    public static boolean isGuarding(Player player) {
        if (player == null || !isAvailable()) return false;
        try {
            Object result = guardingMethod.invoke(null, player);
            return result instanceof Boolean && (Boolean) result;
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static int guardPhase(Player player) {
        if (player == null || !isAvailable()) return PHASE_IDLE;
        try {
            Object states = statesField.get(null);
            if (states instanceof Map<?, ?> map) {
                Object state = map.get(player.getUUID());
                if (state != null) return phaseField.getInt(state);
            }
        } catch (Throwable ignored) {}
        return PHASE_IDLE;
    }

    public static void releaseGuard(ServerPlayer player) {
        if (player == null || !isAvailable()) return;
        try { inputMethod.invoke(null, player, Boolean.FALSE, Boolean.FALSE); } catch (Throwable ignored) {}
    }

    public static void clearClientGuard(Player player) {
        if (player == null || !isAvailable()) return;
        try {
            Object states = statesField.get(null);
            if (states instanceof Map<?, ?> map) {
                Object state = map.remove(player.getUUID());
                if (state != null && phaseField != null) {
                    phaseField.setInt(state, PHASE_IDLE);
                }
            }
        } catch (Throwable ignored) {}
    }

    public static synchronized boolean applyVanillaShieldRule() {
        if (vanillaShieldRuleApplied) return true;
        if (!isAvailable()) return false;
        try {
            ClassLoader loader = MallardGuardBridge.class.getClassLoader();
            Class<?> config = Class.forName(GUARD_CONFIG, false, loader);
            Field blacklistField = config.getField("SHIELD_BLACKLIST");
            Object value = blacklistField.get(null);
            if (value == null) return false;
            Method get = value.getClass().getMethod("get");
            Method set = value.getClass().getMethod("set", Object.class);
            Object raw = get.invoke(value);
            String current = raw == null ? "" : raw.toString().trim();
            String normalized = current.toLowerCase(Locale.ROOT);
            StringBuilder builder = new StringBuilder(current);
            boolean changed = false;
            if (!containsRule(normalized, "minecraft:shield")) {
                appendRule(builder, "minecraft:shield");
                changed = true;
            }
            if (!containsRule(normalized, "#c:shields")) {
                appendRule(builder, "#c:shields");
                changed = true;
            }
            if (changed) {
                set.invoke(value, builder.toString());
            }
            boolean extraChanged = tryAdjustPriorityConfig(config);
            if (changed || extraChanged) {
                Object spec = config.getField("SERVER_SPEC").get(null);
                if (spec != null) spec.getClass().getMethod("save").invoke(spec);
            }
            vanillaShieldRuleApplied = true;
            return true;
        } catch (Throwable failure) {
            report(failure);
            return false;
        }
    }

    private static boolean tryAdjustPriorityConfig(Class<?> config) {
        boolean changed = false;
        try {
            for (Field f : config.getFields()) {
                String fname = f.getName().toUpperCase(Locale.ROOT);
                if (!fname.contains("PRIORITY") && !fname.contains("SHIELD") && !fname.contains("CROUCH") && !fname.contains("OFFHAND")) {
                    continue;
                }
                Object cfgVal = f.get(null);
                if (cfgVal == null) continue;
                Method getter;
                Method setter;
                try {
                    getter = cfgVal.getClass().getMethod("get");
                    setter = cfgVal.getClass().getMethod("set", Object.class);
                } catch (Throwable ignored) {
                    continue;
                }
                Object cur;
                try {
                    cur = getter.invoke(cfgVal);
                } catch (Throwable ignored) {
                    continue;
                }
                if (cur instanceof Enum<?> curEnum && fname.contains("PRIORITY")) {
                    Enum<?>[] constants = curEnum.getDeclaringClass().getEnumConstants();
                    if (constants != null) {
                        for (Enum<?> c : constants) {
                            String cn = c.name().toUpperCase(Locale.ROOT);
                            if (cn.equals("SHIELD") || cn.equals("OFFHAND") || cn.equals("OFF_HAND")
                                    || cn.equals("SHIELD_FIRST") || cn.equals("OFFHAND_FIRST")) {
                                if (c != curEnum) {
                                    setter.invoke(cfgVal, c);
                                    changed = true;
                                    System.out.println("[Hackers 'n Slashers] Mallard Guard config " + f.getName() + " -> " + c.name());
                                }
                                break;
                            }
                        }
                    }
                } else if (cur instanceof Boolean b && Boolean.TRUE.equals(b)
                        && (fname.contains("CROUCH") && fname.contains("SHIELD"))) {
                    setter.invoke(cfgVal, Boolean.FALSE);
                    changed = true;
                    System.out.println("[Hackers 'n Slashers] Mallard Guard config " + f.getName() + " -> false");
                }
            }
        } catch (Throwable ignored) {}
        return changed;
    }

    private static boolean containsRule(String normalizedRules, String rule) {
        for (String entry : normalizedRules.split(",")) {
            if (entry.trim().equals(rule)) return true;
        }
        return false;
    }

    private static void appendRule(StringBuilder builder, String rule) {
        String current = builder.toString().trim();
        if (!current.isEmpty() && !current.endsWith(",")) builder.append(',');
        builder.append(rule);
    }

    private static void report(Throwable failure) {
        if (failureReported) return;
        failureReported = true;
        System.out.println("[Hackers 'n Slashers] Mallard Guard bridge disabled: " + failure.getClass().getSimpleName() + ": " + failure.getMessage());
    }
}
