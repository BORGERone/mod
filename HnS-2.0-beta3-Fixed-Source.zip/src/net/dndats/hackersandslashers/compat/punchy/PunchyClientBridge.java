package net.dndats.hackersandslashers.compat.punchy;

import com.zigythebird.playeranim.accessors.IAnimatedPlayer;
import com.zigythebird.playeranim.animation.PlayerAnimManager;
import com.zigythebird.playeranim.animation.PlayerAnimationController;
import com.zigythebird.playeranim.api.PlayerAnimationAccess;
import com.zigythebird.playeranimcore.animation.layered.IAnimation;
import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonConfiguration;
import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonMode;
import com.zigythebird.playeranimcore.event.Event;
import java.lang.reflect.Method;
import java.util.function.Function;
import net.dndats.api.animations.HnSPlayerFirstPersonPoseController;
import net.dndats.api.animations.PlayerAnimator;
import net.dndats.hackersandslashers.client.utils.InventoryRenderFlag;
import net.dndats.hackersandslashers.client.utils.ShaderHelper;
import net.dndats.hackersandslashers.common.setup.ModKeybinds;
import net.dndats.hackersandslashers.compat.mallardguard.MallardGuardBridge;
import net.dndats.hackersandslashers.config.ServerConfig;
import net.dndats.hackersandslashers.handlers.MallardGuardCompatHandler;
import net.dndats.hackersandslashers.utils.helper.ItemHelper;
import net.dndats.hackersandslashers.utils.helper.PlayerHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.HitResult;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.fml.ModList;

@OnlyIn(Dist.CLIENT)
public final class PunchyClientBridge {
    private static boolean emfCompatRegistered;

    private static volatile ResourceLocation[] hnsLayers;

    private static ResourceLocation[] getHnsLayers() {
        ResourceLocation[] cached = hnsLayers;
        if (cached == null) {
            cached = new ResourceLocation[] {
                PlayerAnimator.FIRST_PERSON_POSE_LAYER,
                PlayerAnimator.ATTACK_LAYER,
                PlayerAnimator.DEFENSE_LAYER,
                PlayerAnimator.ACTION_LAYER,
                PlayerAnimator.POSE_ACTION_LAYER,
                PlayerAnimator.PARKOUR_LAYER,
                PlayerAnimator.POSE_LAYER
            };
            hnsLayers = cached;
        }
        return cached;
    }

    private PunchyClientBridge() {}

    public static void applySyncedFirstPersonConfig(HnSPlayerFirstPersonPoseController ctrl, FirstPersonConfiguration cfg) {
        if (ctrl == null) return;
        if (cfg != null) {
            cfg.setShowRightItem(true);
            cfg.setShowLeftItem(true);
        }
        ctrl.setFirstPersonConfiguration(cfg);
    }

    public static void applySyncedFirstPersonConfig(PlayerAnimationController ctrl, FirstPersonConfiguration cfg) {
        if (ctrl == null) return;
        if (cfg != null) {
            cfg.setShowRightItem(true);
            cfg.setShowLeftItem(true);
        }
        ctrl.setFirstPersonConfiguration(cfg);
    }

    public static boolean isParryKeySharedWithUseKey() {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc == null || mc.options == null || mc.options.keyUse == null || ModKeybinds.PARRY == null) {
                return false;
            }
            return ModKeybinds.PARRY.same(mc.options.keyUse);
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static boolean isHnSFirstPersonActive(AbstractClientPlayer player) {
        if (player == null) return false;
        try {
            if (ShaderHelper.isShadowPass()) return false;
            for (ResourceLocation layerId : getHnsLayers()) {
                IAnimation anim = PlayerAnimationAccess.getPlayerAnimationLayer(player, layerId);
                if (anim != null && anim.isActive() && anim.getFirstPersonMode() == FirstPersonMode.THIRD_PERSON_MODEL) {
                    return true;
                }
            }
        } catch (Throwable ignored) {}
        return false;
    }

    public static boolean shouldSuppressPunchyArm(Player player, HumanoidArm arm) {
        if (player == null || arm == null) return false;
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc == null || mc.player != player) return false;
            if (!mc.options.getCameraType().isFirstPerson()) return false;
            if (mc.getCameraEntity() != player) return false;
            if (InventoryRenderFlag.isRenderingInventory) return false;
            if (ShaderHelper.isShadowPass()) return false;
            if (!(player instanceof IAnimatedPlayer animPlayer)) return false;
            PlayerAnimManager mgr = animPlayer.playerAnimLib$getAnimManager();
            if (mgr == null || !mgr.isActive()) return false;
            if (mgr.getFirstPersonMode() != FirstPersonMode.THIRD_PERSON_MODEL) return false;
            if (mgr.getFirstPersonTransitionProgress() < 1.0F) return false;
            if (!isHnSFirstPersonActive((AbstractClientPlayer) player)) return false;
            FirstPersonConfiguration cfg = mgr.getFirstPersonConfiguration();
            if (cfg == null) return false;
            return arm == HumanoidArm.RIGHT
                    ? (cfg.isShowRightArm() || cfg.isShowRightItem())
                    : (cfg.isShowLeftArm() || cfg.isShowLeftItem());
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static boolean shouldSuppressPunchyHand(Player player, InteractionHand hand) {
        if (player == null || hand == null) return false;
        HumanoidArm main = player.getMainArm();
        HumanoidArm arm = (hand == InteractionHand.MAIN_HAND)
                ? main
                : (main == HumanoidArm.RIGHT ? HumanoidArm.LEFT : HumanoidArm.RIGHT);
        return shouldSuppressPunchyArm(player, arm);
    }

    public static boolean isUsingOrMallardGuarding(AbstractClientPlayer player) {
        if (player == null) return false;
        if (player.isUsingItem()) return true;
        try {
            if (!MallardGuardBridge.isLoaded() || !ServerConfig.enableMallardGuardCompat()) return false;
            if (MallardGuardCompatHandler.hasShieldInOffhand(player)) return false;
            if (MallardGuardBridge.isGuarding(player)) return true;
            Minecraft mc = Minecraft.getInstance();
            if (mc == null || mc.player != player || mc.screen != null || mc.options == null) return false;
            if (!mc.options.keyUse.isDown() || !isParryKeySharedWithUseKey()) return false;
            if (PlayerHelper.isParrying(player)) return false;
            ItemStack main = player.getMainHandItem();
            ItemStack off = player.getOffhandItem();
            if (main.getUseDuration(player) > 0 || off.getUseDuration(player) > 0) return false;
            if (mc.hitResult != null && mc.hitResult.getType() == HitResult.Type.BLOCK
                    && (main.getItem() instanceof BlockItem || off.getItem() instanceof BlockItem)) {
                return false;
            }
            if (PlayerHelper.isPointingAtInteractable(player)) return false;
            return ItemHelper.isHoldingCombatItem(player);
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static void tryForceOffhandShieldBlock(Minecraft mc) {
        try {
            if (mc == null) return;
            LocalPlayer player = mc.player;
            if (player == null || mc.screen != null || mc.gameMode == null || player.isSpectator()) return;
            if (!MallardGuardBridge.isLoaded() || !ServerConfig.offhandShieldForcesVanillaBlocking()) return;
            if (!MallardGuardCompatHandler.hasShieldInOffhand(player)) return;
            MallardGuardBridge.clearClientGuard(player);
            if (!mc.options.keyUse.isDown()) return;
            if (player.isUsingItem()) return;
            ItemStack offhand = player.getOffhandItem();
            if (player.getCooldowns().isOnCooldown(offhand.getItem())) return;
            ItemStack mainhand = player.getMainHandItem();
            if (mainhand.getUseDuration(player) > 0) return;
            if (mainhand.getItem() instanceof BlockItem && mc.hitResult != null && mc.hitResult.getType() == HitResult.Type.BLOCK) return;
            if (PlayerHelper.isPointingAtInteractable(player)) return;
            mc.gameMode.useItem(player, InteractionHand.OFF_HAND);
        } catch (Throwable ignored) {}
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public static void registerSoundAndEmfCompat(Event event, Object listener) {
        if (event != null && listener != null) {
            event.register(listener);
        }
        registerEmfFirstPersonCompat();
    }

    public static synchronized void registerEmfFirstPersonCompat() {
        if (emfCompatRegistered) return;
        emfCompatRegistered = true;
        try {
            ModList list = ModList.get();
            if (list == null || !list.isLoaded("entity_model_features") || list.isLoaded("emf_compat_hackers_and_slashers")) {
                return;
            }
            Class<?> api = Class.forName("traben.entity_model_features.EMFAnimationApi", false, PunchyClientBridge.class.getClassLoader());
            Method reg = api.getMethod("registerVanillaModelCondition", Function.class);
            Function<Object, Boolean> cond = entity -> {
                try {
                    if (!(entity instanceof AbstractClientPlayer player)) return false;
                    Minecraft mc = Minecraft.getInstance();
                    if (mc == null || mc.player != player || InventoryRenderFlag.isRenderingInventory) return false;
                    if (!mc.options.getCameraType().isFirstPerson() || mc.getCameraEntity() != player) return false;
                    return FirstPersonMode.isFirstPersonPass() || isHnSFirstPersonActive(player);
                } catch (Throwable ignored) {
                    return false;
                }
            };
            reg.invoke(null, cond);
            System.out.println("[Hackers 'n Slashers] Registered EMF first-person vanilla-model compat.");
        } catch (Throwable failure) {
            System.out.println("[Hackers 'n Slashers] EMF first-person compat skipped: " + failure.getClass().getSimpleName());
        }
    }
}
