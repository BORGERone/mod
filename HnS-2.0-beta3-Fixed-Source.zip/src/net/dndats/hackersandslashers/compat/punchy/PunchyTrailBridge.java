package net.dndats.hackersandslashers.compat.punchy;

import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonMode;
import net.neoforged.fml.ModList;
import net.dndats.api.helper.AnimationHelper;
import net.dndats.hackersandslashers.client.utils.ClientUtils;
import net.dndats.hackersandslashers.config.ClientConfig;
import net.dndats.hackersandslashers.config.ServerConfig;
import net.dndats.hackersandslashers.handlers.MallardGuardCompatHandler;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.ClientCombatState;
import net.dndats.hackersandslashers.mixin.client.GameRendererAccessor;
import net.dndats.hackersandslashers.utils.helper.ItemHelper;
import net.minecraft.client.Camera;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

public final class PunchyTrailBridge {
    private PunchyTrailBridge() {}

    public static FirstPersonMode determineFirstPersonMode(boolean isAttacking, boolean isIdle, boolean isActionOrBlock, boolean forceDisable) {
        if (ClientConfig.isFirstPersonAnimationsDisabled() || forceDisable) {
            return FirstPersonMode.DISABLED;
        }
        if (!isAttacking && !isIdle) {
            return (ModList.get() != null && ModList.get().isLoaded("firstperson")) ? FirstPersonMode.DISABLED : FirstPersonMode.THIRD_PERSON_MODEL;
        }
        if (isActionOrBlock) {
            if (isAttacking) return FirstPersonMode.THIRD_PERSON_MODEL;
            return (ModList.get() != null && ModList.get().isLoaded("firstperson")) ? FirstPersonMode.DISABLED : FirstPersonMode.THIRD_PERSON_MODEL;
        }
        if (isAttacking) return FirstPersonMode.DISABLED;
        return (ModList.get() != null && ModList.get().isLoaded("firstperson")) ? FirstPersonMode.DISABLED : FirstPersonMode.THIRD_PERSON_MODEL;
    }

    public static boolean isFirstPersonPoseAllowed(CameraType cameraType) {
        if (ClientConfig.isFirstPersonAnimationsDisabled()) return false;
        return cameraType != null && cameraType.isFirstPerson();
    }

    public static boolean shouldApplyFirstPersonWeaponTransform(ItemDisplayContext ctx) {
        if (!ClientConfig.isFirstPersonAnimationsDisabled()) return true;
        return ctx != ItemDisplayContext.FIRST_PERSON_RIGHT_HAND && ctx != ItemDisplayContext.FIRST_PERSON_LEFT_HAND;
    }

    public static void playAttackAnimationAndSwing(Player player, String animName, float speed, boolean isOffhand) {
        AnimationHelper.playAnimation(player, animName, speed, isOffhand);
        if (player != null && ClientConfig.isFirstPersonAnimationsDisabled()) {
            Minecraft mc = Minecraft.getInstance();
            if (mc != null && player == mc.player) {
                player.swinging = false;
                player.swing(isOffhand ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND, false);
            }
        }
    }

    public static Vector3f viewOrWorldToWorld(Vector4f transformed, Vec3 camPos, ItemDisplayContext ctx) {
        Vector3f v = new Vector3f(transformed.x, transformed.y, transformed.z);
        if (ctx == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND || ctx == ItemDisplayContext.FIRST_PERSON_LEFT_HAND) {
            Minecraft mc = Minecraft.getInstance();
            if (mc != null && mc.gameRenderer != null) {
                Camera cam = mc.gameRenderer.getMainCamera();
                if (cam != null) v.rotate(cam.rotation());
            }
        }
        return v.add((float) camPos.x, (float) camPos.y, (float) camPos.z);
    }

    public static Matrix4f getFirstPersonProjectionMatrix(GameRenderer gameRenderer, double configuredFov) {
        if (ClientConfig.isFirstPersonAnimationsDisabled()) {
            try {
                Minecraft mc = Minecraft.getInstance();
                if (mc != null && gameRenderer != null && mc.getTimer() != null) {
                    float partialTick = mc.getTimer().getGameTimeDeltaPartialTick(true);
                    double fov = ((GameRendererAccessor) gameRenderer).hns$invokeGetFov(gameRenderer.getMainCamera(), partialTick, false);
                    return gameRenderer.getProjectionMatrix(fov);
                }
            } catch (Throwable ignored) {}
        }
        return gameRenderer.getProjectionMatrix(configuredFov);
    }

    public static boolean canParryWithMallardAndOffhand(Player player) {
        if (player == null) return false;
        if (MallardGuardCompatHandler.isParryReplacedByMallardGuard()) return false;
        if (MallardGuardCompatHandler.isParryDisabledByShield(player)) return false;
        ItemStack offhand = player.getOffhandItem();
        if (offhand.isEmpty()) return true;
        if (offhand.getItem() instanceof ShieldItem || ItemHelper.isShield(offhand)) return false;
        if (offhand.getItem() instanceof BlockItem) {
            HitResult hit = player.pick(5.0, 0.0F, false);
            return hit == null || hit.getType() != HitResult.Type.BLOCK;
        }
        if (Boolean.TRUE.equals(ServerConfig.SHOULD_PARRY_OVERRIDE_USABLE_ITEMS.get())) return true;
        return offhand.getUseDuration(player) <= 0;
    }

    public static boolean canGrappleTarget(LivingEntity target) {
        if (!ServerConfig.isGrappleEnabled() || target == null || !target.isAlive() || target.isSpectator()) return false;
        if (BuiltInRegistries.ENTITY_TYPE != null && target.getType() != null) {
            ResourceLocation key = BuiltInRegistries.ENTITY_TYPE.getKey(target.getType());
            if (key != null) {
                String entityId = key.toString();
                if (ServerConfig.isGrappleEntityBlacklisted(entityId)) return false;
                if (ServerConfig.isGrappleEntityWhitelisted(entityId)) return true;
            }
        }
        if (!ServerConfig.allowGrappleBabies() && target.isBaby()) return false;
        return target.getBbHeight() >= ServerConfig.getMinGrappleTargetHeight()
            && target.getBbWidth() >= ServerConfig.getMinGrappleTargetWidth();
    }

    public static boolean canStartGrapple(Player player, LivingEntity target, ClientCombatState state) {
        return player != null && target != null && state != null && canGrappleTarget(target);
    }

    public static float getGrappleEnergyCostPerTick() {
        return Math.max(0.0F, ServerConfig.getGrappleEnergyPerSecond()) / 20.0F;
    }

    public static Vec3 calculateDodgeVector(Player player, boolean isRoll) {
        Options opts = ClientUtils.getOptions();
        boolean up = opts.keyUp.isDown();
        boolean down = opts.keyDown.isDown();
        boolean left = opts.keyLeft.isDown();
        boolean right = opts.keyRight.isDown();

        float forward = (up == down) ? 0.0F : (up ? 1.0F : -1.0F);
        float strafe = (left == right) ? 0.0F : (left ? 1.0F : -1.0F);
        if (player.isCrouching()) { forward *= 0.3F; strafe *= 0.3F; }

        float len = (float) Math.sqrt(forward * forward + strafe * strafe);
        if (len > 1.0E-4F) { forward /= len; strafe /= len; }

        float strength = isRoll ? 0.75F : 0.85F;
        if (forward == 0.0F && strafe == 0.0F) { forward = 1.0F; strength = 0.6F; }
        if (player.isCrouching()) strength *= 3.0F;

        if (player.isInWater()) {
            Vec3 look = player.getLookAngle();
            Vec3 rightVec = player.getUpVector(1.0F).cross(look).normalize();
            return look.scale(forward * strength).add(rightVec.scale(-strafe * strength));
        }

        float yawRad = player.getYRot() * 0.017453292F;
        float sin = (float) Math.sin(yawRad);
        float cos = (float) Math.cos(yawRad);
        double dx = forward * (-sin) * strength + strafe * cos * strength;
        double dz = forward * cos * strength + strafe * sin * strength;
        double dy = player.onGround() ? 0.0 : 0.25;
        return new Vec3(dx, dy, dz);
    }
}
