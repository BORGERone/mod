package net.dndats.hackersandslashers.compat.punchy.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.dndats.hackersandslashers.compat.punchy.PunchyClientBridge;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(targets = {"punchy.client.render.PunchyArmRenderer"}, remap = false)
public class PunchyArmRendererMixin {
    @Inject(method = {"renderArm"}, at = {@At("HEAD")}, cancellable = true, remap = false, require = 0)
    private static void hns$suppressOwnedPunchyArm(
            PlayerModel<?> model,
            AbstractClientPlayer player,
            HumanoidArm arm,
            PoseStack poseStack,
            MultiBufferSource bufferSource,
            int light,
            ResourceLocation texture,
            boolean slim,
            float partialTick,
            CallbackInfo ci) {
        if (PunchyClientBridge.shouldSuppressPunchyArm(player, arm)) {
            ci.cancel();
        }
    }

    @Inject(method = {"renderArmArmor"}, at = {@At("HEAD")}, cancellable = true, remap = false, require = 0)
    private static void hns$suppressOwnedPunchyArmor(
            PlayerModel<?> model,
            AbstractClientPlayer player,
            HumanoidArm arm,
            PoseStack poseStack,
            MultiBufferSource bufferSource,
            int light,
            boolean slim,
            float partialTick,
            CallbackInfo ci) {
        if (PunchyClientBridge.shouldSuppressPunchyArm(player, arm)) {
            ci.cancel();
        }
    }

    @Inject(method = {"renderItemInHand"}, at = {@At("HEAD")}, cancellable = true, remap = false, require = 0)
    private static void hns$suppressOwnedPunchyItem(
            ItemInHandRenderer renderer,
            PlayerModel<?> model,
            LocalPlayer player,
            HumanoidArm arm,
            PoseStack poseStack,
            MultiBufferSource bufferSource,
            int light,
            Matrix4f armWorld,
            ModelPart geoArm,
            ModelPart itemBone,
            ModelPart gripBone,
            float partialTick,
            CallbackInfo ci) {
        if (PunchyClientBridge.shouldSuppressPunchyArm(player, arm)) {
            ci.cancel();
        }
    }
}
