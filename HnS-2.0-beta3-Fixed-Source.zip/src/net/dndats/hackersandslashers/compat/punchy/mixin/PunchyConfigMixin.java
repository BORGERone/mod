package net.dndats.hackersandslashers.compat.punchy.mixin;

import net.dndats.hackersandslashers.compat.punchy.PunchyClientBridge;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(targets = {"punchy.config.PunchyConfig"}, remap = false)
public class PunchyConfigMixin {
    @Inject(method = {"isHandBlacklisted"}, at = {@At("HEAD")}, cancellable = true, remap = false, require = 0)
    private static void hns$suppressOwnedPunchyHand(
            Player player,
            InteractionHand hand,
            CallbackInfoReturnable<Boolean> cir) {
        if (PunchyClientBridge.shouldSuppressPunchyHand(player, hand)) {
            cir.setReturnValue(Boolean.TRUE);
        }
    }
}
