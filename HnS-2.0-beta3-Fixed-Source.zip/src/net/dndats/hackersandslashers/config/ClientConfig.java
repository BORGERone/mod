package net.dndats.hackersandslashers.config;

import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.common.ModConfigSpec.BooleanValue;
import net.neoforged.neoforge.common.ModConfigSpec.Builder;
import net.neoforged.neoforge.common.ModConfigSpec.DoubleValue;
import net.neoforged.neoforge.common.ModConfigSpec.EnumValue;
import net.neoforged.neoforge.common.ModConfigSpec.IntValue;

public class ClientConfig {
    public static final ModConfigSpec SPEC;
    public static final EnumValue<StealthoMeterStyle> STEALTHO_METER_STYLE;
    public static final BooleanValue ENABLE_HEALTH_BAR;
    public static final BooleanValue ENABLE_DAMAGE_NUMBERS;
    public static final IntValue ENERGY_BAR_OFFSET_X;
    public static final IntValue ENERGY_BAR_OFFSET_Y;
    public static final BooleanValue ENABLE_CUSTOM_DAMAGE_FLASH;
    public static final IntValue DAMAGE_FLASH_CRITICAL_HIT;
    public static final IntValue DAMAGE_FLASH_FIRE;
    public static final IntValue DAMAGE_FLASH_MAGIC;
    public static final IntValue DAMAGE_FLASH_DEFAULT;
    public static final BooleanValue ENABLE_CRITICAL_BURST;
    public static final BooleanValue ENABLE_SPEEDLINES;
    public static final DoubleValue FIRST_PERSON_ANIMATION_FOV;
    public static final BooleanValue DISABLE_FIRST_PERSON_ANIMATIONS;
    public static final BooleanValue DEBUG_MOB_DETECTION;

    public static boolean isFirstPersonAnimationsDisabled() {
        try {
            return Boolean.TRUE.equals(DISABLE_FIRST_PERSON_ANIMATIONS.get());
        } catch (IllegalStateException e) {
            return true;
        }
    }

    static {
        Builder builder = new Builder();

        builder.push("UI");
        STEALTHO_METER_STYLE = builder.defineEnum("stealtho_meter_style", StealthoMeterStyle.CROSSHAIR);
        ENABLE_HEALTH_BAR = builder.define("enable_health_bar", false);
        ENABLE_DAMAGE_NUMBERS = builder.define("enable_damage_numbers", true);
        ENERGY_BAR_OFFSET_X = builder.comment("Horizontal offset of the energy bar relative to screen center.")
            .defineInRange("energy_bar_offset_x", 10, -2000, 2000);
        ENERGY_BAR_OFFSET_Y = builder.comment("Vertical offset of the energy bar relative to screen bottom.")
            .defineInRange("energy_bar_offset_y", -48, -2000, 2000);
        builder.pop();

        builder.push("Visuals");
        ENABLE_CUSTOM_DAMAGE_FLASH = builder.define("enable_custom_damage_flash", true);
        FIRST_PERSON_ANIMATION_FOV = builder.comment("Field of View used when rendering player model during first-person animations.")
            .defineInRange("first_person_animation_fov", 100.0, 30.0, 150.0);
        DISABLE_FIRST_PERSON_ANIMATIONS = builder.comment("Disable Hackers 'n Slashers first-person model/arm animations so vanilla/Punchy handles 1st-person hands while keeping HnS blade trails, hitboxes, and 3rd-person animations.")
            .define("disable_first_person_animations", true);

        builder.push("Damage Flash Colors");
        DAMAGE_FLASH_CRITICAL_HIT = builder.defineInRange("critical_hit", 14669820, 0, 16777215);
        DAMAGE_FLASH_FIRE = builder.defineInRange("fire", 16743447, 0, 16777215);
        DAMAGE_FLASH_MAGIC = builder.defineInRange("magic", 16266239, 0, 16777215);
        DAMAGE_FLASH_DEFAULT = builder.defineInRange("default", 16771453, 0, 16777215);
        builder.pop();

        builder.push("Combat Particles");
        ENABLE_CRITICAL_BURST = builder.define("enable_critical_burst", true);
        ENABLE_SPEEDLINES = builder.define("enable_speedlines", true);
        builder.pop();

        builder.pop();

        builder.push("Debug");
        DEBUG_MOB_DETECTION = builder.define("debug_mob_detection", false);
        builder.pop();

        SPEC = builder.build();
    }
}
