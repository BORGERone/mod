package net.dndats.hackersandslashers.config;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.common.ModConfigSpec.BooleanValue;
import net.neoforged.neoforge.common.ModConfigSpec.Builder;
import net.neoforged.neoforge.common.ModConfigSpec.ConfigValue;
import net.neoforged.neoforge.common.ModConfigSpec.DoubleValue;
import net.neoforged.neoforge.common.ModConfigSpec.IntValue;

public class ServerConfig {
    public static final ModConfigSpec SPEC;
    public static final BooleanValue ENABLE_STEALTH_SYSTEM;
    public static final BooleanValue ENABLE_PARRY_SYSTEM;
    public static final BooleanValue ENABLE_BASH_SYSTEM;
    public static final BooleanValue ENABLE_EXPERIMENTAL_MOB_COMBAT;
    public static final BooleanValue DISABLE_DEFAULT_CRITICAL;
    public static final BooleanValue ENABLE_HEADSHOT;
    public static final BooleanValue ENABLE_RIPOSTE;
    public static final BooleanValue ENABLE_SNEAK_ATTACK;
    public static final DoubleValue AGGRO_LEADER_MULTIPLIER;
    public static final DoubleValue TAUNT_APPLIED_WEIGHT;
    public static final DoubleValue DAMAGE_ABSORBED_WEIGHT;
    public static final DoubleValue DAMAGE_DEALT_WEIGHT;
    public static final DoubleValue HEALING_DONE_WEIGHT;
    public static final DoubleValue EFFECT_APPLIED_WEIGHT;
    public static final DoubleValue DEFAULT_PER_TICK_THREAT_DECAY;
    public static final ConfigValue<List<? extends String>> ATTRACTIVE_SOUNDS;
    public static final ConfigValue<String> PARRY_STAGGER_MODE;
    public static final IntValue BASE_PARRY_COOLDOWN_REDUCTION;
    public static final BooleanValue SHOULD_PARRY_OVERRIDE_USABLE_ITEMS;
    public static final BooleanValue SHOULD_PARRY_DEFLECT_PROJECTILES;
    public static final BooleanValue SHOULD_PARRY_FAIL;
    public static final DoubleValue BASE_BASH_STRENGTH;
    public static final IntValue BASH_SLOWNESS_DURATION_TICKS;
    public static final BooleanValue SHOULD_BASH_APPLY_SLOWNESS;
    public static final BooleanValue SHOULD_BASH_DEAL_DAMAGE;
    public static final BooleanValue ENABLE_GRAPPLE;
    public static final DoubleValue MIN_GRAPPLE_TARGET_HEIGHT;
    public static final DoubleValue MIN_GRAPPLE_TARGET_WIDTH;
    public static final BooleanValue ALLOW_GRAPPLE_BABIES;
    public static final DoubleValue GRAPPLE_ENERGY_PER_SECOND;
    public static final ConfigValue<List<? extends String>> GRAPPLE_ENTITY_BLACKLIST;
    public static final ConfigValue<List<? extends String>> GRAPPLE_ENTITY_WHITELIST;
    public static final BooleanValue ENABLE_MALLARD_GUARD_COMPAT;
    public static final DoubleValue MALLARD_BLOCK_ENERGY_COST;
    public static final DoubleValue MALLARD_BLOCK_FATAL_ENERGY_COST;
    public static final DoubleValue MALLARD_PARRY_ENERGY_COST;
    public static final DoubleValue MALLARD_PERFECT_PARRY_REFUND;
    public static final BooleanValue MALLARD_GUARD_REQUIRES_STAMINA;
    public static final BooleanValue MALLARD_SHIELD_BLOCK_COSTS_STAMINA;
    public static final BooleanValue OFFHAND_SHIELD_DISABLES_PARRY;
    public static final BooleanValue OFFHAND_SHIELD_FORCES_VANILLA_BLOCKING;
    public static final BooleanValue DISABLE_PARRY_WITH_MALLARD_GUARD;
    public static final BooleanValue ENABLE_CUSTOM_CRITICAL_SOUNDS;

    public static Set<String> mobSoundWhitelistSet = Set.of();

    private static String getSoundKey(SoundEvent sound) {
        ResourceLocation key = BuiltInRegistries.SOUND_EVENT.getKey(sound);
        return key == null ? "" : key.toString();
    }

    public static boolean isSoundAllowed(SoundEvent sound) {
        return mobSoundWhitelistSet.contains(getSoundKey(sound));
    }

    public static void bake() {
        mobSoundWhitelistSet = new HashSet<>(ATTRACTIVE_SOUNDS.get());
    }

    public static boolean isGrappleEnabled() {
        try { return Boolean.TRUE.equals(ENABLE_GRAPPLE.get()); } catch (IllegalStateException e) { return true; }
    }
    public static double getMinGrappleTargetHeight() {
        try { return MIN_GRAPPLE_TARGET_HEIGHT.get(); } catch (IllegalStateException e) { return 1.6; }
    }
    public static double getMinGrappleTargetWidth() {
        try { return MIN_GRAPPLE_TARGET_WIDTH.get(); } catch (IllegalStateException e) { return 0.5; }
    }
    public static boolean allowGrappleBabies() {
        try { return Boolean.TRUE.equals(ALLOW_GRAPPLE_BABIES.get()); } catch (IllegalStateException e) { return false; }
    }
    public static float getGrappleEnergyPerSecond() {
        try { return GRAPPLE_ENERGY_PER_SECOND.get().floatValue(); } catch (IllegalStateException e) { return 1.0F; }
    }
    public static boolean enableMallardGuardCompat() {
        try { return Boolean.TRUE.equals(ENABLE_MALLARD_GUARD_COMPAT.get()); } catch (IllegalStateException e) { return true; }
    }
    public static float mallardBlockEnergyCost() {
        try { return MALLARD_BLOCK_ENERGY_COST.get().floatValue(); } catch (IllegalStateException e) { return 2.0F; }
    }
    public static float mallardBlockFatalEnergyCost() {
        try { return MALLARD_BLOCK_FATAL_ENERGY_COST.get().floatValue(); } catch (IllegalStateException e) { return 4.0F; }
    }
    public static float mallardParryEnergyCost() {
        try { return MALLARD_PARRY_ENERGY_COST.get().floatValue(); } catch (IllegalStateException e) { return 2.0F; }
    }
    public static float mallardPerfectParryRefund() {
        try { return MALLARD_PERFECT_PARRY_REFUND.get().floatValue(); } catch (IllegalStateException e) { return 0.0F; }
    }
    public static boolean mallardGuardRequiresStamina() {
        try { return Boolean.TRUE.equals(MALLARD_GUARD_REQUIRES_STAMINA.get()); } catch (IllegalStateException e) { return true; }
    }
    public static boolean mallardShieldBlockCostsStamina() {
        try { return Boolean.TRUE.equals(MALLARD_SHIELD_BLOCK_COSTS_STAMINA.get()); } catch (IllegalStateException e) { return false; }
    }
    public static boolean offhandShieldDisablesParry() {
        try { return Boolean.TRUE.equals(OFFHAND_SHIELD_DISABLES_PARRY.get()); } catch (IllegalStateException e) { return true; }
    }
    public static boolean offhandShieldForcesVanillaBlocking() {
        try { return Boolean.TRUE.equals(OFFHAND_SHIELD_FORCES_VANILLA_BLOCKING.get()); } catch (IllegalStateException e) { return true; }
    }
    public static boolean disableParryWithMallardGuard() {
        try { return Boolean.TRUE.equals(DISABLE_PARRY_WITH_MALLARD_GUARD.get()); } catch (IllegalStateException e) { return false; }
    }

    public static boolean isGrappleEntityBlacklisted(String entityId) {
        if (entityId == null || entityId.isEmpty()) return false;
        List<? extends String> list;
        try { list = GRAPPLE_ENTITY_BLACKLIST.get(); } catch (IllegalStateException e) { list = List.of("minecraft:armor_stand"); }
        return matchesAnyPattern(entityId, list);
    }

    public static boolean isGrappleEntityWhitelisted(String entityId) {
        if (entityId == null || entityId.isEmpty()) return false;
        List<? extends String> list;
        try { list = GRAPPLE_ENTITY_WHITELIST.get(); } catch (IllegalStateException e) { return false; }
        return matchesAnyPattern(entityId, list);
    }

    public static boolean matchesAnyPattern(String id, List<? extends String> patterns) {
        if (patterns == null || patterns.isEmpty()) return false;
        String normalizedId = id.toLowerCase(Locale.ROOT);
        for (String raw : patterns) {
            if (raw != null && !raw.isBlank() && wildcardMatch(normalizedId, raw.trim().toLowerCase(Locale.ROOT))) {
                return true;
            }
        }
        return false;
    }

    public static boolean wildcardMatch(String text, String pattern) {
        if (!pattern.contains("*")) return text.equals(pattern);
        int ti = 0, pi = 0, starIdx = -1, matchIdx = 0;
        while (ti < text.length()) {
            if (pi < pattern.length() && pattern.charAt(pi) == text.charAt(ti)) {
                pi++; ti++;
            } else if (pi < pattern.length() && pattern.charAt(pi) == '*') {
                starIdx = pi++; matchIdx = ti;
            } else if (starIdx != -1) {
                pi = starIdx + 1; ti = ++matchIdx;
            } else {
                return false;
            }
        }
        while (pi < pattern.length() && pattern.charAt(pi) == '*') pi++;
        return pi == pattern.length();
    }

    static {
        Builder builder = new Builder();

        builder.comment(
            "Hey there :D Having balancement issues?\nJoin our Discord for help:\n\nhttps://discord.gg/fvCuvYsB6C\n\nAdditional configs for better and modular\nfeatures will be added in the future, with\nmany configs for modpack creators!\n\n\ud83d\udd39 HACKERS 'N SLASHERS CONFIGS \ud83d\udd39\n\n⚙ Module Toggles"
        ).push("Module Toggles");
        ENABLE_STEALTH_SYSTEM = builder.define("enable_stealth_system", true);
        ENABLE_PARRY_SYSTEM = builder.define("enable_parry_system", true);
        ENABLE_BASH_SYSTEM = builder.define("enable_bash_system", true);
        ENABLE_EXPERIMENTAL_MOB_COMBAT = builder.define("enable_experimental_mob_combat", false);
        builder.pop();

        builder.comment("────────────────────────────────────────────────────────────────\n\n⚔ Critical Hit Settings")
            .push("Critical Hit Settings");
        DISABLE_DEFAULT_CRITICAL = builder.define("disable_default_critical", true);
        ENABLE_HEADSHOT = builder.define("enable_headshot", true);
        ENABLE_RIPOSTE = builder.define("enable_riposte", true);
        ENABLE_SNEAK_ATTACK = builder.define("enable_sneak_attack", true);
        builder.pop();

        builder.comment(
            "────────────────────────────────────────────────────────────────\n\n⚔ Aggro Settings\n\n• Damage dealt/status/absorbed = threat weights\n• Aggro leader = initial attacker bonus\n\nThe higher the value, the more this parameter will be effective in\npulling a mob aggro\n\n⚠ Healing done applies to each HP restored"
        ).push("Aggro Settings");
        AGGRO_LEADER_MULTIPLIER = builder.defineInRange("aggro_leader_multiplier", 2.0, 0.0, 100.0);
        TAUNT_APPLIED_WEIGHT = builder.defineInRange("taunt_applied_weight", 5.0, 0.0, 100.0);
        DAMAGE_ABSORBED_WEIGHT = builder.defineInRange("damage_absorbed_weight", 0.5, 0.0, 100.0);
        DAMAGE_DEALT_WEIGHT = builder.defineInRange("damage_dealt_weight", 1.0, 0.0, 100.0);
        HEALING_DONE_WEIGHT = builder.defineInRange("healing_done_weight", 0.25, 0.0, 100.0);
        EFFECT_APPLIED_WEIGHT = builder.defineInRange("effect_applied_weight", 1.0, 0.0, 100.0);
        builder.comment("⚔ Threat generation values\n\n• Tick decay = threat fade rate")
            .push("Threat generation values");
        DEFAULT_PER_TICK_THREAT_DECAY = builder.defineInRange("default_per_tick_threat_decay", 0.01, 0.0, 1.0);
        builder.pop(2);

        builder.comment("────────────────────────────────────────────────────────────────\n\n\ud83e\udde0 AI Settings")
            .push("AI Settings");
        ATTRACTIVE_SOUNDS = builder.defineList(
            "attractive_sounds",
            List.of(
                "minecraft:block.wooden_door.open", "minecraft:block.wooden_door.close",
                "minecraft:block.iron_door.open", "minecraft:block.iron_door.close",
                "minecraft:block.trapdoor.open", "minecraft:block.trapdoor.close",
                "minecraft:block.fence_gate.open", "minecraft:block.fence_gate.close",
                "minecraft:block.lever.click",
                "minecraft:block.stone_button.click_on", "minecraft:block.stone_button.click_off",
                "minecraft:block.wooden_button.click_on", "minecraft:block.wooden_button.click_off",
                "minecraft:block.chest.open", "minecraft:block.chest.close",
                "minecraft:block.ender_chest.open", "minecraft:block.ender_chest.close"
            ),
            obj -> obj instanceof String
        );
        builder.pop();

        builder.comment("────────────────────────────────────────────────────────────────\n\n\ud83d\udee1️ Parry System\n\nModes: (DEFAULT, MISSING-HEALTH, DISABLED)\n⚠ DISABLED disables stun and riposte")
            .push("Parry System");
        PARRY_STAGGER_MODE = builder.define("parry_stagger_mode", "DEFAULT");
        BASE_PARRY_COOLDOWN_REDUCTION = builder.defineInRange("base_parry_cooldown_reduction", 0, 0, 1000);
        SHOULD_PARRY_OVERRIDE_USABLE_ITEMS = builder.define("should_parry_override_usable_items", false);
        SHOULD_PARRY_DEFLECT_PROJECTILES = builder.define("should_parry_deflect_projectiles", true);
        SHOULD_PARRY_FAIL = builder.define("should_parry_fail", true);
        builder.pop();

        builder.comment("────────────────────────────────────────────────────────────────\n\n\ud83d\udee1️ Bash System\n(cooldown ≥ 10 ticks)")
            .push("Bash System");
        BASE_BASH_STRENGTH = builder.defineInRange("base_bash_strength", 0.25, 0.0, 10.0);
        BASH_SLOWNESS_DURATION_TICKS = builder.defineInRange("bash_slowness_duration_ticks", 60, 0, 1200);
        SHOULD_BASH_APPLY_SLOWNESS = builder.define("should_bash_apply_slowness", true);
        SHOULD_BASH_DEAL_DAMAGE = builder.define("should_bash_deal_damage", true);
        builder.pop();

        builder.comment("────────────────────────────────────────────────────────────────\n\n\ud83e\uddd7 Grapple & Parkour Settings\n\n• Total stamina bar = 10.0 (5 pods × 2.0; half a pod = 1.0)\n• Supports exact IDs ('modid:entity') and wildcards ('modid:*', '*:*butterfly*')")
            .push("Grapple & Parkour Settings");
        ENABLE_GRAPPLE = builder.define("enable_grapple", true);
        MIN_GRAPPLE_TARGET_HEIGHT = builder.defineInRange("min_grapple_target_height", 1.6, 0.0, 20.0);
        MIN_GRAPPLE_TARGET_WIDTH = builder.defineInRange("min_grapple_target_width", 0.5, 0.0, 20.0);
        ALLOW_GRAPPLE_BABIES = builder.define("allow_grapple_babies", false);
        GRAPPLE_ENERGY_PER_SECOND = builder.defineInRange("grapple_energy_per_second", 1.0, 0.0, 10.0);
        GRAPPLE_ENTITY_BLACKLIST = builder.defineList("grapple_entity_blacklist", List.of("minecraft:armor_stand"), obj -> obj instanceof String);
        GRAPPLE_ENTITY_WHITELIST = builder.defineList("grapple_entity_whitelist", List.of(), obj -> obj instanceof String);
        builder.pop();

        builder.comment("────────────────────────────────────────────────────────────────\n\n\ud83d\udee1️ Block Stamina & Shield Settings\n\n• Mallard Guard compatibility: regular weapon blocks and\ntimed parries now consume stamina. A perfect parry stays free.\n\n• Stamina scale: total bar = 10.0 (5 pods × 2.0; half a pod = 1.0)\n• A block that would kill you uses the fatal cost\n• With a shield in the off hand the parry mechanic is disabled\nand the right mouse button blocks like vanilla")
            .push("Block Stamina & Shield Settings");
        ENABLE_MALLARD_GUARD_COMPAT = builder.define("enable_mallard_guard_compat", true);
        MALLARD_BLOCK_ENERGY_COST = builder.defineInRange("mallard_block_energy_cost", 2.0, 0.0, 10.0);
        MALLARD_BLOCK_FATAL_ENERGY_COST = builder.defineInRange("mallard_block_fatal_energy_cost", 4.0, 0.0, 10.0);
        MALLARD_PARRY_ENERGY_COST = builder.defineInRange("mallard_parry_energy_cost", 2.0, 0.0, 10.0);
        MALLARD_PERFECT_PARRY_REFUND = builder.defineInRange("mallard_perfect_parry_refund", 0.0, 0.0, 10.0);
        MALLARD_GUARD_REQUIRES_STAMINA = builder.define("mallard_guard_requires_stamina", true);
        MALLARD_SHIELD_BLOCK_COSTS_STAMINA = builder.define("mallard_shield_block_costs_stamina", false);
        OFFHAND_SHIELD_DISABLES_PARRY = builder.define("offhand_shield_disables_parry", true);
        OFFHAND_SHIELD_FORCES_VANILLA_BLOCKING = builder.define("offhand_shield_forces_vanilla_blocking", true);
        DISABLE_PARRY_WITH_MALLARD_GUARD = builder.define("disable_parry_with_mallard_guard", false);
        builder.pop();

        builder.comment("────────────────────────────────────────────────────────────────\n\n⚙ Miscellaneous")
            .push("Miscellaneous");
        ENABLE_CUSTOM_CRITICAL_SOUNDS = builder.define("enable_custom_critical_sounds", true);
        builder.pop();

        SPEC = builder.build();
    }
}
