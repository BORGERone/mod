package net.dndats.hackersandslashers.handlers.movement;

import java.util.List;
import net.dndats.hackersandslashers.client.utils.SpamTracker;
import net.dndats.hackersandslashers.common.setup.ModKeybinds;
import net.dndats.hackersandslashers.compat.punchy.PunchyTrailBridge;
import net.dndats.hackersandslashers.datapacks.models.MovesetActionData;
import net.dndats.hackersandslashers.datapacks.models.StancesData;
import net.dndats.hackersandslashers.datapacks.models.WeaponComboStep;
import net.dndats.hackersandslashers.datapacks.models.WeaponStatOverride;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.BladeTracker;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.ClientCombatState;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.ComboManager;
import net.dndats.hackersandslashers.impl.combat.mechanics.movement.parkour.CombatParkourManager;
import net.dndats.hackersandslashers.impl.combat.resources.energy.EnergyHelper;
import net.dndats.hackersandslashers.impl.combat.resources.energy.EnergyManager;
import net.dndats.hackersandslashers.utils.FancyLogger;
import net.dndats.hackersandslashers.utils.helper.CombatHelper;
import net.dndats.hackersandslashers.utils.helper.ItemHelper;
import net.dndats.hackersandslashers.utils.helper.PlayerHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

@EventBusSubscriber(modid = "hackersandslashers")
public class CombatParkourHandler {
    @SubscribeEvent
    public static void handleDodgeBehavior(LivingIncomingDamageEvent event) {
        try {
            CombatParkourManager.dodgeBehavior(event);
        } catch (Exception e) {
            FancyLogger.log(e);
        }
    }

    @EventBusSubscriber(modid = "hackersandslashers", value = {Dist.CLIENT})
    public static class Client {
        private static boolean wasJumping = false;

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Pre event) {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player == null) {
                return;
            }
            CombatParkourManager.tickCooldowns();
            CombatParkourManager.tickState(player);

            boolean isJumping = Minecraft.getInstance().options.keyJump.isDown();
            boolean jumpPressed = isJumping && !wasJumping;
            boolean jumpReleased = !isJumping && wasJumping;
            wasJumping = isJumping;

            if (jumpPressed
                    && !player.isPassenger()
                    && !PlayerHelper.isFlying(player)
                    && PlayerHelper.lastComboStep(player) != null
                    && BladeTracker.isCurrentAttackPower()) {
                WeaponStatOverride stats = ItemHelper.resolvePresetStats(player.getMainHandItem());
                WeaponComboStep step = null;
                if (stats != null && stats.moveset != null) {
                    MovesetActionData action = stats.moveset.actions.get("hackersandslashers:hns_weapon_attack_event");
                    if (action != null) {
                        int comboIdx = PlayerHelper.getComboIndex(player);
                        boolean dual = ItemHelper.isSameStyle(player.getMainHandItem(), player.getOffhandItem());
                        List<WeaponComboStep> list = (dual && !action.dualHanded.isEmpty())
                                ? action.dualHanded
                                : action.oneHanded;
                        if (!list.isEmpty()) {
                            WeaponComboStep baseStep = list.get(comboIdx % list.size());
                            if (baseStep != null && baseStep.onPowerAttack != null) {
                                step = baseStep.onPowerAttack;
                            }
                        }
                    }
                }
                if (step != null && step.jumpImpulseStrength != null && step.jumpImpulseStrength > 0.0F) {
                    Vec3 motion = player.getDeltaMovement();
                    player.setDeltaMovement(motion.add(0.0D, step.jumpImpulseStrength, 0.0D));
                }
            }

            ClientCombatState state = ComboManager.getState(player);
            StancesData stances = ItemHelper.getStances(player.getMainHandItem());
            boolean hasGrapple = stances != null && stances.getOnGrappleHold(player) != null;

            if (hasGrapple
                    && !player.onGround()
                    && !player.isPassenger()
                    && !PlayerHelper.isFlying(player)
                    && jumpPressed
                    && CombatParkourManager.getParkourCooldown() == 0
                    && !player.isBlocking()
                    && !PlayerHelper.isParrying(player)) {
                AABB box = player.getBoundingBox().inflate(1.25D);
                List<LivingEntity> targets = player.level().getEntitiesOfClass(
                        LivingEntity.class, box, e -> e != player && e.isAlive());
                if (!targets.isEmpty()) {
                    LivingEntity target = targets.get(0);
                    double playerHeight = player.getBbHeight();
                    double targetHeight = target.getBbHeight();
                    if (targetHeight < playerHeight * 0.5D) {
                        if (CombatHelper.isInActiveHitbox(player)) {
                            return;
                        }
                        boolean downPressed = Minecraft.getInstance().options.keyDown.isDown();
                        if (downPressed) {
                            if (stances.getOnKickOff(player) != null && EnergyHelper.tryConsume(player, 2.0F)) {
                                ComboManager.performFeint(player);
                                CombatParkourManager.performKickOff(player, target);
                                CombatParkourManager.setParkourCooldown(5);
                            }
                        } else if (stances.getOnVault(player) != null && EnergyHelper.tryConsume(player, 2.0F)) {
                            ComboManager.performFeint(player);
                            CombatParkourManager.performVault(player, target);
                            CombatParkourManager.setParkourCooldown(5);
                        }
                        return;
                    }
                    CombatParkourManager.startGrapple(player, target, state);
                }
            }

            if (state.grappledEntity != null && (!state.grappledEntity.isAlive() || PlayerHelper.isFlying(player))) {
                CombatParkourManager.endGrapple(player, state);
            }

            if (isJumping && state.grappledEntity != null) {
                double maxDist = state.grappledEntity.getBbHeight() + state.grappledEntity.getBbWidth() + 4.0D;
                if (state.grappledEntity.distanceToSqr(player) > maxDist * maxDist) {
                    CombatParkourManager.endGrapple(player, state);
                } else if (EnergyManager.getCurrentEnergy() <= 0.0F) {
                    Vec3 vel = state.currentGrappleVelocity;
                    if (vel != null && vel.lengthSqr() > 0.001D) {
                        double len = vel.length();
                        if (len > 1.5D) {
                            vel = vel.normalize().scale(1.5D);
                        }
                        vel = vel.add(0.0D, 0.4D, 0.0D);
                        player.setDeltaMovement(vel);
                    } else {
                        player.setDeltaMovement(player.getLookAngle().scale(-0.5D).add(0.0D, 0.3D, 0.0D));
                    }
                    CombatParkourManager.endGrapple(player, state);
                } else {
                    float cost = PunchyTrailBridge.getGrappleEnergyCostPerTick();
                    if (state.grappledEntity.swinging) {
                        cost = 0.4F;
                    } else if (state.grappledEntity.position().distanceToSqr(
                            state.grappledEntity.xOld,
                            state.grappledEntity.yOld,
                            state.grappledEntity.zOld) > 1.0E-4D) {
                        cost = 0.15F;
                    }
                    EnergyManager.consumeEnergy(cost);
                    state.grappleTicks++;
                }
            }

            if (jumpReleased && state.grappledEntity != null) {
                if (!PlayerHelper.isFlying(player)) {
                    boolean downPressed = Minecraft.getInstance().options.keyDown.isDown();
                    StancesData currentStances = ItemHelper.getStances(player.getMainHandItem());
                    if (downPressed) {
                        if (currentStances != null
                                && currentStances.getOnKickOff(player) != null
                                && EnergyHelper.tryConsume(player, 2.0F)) {
                            ComboManager.performFeint(player);
                            CombatParkourManager.performKickOff(player, state.grappledEntity);
                            CombatParkourManager.setParkourCooldown(5);
                        }
                    } else if (currentStances != null
                            && currentStances.getOnVault(player) != null
                            && EnergyHelper.tryConsume(player, 2.0F)) {
                        ComboManager.performFeint(player);
                        CombatParkourManager.performVault(player, state.grappledEntity);
                        CombatParkourManager.setParkourCooldown(5);
                    }
                }
                CombatParkourManager.endGrapple(player, state);
            }

            if (ModKeybinds.DASH.consumeClick()) {
                SpamTracker.trackAction("DASH");
                if (!player.isPassenger()) {
                    tryTriggerDash(player);
                }
            }
        }

        @SubscribeEvent
        public static void onClientTickPost(ClientTickEvent.Post event) {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player == null) {
                return;
            }
            ClientCombatState state = ComboManager.getState(player);
            boolean isJumping = Minecraft.getInstance().options.keyJump.isDown();
            if (isJumping && state.grappledEntity != null) {
                CombatParkourManager.tickGrapple(player, state.grappledEntity);
            }
        }

        @SubscribeEvent
        public static void onMovementInput(MovementInputUpdateEvent event) {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player == null) {
                return;
            }
            CombatParkourManager.handleMovementInput(player, event.getInput(), ModKeybinds.DASH.isDown());
        }

        private static void tryTriggerDash(LocalPlayer player) {
            if (player.isCrouching()) {
                return;
            }
            if (CombatParkourManager.getDodgeCooldown() == 0
                    && CombatParkourManager.canDash(player)
                    && EnergyHelper.tryConsume(player, 1.0F)) {
                CombatParkourManager.setDodgeCooldown(10);
                CombatParkourManager.triggerDash(player);
            }
        }
    }
}
