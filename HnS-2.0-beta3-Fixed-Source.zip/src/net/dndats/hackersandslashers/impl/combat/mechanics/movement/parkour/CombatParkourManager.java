package net.dndats.hackersandslashers.impl.combat.mechanics.movement.parkour;

import java.util.List;
import net.dndats.api.animations.PlayerAnimator;
import net.dndats.hackersandslashers.client.utils.ClientModelHelper;
import net.dndats.hackersandslashers.client.utils.ClientMovementHelper;
import net.dndats.hackersandslashers.client.utils.ClientUtils;
import net.dndats.hackersandslashers.common.data.IsDodgingData;
import net.dndats.hackersandslashers.common.data.IsInvulnerableData;
import net.dndats.hackersandslashers.common.data.PlayerComboData;
import net.dndats.hackersandslashers.common.network.packets.C2S_PacketGrappleState;
import net.dndats.hackersandslashers.common.network.packets.C2S_PacketParkourHit;
import net.dndats.hackersandslashers.common.network.packets.C2S_PacketSetInvulnerable;
import net.dndats.hackersandslashers.common.network.packets.C2S_PacketTriggerPlayerDodge;
import net.dndats.hackersandslashers.common.setup.ModDataAttachments;
import net.dndats.hackersandslashers.common.setup.ModMobEffects;
import net.dndats.hackersandslashers.compat.punchy.PunchyTrailBridge;
import net.dndats.hackersandslashers.datapacks.models.StancesData;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.ClientCombatState;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.ComboManager;
import net.dndats.hackersandslashers.mixin.accessor.CreeperAccessor;
import net.dndats.hackersandslashers.utils.helper.Animator;
import net.dndats.hackersandslashers.utils.helper.CombatHelper;
import net.dndats.hackersandslashers.utils.helper.ItemHelper;
import net.dndats.hackersandslashers.utils.helper.PlayerHelper;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.joml.Matrix4f;
import org.joml.Vector4f;

public class CombatParkourManager {
    private static int parkourCooldown = 0;
    private static int dodgeCooldown = 0;

    public static int getParkourCooldown() {
        return parkourCooldown;
    }

    public static void setParkourCooldown(int cooldown) {
        parkourCooldown = cooldown;
    }

    public static int getDodgeCooldown() {
        return dodgeCooldown;
    }

    public static void setDodgeCooldown(int cooldown) {
        dodgeCooldown = cooldown;
    }

    public static void tickCooldowns() {
        if (parkourCooldown > 0) {
            parkourCooldown--;
        }
        if (dodgeCooldown > 0) {
            dodgeCooldown--;
        }
    }

    public static void handleLeanInput(Player player, Input input, boolean isDashDown) {
        ClientCombatState state = ComboManager.getState(player);
        if (state == null) {
            return;
        }
        if (player.isCrouching()) {
            if (isDashDown) {
                input.forwardImpulse = 0.0F;
                input.leftImpulse = 0.0F;
                player.setDeltaMovement(0.0D, player.getDeltaMovement().y, 0.0D);
                if (input.left && !input.right) {
                    state.isLeaningLeft = true;
                    state.isLeaningRight = false;
                    state.targetLeanX = -0.45F;
                } else if (input.right && !input.left) {
                    state.isLeaningRight = true;
                    state.isLeaningLeft = false;
                    state.targetLeanX = 0.45F;
                } else {
                    state.isLeaningLeft = false;
                    state.isLeaningRight = false;
                    state.targetLeanX = 0.0F;
                }
            } else {
                state.isLeaningLeft = false;
                state.isLeaningRight = false;
                state.targetLeanX = 0.0F;
            }
        } else {
            state.isLeaningLeft = false;
            state.isLeaningRight = false;
            state.targetLeanX = 0.0F;
        }
    }

    public static void tickState(Player player) {
        ClientCombatState state = ComboManager.getState(player);
        if (state != null && state.isDashing) {
            AABB box = player.getBoundingBox().inflate(0.1D);
            List<LivingEntity> entities = player.level().getEntitiesOfClass(
                    LivingEntity.class, box, e -> e != player && e.isAlive());
            if (!entities.isEmpty()) {
                player.setDeltaMovement(0.0D, player.getDeltaMovement().y, 0.0D);
                state.isDashing = false;
            }
        }
        if (state != null && state.isDashing) {
            int elapsed = player.tickCount - state.dashStartTick;
            if (state.dashStartTick != -1 && elapsed >= 6) {
                state.isDashing = false;
                state.dashStartTick = -1;
                IsDodgingData dodging = player.getData(ModDataAttachments.IS_DODGING);
                if (dodging.getIsDodging()) {
                    dodging.setDodging(false);
                    PacketDistributor.sendToServer(
                            new C2S_PacketTriggerPlayerDodge(dodging, 0, 0.0D, 0.0D, 0.0D),
                            new CustomPacketPayload[0]);
                }
            }
        } else if (!PlayerHelper.isDodging(player) && state != null) {
            state.isDashing = false;
            state.isRolling = false;
        }
    }

    public static void startGrapple(Player player, LivingEntity target, ClientCombatState state) {
        if (!PunchyTrailBridge.canStartGrapple(player, target, state)) {
            return;
        }
        state.grappledEntity = target;
        state.grappleTicks = 0;
        PlayerHelper.setComboIndex(player, 0);
        state.currentLastAttackComboTicker = 0;
        state.grappleBasicAttackCount = 0;
        state.grapplePowerAttackCount = 0;
        state.initialBoneMatrix = null;
        state.grappleSurfaceNormal = null;
        player.setShiftKeyDown(false);
        player.setNoGravity(true);
        player.setDeltaMovement(Vec3.ZERO);

        Vec3 offset = player.position().subtract(target.position());
        double horizDist = offset.horizontalDistance();
        double minDist = (player.getBbWidth() + target.getBbWidth()) / 2.0D;
        double maxDist = minDist + 0.5D;
        if (horizDist < minDist || horizDist == 0.0D) {
            if (horizDist == 0.0D) {
                offset = new Vec3(1.0D, offset.y, 0.0D);
            }
            offset = new Vec3(offset.x, 0.0D, offset.z).normalize().scale(minDist).add(0.0D, offset.y, 0.0D);
        } else if (horizDist > maxDist) {
            offset = new Vec3(offset.x, 0.0D, offset.z).normalize().scale(maxDist).add(0.0D, offset.y, 0.0D);
        }

        float rad = target.yBodyRot * 3.1415927F / 180.0F;
        state.grappleLocalOffset = offset.yRot(rad);
        state.lastTargetYRot = target.yBodyRot;
        state.attachedBonePath = null;
        state.boneLocalOffset = null;

        boolean back = state.grappleLocalOffset.z < 0.0D;
        PacketDistributor.sendToServer(
                new C2S_PacketGrappleState(target.getId(), true, back),
                new CustomPacketPayload[0]);
    }

    public static void handleMovementInput(LocalPlayer player, Input input, boolean isDashDown) {
        if (player == null || input == null) {
            return;
        }
        ClientCombatState state = ComboManager.getState(player);
        if (state != null && (player.onGround() || player.isInWater() || PlayerHelper.isFlying(player))) {
            state.hasPerformedAirRoll = false;
            state.hasPerformedAirDash = false;
        }
        if (PlayerHelper.isGrappling(player)) {
            input.shiftKeyDown = false;
        }
        handleLeanInput(player, input, isDashDown);
    }

    public static void endGrapple(Player player, ClientCombatState state) {
        if (state != null) {
            state.grappledEntity = null;
            state.attachedBonePath = null;
            state.boneLocalOffset = null;
            state.initialBoneMatrix = null;
            state.grappleSurfaceNormal = null;
        }
        if (player != null) {
            player.setNoGravity(false);
        }
        PacketDistributor.sendToServer(
                new C2S_PacketGrappleState(0, false, false),
                new CustomPacketPayload[0]);
    }

    public static void tickGrapple(Player player, LivingEntity target) {
        if (player == null || target == null) {
            return;
        }
        player.setDeltaMovement(0.0D, 0.0D, 0.0D);
        player.setNoGravity(true);
        player.hasImpulse = false;
        player.fallDistance = 0.0F;

        ClientCombatState state = ComboManager.getState(player);
        if (state == null || state.grappleLocalOffset == null) {
            double midY = target.getY() + target.getBbHeight() * 0.6D;
            Vec3 cur = player.position();
            Vec3 next = new Vec3(
                    cur.x + (target.getX() - cur.x) * 0.5D,
                    cur.y + (midY - cur.y) * 0.5D,
                    cur.z + (target.getZ() - cur.z) * 0.5D);
            player.setPos(next.x, next.y, next.z);
            return;
        }

        if (player.level().isClientSide()) {
            ClientModelHelper.ModelGeometry geometry = ClientModelHelper.getModelGeometry(target);
            if (state.attachedBonePath != null && state.boneLocalOffset != null) {
                Matrix4f boneMat = geometry.boneTransforms.get(state.attachedBonePath);
                if (boneMat != null) {
                    Vector4f v = new Vector4f(
                            (float) state.boneLocalOffset.x,
                            (float) state.boneLocalOffset.y,
                            (float) state.boneLocalOffset.z,
                            1.0F);
                    boneMat.transform(v);
                    state.grappleLocalOffset = new Vec3(
                            v.x() * geometry.visualScale,
                            v.y() * geometry.visualScale,
                            v.z() * geometry.visualScale);
                }
            }

            float forward = ClientUtils.getForwardImpulse();
            float strafe = ClientUtils.getLeftImpulse();
            double playerHeight = player.getBbHeight();
            double targetHeight = target.getBbHeight();
            boolean tallTarget = targetHeight >= playerHeight + 1.0D;
            float climbInput = tallTarget ? forward : 0.0F;
            boolean moving = climbInput != 0.0F || strafe != 0.0F;
            if (moving) {
                player.setSprinting(false);
                double speed = player.getAttributeValue(Attributes.MOVEMENT_SPEED) * 1.5D;
                if (climbInput != 0.0F) {
                    double nextY = state.grappleLocalOffset.y + climbInput * speed;
                    nextY = Math.clamp(nextY, 0.0D, target.getBbHeight());
                    state.grappleLocalOffset = new Vec3(state.grappleLocalOffset.x, nextY, state.grappleLocalOffset.z);
                }
                if (strafe != 0.0F) {
                    double radius = Math.max(0.1D, state.grappleLocalOffset.horizontalDistance());
                    double angle = (strafe * speed) / radius;
                    state.grappleLocalOffset = state.grappleLocalOffset.yRot((float) (-angle));
                    boolean back = state.grappleLocalOffset.z < 0.0D;
                    PacketDistributor.sendToServer(
                            new C2S_PacketGrappleState(target.getId(), true, back),
                            new CustomPacketPayload[0]);
                }
            }

            boolean needSurface = moving || state.attachedBonePath == null || state.boneLocalOffset == null;
            if (needSurface) {
                ClientModelHelper.SurfaceResult surf = ClientModelHelper.getSurfaceResult(
                        target, state.grappleLocalOffset, geometry);
                Vec3 horiz = new Vec3(state.grappleLocalOffset.x, 0.0D, state.grappleLocalOffset.z);
                if (horiz.lengthSqr() < 1.0E-4D) {
                    horiz = new Vec3(0.0D, 0.0D, 1.0D);
                }
                horiz = horiz.normalize();
                Vec3 snapped = surf.point.add(horiz.scale(player.getBbWidth() / 2.0D + 0.15D));
                state.grappleLocalOffset = new Vec3(snapped.x, state.grappleLocalOffset.y, snapped.z);
                if (surf.normal != null && surf.normal.lengthSqr() > 0.01D) {
                    state.grappleSurfaceNormal = surf.normal;
                } else {
                    state.grappleSurfaceNormal = horiz;
                }
                if (surf.attachedPath != null) {
                    state.attachedBonePath = surf.attachedPath;
                    Matrix4f mat = geometry.boneTransforms.get(surf.attachedPath);
                    if (mat != null) {
                        Matrix4f inv = new Matrix4f(mat).invert();
                        Vector4f lv = new Vector4f(
                                (float) (state.grappleLocalOffset.x / geometry.visualScale),
                                (float) (state.grappleLocalOffset.y / geometry.visualScale),
                                (float) (state.grappleLocalOffset.z / geometry.visualScale),
                                1.0F);
                        inv.transform(lv);
                        state.boneLocalOffset = new Vec3(lv.x(), lv.y(), lv.z());
                    }
                }
            }

            Vec3 norm = state.grappleSurfaceNormal;
            if (norm == null || norm.lengthSqr() < 1.0E-4D) {
                norm = new Vec3(state.grappleLocalOffset.x, 0.0D, state.grappleLocalOffset.z).normalize();
            }
            if (norm.lengthSqr() > 1.0E-4D) {
                Vec3 worldNorm = norm.yRot(-target.yBodyRot * 3.1415927F / 180.0F);
                float bodyYaw = (float) (Math.atan2(-worldNorm.x, worldNorm.z) * 57.29577951308232D) + 180.0F;
                player.yBodyRot = bodyYaw;
                player.yBodyRotO = bodyYaw;
                player.yHeadRot = bodyYaw;
                player.yHeadRotO = bodyYaw;
            }

            float yawDelta = target.yBodyRot - state.lastTargetYRot;
            if (Math.abs(yawDelta) > 0.001F && Math.abs(yawDelta) < 90.0F) {
                player.setYRot(player.getYRot() + yawDelta);
                player.yRotO += yawDelta;
            }

            if (state.attachedBonePath != null) {
                Matrix4f currentMat = geometry.boneTransforms.get(state.attachedBonePath);
                if (currentMat != null) {
                    if (state.initialBoneMatrix == null) {
                        state.initialBoneMatrix = new Matrix4f(currentMat);
                    }
                    Matrix4f invInit = new Matrix4f(state.initialBoneMatrix).invert();
                    Matrix4f delta = new Matrix4f(currentMat).mul(invInit);
                    float rad = target.yBodyRot * 3.1415927F / 180.0F;
                    Vector4f up = new Vector4f(0.0F, 1.0F, 0.0F, 0.0F);
                    delta.transform(up);
                    Vec3 transformedUp = new Vec3(up.x(), up.y(), up.z()).normalize().yRot(-rad);

                    float pYaw = player.getYRot() * 3.1415927F / 180.0F;
                    Vec3 lookHoriz = new Vec3(-Math.sin(pYaw), 0.0D, Math.cos(pYaw));
                    Vec3 localLook = lookHoriz.yRot(rad);
                    Vector4f fwd4 = new Vector4f((float) localLook.x, (float) localLook.y, (float) localLook.z, 0.0F);
                    delta.transform(fwd4);
                    Vec3 transformedFwd = new Vec3(fwd4.x(), fwd4.y(), fwd4.z()).normalize().yRot(-rad);

                    state.targetBonePitch = (float) (Math.asin(transformedFwd.y) * 180.0D / Math.PI);
                    state.targetBonePitch = Mth.clamp(state.targetBonePitch, -60.0F, 60.0F);

                    float pitchRad = state.targetBonePitch * 3.1415927F / 180.0F;
                    Vec3 pitchedUp = new Vec3(
                            -Math.sin(pYaw) * Math.sin(pitchRad),
                            Math.cos(pitchRad),
                            Math.cos(pYaw) * Math.sin(pitchRad));
                    double dot = pitchedUp.dot(transformedUp);
                    double crossDot = lookHoriz.dot(pitchedUp.cross(transformedUp));
                    state.targetBoneRoll = (float) (Math.atan2(crossDot, dot) * 180.0D / Math.PI);
                    state.targetBoneRoll = Mth.clamp(state.targetBoneRoll, -60.0F, 60.0F);
                }
            } else {
                state.targetBonePitch = 0.0F;
                state.targetBoneRoll = 0.0F;
            }
        }

        float invRad = -target.yBodyRot * 3.1415927F / 180.0F;
        Vec3 worldOffset = state.grappleLocalOffset.yRot(invRad);
        Vec3 worldPos = target.position().add(worldOffset);
        if (state.lastGrappleBoneWorldPos != null) {
            state.currentGrappleVelocity = worldPos.subtract(state.lastGrappleBoneWorldPos);
        }
        state.lastGrappleBoneWorldPos = worldPos;
        player.setPos(worldPos.x, worldPos.y, worldPos.z);
        state.lastTargetYRot = target.yBodyRot;
    }

    public static void dodgeBehavior(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        if ((PlayerHelper.isDodging(player) || PlayerHelper.isInvulnerable(player))
                && shouldDodgeDamage(event.getSource())) {
            event.setCanceled(true);
            return;
        }
        if (event.getSource().getEntity() != null) {
            PlayerComboData data = player.getData(ModDataAttachments.PLAYER_COMBO_DATA);
            if (data.isGrappling()
                    && data.isGrappledToBack()
                    && event.getSource().getEntity().getId() == data.getGrappledTargetId()) {
                event.setCanceled(true);
            }
        }
    }

    public static void triggerDash(Player player) {
        if (player == null) {
            return;
        }
        Vec3 dodgeVec = calculateDodgeVector(player, true);
        Animator.playDashAnimation(player);
        ClientMovementHelper.applyDashEffects(player, dodgeVec, false, 0, true);
        ComboManager.performFeint(player);
        ClientCombatState state = ComboManager.getState(player);
        if (state != null) {
            state.isDashing = true;
            state.isRolling = false;
            state.dashStartTick = player.tickCount;
            if (!player.onGround()) {
                state.hasPerformedAirDash = true;
                state.hasJumpedFromGround = true;
            }
        }
        IsDodgingData dodging = player.getData(ModDataAttachments.IS_DODGING);
        dodging.setDodging(true);
        PacketDistributor.sendToServer(
                new C2S_PacketTriggerPlayerDodge(dodging, 0, dodgeVec.x, dodgeVec.y, dodgeVec.z),
                new CustomPacketPayload[0]);
    }


    public static void interruptAerialParkour(Player player) {
        if (player == null) {
            return;
        }
        ClientCombatState state = ComboManager.getState(player);
        if (state != null) {
            state.isDashing = false;
            state.isRolling = false;
            state.dashStartTick = -1;
            state.rollStartTick = -1;
            state.vaultAnimStartTick = -1;
            state.hasJumpedFromGround = true;
            Animator.cancelAnimation(player, PlayerAnimator.ACTION_LAYER);
            IsDodgingData dodging = player.getData(ModDataAttachments.IS_DODGING);
            if (dodging.getIsDodging()) {
                dodging.setDodging(false);
                PacketDistributor.sendToServer(
                        new C2S_PacketTriggerPlayerDodge(dodging, 0, 0.0D, 0.0D, 0.0D),
                        new CustomPacketPayload[0]);
            }
        }
    }

    private static boolean shouldDodgeDamage(DamageSource source) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return false;
        }
        if (source.is(DamageTypeTags.BYPASSES_ARMOR)
                && !source.is(DamageTypes.MAGIC)
                && (source.is(DamageTypes.STARVE) || source.is(DamageTypes.DROWN))) {
            return false;
        }
        return true;
    }

    private static Vec3 calculateDodgeVector(Player player, boolean isDash) {
        return PunchyTrailBridge.calculateDodgeVector(player, isDash);
    }

    public static boolean canDash(Player player) {
        if (PlayerHelper.isFlying(player)) {
            return false;
        }
        StancesData stances = ItemHelper.getStances(player.getMainHandItem());
        if (stances == null) {
            return false;
        }
        if (player.level().isClientSide()) {
            ClientCombatState state = ComboManager.getState(player);
            if (state != null) {
                if (CombatHelper.isInActiveHitbox(player)) {
                    return false;
                }
                if (!player.onGround() && state.hasPerformedAirDash) {
                    return false;
                }
            }
            if (parkourCooldown > 0) {
                return false;
            }
        }
        return !PlayerHelper.isDodging(player)
                && !player.isPassenger()
                && !PlayerHelper.isFlying(player)
                && !player.hasEffect(ModMobEffects.STAGGER);
    }

    public static void performKickOff(Player player, LivingEntity target) {
        IsInvulnerableData invuln = player.getData(ModDataAttachments.IS_INVULNERABLE);
        invuln.setInvulnerable(true);
        PacketDistributor.sendToServer(
                new C2S_PacketSetInvulnerable(invuln, 5),
                new CustomPacketPayload[0]);

        Vec3 dir = target.position().subtract(player.position()).normalize();
        Vec3 launch = dir.scale(-0.6D).add(0.0D, 0.4D, 0.0D);
        player.setNoGravity(false);
        player.setDeltaMovement(launch);

        StancesData stances = ItemHelper.getStances(player.getMainHandItem());
        String anim = (stances != null && stances.getOnKickOff(player) != null)
                ? stances.getOnKickOff(player)
                : "kick_off";
        Animator.playAnimation(player, anim, 1.0F, false);

        Vec3 hitVec = dir.scale(0.5D).add(0.0D, 0.2D, 0.0D);
        PacketDistributor.sendToServer(
                new C2S_PacketParkourHit(target.getId(), hitVec.x, hitVec.y, hitVec.z, 2.0F),
                new CustomPacketPayload[0]);

        if (player.isInWater()) {
            player.playSound(SoundEvents.BUBBLE_COLUMN_UPWARDS_INSIDE, 1.0F, 1.2F);
        } else {
            player.playSound(SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.0F, 1.2F);
        }

        if (target instanceof Creeper creeper) {
            creeper.setSwellDir(-1);
            ((CreeperAccessor) creeper).setSwell(0);
        }

        ClientCombatState state = ComboManager.getState(player);
        if (state != null) {
            state.hasPerformedAirRoll = false;
            state.hasPerformedAirDash = false;
            state.hasJumpedFromGround = true;
        }
    }

    public static void performVault(Player player, LivingEntity target) {
        float leftImpulse = ClientUtils.getLeftImpulse();
        float forwardImpulse = ClientUtils.getForwardImpulse();
        String anim = "roll_front";
        float tiltX = 0.0F;
        float tiltZ = 0.0F;
        if (Math.abs(leftImpulse) > Math.abs(forwardImpulse)) {
            tiltX = leftImpulse > 0.0F ? 1.0F : -1.0F;
        } else {
            tiltZ = 1.0F;
        }

        float rad = player.getYRot() * 0.017453292F;
        float fwdX = (float) (-Math.sin(rad));
        float fwdZ = (float) Math.cos(rad);
        float rightX = (float) Math.cos(rad);
        float rightZ = (float) Math.sin(rad);

        if (leftImpulse == 0.0F && forwardImpulse == 0.0F) {
            forwardImpulse = 1.0F;
            tiltZ = 1.0F;
        }

        double vx = forwardImpulse * fwdX + leftImpulse * rightX;
        double vz = forwardImpulse * fwdZ + leftImpulse * rightZ;
        Vec3 launch = new Vec3(vx, 0.0D, vz).normalize().scale(0.8D).add(0.0D, 0.4D, 0.0D);
        player.setNoGravity(false);
        player.setDeltaMovement(launch);

        StancesData stances = ItemHelper.getStances(player.getMainHandItem());
        if (stances != null && stances.getOnVault(player) != null) {
            anim = stances.getOnVault(player);
        }
        Animator.playAnimation(player, anim, 1.0F, false);

        Vec3 dir = target.position().subtract(player.position()).normalize();
        Vec3 hitVec = dir.scale(0.5D).add(0.0D, 0.2D, 0.0D);
        PacketDistributor.sendToServer(
                new C2S_PacketParkourHit(target.getId(), hitVec.x, hitVec.y, hitVec.z, 2.0F),
                new CustomPacketPayload[0]);

        if (player.isInWater()) {
            player.playSound(SoundEvents.BUBBLE_COLUMN_UPWARDS_INSIDE, 1.0F, 1.5F);
        } else {
            player.playSound(SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.0F, 1.5F);
        }

        ClientCombatState state = ComboManager.getState(player);
        if (state != null) {
            state.hasPerformedAirRoll = false;
            state.hasPerformedAirDash = false;
            state.vaultTiltX = tiltX;
            state.vaultTiltZ = tiltZ;
            state.vaultAnimStartTick = player.tickCount;
            state.hasJumpedFromGround = true;
        }
    }

    public static boolean canGrappleTarget(LivingEntity target) {
        return PunchyTrailBridge.canGrappleTarget(target);
    }
}
