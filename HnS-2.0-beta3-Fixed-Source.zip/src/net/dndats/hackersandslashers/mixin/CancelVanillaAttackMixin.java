package net.dndats.hackersandslashers.mixin;

import net.dndats.api.animations.PlayerAnimator;
import net.dndats.hackersandslashers.datapacks.enums.ItemCategory;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.BladeTracker;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.ClientCombatState;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.ComboManager;
import net.dndats.hackersandslashers.utils.helper.Animator;
import net.dndats.hackersandslashers.utils.helper.EntityHelper;
import net.dndats.hackersandslashers.utils.helper.ItemHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = Minecraft.class, priority = 900)
public abstract class CancelVanillaAttackMixin {
    @Unique
    @Inject(method = {"startAttack"}, at = {@At("HEAD")}, cancellable = true)
    private void HnS$cancelAttackIfCooldownLow(CallbackInfoReturnable<Boolean> cir) {
        if (cir.isCancelled()) return;
        Minecraft mc = (Minecraft) (Object) this;
        LocalPlayer player = mc.player;
        if (player == null) return;
        if (player.isBlocking() && ItemHelper.isHoldingCombatItem(player)) {
            this.hns$triggerCombo();
            cir.setReturnValue(false);
            cir.cancel();
            return;
        }
        if (!ItemHelper.isHoldingCombatItem(player)) return;
        ItemCategory category = ItemHelper.getItemCategory(player.getMainHandItem());
        boolean isBlockHit = mc.hitResult != null && mc.hitResult.getType() == HitResult.Type.BLOCK;
        Entity hitEntity = mc.hitResult instanceof EntityHitResult ehr ? ehr.getEntity() : null;
        boolean nonCombat = EntityHelper.isDecorativeOrNonCombatEntity(hitEntity);
        if (ItemHelper.isHoldingCombatItem(player)) {
            if (nonCombat) {
                ClientCombatState state = ComboManager.getState(player);
                if (state.currentMoveId != null || state.attackSlowdownTicks > 0) {
                    Animator.cancelAnimation(player, PlayerAnimator.ATTACK_LAYER);
                    BladeTracker.forceStopAttack();
                    state.currentMoveId = null;
                    state.attackSlowdownTicks = 0;
                }
                if (state.isPowerAttackCharging) {
                    Animator.cancelAnimation(player, PlayerAnimator.ACTION_LAYER);
                    state.resetCharge();
                }
                return;
            }
            boolean isNextPower = ComboManager.getState(player).isNextAttackPowerAttack;
            if ((category.equals(ItemCategory.WEAPON_TOOL) || category.equals(ItemCategory.TOOL)) && isBlockHit && !isNextPower) {
                return;
            }
            this.hns$triggerCombo();
            cir.setReturnValue(false);
            cir.cancel();
        }
    }

    @Unique
    private void hns$triggerCombo() {
        Minecraft mc = (Minecraft) (Object) this;
        if (ComboManager.getState(mc.player).isNextAttackPowerAttack) {
            ComboManager.powerAttackBehavior();
            ComboManager.getState(mc.player).isNextAttackPowerAttack = false;
        } else {
            ComboManager.comboBehavior();
        }
    }
}
