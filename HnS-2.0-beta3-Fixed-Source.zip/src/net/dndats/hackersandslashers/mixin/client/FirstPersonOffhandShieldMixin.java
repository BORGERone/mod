package net.dndats.hackersandslashers.mixin.client;

import com.zigythebird.playeranimcore.animation.AnimationController;
import net.dndats.api.animations.HnSPlayerActionController;
import net.dndats.api.animations.HnSPlayerAttackController;
import net.dndats.api.animations.HnSPlayerDefenseController;
import net.dndats.api.animations.HnSPlayerFirstPersonPoseController;
import net.dndats.api.animations.OffhandShieldPoseModifier;
import net.minecraft.client.player.AbstractClientPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(
    value = {
        HnSPlayerFirstPersonPoseController.class,
        HnSPlayerDefenseController.class,
        HnSPlayerAttackController.class,
        HnSPlayerActionController.class
    },
    remap = false
)
public class FirstPersonOffhandShieldMixin {
    @Inject(method = {"<init>"}, at = {@At("RETURN")}, remap = false)
    private void hns$attachOffhandShieldModifier(AbstractClientPlayer player, CallbackInfo ci) {
        ((AnimationController) (Object) this).addModifierBefore(new OffhandShieldPoseModifier(player));
    }
}
