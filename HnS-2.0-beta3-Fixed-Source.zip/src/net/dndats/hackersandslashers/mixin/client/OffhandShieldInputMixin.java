package net.dndats.hackersandslashers.mixin.client;

import net.dndats.hackersandslashers.compat.punchy.PunchyClientBridge;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = Minecraft.class, priority = 1500)
public class OffhandShieldInputMixin {
    @Inject(method = {"handleKeybinds"}, at = {@At("TAIL")})
    private void hns$forceOffhandShieldBlock(CallbackInfo ci) {
        PunchyClientBridge.tryForceOffhandShieldBlock((Minecraft) (Object) this);
    }
}
