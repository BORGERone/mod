package net.dndats.hackersandslashers.mixin.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonMode;
import net.dndats.hackersandslashers.config.ClientConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = PlayerRenderer.class, priority = 2050)
public class PlayerRendererFovMixin {
    private Matrix4f hackersandslashers$savedProjectionMatrix;

    @Inject(method = {"render(Lnet/minecraft/client/player/AbstractClientPlayer;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"}, at = {@At("HEAD")})
    private void hackersandslashers$applyFixedFovOnFpAnimation(AbstractClientPlayer player, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int packedLight, CallbackInfo ci) {
        if (ClientConfig.isFirstPersonAnimationsDisabled()) return;
        if (FirstPersonMode.isFirstPersonPass() && player == Minecraft.getInstance().player) {
            if (buffer instanceof MultiBufferSource.BufferSource buf) {
                buf.endBatch();
            }
            GameRenderer gameRenderer = Minecraft.getInstance().gameRenderer;
            this.hackersandslashers$savedProjectionMatrix = new Matrix4f(RenderSystem.getProjectionMatrix());
            double fov = ClientConfig.FIRST_PERSON_ANIMATION_FOV.get();
            Matrix4f proj = gameRenderer.getProjectionMatrix(fov);
            gameRenderer.resetProjectionMatrix(proj);
        }
    }

    @Inject(method = {"render(Lnet/minecraft/client/player/AbstractClientPlayer;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"}, at = {@At("RETURN")})
    private void hackersandslashers$restoreProjectionMatrixAfterFpAnimation(AbstractClientPlayer player, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int packedLight, CallbackInfo ci) {
        if (this.hackersandslashers$savedProjectionMatrix != null) {
            if (buffer instanceof MultiBufferSource.BufferSource buf) {
                buf.endBatch();
            }
            Minecraft.getInstance().gameRenderer.resetProjectionMatrix(this.hackersandslashers$savedProjectionMatrix);
            this.hackersandslashers$savedProjectionMatrix = null;
        }
    }
}
