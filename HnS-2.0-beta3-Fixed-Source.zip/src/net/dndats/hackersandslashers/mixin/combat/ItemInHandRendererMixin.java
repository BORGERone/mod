package net.dndats.hackersandslashers.mixin.combat;

import com.mojang.blaze3d.vertex.PoseStack;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import net.dndats.hackersandslashers.client.animations.ClientMobAnimationManager;
import net.dndats.hackersandslashers.client.rendering.WeaponRenderTransformHelper;
import net.dndats.hackersandslashers.client.utils.InventoryRenderFlag;
import net.dndats.hackersandslashers.client.utils.ShaderHelper;
import net.dndats.hackersandslashers.compat.punchy.PunchyTrailBridge;
import net.dndats.hackersandslashers.config.ClientConfig;
import net.dndats.hackersandslashers.datapacks.enums.HitType;
import net.dndats.hackersandslashers.datapacks.enums.UsedHand;
import net.dndats.hackersandslashers.datapacks.loaders.MoveDefinitionLoader;
import net.dndats.hackersandslashers.datapacks.models.MoveDefinition;
import net.dndats.hackersandslashers.datapacks.models.MovesetActionData;
import net.dndats.hackersandslashers.datapacks.models.WeaponComboStep;
import net.dndats.hackersandslashers.datapacks.models.WeaponHitboxData;
import net.dndats.hackersandslashers.datapacks.models.WeaponStatOverride;
import net.dndats.hackersandslashers.datapacks.models.WeaponTrailOverride;
import net.dndats.hackersandslashers.debug.DebugManager;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.AnimationTimelineCache;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.BladeTracker;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.RemoteAttackManager;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.TrailSystem;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.WeaponAnalyzerCache;
import net.dndats.hackersandslashers.utils.helper.ItemHelper;
import net.dndats.hackersandslashers.utils.helper.PlayerHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonMode;

@Mixin(ItemInHandRenderer.class)
public class ItemInHandRendererMixin {
    @Inject(method = {"renderItem"}, at = {@At("HEAD")})
    private void HnS$captureWeaponPosition(LivingEntity entity, ItemStack stack, ItemDisplayContext displayContext, boolean leftHand, PoseStack poseStack, MultiBufferSource buffer, int seed, CallbackInfo ci) {
        if (displayContext != ItemDisplayContext.FIRST_PERSON_RIGHT_HAND
                && displayContext != ItemDisplayContext.FIRST_PERSON_LEFT_HAND
                && displayContext != ItemDisplayContext.THIRD_PERSON_RIGHT_HAND
                && displayContext != ItemDisplayContext.THIRD_PERSON_LEFT_HAND) {
            return;
        }
        if (entity != Minecraft.getInstance().player || stack.isEmpty()) return;
        boolean isMainhand = stack == entity.getMainHandItem();
        boolean isOffhand = stack == entity.getOffhandItem();
        if (!isMainhand && !isOffhand) return;
        if ((leftHand && !isOffhand) || (!leftHand && !isMainhand)) return;

        try {
            Matrix4f pose = poseStack.last().pose();
            Vec3 camPos = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
            WeaponAnalyzerCache.WeaponAnalysis analysis = WeaponAnalyzerCache.getAnalysis(stack);
            float effectiveLen = analysis.modelLength * analysis.modelScale;
            WeaponStatOverride override = ItemHelper.resolvePresetStats(stack);
            WeaponHitboxData hitboxData = override != null ? override.hitboxData : null;
            Vector3f startLocal = resolveHitboxStart(hitboxData);
            Vector3f endLocal = resolveHitboxEnd(hitboxData, effectiveLen);
            float midY = (startLocal.y + endLocal.y) / 2.0F;

            Vector4f midView = new Vector4f(0.0F, midY, 0.0F, 1.0F).mul(pose);
            Vector4f baseView = new Vector4f(startLocal.x, startLocal.y, startLocal.z, 1.0F).mul(pose);
            Vector4f tipView = new Vector4f(endLocal.x, endLocal.y, endLocal.z, 1.0F).mul(pose);

            Vector3f midWorld = PunchyTrailBridge.viewOrWorldToWorld(midView, camPos, displayContext);
            Vector3f baseWorld = PunchyTrailBridge.viewOrWorldToWorld(baseView, camPos, displayContext);
            Vector3f tipWorld = PunchyTrailBridge.viewOrWorldToWorld(tipView, camPos, displayContext);

            float maxDist = BladeTracker.isDetached ? 64.0F : 10.0F;
            if (midWorld.distance(new Vector3f((float) entity.getX(), (float) entity.getY(), (float) entity.getZ())) > maxDist) {
                return;
            }
            if (isMainhand) {
                BladeTracker.currentMainHandWeaponTipPosition.set(midWorld);
                BladeTracker.currentMainHandWeaponBasePosition.set(baseWorld);
                BladeTracker.currentMainHandWeaponActualTipPosition.set(tipWorld);
            } else if (isOffhand) {
                BladeTracker.currentOffhandWeaponTipPosition.set(midWorld);
                BladeTracker.currentOffhandWeaponBasePosition.set(baseWorld);
                BladeTracker.currentOffhandWeaponActualTipPosition.set(tipWorld);
            }
        } catch (Exception ignored) {}
    }

    @Inject(method = {"renderItem"}, at = {@At("HEAD")})
    private void HnS$captureTrail(LivingEntity entity, ItemStack stack, ItemDisplayContext displayContext, boolean leftHand, PoseStack poseStack, MultiBufferSource buffer, int seed, CallbackInfo ci) {
        if (displayContext != ItemDisplayContext.FIRST_PERSON_RIGHT_HAND
                && displayContext != ItemDisplayContext.FIRST_PERSON_LEFT_HAND
                && displayContext != ItemDisplayContext.THIRD_PERSON_RIGHT_HAND
                && displayContext != ItemDisplayContext.THIRD_PERSON_LEFT_HAND) {
            return;
        }
        boolean isAttacking = false;
        boolean isOffhand = false;
        BladeTracker.SwingDirection direction = BladeTracker.SwingDirection.ANY;
        HitType shape = HitType.NONE;

        if (entity instanceof Player player) {
            if (player == Minecraft.getInstance().player) {
                isAttacking = BladeTracker.isEffectivelyAttacking();
                isOffhand = PlayerHelper.wasLastAttackLeftHanded(player);
                direction = BladeTracker.getCurrentSwingDirection();
                shape = BladeTracker.getCurrentAttackShape();
            } else {
                RemoteAttackManager.RemoteTrail remote = RemoteAttackManager.getTrail(player.getId());
                if (remote != null) {
                    isAttacking = true;
                    isOffhand = remote.isOffhand;
                    direction = remote.direction;
                    shape = remote.shape;
                }
            }
        } else if (entity instanceof Mob mob) {
            ClientMobAnimationManager.MobAnimationInfo info = ClientMobAnimationManager.getAttackInfo(mob);
            if (info.animationId != null && info.state.isStarted()) {
                MoveDefinition move = MoveDefinitionLoader.INSTANCE.getMove(info.animationId);
                if (move != null && move.trailParticle != null && move.trailBones.isEmpty()) {
                    Float startWin = move.attackWindowStart;
                    Float endWin = move.attackWindowEnd;
                    if (startWin == null || endWin == null) {
                        String animKey = move.animation.replace("hackersandslashers:", "").replace("mob_animations/", "");
                        TreeMap<Float, String> timeline = AnimationTimelineCache.getTimeline(animKey);
                        if (timeline != null) {
                            for (Map.Entry<Float, String> entry : timeline.entrySet()) {
                                if (entry.getValue().contains("attack_window_start") && startWin == null) startWin = entry.getKey();
                                if (entry.getValue().contains("attack_window_end") && endWin == null) endWin = entry.getKey();
                            }
                        }
                    }
                    boolean inWindow = true;
                    if (startWin != null || endWin != null) {
                        float sec = info.state.getAccumulatedTime() / 1000.0F;
                        if (startWin != null && sec < startWin) inWindow = false;
                        if (endWin != null && sec > endWin) inWindow = false;
                    }
                    if (inWindow) {
                        isAttacking = true;
                        isOffhand = false;
                        direction = BladeTracker.SwingDirection.ANY;
                        shape = HitType.SLASH;
                    }
                }
            }
        }

        if (!isAttacking) return;

        boolean bothHands = false;
        if (entity instanceof Player player) {
            if (player == Minecraft.getInstance().player) {
                bothHands = BladeTracker.isCachedBothHands();
            } else {
                WeaponComboStep step = PlayerHelper.lastComboStep(player);
                if (step != null && step.usedHand != null) {
                    bothHands = step.usedHand.equals(UsedHand.BOTH);
                }
            }
        }
        if (!bothHands && leftHand != isOffhand) return;

        WeaponStatOverride override = ItemHelper.resolvePresetStats(stack);
        if (override == null) return;
        WeaponHitboxData hitboxData = override.hitboxData;
        WeaponAnalyzerCache.WeaponAnalysis analysis = WeaponAnalyzerCache.getAnalysis(stack);
        float effectiveLen = analysis.modelLength * analysis.modelScale;

        if (shape == HitType.SLASH || shape == HitType.SMASH || shape == HitType.SLAM || shape == HitType.BLUNT) {
            boolean invert = false;
            if (shape != HitType.SLAM) {
                invert = !direction.equals(BladeTracker.SwingDirection.RIGHT);
                if (bothHands && leftHand) invert = !invert;
            }
            if (BladeTracker.getCurrentAttackShape() == HitType.NONE) return;

            Vector3f hitboxStartLocal = resolveHitboxStart(hitboxData);
            Vector3f hitboxEndLocal = resolveHitboxEnd(hitboxData, effectiveLen);
            Vector3f trailStartLocal = resolveTrailStart(hitboxData, analysis, effectiveLen);
            Vector3f trailEndLocal = resolveTrailEnd(hitboxData, analysis, effectiveLen);

            Matrix4f pose = poseStack.last().pose();
            Vec3 camPos = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();

            Vector4f tStart4 = new Vector4f(trailStartLocal, 1.0F).mul(pose);
            Vector4f tEnd4 = new Vector4f(trailEndLocal, 1.0F).mul(pose);
            Vector3f trailStartWorld = PunchyTrailBridge.viewOrWorldToWorld(tStart4, camPos, displayContext);
            Vector3f trailEndWorld = PunchyTrailBridge.viewOrWorldToWorld(tEnd4, camPos, displayContext);

            Vector4f hStart4 = new Vector4f(hitboxStartLocal, 1.0F).mul(pose);
            Vector4f hEnd4 = new Vector4f(hitboxEndLocal, 1.0F).mul(pose);
            Vector3f hitboxStartWorld = PunchyTrailBridge.viewOrWorldToWorld(hStart4, camPos, displayContext);
            Vector3f hitboxEndWorld = PunchyTrailBridge.viewOrWorldToWorld(hEnd4, camPos, displayContext);

            if (entity == Minecraft.getInstance().player) {
                float maxDist = BladeTracker.isDetached ? 64.0F : 3.5F;
                if (hitboxStartWorld.distance(new Vector3f((float) entity.getX(), (float) entity.getY(), (float) entity.getZ())) > maxDist) {
                    return;
                }
            }

            int color = analysis.color;
            double attackSpeed = 4.0;
            if (entity.getAttributes().hasAttribute(Attributes.ATTACK_SPEED)) {
                attackSpeed = entity.getAttributeValue(Attributes.ATTACK_SPEED);
            }
            float speedRatio = (float) (attackSpeed / 4.0);
            long duration = Math.max(200L, (long) (250L / Math.max(1.0F, speedRatio)));
            WeaponTrailOverride trailOverride = null;

            if (entity instanceof Player player) {
                if (player == Minecraft.getInstance().player) {
                    trailOverride = BladeTracker.getCachedTrailParticle();
                } else if (override != null) {
                    WeaponComboStep powerStep = null;
                    if (override.moveset != null) {
                        MovesetActionData action = override.moveset.actions.get("hackersandslashers:hns_weapon_attack_event");
                        if (action != null) {
                            int idx = PlayerHelper.getComboIndex(player);
                            boolean dual = ItemHelper.isSameStyle(player.getMainHandItem(), player.getOffhandItem());
                            List<WeaponComboStep> list = (dual && !action.dualHanded.isEmpty()) ? action.dualHanded : action.oneHanded;
                            if (!list.isEmpty()) {
                                WeaponComboStep cur = list.get(idx % list.size());
                                if (cur != null && cur.onPowerAttack != null) powerStep = cur.onPowerAttack;
                            }
                        }
                    }
                    WeaponComboStep lastStep = PlayerHelper.lastComboStep(player);
                    if (shape == HitType.SMASH && powerStep != null) trailOverride = powerStep.trailParticle;
                    else if (lastStep != null) trailOverride = lastStep.trailParticle;
                }
            } else if (entity instanceof Mob mob) {
                ClientMobAnimationManager.MobAnimationInfo info = ClientMobAnimationManager.getAttackInfo(mob);
                if (info.animationId != null) {
                    MoveDefinition move = MoveDefinitionLoader.INSTANCE.getMove(info.animationId);
                    if (move != null && move.trailParticle != null) trailOverride = move.trailParticle;
                }
            }

            if (BladeTracker.isDetached) {
                Vector3f center = new Vector3f(hitboxStartWorld).add(hitboxEndWorld).mul(0.5F);
                Vector3f prevCenter = leftHand ? BladeTracker.lastOffhandDetachedCenter : BladeTracker.lastMainHandDetachedCenter;
                if (prevCenter == null) prevCenter = new Vector3f(center);
                Vector3f delta = new Vector3f(center).sub(prevCenter);
                if (delta.lengthSquared() > 1.0E-4F) {
                    delta.normalize();
                    Vector3f up = new Vector3f(0.0F, 1.0F, 0.0F);
                    if (Math.abs(delta.dot(up)) > 0.99F) up.set(1.0F, 0.0F, 0.0F);
                    Vector3f side = new Vector3f(delta).cross(up).normalize();
                    float radius = (hitboxData != null && hitboxData.hitboxRadius != null) ? hitboxData.hitboxRadius : 0.8F;
                    trailStartWorld = new Vector3f(center).add(new Vector3f(side).mul(radius));
                    trailEndWorld = new Vector3f(center).sub(new Vector3f(side).mul(radius));
                    if (Boolean.TRUE.equals(ClientConfig.DEBUG_MOB_DETECTION.get())) {
                        DebugManager.addDebugLine(trailStartWorld, trailEndWorld, 2);
                    }
                } else {
                    trailStartWorld = new Vector3f(center);
                    trailEndWorld = new Vector3f(center);
                }
                if (leftHand) BladeTracker.lastOffhandDetachedCenter = center;
                else BladeTracker.lastMainHandDetachedCenter = center;
            }

            Float thickness = hitboxData != null ? hitboxData.getTrailThickness() : null;
            TrailSystem.recordPoint(entity.getId(), trailStartWorld, trailEndWorld, color, invert, leftHand, duration, trailOverride, thickness, shape);
            if (entity == Minecraft.getInstance().player) {
                BladeTracker.updateBladePositions(hitboxStartWorld, hitboxEndWorld, leftHand);
            }
        } else if (shape == HitType.THRUST) {
            Vector3f hStartLocal = resolveHitboxStart(hitboxData);
            Vector3f hEndLocal = resolveHitboxEnd(hitboxData, effectiveLen);
            Matrix4f pose = poseStack.last().pose();
            Vec3 camPos = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
            Vector4f hStart4 = new Vector4f(hStartLocal, 1.0F).mul(pose);
            Vector4f hEnd4 = new Vector4f(hEndLocal, 1.0F).mul(pose);
            Vector3f hStartWorld = PunchyTrailBridge.viewOrWorldToWorld(hStart4, camPos, displayContext);
            Vector3f hEndWorld = PunchyTrailBridge.viewOrWorldToWorld(hEnd4, camPos, displayContext);
            if (entity == Minecraft.getInstance().player) {
                float maxDist = BladeTracker.isDetached ? 64.0F : 3.5F;
                if (hStartWorld.distance(new Vector3f((float) entity.getX(), (float) entity.getY(), (float) entity.getZ())) > maxDist) {
                    return;
                }
                BladeTracker.updateBladePositions(hStartWorld, hEndWorld, leftHand);
            } else if (entity instanceof Player player) {
                WeaponComboStep step = PlayerHelper.lastComboStep(player);
                WeaponTrailOverride trailOverride = step != null ? step.trailParticle : null;
                float radius = (hitboxData != null && hitboxData.hitboxRadius != null) ? hitboxData.hitboxRadius : 0.3F;
                TrailSystem.spawnThrustTrail(player, stack, hStartWorld, hEndWorld, radius, leftHand, trailOverride);
                TrailSystem.updateThrustTrail(player.getId(), hStartWorld, hEndWorld, radius, leftHand);
            }
        }
    }

    @Inject(method = {"renderItem"}, at = {@At("HEAD")})
    private void HnS$applyWeaponTransforms(LivingEntity entity, ItemStack stack, ItemDisplayContext displayContext, boolean leftHand, PoseStack poseStack, MultiBufferSource buffer, int seed, CallbackInfo ci) {
        if (displayContext != ItemDisplayContext.FIRST_PERSON_RIGHT_HAND
                && displayContext != ItemDisplayContext.FIRST_PERSON_LEFT_HAND
                && displayContext != ItemDisplayContext.THIRD_PERSON_RIGHT_HAND
                && displayContext != ItemDisplayContext.THIRD_PERSON_LEFT_HAND) {
            return;
        }
        if (stack.isEmpty()) return;
        if (!PunchyTrailBridge.shouldApplyFirstPersonWeaponTransform(displayContext)) return;
        boolean isFirstPerson = !InventoryRenderFlag.isRenderingInventory
                && !ShaderHelper.isShadowPass()
                && entity == Minecraft.getInstance().player
                && (displayContext == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND
                    || displayContext == ItemDisplayContext.FIRST_PERSON_LEFT_HAND
                    || FirstPersonMode.isFirstPersonPass()
                    || Minecraft.getInstance().options.getCameraType().isFirstPerson());
        WeaponRenderTransformHelper.applyTransforms(entity, stack, leftHand, poseStack, isFirstPerson);
    }

    private static Vector3f resolveHitboxStart(WeaponHitboxData data) {
        float mul = (data != null && data.rangeMultiplier != null) ? data.rangeMultiplier : 1.0F;
        if (data != null) {
            Vector3f v = data.getHitboxStart();
            if (v != null) return new Vector3f(v.x, v.y * mul, v.z);
        }
        return new Vector3f(0.0F, 0.0F, 0.0F);
    }

    private static Vector3f resolveHitboxEnd(WeaponHitboxData data, float len) {
        float mul = (data != null && data.rangeMultiplier != null) ? data.rangeMultiplier : 1.0F;
        if (data != null) {
            Vector3f v = data.getHitboxEnd();
            if (v != null) return new Vector3f(v.x, v.y * mul, v.z);
        }
        return new Vector3f(0.0F, len * mul, 0.0F);
    }

    private static Vector3f resolveTrailStart(WeaponHitboxData data, WeaponAnalyzerCache.WeaponAnalysis analysis, float len) {
        float mul = (data != null && data.rangeMultiplier != null) ? data.rangeMultiplier : 1.0F;
        if (data != null) {
            Vector3f v = data.getTrailStart();
            if (v != null) return new Vector3f(v.x, v.y * mul, v.z);
        }
        return new Vector3f(0.0F, len * analysis.bladeStartRatio * mul, 0.0F);
    }

    private static Vector3f resolveTrailEnd(WeaponHitboxData data, WeaponAnalyzerCache.WeaponAnalysis analysis, float len) {
        float mul = (data != null && data.rangeMultiplier != null) ? data.rangeMultiplier : 1.0F;
        if (data != null) {
            Vector3f v = data.getTrailEnd();
            if (v != null) return new Vector3f(v.x, v.y * mul, v.z);
        }
        return new Vector3f(0.0F, len * analysis.bladeEndRatio * mul, 0.0F);
    }
}
