package net.dndats.hackersandslashers.mixin.combat;

import net.dndats.hackersandslashers.config.ClientConfig;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.BladeTracker;
import net.dndats.hackersandslashers.utils.helper.PlayerHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public class VanillaEntitySwingMixin {
    @Inject(method = {"swing(Lnet/minecraft/world/InteractionHand;Z)V"}, at = {@At("HEAD")}, cancellable = true)
    private void hns$cancelVanillaSwingAnimation(InteractionHand hand, boolean updateSelf, CallbackInfo ci) {
        if (ClientConfig.isFirstPersonAnimationsDisabled()) return;
        if (!((LivingEntity) (Object) this instanceof Player player)) return;
        if (player == Minecraft.getInstance().player
                && PlayerHelper.lastComboStep(player) != null
                && BladeTracker.isEffectivelyAttacking()) {
            ci.cancel();
        }
    }
}
