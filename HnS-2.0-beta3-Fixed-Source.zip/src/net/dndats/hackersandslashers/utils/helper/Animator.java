package net.dndats.hackersandslashers.utils.helper;

import com.zigythebird.playeranim.animation.PlayerAnimResources;
import com.zigythebird.playeranim.animation.PlayerAnimationController;
import com.zigythebird.playeranim.api.PlayerAnimationAccess;
import com.zigythebird.playeranimcore.animation.layered.IAnimation;
import net.dndats.api.animations.HnSPlayerAttackController;
import net.dndats.api.animations.PlayerAnimator;
import net.dndats.api.helper.AnimationHelper;
import net.dndats.hackersandslashers.common.setup.ModKeybinds;
import net.dndats.hackersandslashers.datapacks.loaders.WeaponStatOverrideLoader;
import net.dndats.hackersandslashers.datapacks.models.StancesData;
import net.dndats.hackersandslashers.datapacks.models.WeaponStatOverride;
import net.dndats.hackersandslashers.impl.combat.mechanics.combo.ComboManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class Animator {
    public static void playAnimation(Player player, String animName, float speed, boolean mirrored) {
        AnimationHelper.playAnimation(player, animName, speed, mirrored);
    }

    public static void playAnimation(Player player, String animName, float speed, boolean mirrored, ResourceLocation layer) {
        AnimationHelper.playAnimation(player, animName, speed, mirrored, layer);
    }

    public static void playActionAnimation(Player player, String animName, float speed, boolean mirrored) {
        AnimationHelper.playAnimation(player, animName, speed, mirrored, PlayerAnimator.ACTION_LAYER);
    }

    public static void playAttackAnimation(Player player, String animName, float speed, boolean mirrored) {
        AnimationHelper.playAnimation(player, animName, speed, mirrored, PlayerAnimator.ATTACK_LAYER);
    }

    public static void setAttackAnimationSpeed(Player player, float speed) {
        if (!(player instanceof AbstractClientPlayer clientPlayer)) {
            return;
        }
        IAnimation layer = PlayerAnimationAccess.getPlayerAnimationLayer(clientPlayer, PlayerAnimator.ATTACK_LAYER);
        if (layer instanceof HnSPlayerAttackController attackController) {
            attackController.speedModifier.setDynamicSpeed(speed);
        }
    }

    public static void cancelAnimation(Player player, ResourceLocation layer) {
        AnimationHelper.cancelAnimation(player, layer);
    }

    public static boolean isAttackAnimationPlaying(Player player) {
        PlayerAnimationController ctrl = (PlayerAnimationController) PlayerAnimationAccess.getPlayerAnimationLayer(
                (AbstractClientPlayer) player, PlayerAnimator.ATTACK_LAYER);
        return ctrl != null && ctrl.getCurrentRawAnimation() != null;
    }

    public static boolean isDefenseAnimationPlaying(Player player) {
        PlayerAnimationController ctrl = (PlayerAnimationController) PlayerAnimationAccess.getPlayerAnimationLayer(
                (AbstractClientPlayer) player, PlayerAnimator.DEFENSE_LAYER);
        return ctrl != null && ctrl.getCurrentRawAnimation() != null;
    }

    public static String getParryAnimationString(Player player) {
        WeaponStatOverride stats = WeaponStatOverrideLoader.INSTANCE.getOverride(
                BuiltInRegistries.ITEM.getKey(player.getMainHandItem().getItem()));
        if (stats == null) {
            stats = ItemHelper.resolvePresetStats(player.getMainHandItem());
        }
        if (stats != null && stats.stances != null) {
            boolean fp = Minecraft.getInstance().options.getCameraType().isFirstPerson();
            if (fp) {
                String explicit = stats.stances.getExplicitOnParry(player, true);
                if (explicit != null) {
                    return explicit;
                }
            }
            return stats.stances.getOnParry(player, false);
        }
        return null;
    }

    public static void playBreakFreeAnimation(Player player) {
        playAnimation(player, "break_free", 1.0F, false);
    }

    public static void playSheatheAnimation(Player player, String animName) {
        playAnimation(player, animName, 1.0F, false);
    }

    public static boolean isRegisteredAnimation(String animName) {
        if (animName == null || animName.isEmpty()) {
            return false;
        }
        try {
            ResourceLocation id = animName.contains(":")
                    ? ResourceLocation.parse(animName)
                    : ResourceLocation.fromNamespaceAndPath("hackersandslashers", animName);
            return PlayerAnimResources.hasAnimation(id);
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static String resolveDashAnimation(Player player) {
        StancesData stances = player != null ? ItemHelper.getStances(player.getMainHandItem()) : null;
        boolean isInAir = player != null && !player.onGround();
        String anim = null;
        if (stances != null && player != null) {
            anim = isInAir ? stances.getOnAirDash(player) : stances.getOnDash(player);
            if (anim == null && isInAir) {
                anim = stances.getOnDash(player);
            }
        }
        if (isRegisteredAnimation(anim)) {
            return anim;
        }
        if (isRegisteredAnimation("hackersandslashers:one_handed_dash")) {
            return "hackersandslashers:one_handed_dash";
        }
        if (isRegisteredAnimation("hackersandslashers:dash_front")) {
            return "hackersandslashers:dash_front";
        }
        if (isRegisteredAnimation("hackersandslashers:hns_greatsword_dash")) {
            return "hackersandslashers:hns_greatsword_dash";
        }
        return "one_handed_dash";
    }

    public static void playDashAnimation(Player player) {
        playAnimation(player, resolveDashAnimation(player), 1.0F, false);
    }

    public static void playPowerAttackChargeAnimation(Player player, String animName, boolean mirrored) {
        startPowerAttackChargingAnimation(player, animName, mirrored);
    }

    public static void playParryAnimation(Player player) {
        startBlockingAnimation(player);
    }

    public static void playBashAnimation(Player player) {
        StancesData offhandStances = ItemHelper.getStances(player.getOffhandItem());
        StancesData mainhandStances = ItemHelper.getStances(player.getMainHandItem());
        String anim = "hackersandslashers:bash";
        if (offhandStances != null && offhandStances.getOnBash(player) != null) {
            anim = offhandStances.getOnBash(player);
        } else if (mainhandStances != null && mainhandStances.getOnBash(player) != null) {
            anim = mainhandStances.getOnBash(player);
        }
        playAnimation(player, anim, 1.0F, false);
    }

    private static void startPowerAttackChargingAnimation(Player player, String animName, boolean mirrored) {
        playAnimation(player, animName, 1.0F, mirrored);
        ClientTickScheduler.scheduleIf(
                () -> {
                    if (Minecraft.getInstance().options.keyAttack.isDown()
                            && ComboManager.isChargingPowerAttack(player)
                            && !isAttackAnimationPlaying(player)) {
                        playAnimation(player, animName, 1.0F, mirrored);
                    }
                },
                5,
                () -> Minecraft.getInstance().level != null);
    }

    private static void startBlockingAnimation(Player player) {
        playAnimation(player, getParryAnimationString(player), 1.0F, false);
        ClientTickScheduler.scheduleIf(
                () -> {
                    if (ModKeybinds.PARRY.isDown()
                            && PlayerHelper.isParrying(player)
                            && !isDefenseAnimationPlaying(player)) {
                        playAnimation(player, getParryAnimationString(player), 1.0F, false);
                    }
                },
                5,
                () -> Minecraft.getInstance().level != null);
    }
}
