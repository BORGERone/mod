Settled Lands — Build 217 «player-corpse»
=========================================

Что нового
----------
Игрок, вселённый в NPC, теперь умирает «как NPC»:

1. При смерти вселённого игрока стоковый цикл уже оставляет труп на месте гибели —
   build 217 делает так, что этот труп ВЫГЛЯДИТ как тело, которым управлял игрок
   (модель и имя тела подставляются в профиль трупа в момент спавна).
2. Труп дальше ведёт себя стоково: его нельзя убить, его можно уложить в гроб
   (правый клик Coffin-item'ом), тащить на поводке и принести к маяку возрождения.
3. Как только гроб с таким телом оказывается у маяка и срабатывает СТОКОВОЕ
   воскрешение (игрок выходит из очереди чистилища и телепортируется к алтарю),
   build 217 тут же возвращает игрока в его тело: состояние вселения
   (модель/имя) восстанавливается, эффект бестелесности снимается, клиентам
   рассылается possession_state. Звук тотема + сообщение
   «Ваше тело возрождено — вы снова вселились в него.»

Граничные случаи
----------------
- Игрок уже вселился в кого-то другого, пока тело ждало у алтаря — авто-вселение
  НЕ перебивает текущее тело; приходит сообщение body_revived_busy.
- Изумруды у алтаря для тела игрока не требуются — как и в стоковом воскрешении
  игрока (reviveOwner). Изумрудная механика остаётся только для NPC-гробов (213/214).
- Инвентарь NPC (27 ячеек, NBT settledlands_inventory) сохраняется из момента
  вселения — при возврате в тело он снова доступен (Shift+ПКМ wand'ом, op-only).
- Маркер переживает смерть/респавн (перенос через PlayerEvent.Clone) и выход с сервера.
- Труп помечается settledlands_player_body (+model/name) в persistent-NBT.

Классы
------
Новый: dev/settledlands/npc/PlayerCorpsePossession.java (+ PendingBody record)
- onPlayerDeath (HIGHEST, до CorpseLifecycle): метка, если игрок вселён.
- onPlayerClone: перенос метки через смерть.
- onPlayerLogout: очистка временной карты.
- onCorpseJoin (EntityJoinLevelEvent): только труп этого тика (tickCount<=2),
  владелец читается из private поля ownerUuid через reflection; профиль трупа
  заменяется на тело NPC (setProfile+applyProfile — стоковый путь из сцен смерти).
- onServerTick (ServerTickEvent.Post): если игрок жив, не в очереди чистилища и
  имеет метку — авто-вселение (NBT settledlands_possess*, removeEffect(bodiless),
  PossessionClientSync.push, звук/сообщение).

Ничего из GuideNpc/NpcContent/GuideRenderer/PossessionSystem не пересобрано —
jar217 = jar216 + 2 новых класса + 2 lang-ключа + версия/описание в toml.
Стоковая механика чистилища/алтаря/очереди не тронута.

Ключи перевода (ru/en, +2)
--------------------------
message.settledlands.possession.body_revived
message.settledlands.possession.body_revived_busy

Проверки
--------
- javac (JDK 21, CP: jar216 classes + minecraft-compile + neoforge + bus/loader/fastutil/brigadier): 0 ошибок.
- unzip -Z1 diff против jar216: ровно +2 class-файла, остальное байт-идентично.

sha256 jar: e03a199617e4eec9ce15fa5de9e3d26e476d6e54b7eb0c45126901066dea0359
