Settled Lands — Build 224 «mixin-fix» (hotfix 223)
==================================================

223 не стартовал: краш «Sodium's config could not be found» — маскировка.
Реальная причина: в GuideCorpseKeepMixin @Redirect на discard() целил
owner=Entity, а байткод tickCorpseState инвокает discard() с
owner=GuideCorpseNpc (constant pool #325) → точка инъекции не найдена,
defaultRequire=1 → mixin apply падает на старте, дальше каскад.

Фикс: target исправлен на Ldev/settledlands/npc/GuideCorpseNpc;discard()V,
receiver-параметр хендлера — GuideCorpseNpc. Вся остальная механика 223
(keep-труп + queue-only ревайв + вещи тела) без изменений.
Старый jar 223 — удалить (стартап сломан).
sha256: 090151d4f5189cf17e55173f148466072493348a1812964f299fae98ff2aff2b
