package dev.settledlands.mixin;

import java.lang.reflect.Method;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.neoforged.neoforge.common.extensions.IEntityExtension;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import java.util.List;

import dev.settledlands.npc.GuideCorpseNpc;
import dev.settledlands.revival.PurgatoryData;

/**
 * Build 223 «corpse-keep»: помеченный труп-тело игрока (settledlands_player_body,
 * ставит PlayerCorpsePossession) должен жить как NPC-труп:
 *  - стоковый tickCorpseState дискардит труп, как только владелец оказался живым
 *    вне очереди чистилища (в т.ч. сам-выход через портал) — для трупа-тела это
 *    отключается: труп ждёт, пока его не воскресят у маяка;
 *  - reviveOwner у маяка не должен трогать владельца, который уже САМ вышел из
 *    чистилища (иначе игрока выдёргивает телепортом): для трупа-тела ревайв
 *    пропускается, если владельца нет в очереди чистилища.
 */
@Mixin(GuideCorpseNpc.class)
public abstract class GuideCorpseKeepMixin {

    private static Method reviveOwnerMethod;

    private static boolean markedCorpse(Entity entity) {
        try {
            return ((IEntityExtension) entity).getPersistentData().getBoolean("settledlands_player_body");
        } catch (Throwable t) {
            return false;
        }
    }

    @Redirect(method = "tickCorpseState",
              at = @At(value = "INVOKE",
                       target = "Ldev/settledlands/npc/GuideCorpseNpc;discard()V"))
    private void settledlands$keepBodyCorpse(GuideCorpseNpc corpse) {
        // Байткод инвокает discard() с owner GuideCorpseNpc (сверено по constant pool #325).
        if (markedCorpse(corpse)) {
            return; // труп-тело игрока не самоликвидируется
        }
        corpse.discard();
    }

    /** Переносит вещи из NBT трупа в pending-буфер игрока (исчезают вместе с трупом после воскрешения). */
    private static void handCorpseItemsToPlayer(GuideCorpseNpc corpse, ServerPlayer player) {
        try {
            net.minecraft.nbt.CompoundTag corpseTag = ((IEntityExtension) corpse).getPersistentData();
            if (!corpseTag.contains(dev.settledlands.npc.PlayerCorpsePossession.CORPSE_ITEMS_KEY)) return;
            net.minecraft.nbt.Tag stacks = corpseTag.get(dev.settledlands.npc.PlayerCorpsePossession.CORPSE_ITEMS_KEY);
            ((IEntityExtension) player).getPersistentData().put(
                    dev.settledlands.npc.PlayerCorpsePossession.ITEMS_KEY, stacks);
            corpseTag.remove(dev.settledlands.npc.PlayerCorpsePossession.CORPSE_ITEMS_KEY);
        } catch (Throwable ignored) {}
    }

    /** Берёт с маяка 9 изумрудов (та же коробка, что у RevivalNpcHelper). */
    private static boolean tryConsumeEmeralds(ServerLevel level, BlockPos altar) {
        AABB box = new AABB(altar.getX(), altar.getY() + 0.9D, altar.getZ(),
                altar.getX() + 1.0D, altar.getY() + 1.75D, altar.getZ() + 1.0D);
        List<ItemEntity> stacks = level.getEntitiesOfClass(ItemEntity.class, box,
                e -> e.getItem().is(Items.EMERALD));
        int total = 0;
        for (ItemEntity stack : stacks) total += stack.getItem().getCount();
        if (total < 9) return false;
        int left = 9;
        for (ItemEntity entity : stacks) {
            ItemStack stack = entity.getItem();
            int take = Math.min(stack.getCount(), left);
            stack.shrink(take);
            left -= take;
            if (stack.isEmpty()) entity.discard();
            if (left <= 0) break;
        }
        return true;
    }

    @Redirect(method = "tickCorpseState",
              at = @At(value = "INVOKE",
                       target = "Ldev/settledlands/npc/GuideCorpseNpc;reviveOwner(Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/server/level/ServerLevel;Ldev/settledlands/revival/PurgatoryData;Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/core/BlockPos;)V"))
    private void settledlands$reviveOnlyFromQueue(GuideCorpseNpc self, MinecraftServer server,
                                                  ServerLevel level, PurgatoryData data,
                                                  ServerPlayer player, BlockPos altar) {
        if (markedCorpse(self)) {
            // Владелец уже вышел из чистилища сам (или офлайн) — маяк его не ресает.
            if (player == null || !data.isDeadInQueue(player.getUUID())) {
                return;
            }
            // Как у NPC-гробов: воскрешение тела стоит 9 изумрудов, лежащих на маяке.
            if (!tryConsumeEmeralds(level, altar)) {
                return;
            }
            // Вещи, записанные в ЭТОТ труп, переходят владельцу (вернутся при авто-вселении).
            handCorpseItemsToPlayer(self, player);
        }
        try {
            if (reviveOwnerMethod == null) {
                reviveOwnerMethod = GuideCorpseNpc.class.getDeclaredMethod("reviveOwner",
                        MinecraftServer.class, ServerLevel.class, PurgatoryData.class,
                        ServerPlayer.class, BlockPos.class);
                reviveOwnerMethod.setAccessible(true);
            }
            reviveOwnerMethod.invoke(self, server, level, data, player, altar);
        } catch (Throwable ignored) {
            // не должно случаться — метод стоковый, сигнатура сверена по байткоду
        }
    }
}
