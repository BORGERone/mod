/*
 * Decompiled with CFR 0.152.
 */
package dev.settledlands.npc;

import dev.settledlands.npc.ActionSequence;
import dev.settledlands.npc.CutsceneCamera;
import dev.settledlands.npc.GuideNpc;
import dev.settledlands.npc.GuidePhrase;
import dev.settledlands.npc.NpcActions;
import dev.settledlands.npc.NpcContent;
import dev.settledlands.npc.NpcDialogueGraph;
import dev.settledlands.npc.NpcEscort;
import dev.settledlands.npc.NpcMobilityGroups;
import dev.settledlands.npc.NpcNet;
import dev.settledlands.npc.NpcPoints;
import dev.settledlands.npc.NpcProfile;
import dev.settledlands.npc.NpcQuests;
import dev.settledlands.npc.NpcRelations;
import dev.settledlands.npc.NpcShop;
import java.lang.invoke.StringConcatFactory;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.extensions.IEntityExtension;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@EventBusSubscriber(modid="settledlands")
public final class GuideDialogue {
    private static final Logger RADIUS_LOG = LoggerFactory.getLogger("settledlands");
    private static final String KIND_LEGACY = "#gui.settledlands.dlg.legacy.kind";
    private static final String HINT_SAY = "#gui.settledlands.dlg.hint.say";
    private static final String HINT_NEXT = "#gui.settledlands.dlg.hint.next";
    private static final String BTN_NEXT = "#gui.settledlands.dlg.next";
    private static final String BTN_MORE = "#gui.settledlands.dlg.more";
    private static final String BTN_FINISH = "#gui.settledlands.dlg.finish";
    private static final String LINE_LEGACY = "#gui.settledlands.dlg.legacy";
    private static final String LINE_SILENT = "#gui.settledlands.dlg.silent";
    private static final String QUEST_LIST = "#gui.settledlands.quest.list";
    private static final String QUEST_ROW = "#gui.settledlands.quest.row";
    private static final String QUEST_TAKEN_MARK = "#gui.settledlands.quest.mark.taken";
    private static final String QUEST_NONE = "#gui.settledlands.quest.none";
    private static final int QUEST_ENTRY = -2;
    private static final String QUEST_ACTIONS = "#gui.settledlands.quest.actions";
    public static final int MENU_HAND = 0;
    public static final int MENU_WHERE = 1;
    public static final int MENU_DROP = 2;
    private static final String[] MENU_KEYS = new String[]{"#gui.settledlands.quest.handin", "#gui.settledlands.quest.where", "#gui.settledlands.quest.abandon"};
    private static final long PICK_DEBOUNCE_MS = 250L;
    public static final int MENU_SKIP_REMIND = -1;
    private static final char ARG = '\u0001';
    private static final Map<UUID, Session> SESSIONS = new HashMap<UUID, Session>();
    private static final Map<UUID, Observation> OBSERVING = new HashMap<UUID, Observation>();
    private static final Map<UUID, Set<UUID>> LISTENERS = new HashMap<UUID, Set<UUID>>();
    private static final int FAN_SNAPSHOT_SENTINEL = -999999;
    private static final String LOCAL_VARS_NBT = "settledlands_local_vars";
    private static final int GRAPH_NEXT = -1;
    private static final int GRAPH_CLOSE = -2;
    private static final Map<UUID, PendingCutsceneReplica> PENDING_CUTSCENE_REPLICA = new HashMap<UUID, PendingCutsceneReplica>();

    private GuideDialogue() {
    }

    public static void start(Player player, GuideNpc guideNpc) {
        if (player instanceof ServerPlayer) {
            ServerPlayer serverPlayer = (ServerPlayer)player;
            if (!guideNpc.level().isClientSide()) {
                if (GuideDialogue.cutsceneConversationActive(serverPlayer)) {
                    return;
                }
                if (guideNpc.isEscorting()) {
                    if (!guideNpc.escort().openArrival(guideNpc, serverPlayer)) {
                        GuideDialogue.startEscort(serverPlayer, guideNpc, false);
                    }
                    return;
                }
                GuideDialogue.stop(serverPlayer);
                NpcProfile npcProfile = guideNpc.profile();
                Session session = new Session(guideNpc.getId(), guideNpc.level().dimension(), guideNpc.relationTo(serverPlayer));
                session.focusEntityId = guideNpc.getId();
                session.focusSpeaker = GuideDialogue.speaker(guideNpc);
                session.focusTitle = npcProfile.title == null ? "" : npcProfile.title;
                session.focusNameColor = NpcProfile.clamp(npcProfile.nameColor, 0, 3);
                SESSIONS.put(serverPlayer.getUUID(), session);
                guideNpc.setTalking(true);
                guideNpc.getNavigation().stop();
                if (npcProfile.lookAtPlayer) {
                    guideNpc.getLookControl().setLookAt(serverPlayer, 40.0f, 40.0f);
                }
                session.rootCursor = 0;
                session.defaultTabDone = false;
                if (GuideDialogue.graphActive(npcProfile) && npcProfile.defaultTab == 0) {
                    GuideDialogue.startGraph(serverPlayer, session, guideNpc);
                } else {
                    GuideDialogue.sendRoot(serverPlayer, session, guideNpc);
                }
            }
        }
    }

    public static boolean isInDialogue(ServerPlayer serverPlayer) {
        return SESSIONS.containsKey(serverPlayer.getUUID()) || OBSERVING.containsKey(serverPlayer.getUUID());
    }

    public static boolean hasEscortConversation(ServerPlayer serverPlayer, GuideNpc guideNpc) {
        Session session = SESSIONS.get(serverPlayer.getUUID());
        return session != null && session.entityId == guideNpc.getId() && session.dimension.equals(guideNpc.level().dimension()) && session.escortLine != 0;
    }

    public static boolean hasEscortArrival(ServerPlayer serverPlayer, GuideNpc guideNpc) {
        Session session = SESSIONS.get(serverPlayer.getUUID());
        return session != null && session.entityId == guideNpc.getId() && session.dimension.equals(guideNpc.level().dimension()) && session.escortLine == 2;
    }

    public static void closeNpcDialogues(GuideNpc guideNpc) {
        Object object;
        Object object2 = guideNpc.level();
        if (!(object2 instanceof ServerLevel)) {
            return;
        }
        ServerLevel serverLevel = (ServerLevel)object2;
        object2 = new ArrayList();
        for (Map.Entry<UUID, Session> object3 : SESSIONS.entrySet()) {
            object = object3.getValue();
            if (((Session)object).entityId != guideNpc.getId() || !((Session)object).dimension.equals(guideNpc.level().dimension())) continue;
            ((ArrayList)object2).add(object3.getKey());
        }
        Iterator<Map.Entry<UUID, Session>> iterator = ((ArrayList)object2).iterator();
        while (iterator.hasNext()) {
            UUID uUID = (UUID)((Object)iterator.next());
            object = serverLevel.getServer().getPlayerList().getPlayer(uUID);
            if (object != null) {
                GuideDialogue.stop((ServerPlayer)object);
                continue;
            }
            Session session = SESSIONS.remove(uUID);
            if (session == null) continue;
            GuideDialogue.closeListeners(serverLevel.getServer(), uUID, session.entityId);
        }
        guideNpc.setTalking(false);
    }

    public static void startEscort(ServerPlayer serverPlayer, GuideNpc guideNpc, boolean bl) {
        if (!guideNpc.isEscorting() || serverPlayer.level() != guideNpc.level()) {
            return;
        }
        if (GuideDialogue.cutsceneConversationActive(serverPlayer)) {
            return;
        }
        GuideDialogue.stop(serverPlayer);
        NpcProfile npcProfile = guideNpc.profile();
        Session session = new Session(guideNpc.getId(), guideNpc.level().dimension(), guideNpc.relationTo(serverPlayer));
        session.escortLine = bl ? 2 : 1;
        session.focusEntityId = guideNpc.getId();
        session.focusSpeaker = GuideDialogue.speaker(guideNpc);
        session.focusTitle = npcProfile.title;
        session.focusNameColor = NpcProfile.clamp(npcProfile.nameColor, 0, 3);
        SESSIONS.put(serverPlayer.getUUID(), session);
        guideNpc.setTalking(true);
        if (bl || guideNpc.escort().belongsTo(serverPlayer)) {
            NpcEscort.stopMotion(guideNpc);
        }
        if (npcProfile.lookAtPlayer) {
            guideNpc.getLookControl().setLookAt(serverPlayer, 40.0f, 40.0f);
        }
        GuideDialogue.sendEscortLine(serverPlayer, session, guideNpc);
    }

    private static void sendEscortLine(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc) {
        NpcProfile npcProfile = guideNpc.profile();
        String string = session.escortLine == 2 ? npcProfile.escortArrivalLine : npcProfile.escortTravelLine;
        session.state = 2;
        session.inShop = false;
        NpcNet.DlgStyle dlgStyle = new NpcNet.DlgStyle(npcProfile.style, npcProfile.textColor, npcProfile.nameColor, npcProfile.typingSpeed, npcProfile.showSpeaker, npcProfile.keyHints, npcProfile.answerNumbers, npcProfile.reputationLabel(session.relation), false, false, false, false, 0, npcProfile.zoom, npcProfile.offsetX, npcProfile.offsetY, npcProfile.cameraOnFace, npcProfile.blockMouseLook, npcProfile.dim, npcProfile.blur, npcProfile.muteHud, npcProfile.vignette, npcProfile.exitKey, npcProfile.blockMovement, npcProfile.pauseWorld, npcProfile.voice, npcProfile.voicePitch);
        NpcNet.sendTo(serverPlayer, new NpcNet.DlgView(guideNpc.getId(), GuideDialogue.speaker(guideNpc), npcProfile.title, GuideDialogue.fill(string, serverPlayer, session, npcProfile), List.of(BTN_FINISH), List.of(HINT_NEXT), session.relation, 2, false, dlgStyle));
    }

    private static boolean sendDefaultTab(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile npcProfile, String string) {
        return switch (NpcProfile.clamp(npcProfile.defaultTab, 0, 3)) {
            case 1 -> GuideDialogue.defaultTabOr(npcProfile.showTradeTab && npcProfile.hasShop(), () -> {
                session.inShop = true;
                NpcShop.send(serverPlayer, guideNpc);
            });
            case 2 -> GuideDialogue.defaultTabOr(npcProfile.showQuestTab && (!npcProfile.quests.isEmpty() || npcProfile.dialogueGraph != null && npcProfile.dialogueGraph.hasQuestNodes()) && (!GuideDialogue.questList(serverPlayer, guideNpc, npcProfile, session.relation).isEmpty() || !GuideDialogue.graphQuestNodes(serverPlayer, guideNpc, npcProfile, session.relation).isEmpty()), () -> GuideDialogue.openQuestList(serverPlayer, session, guideNpc, npcProfile, GuideDialogue.questTopicIndex(npcProfile, guideNpc), string));
            case 3 -> GuideDialogue.defaultTabOr(npcProfile.showPhrasesTab && !GuideDialogue.group(guideNpc.sortedPhrases()).isEmpty(), () -> GuideDialogue.startLegacy(serverPlayer, session, guideNpc));
            default -> false;
        };
    }

    private static boolean defaultTabOr(boolean bl, Runnable runnable) {
        if (!bl) {
            return false;
        }
        runnable.run();
        return true;
    }

    public static void stop(ServerPlayer serverPlayer) {
        if (PENDING_CUTSCENE_REPLICA.containsKey(serverPlayer.getUUID())) {
            return;
        }
        CutsceneCamera.resumeAfterDeferral(serverPlayer);
        if (OBSERVING.containsKey(serverPlayer.getUUID())) {
            GuideDialogue.stopListening(serverPlayer);
            return;
        }
        Session session = SESSIONS.remove(serverPlayer.getUUID());
        if (session != null) {
            GuideNpc guideNpc = GuideDialogue.npcOf(serverPlayer.server, session);
            if (guideNpc != null && guideNpc.isEscorting()) {
                guideNpc.escort().dialogueClosed(serverPlayer, session.escortLine == 2);
            }
            if (guideNpc != null && !GuideDialogue.stillTalking(serverPlayer.server, guideNpc, serverPlayer.getUUID())) {
                guideNpc.setTalking(false);
            }
            if (session.graphNode >= 0 && session.lastExecutedTriggersNode != session.graphNode && guideNpc != null && GuideDialogue.graphActive(guideNpc.profile())) {
                NpcDialogueGraph.Node node;
                session.lastExecutedTriggersNode = session.graphNode;
                NpcDialogueGraph npcDialogueGraph = guideNpc.profile().dialogueGraph;
                NpcDialogueGraph.Node node2 = node = npcDialogueGraph != null ? npcDialogueGraph.get(session.graphNode) : null;
                if (node != null) {
                    if (!node.action.isBlank()) {
                        NpcActions.run(serverPlayer, guideNpc, session.relation, node.action);
                    }
                    GuideDialogue.executeGraphTriggers(serverPlayer, guideNpc, session.relation, npcDialogueGraph, node.triggers);
                }
            }
            GuideDialogue.closeListeners(serverPlayer.server, serverPlayer.getUUID(), session.entityId);
            NpcNet.sendTo(serverPlayer, new NpcNet.DlgEnd(session.entityId));
        }
    }

    public static boolean listenToNpc(ServerPlayer serverPlayer, GuideNpc guideNpc) {
        if (serverPlayer == null || guideNpc == null || guideNpc.level().isClientSide()) {
            return false;
        }
        UUID uUID = null;
        Session session = null;
        double d = Double.MAX_VALUE;
        for (Map.Entry<UUID, Session> entry : SESSIONS.entrySet()) {
            double d2;
            ServerPlayer serverPlayer2;
            Session session2 = entry.getValue();
            if (session2.entityId != guideNpc.getId() || !session2.dimension.equals(guideNpc.level().dimension()) || (serverPlayer2 = serverPlayer.server.getPlayerList().getPlayer(entry.getKey())) == null || !serverPlayer2.isAlive() || !((d2 = serverPlayer2.distanceToSqr(serverPlayer)) < d)) continue;
            d = d2;
            uUID = entry.getKey();
            session = session2;
        }
        if (uUID == null || session == null || uUID.equals(serverPlayer.getUUID()) || SESSIONS.containsKey(serverPlayer.getUUID())) {
            return false;
        }
        ServerPlayer serverPlayer3 = serverPlayer.server.getPlayerList().getPlayer(uUID);
        if (serverPlayer3 == null) {
            return false;
        }
        return GuideDialogue.observe(serverPlayer, serverPlayer3, session);
    }

    public static boolean listenToPlayer(ServerPlayer serverPlayer, ServerPlayer serverPlayer2) {
        if (serverPlayer == null || serverPlayer2 == null || serverPlayer.getUUID().equals(serverPlayer2.getUUID()) || SESSIONS.containsKey(serverPlayer.getUUID())) {
            return false;
        }
        Session session = SESSIONS.get(serverPlayer2.getUUID());
        if (session == null || GuideDialogue.npcOf(serverPlayer2.server, session) == null) {
            return false;
        }
        return GuideDialogue.observe(serverPlayer, serverPlayer2, session);
    }

    private static boolean observe(ServerPlayer serverPlayer, ServerPlayer serverPlayer2, Session session) {
        UUID uUID2 = serverPlayer.getUUID();
        UUID uUID3 = serverPlayer2.getUUID();
        Observation observation = OBSERVING.get(uUID2);
        if (observation != null && observation.owner.equals(uUID3)) {
            GuideDialogue.stopListening(serverPlayer);
            return true;
        }
        if (observation != null) {
            GuideDialogue.stopListening(serverPlayer);
        }
        OBSERVING.put(uUID2, new Observation(uUID3, session.entityId));
        LISTENERS.computeIfAbsent(uUID3, uUID -> new HashSet()).add(uUID2);
        GuideNpc guideNpc = GuideDialogue.npcOf(serverPlayer2.server, session);
        if (guideNpc == null) {
            GuideDialogue.stopListening(serverPlayer);
            return false;
        }
        if (session.inShop) {
            if (session.lastView != null) {
                NpcNet.sendRaw(serverPlayer, session.lastView.asObserver());
                NpcNet.sendRaw(serverPlayer, new NpcNet.DlgFocus(session.entityId, session.focusEntityId, session.focusSpeaker, session.focusTitle, session.focusNameColor));
            }
            NpcShop.send(serverPlayer2, guideNpc);
        } else {
            GuideDialogue.resend(serverPlayer2, session, guideNpc);
        }
        return true;
    }

    private static void stopListening(ServerPlayer serverPlayer) {
        UUID uUID = serverPlayer.getUUID();
        Observation observation = OBSERVING.remove(uUID);
        if (observation == null) {
            return;
        }
        Set<UUID> set = LISTENERS.get(observation.owner);
        if (set != null) {
            set.remove(uUID);
            if (set.isEmpty()) {
                LISTENERS.remove(observation.owner);
            }
        }
        NpcNet.sendTo(serverPlayer, new NpcNet.DlgEnd(observation.entityId));
    }

    private static void closeListeners(MinecraftServer minecraftServer, UUID uUID, int n) {
        Set<UUID> set = LISTENERS.remove(uUID);
        if (set == null) {
            return;
        }
        for (UUID uUID2 : set) {
            Observation observation = OBSERVING.get(uUID2);
            if (observation == null || !observation.owner.equals(uUID)) continue;
            OBSERVING.remove(uUID2);
            ServerPlayer serverPlayer = minecraftServer.getPlayerList().getPlayer(uUID2);
            if (serverPlayer == null) continue;
            NpcNet.sendTo(serverPlayer, new NpcNet.DlgEnd(n));
        }
    }

    public static boolean isObserver(ServerPlayer serverPlayer) {
        return serverPlayer != null && OBSERVING.containsKey(serverPlayer.getUUID());
    }

    public static void broadcastView(ServerPlayer serverPlayer, NpcNet.DlgView dlgView) {
        Set<UUID> set;
        Session session = SESSIONS.get(serverPlayer.getUUID());
        if (session != null) {
            session.lastView = dlgView;
        }
        if ((set = LISTENERS.get(serverPlayer.getUUID())) == null) {
            return;
        }
        for (UUID uUID : new HashSet<UUID>(set)) {
            ServerPlayer serverPlayer2 = serverPlayer.server.getPlayerList().getPlayer(uUID);
            if (serverPlayer2 == null) continue;
            NpcNet.sendRaw(serverPlayer2, dlgView.asObserver());
        }
    }

    public static void broadcastFocus(ServerPlayer serverPlayer, NpcNet.DlgFocus dlgFocus) {
        Set<UUID> set = LISTENERS.get(serverPlayer.getUUID());
        if (set == null) {
            return;
        }
        for (UUID uUID : new HashSet<UUID>(set)) {
            ServerPlayer serverPlayer2 = serverPlayer.server.getPlayerList().getPlayer(uUID);
            if (serverPlayer2 == null) continue;
            NpcNet.sendRaw(serverPlayer2, dlgFocus);
        }
    }

    public static void broadcastShop(ServerPlayer serverPlayer, NpcNet.ShopView shopView) {
        Set<UUID> set = LISTENERS.get(serverPlayer.getUUID());
        if (set == null) {
            return;
        }
        for (UUID uUID : new HashSet<UUID>(set)) {
            ServerPlayer serverPlayer2 = serverPlayer.server.getPlayerList().getPlayer(uUID);
            if (serverPlayer2 == null) continue;
            NpcNet.sendRaw(serverPlayer2, shopView.asObserver());
        }
    }

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract entityInteract) {
        Entity entity = entityInteract.getEntity();
        if (entity instanceof ServerPlayer) {
            ServerPlayer serverPlayer;
            ServerPlayer serverPlayer2 = (ServerPlayer)entity;
            entity = entityInteract.getTarget();
            if (entity instanceof ServerPlayer && GuideDialogue.listenToPlayer(serverPlayer2, serverPlayer = (ServerPlayer)entity)) {
                entityInteract.setCancellationResult(InteractionResult.SUCCESS);
                entityInteract.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock rightClickBlock) {
        ItemStack itemStack = rightClickBlock.getItemStack();
        if (!itemStack.isEmpty() && (itemStack.is(Items.STICK) || NpcContent.coordStick() != null && itemStack.is(NpcContent.coordStick()))) {
            BlockPos blockPos = rightClickBlock.getPos();
            String string = blockPos.getX() + " " + blockPos.getY() + " " + blockPos.getZ();
            itemStack.set(DataComponents.CUSTOM_NAME, Component.literal(string));
            Player player = rightClickBlock.getEntity();
            if (player instanceof ServerPlayer) {
                ServerPlayer serverPlayer = (ServerPlayer)player;
                serverPlayer.displayClientMessage(Component.literal("\u00a7a[SettledLands] \u00a7f\u041a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b \u0437\u0430\u043f\u0438\u0441\u0430\u043d\u044b \u0432 \u043f\u0430\u043b\u043a\u0443: \u00a7e" + string), true);
            }
            rightClickBlock.setCancellationResult(InteractionResult.sidedSuccess(rightClickBlock.getLevel().isClientSide()));
            rightClickBlock.setCanceled(true);
        }
    }

    private static void leave(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile npcProfile) {
        if (npcProfile.exitAction == 1) {
            MutableComponent mutableComponent = Component.translatable("gui.settledlands.dlg.farewell", GuideDialogue.speaker(guideNpc));
            serverPlayer.displayClientMessage(mutableComponent, false);
        }
        GuideDialogue.stop(serverPlayer);
    }

    public static boolean setVisualFocus(ServerPlayer serverPlayer, GuideNpc guideNpc, GuideNpc guideNpc2) {
        Session session = SESSIONS.get(serverPlayer.getUUID());
        if (session == null || guideNpc == null || guideNpc2 == null || session.entityId != guideNpc.getId() || !guideNpc2.isAlive()) {
            return false;
        }
        if (guideNpc2.level() != serverPlayer.level() || serverPlayer.distanceToSqr(guideNpc2) > 16384.0) {
            return false;
        }
        session.focusEntityId = guideNpc2.getId();
        session.focusSpeaker = GuideDialogue.speaker(guideNpc2);
        session.focusTitle = guideNpc2.profile().title == null ? "" : guideNpc2.profile().title;
        session.focusNameColor = NpcProfile.clamp(guideNpc2.profile().nameColor, 0, 3);
        NpcNet.sendTo(serverPlayer, new NpcNet.DlgFocus(session.entityId, session.focusEntityId, session.focusSpeaker, session.focusTitle, session.focusNameColor));
        return true;
    }

    public static void sendCurrentFocus(ServerPlayer serverPlayer) {
        Session session = SESSIONS.get(serverPlayer.getUUID());
        if (session != null) {
            NpcNet.sendTo(serverPlayer, new NpcNet.DlgFocus(session.entityId, session.focusEntityId, session.focusSpeaker, session.focusTitle, session.focusNameColor));
        }
    }

    public static void pick(ServerPlayer serverPlayer, int n, int n2) {
        Session session = SESSIONS.get(serverPlayer.getUUID());
        if (session != null && session.entityId == n) {
            session.inShop = n2 == -2;
            GuideNpc guideNpc = GuideDialogue.npcOf(serverPlayer.server, session);
            if (guideNpc == null) {
                GuideDialogue.stop(serverPlayer);
            } else {
                if (session.escortLine != 0 || guideNpc.isEscorting()) {
                    if (session.escortLine == 0) {
                        GuideDialogue.startEscort(serverPlayer, guideNpc, false);
                        return;
                    }
                    if (n2 == 0) {
                        GuideDialogue.stop(serverPlayer);
                    } else {
                        GuideDialogue.sendEscortLine(serverPlayer, session, guideNpc);
                    }
                    return;
                }
                NpcProfile npcProfile = guideNpc.profile();
                session.relation = guideNpc.relationTo(serverPlayer);
                if (n2 >= 0) {
                    long l = System.currentTimeMillis();
                    if (l - session.lastPick < 250L) {
                        return;
                    }
                    session.lastPick = l;
                }
                if (n2 == -2) {
                    session.graphNode = -1;
                    NpcShop.send(serverPlayer, guideNpc);
                } else if (n2 == -3) {
                    session.graphNode = -1;
                    GuideDialogue.startLegacy(serverPlayer, session, guideNpc);
                } else if (n2 == -4) {
                    session.graphNode = -1;
                    GuideDialogue.openQuestList(serverPlayer, session, guideNpc, npcProfile, GuideDialogue.graphActive(npcProfile) ? -1 : GuideDialogue.questTopicIndex(npcProfile, guideNpc));
                } else if (n2 == -5) {
                    if (GuideDialogue.graphActive(npcProfile)) {
                        GuideDialogue.startGraph(serverPlayer, session, guideNpc);
                        return;
                    }
                    if (session.rootCursor == 0) {
                        GuideDialogue.sendRoot(serverPlayer, session, guideNpc);
                    } else {
                        GuideDialogue.sendWelcome(serverPlayer, session, guideNpc);
                    }
                } else if (n2 < 0) {
                    GuideDialogue.resend(serverPlayer, session, guideNpc);
                } else {
                    if (session.graphNode >= 0 && GuideDialogue.graphActive(npcProfile)) {
                        GuideDialogue.pickGraph(serverPlayer, session, guideNpc, n2);
                        return;
                    }
                    switch (session.state) {
                        case 0: {
                            GuideDialogue.chooseTopic(serverPlayer, session, guideNpc, npcProfile, n2);
                            break;
                        }
                        case 1: {
                            GuideDialogue.chooseAnswer(serverPlayer, session, guideNpc, npcProfile, n2);
                            break;
                        }
                        case 2: {
                            if (session.pendingTopic >= 0) {
                                GuideDialogue.openTopic(serverPlayer, session, guideNpc, session.pendingTopic);
                                break;
                            }
                            if (session.pendingNext == -1) {
                                GuideDialogue.finish(serverPlayer, session, guideNpc, npcProfile);
                                break;
                            }
                            session.step = session.pendingNext;
                            GuideDialogue.sendStep(serverPlayer, session, guideNpc);
                            break;
                        }
                        case 3: {
                            GuideDialogue.advanceLegacy(serverPlayer, session, guideNpc);
                            break;
                        }
                        case 4: {
                            GuideDialogue.sendRoot(serverPlayer, session, guideNpc);
                            break;
                        }
                        case 5: {
                            GuideDialogue.chooseQuest(serverPlayer, session, guideNpc, npcProfile, n2);
                            break;
                        }
                        case 6: {
                            GuideDialogue.chooseQuestMenu(serverPlayer, session, guideNpc, npcProfile, n2);
                            break;
                        }
                        default: {
                            GuideDialogue.sendWelcome(serverPlayer, session, guideNpc);
                        }
                    }
                }
            }
        }
    }

    private static void openQuestList(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile npcProfile, int n) {
        GuideDialogue.openQuestList(serverPlayer, session, guideNpc, npcProfile, n, null);
    }

    private static void openQuestList(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile npcProfile, int n, String string) {
        session.questTopic = n;
        session.quest = -1;
        NpcProfile.Topic topic = n >= 0 && npcProfile != null && npcProfile.topics != null && n < npcProfile.topics.size() ? npcProfile.topics.get(n) : null;
        GuideDialogue.sendQuestList(serverPlayer, session, guideNpc, topic, string, QUEST_NONE);
    }

    private static int questTopicIndex(NpcProfile npcProfile, GuideNpc guideNpc) {
        if (npcProfile == null || npcProfile.topics == null) {
            return -1;
        }
        for (int n : GuideDialogue.visibleTopics(npcProfile, guideNpc)) {
            if (n < 0 || n >= npcProfile.topics.size() || npcProfile.topics.get((int)n).type != 3) continue;
            return n;
        }
        for (int i = 0; i < npcProfile.topics.size(); ++i) {
            if (npcProfile.topics.get((int)i).type != 3) continue;
            return i;
        }
        return -1;
    }

    private static void chooseTopic(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile npcProfile, int n) {
        List<Integer> list = GuideDialogue.visibleTopics(npcProfile, guideNpc);
        if (n < list.size()) {
            int n2 = list.get(n);
            if (n2 == -2) {
                GuideDialogue.openQuestList(serverPlayer, session, guideNpc, npcProfile, GuideDialogue.questTopicIndex(npcProfile, guideNpc));
            } else if (n2 < 0) {
                GuideDialogue.startLegacy(serverPlayer, session, guideNpc);
            } else {
                GuideDialogue.openTopic(serverPlayer, session, guideNpc, n2);
            }
        }
    }

    private static void openTopic(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, int n) {
        NpcProfile npcProfile = guideNpc.profile();
        if (n >= 0 && n < npcProfile.topics.size()) {
            NpcProfile.Topic topic = npcProfile.topics.get(n);
            session.topic = n;
            session.step = 0;
            session.chainFrom = -1;
            session.answerStep = -1;
            session.quest = NpcProfile.questOfTopic(npcProfile, n);
            switch (topic.type) {
                case 1: {
                    if (npcProfile.hasShop()) {
                        session.inShop = true;
                        NpcShop.send(serverPlayer, guideNpc);
                        break;
                    }
                    GuideDialogue.sendSilent(serverPlayer, session, guideNpc, topic);
                    break;
                }
                default: {
                    if (NpcProfile.usable(topic)) {
                        GuideDialogue.sendStep(serverPlayer, session, guideNpc);
                        break;
                    }
                    GuideDialogue.sendSilent(serverPlayer, session, guideNpc, topic);
                    break;
                }
                case 3: {
                    if (!GuideDialogue.questList(serverPlayer, guideNpc, npcProfile, session.relation).isEmpty()) {
                        GuideDialogue.openQuestList(serverPlayer, session, guideNpc, npcProfile, n);
                        return;
                    }
                    if (NpcProfile.usable(topic)) {
                        GuideDialogue.sendStep(serverPlayer, session, guideNpc);
                        break;
                    }
                    GuideDialogue.openQuestList(serverPlayer, session, guideNpc, npcProfile, n);
                    break;
                }
                case 4: {
                    GuideDialogue.leave(serverPlayer, session, guideNpc, npcProfile);
                    break;
                }
            }
        } else {
            GuideDialogue.sendWelcome(serverPlayer, session, guideNpc);
        }
    }

    private static void chooseAnswer(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile npcProfile, int n) {
        NpcProfile.Topic topic = GuideDialogue.topicOf(npcProfile, session);
        NpcProfile.Step step = GuideDialogue.stepOf(topic, session);
        if (step == null) {
            GuideDialogue.sendWelcome(serverPlayer, session, guideNpc);
        } else if (session.chainFrom >= 0 && session.answerStep < 0) {
            GuideDialogue.runStepTrigger(serverPlayer, session, guideNpc, step);
            if (SESSIONS.get(serverPlayer.getUUID()) != session) {
                return;
            }
            GuideDialogue.advanceStep(serverPlayer, session, guideNpc);
        } else {
            if (session.answerStep >= 0 && topic != null && session.answerStep < topic.steps.size()) {
                step = topic.steps.get(session.answerStep);
            }
            GuideDialogue.runStepTrigger(serverPlayer, session, guideNpc, step);
            if (SESSIONS.get(serverPlayer.getUUID()) != session) {
                return;
            }
            List<NpcProfile.Answer> list = GuideDialogue.visibleAnswers(serverPlayer, step, session.relation);
            if (list.isEmpty()) {
                GuideDialogue.advanceStep(serverPlayer, session, guideNpc);
            } else if (n >= 0 && n < list.size()) {
                NpcProfile.Answer answer = list.get(n);
                if (answer.relation != 0) {
                    GuideNpc.addRelation(serverPlayer, guideNpc, answer.relation);
                    session.relation = guideNpc.relationTo(serverPlayer);
                }
                if (!answer.action.isEmpty()) {
                    if (session.quest >= 0 && NpcQuests.isQuestAction(answer.action)) {
                        if (!NpcQuests.runAction(serverPlayer, guideNpc, session.quest, answer.action)) {
                            GuideDialogue.sendStep(serverPlayer, session, guideNpc);
                            return;
                        }
                        ActionSequence.runExtras(serverPlayer, guideNpc, session.relation, answer.action);
                        if (SESSIONS.get(serverPlayer.getUUID()) != session) {
                            return;
                        }
                        session.menuOnEnd = "quest:take".equals(ActionSequence.first(answer.action)) ? session.quest : -1;
                        session.remindOnEnd = false;
                        if (!NpcProfile.readsAfterAction(answer.next, session.step)) {
                            if (session.menuOnEnd >= 0) {
                                GuideDialogue.openQuestMenu(serverPlayer, session, guideNpc, npcProfile, session.menuOnEnd, session.remindOnEnd);
                                return;
                            }
                            GuideDialogue.stop(serverPlayer);
                            return;
                        }
                        session.closeOnEnd = session.menuOnEnd < 0;
                    } else {
                        NpcActions.run(serverPlayer, guideNpc, session.relation, answer.action);
                    }
                }
                if (SESSIONS.containsKey(serverPlayer.getUUID())) {
                    String string;
                    session.pendingNext = answer.next;
                    session.pendingTopic = answer.next >= 1000 ? answer.next - 1000 : -1;
                    session.chainFrom = -1;
                    session.answerStep = -1;
                    String string2 = string = answer.reaction.isEmpty() ? "" : GuideDialogue.fill(answer.reaction, serverPlayer, session, npcProfile);
                    if (string.isEmpty()) {
                        if (session.pendingTopic >= 0) {
                            GuideDialogue.openTopic(serverPlayer, session, guideNpc, session.pendingTopic);
                        } else if (session.pendingNext == -1) {
                            GuideDialogue.finish(serverPlayer, session, guideNpc, npcProfile);
                        } else {
                            session.step = session.pendingNext;
                            GuideDialogue.sendStep(serverPlayer, session, guideNpc);
                        }
                    } else {
                        session.pendingReaction = string;
                        GuideDialogue.sendLine(serverPlayer.getServer(), serverPlayer, session, guideNpc, string, 2);
                    }
                }
            }
        }
    }

    private static void runStepTrigger(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile.Step step) {
        if (step != null && step.action != null && !step.action.isEmpty()) {
            NpcActions.run(serverPlayer, guideNpc, session.relation, step.action);
        }
    }

    private static void advanceStep(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc) {
        int n;
        if (SESSIONS.get(serverPlayer.getUUID()) != session) {
            return;
        }
        NpcProfile npcProfile = guideNpc.profile();
        NpcProfile.Topic topic = GuideDialogue.topicOf(npcProfile, session);
        int n2 = n = topic == null ? -1 : NpcProfile.chainNext(topic, session.step);
        if (n < 0) {
            GuideDialogue.finish(serverPlayer, session, guideNpc, npcProfile);
        } else {
            session.step = n;
            GuideDialogue.sendStep(serverPlayer, session, guideNpc);
        }
    }

    private static void sendLine(MinecraftServer minecraftServer, ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, String string, int n) {
        NpcProfile npcProfile = guideNpc.profile();
        session.state = n;
        List<String> list = n == 2 ? List.of(BTN_NEXT) : List.of();
        List<String> list2 = n == 2 ? List.of(HINT_NEXT) : List.of();
        NpcNet.sendTo(serverPlayer, new NpcNet.DlgView(guideNpc.getId(), GuideDialogue.speaker(guideNpc), npcProfile.title, GuideDialogue.fill(string, serverPlayer, session, npcProfile), list, list2, session.relation, n, npcProfile.hasShop(), GuideDialogue.style(npcProfile, serverPlayer, session.relation)));
    }

    private static void sendSilent(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile.Topic topic) {
        NpcProfile npcProfile = guideNpc.profile();
        session.state = 2;
        session.pendingNext = -1;
        session.pendingTopic = -1;
        NpcNet.sendTo(serverPlayer, new NpcNet.DlgView(guideNpc.getId(), GuideDialogue.speaker(guideNpc), npcProfile.title, LINE_SILENT, List.of(BTN_NEXT), List.of(HINT_NEXT), session.relation, 2, npcProfile.hasShop(), GuideDialogue.style(npcProfile, serverPlayer, session.relation)));
    }

    private static int rankOf(int n, int n2) {
        return switch (n2) {
            case 1 -> {
                if (n == 1) {
                    yield 0;
                }
                yield 1;
            }
            case 2 -> {
                if (n == 3) {
                    yield 0;
                }
                yield 1;
            }
            case 3 -> 1;
            default -> n != 1 && n != 4 ? 1 : 0;
        };
    }

    private static void sendRoot(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc) {
        NpcProfile npcProfile = guideNpc.profile();
        if (session.rootCursor == 0 && GuideDialogue.visibleTopics(npcProfile, guideNpc).isEmpty()) {
            session.state = 4;
            session.rootCursor = 1;
            session.rootLine = npcProfile.welcome;
            GuideDialogue.sendLine(serverPlayer.getServer(), serverPlayer, session, guideNpc, npcProfile.welcome, 4);
        } else {
            List<String> list = npcProfile.rootSequence();
            int n = Math.max(0, session.rootCursor);
            if (n < list.size() - 1) {
                session.rootCursor = n + 1;
                session.state = 4;
                session.rootLine = list.get(n);
                GuideDialogue.sendLine(serverPlayer.getServer(), serverPlayer, session, guideNpc, list.get(n), 4);
            } else {
                String string;
                session.rootCursor = Math.max(n, list.size() - 1);
                String string2 = string = list.isEmpty() ? null : list.get(list.size() - 1);
                if (!session.defaultTabDone) {
                    session.defaultTabDone = true;
                    if (GuideDialogue.sendDefaultTab(serverPlayer, session, guideNpc, npcProfile, string)) {
                        return;
                    }
                }
                GuideDialogue.sendWelcome(serverPlayer, session, guideNpc, string);
            }
        }
    }

    private static List<Integer> questList(ServerPlayer serverPlayer, GuideNpc guideNpc, NpcProfile npcProfile, int n3) {
        if (npcProfile == null || npcProfile.quests.isEmpty()) {
            return new ArrayList<Integer>();
        }
        NpcRelations npcRelations = null;
        try {
            npcRelations = NpcRelations.get(serverPlayer.server);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        NpcRelations npcRelations2 = npcRelations;
        return NpcQuests.visible(npcProfile, n3, n -> npcRelations2 != null && NpcQuests.isTaken(npcRelations2, guideNpc, serverPlayer, n), n -> NpcQuests.doneFor(npcProfile, n, npcRelations2 != null && NpcQuests.isDone(npcRelations2, guideNpc, serverPlayer, n), npcRelations2 != null && NpcQuests.isChainDone(npcRelations2, guideNpc, n)), n2 -> NpcQuests.chainReady(npcProfile, n2, n -> npcRelations2 != null && NpcQuests.isDone(npcRelations2, guideNpc, serverPlayer, n), n -> npcRelations2 != null && NpcQuests.isChainDone(npcRelations2, guideNpc, n)));
    }

    private static CompoundTag localVars(GuideNpc guideNpc, boolean create) {
        if (guideNpc == null) {
            return null;
        }
        CompoundTag persistent = ((IEntityExtension)guideNpc).getPersistentData();
        CompoundTag vars = persistent.getCompound(LOCAL_VARS_NBT);
        if (create && !persistent.contains(LOCAL_VARS_NBT, 10)) {
            persistent.put(LOCAL_VARS_NBT, vars);
        }
        return vars;
    }

    private static int readVarValue(ServerPlayer serverPlayer, GuideNpc guideNpc, String name, boolean shared, boolean local) {
        if (name == null || name.isBlank()) {
            return 0;
        }
        if (local) {
            CompoundTag vars = GuideDialogue.localVars(guideNpc, false);
            return vars == null ? 0 : vars.getInt(name);
        }
        if (serverPlayer != null && serverPlayer.getServer() != null) {
            try {
                return NpcPoints.get(serverPlayer.getServer()).get(serverPlayer.getUUID(), name, shared);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return 0;
    }

    private static void addVarValue(ServerPlayer serverPlayer, GuideNpc guideNpc, String name, boolean shared, boolean local, int delta) {
        if (name == null || name.isBlank() || delta == 0) {
            return;
        }
        if (local) {
            if (guideNpc == null) {
                return;
            }
            CompoundTag vars = GuideDialogue.localVars(guideNpc, true);
            if (vars != null) {
                vars.putInt(name, vars.getInt(name) + delta);
            }
            return;
        }
        if (serverPlayer != null && serverPlayer.getServer() != null) {
            NpcPoints.get(serverPlayer.getServer()).add(serverPlayer.getUUID(), name, shared, delta);
        }
    }

    public static boolean evalIfNode(ServerPlayer serverPlayer, GuideNpc guideNpc, int n, NpcDialogueGraph npcDialogueGraph, NpcDialogueGraph.Node node) {
        NpcDialogueGraph.Node node2;
        if (node == null || node.type != 3) {
            return true;
        }
        String varName = node.pointsName;
        boolean shared = node.pointsShared;
        boolean local = node.varLocal;
        if (node.varInputNode >= 0 && npcDialogueGraph != null && (node2 = npcDialogueGraph.get(node.varInputNode)) != null && node2.type == 4 && !node2.pointsName.isBlank()) {
            varName = node2.pointsName;
            shared = node2.pointsShared;
            local = node2.varLocal;
        }
        int value = !varName.isBlank() ? GuideDialogue.readVarValue(serverPlayer, guideNpc, varName, shared, local) : n;
        return GuideDialogue.evalCondition(value, node.varOp, node.varCompare);
    }

    private static boolean isIfBranchSatisfied(ServerPlayer serverPlayer, GuideNpc guideNpc, int n, NpcDialogueGraph npcDialogueGraph, NpcDialogueGraph.Node node, int n2, Set<Integer> set) {
        int n3;
        if (node == null || node.type != 3) {
            return false;
        }
        if (!set.add(node.id) || set.size() > 64) {
            return false;
        }
        boolean bl = GuideDialogue.evalIfNode(serverPlayer, guideNpc, n, npcDialogueGraph, node);
        int n4 = n3 = bl ? node.next : node.falseNext;
        if (n3 == n2) {
            ArrayList<NpcDialogueGraph.Node> arrayList = new ArrayList<NpcDialogueGraph.Node>();
            for (NpcDialogueGraph.Node node2 : npcDialogueGraph.nodes.values()) {
                if (node2.type != 3 || node2.next != node.id && node2.falseNext != node.id) continue;
                arrayList.add(node2);
            }
            if (arrayList.isEmpty()) {
                return true;
            }
            for (NpcDialogueGraph.Node node2 : arrayList) {
                if (!GuideDialogue.isIfBranchSatisfied(serverPlayer, guideNpc, n, npcDialogueGraph, node2, node.id, set)) continue;
                return true;
            }
            return false;
        }
        return false;
    }

    private static Set<Integer> fanSnapshot(Set<Integer> set) {
        HashSet<Integer> hashSet = set != null ? new HashSet<Integer>(set) : new HashSet();
        hashSet.add(-999999);
        return hashSet;
    }

    private static List<NpcDialogueGraph.Node> findRadiusAttachments(NpcDialogueGraph npcDialogueGraph, NpcDialogueGraph.Node node, Set<Integer> set) {
        ArrayList<NpcDialogueGraph.Node> arrayList = new ArrayList<NpcDialogueGraph.Node>();
        if (node == null || npcDialogueGraph == null) {
            return arrayList;
        }
        for (NpcDialogueGraph.Node node2 : npcDialogueGraph.nodes.values()) {
            if (node2.type != 15 || node2.id == node.id || node2.next != node.id && !node2.triggers.contains(node.id) || set != null && set.contains(node2.id)) continue;
            arrayList.add(node2);
        }
        return arrayList;
    }

    private static boolean initiatorExecutesWithRadiusGate(ServerPlayer serverPlayer, GuideNpc guideNpc, List<NpcDialogueGraph.Node> list) {
        if (list == null || list.isEmpty()) {
            return true;
        }
        if (serverPlayer == null) {
            return false;
        }
        Vec3 vec3 = guideNpc != null ? guideNpc.position() : serverPlayer.position();
        for (NpcDialogueGraph.Node node : list) {
            int n = Math.max(0, Math.min(4, node.radiusTarget));
            if (n != 0 && n != 3) continue;
            int n2 = Math.max(1, Math.min(96, node.radius));
            if (!(serverPlayer.distanceToSqr(vec3) <= (double)n2 * (double)n2)) continue;
            return true;
        }
        return false;
    }

    private static void expandRadiusAttachments(ServerPlayer serverPlayer, GuideNpc guideNpc, NpcDialogueGraph npcDialogueGraph, NpcDialogueGraph.Node node, List<NpcDialogueGraph.Node> list, Set<Integer> set) {
        if (node == null || npcDialogueGraph == null || serverPlayer == null && guideNpc == null) {
            return;
        }
        if (list == null || list.isEmpty()) {
            return;
        }
        ServerLevel serverLevel = null;
        if (guideNpc != null && guideNpc.level() instanceof ServerLevel) {
            serverLevel = (ServerLevel)guideNpc.level();
        } else if (serverPlayer != null && serverPlayer.level() instanceof ServerLevel) {
            serverLevel = (ServerLevel)serverPlayer.level();
        }
        if (serverLevel == null) {
            return;
        }
        Vec3 center = guideNpc != null ? guideNpc.position() : serverPlayer.position();
        IdentityHashMap<Entity, Boolean> matched = new IdentityHashMap<Entity, Boolean>();
        for (NpcDialogueGraph.Node attach : list) {
            int radius = Math.max(1, Math.min(96, attach.radius));
            int mode = Math.max(0, Math.min(4, attach.radiusTarget));
            double maxDistSqr = (double)radius * (double)radius;
            AABB box = new AABB(center.x - (double)radius, center.y - (double)radius, center.z - (double)radius, center.x + (double)radius, center.y + (double)radius, center.z + (double)radius);
            int before = matched.size();
            try {
                if (mode == 0 || mode == 3) {
                    for (ServerPlayer other : serverLevel.getEntitiesOfClass(ServerPlayer.class, box)) {
                        if (other == serverPlayer || other.distanceToSqr(center) > maxDistSqr) continue;
                        matched.put(other, Boolean.TRUE);
                    }
                }
                if (mode == 1 || mode == 3) {
                    for (GuideNpc otherNpc : serverLevel.getEntitiesOfClass(GuideNpc.class, box)) {
                        if (otherNpc == guideNpc || !otherNpc.isAlive() || otherNpc.distanceToSqr(center) > maxDistSqr) continue;
                        matched.put(otherNpc, Boolean.TRUE);
                    }
                }
                if (mode == 2 || mode == 3) {
                    for (Entity mob : serverLevel.getEntitiesOfClass(Mob.class, box)) {
                        if (!(mob instanceof Enemy) || mob instanceof GuideNpc || !mob.isAlive() || mob.distanceToSqr(center) > maxDistSqr) continue;
                        matched.put(mob, Boolean.TRUE);
                    }
                }
                if (mode == 4 || mode == 3) {
                    for (Entity mob : serverLevel.getEntitiesOfClass(Mob.class, box)) {
                        if (mob instanceof Enemy || mob instanceof GuideNpc || !mob.isAlive() || mob.distanceToSqr(center) > maxDistSqr) continue;
                        matched.put(mob, Boolean.TRUE);
                    }
                }
                RADIUS_LOG.info("[radius] attach fan node #{} -> target #{}: {} entities matched (mode {}, radius {})", attach.id, node.id, matched.size() - before, mode, radius);
            }
            catch (Throwable t) {
                RADIUS_LOG.warn("[radius] attach fan node #{} failed: {}", (Object)attach.id, (Object)String.valueOf(t));
            }
        }
        for (Entity entity : matched.keySet()) {
            try {
                Set<Integer> snapshot = GuideDialogue.fanSnapshot(set);
                if (entity instanceof ServerPlayer) {
                    GuideDialogue.resolveExecutionTarget((ServerPlayer)entity, guideNpc, null, npcDialogueGraph, node.id, snapshot);
                    continue;
                }
                GuideDialogue.resolveExecutionTarget(null, entity, guideNpc, null, npcDialogueGraph, node.id, snapshot);
            }
            catch (Throwable t) {
                RADIUS_LOG.warn("[radius] attach execution failed for {}: {}", (Object)entity.getName().getString(), (Object)String.valueOf(t));
            }
        }
    }

    public static boolean isIncomingIfSatisfied(ServerPlayer serverPlayer, GuideNpc guideNpc, int n, NpcDialogueGraph npcDialogueGraph, NpcDialogueGraph.Node node) {
        if (node == null || npcDialogueGraph == null) {
            return true;
        }
        ArrayList<NpcDialogueGraph.Node> arrayList = new ArrayList<NpcDialogueGraph.Node>();
        for (NpcDialogueGraph.Node node2 : npcDialogueGraph.nodes.values()) {
            if (node2.type != 3 || node2.next != node.id && node2.falseNext != node.id) continue;
            arrayList.add(node2);
        }
        if (arrayList.isEmpty()) {
            return true;
        }
        for (NpcDialogueGraph.Node node2 : arrayList) {
            if (!GuideDialogue.isIfBranchSatisfied(serverPlayer, guideNpc, n, npcDialogueGraph, node2, node.id, new HashSet<Integer>())) continue;
            return true;
        }
        return false;
    }

    public static boolean isQuestNodeVisible(ServerPlayer serverPlayer, GuideNpc guideNpc, int n, NpcDialogueGraph npcDialogueGraph, NpcDialogueGraph.Node node) {
        if (node == null || node.type != 10) {
            return false;
        }
        if (node.minRelation > 0 && n < node.minRelation) {
            return false;
        }
        if (node.maxRelation < 100 && n > node.maxRelation) {
            return false;
        }
        return GuideDialogue.isIncomingIfSatisfied(serverPlayer, guideNpc, n, npcDialogueGraph, node);
    }

    public static boolean executeMoveNode(GuideNpc guideNpc, ServerPlayer serverPlayer, NpcDialogueGraph.Node node) {
        if (guideNpc == null || node == null || node.type != 11) {
            return false;
        }
        String string = node.moveCoords;
        if ((string == null || string.isBlank()) && node.moveEscort && guideNpc.profile() != null) {
            string = guideNpc.profile().escortCoordinates;
        }
        if (string == null || string.isBlank()) {
            return false;
        }
        Vec3 vec3 = new Vec3(guideNpc.getX(), guideNpc.getY(), guideNpc.getZ());
        Vec3 vec32 = GuideDialogue.parseCoordinates(string, vec3);
        if (vec32 == null) {
            return false;
        }
        if (node.moveEscort) {
            BlockPos blockPos;
            if (serverPlayer == null || serverPlayer.level() != guideNpc.level()) {
                return false;
            }
            BlockPos blockPos2 = BlockPos.containing(vec32.x, vec32.y, vec32.z);
            Level level = guideNpc.level();
            if (level instanceof ServerLevel) {
                blockPos = guideNpc.findStablePosition((ServerLevel)level, blockPos2);
            } else {
                blockPos = blockPos2;
            }
            if (!guideNpc.level().getWorldBorder().isWithinBounds(blockPos)) {
                return false;
            }
            String escortCode = guideNpc.profile() != null && !guideNpc.profile().escortCode.isBlank() ? guideNpc.profile().escortCode : "escort";
            guideNpc.beginEscort(serverPlayer, escortCode, blockPos);
            return true;
        }
        double d = node.moveSpeed <= 0.001 ? 1.0 : node.moveSpeed;
        return guideNpc.walkTo(vec32.x, vec32.y, vec32.z, d);
    }

    public static boolean executeMobilityNode(GuideNpc guideNpc, NpcDialogueGraph.Node node) {
        if (guideNpc == null || node == null || node.type != 12) {
            return false;
        }
        String string = node.mobilityGroupId;
        if (string != null && !string.isBlank()) {
            ServerLevel serverLevel;
            Object object;
            guideNpc.profile().mobilityGroupId = string;
            if (!node.mobilityGroupName.isBlank()) {
                guideNpc.profile().mobilityGroupName = node.mobilityGroupName;
            }
            if ((object = guideNpc.level()) instanceof ServerLevel && (object = NpcMobilityGroups.get((serverLevel = (ServerLevel)object).getServer())) != null) {
                ((NpcMobilityGroups)object).assignProfile(guideNpc.profile(), string);
            }
        }
        guideNpc.profile().idleWalking = true;
        guideNpc.beginMobilityWatch(node.id);
        return true;
    }

    public static void triggerMobilityChain(GuideNpc guideNpc, int n) {
        if (guideNpc == null || guideNpc.profile() == null || guideNpc.profile().dialogueGraph == null) {
            return;
        }
        NpcDialogueGraph.Node node = guideNpc.profile().dialogueGraph.get(n);
        if (node != null) {
            GuideDialogue.triggerMobilityChain(guideNpc, null, node);
        }
    }

    public static void triggerMobilityChain(GuideNpc guideNpc, ServerPlayer serverPlayer, NpcDialogueGraph.Node node) {
        int n;
        int n2;
        if (guideNpc == null || node == null || node.type != 12) {
            return;
        }
        NpcDialogueGraph npcDialogueGraph = guideNpc.profile().dialogueGraph;
        if (npcDialogueGraph == null) {
            return;
        }
        int n3 = n2 = serverPlayer != null ? guideNpc.relationTo(serverPlayer) : 0;
        if (!GuideDialogue.isIncomingIfSatisfied(serverPlayer, guideNpc, n2, npcDialogueGraph, node)) {
            return;
        }
        HashSet<Integer> hashSet = new HashSet<Integer>();
        if (!(node.action.isBlank() || serverPlayer == null && guideNpc == null)) {
            NpcActions.run(serverPlayer, guideNpc, n2, node.action);
        }
        GuideDialogue.executeGraphTriggers(serverPlayer, guideNpc, n2, npcDialogueGraph, node.triggers, hashSet);
        if (node.next >= 0 && (n = GuideDialogue.resolveExecutionTarget(serverPlayer, guideNpc, null, npcDialogueGraph, node.next, hashSet)) >= 0 && serverPlayer != null) {
            GuideDialogue.startAtLine(serverPlayer, guideNpc, n, hashSet);
        }
    }

    public static Vec3 parseCoordinates(String string, Vec3 vec3) {
        if (string == null || string.isBlank()) {
            return null;
        }
        String string2 = string.trim();
        string2 = string2.replaceAll("(?i)^(?:/tp|/teleport)\\s+", "");
        string2 = string2.replaceAll("(?i)[XYZxyz]\\s*[:=]\\s*", "");
        String[] stringArray = (string2 = string2.replaceAll("~\\s+(?=[0-9+\\-])", "~")).split("[,\\s]+");
        if (stringArray.length != 2 && stringArray.length != 3) {
            return null;
        }
        try {
            double d = GuideDialogue.parseCoordComponent(stringArray[0], vec3 != null ? vec3.x : 0.0);
            double d2 = stringArray.length == 3 ? GuideDialogue.parseCoordComponent(stringArray[1], vec3 != null ? vec3.y : 0.0) : (vec3 != null ? vec3.y : 64.0);
            double d3 = GuideDialogue.parseCoordComponent(stringArray[stringArray.length - 1], vec3 != null ? vec3.z : 0.0);
            return new Vec3(d, d2, d3);
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private static double parseCoordComponent(String string, double d) throws NumberFormatException {
        if ((string = string.trim()).startsWith("~")) {
            String string2 = string.substring(1).trim();
            if (string2.isEmpty()) {
                return d;
            }
            return d + Double.parseDouble(string2);
        }
        return Double.parseDouble(string);
    }

    public static List<NpcDialogueGraph.Node> graphQuestNodes(ServerPlayer serverPlayer, GuideNpc guideNpc, NpcProfile npcProfile, int n) {
        ArrayList<NpcDialogueGraph.Node> arrayList = new ArrayList<NpcDialogueGraph.Node>();
        if (npcProfile != null && npcProfile.dialogueGraph != null && npcProfile.dialogueGraph.enabled) {
            for (NpcDialogueGraph.Node node2 : npcProfile.dialogueGraph.nodes.values()) {
                if (node2.type != 10 || !GuideDialogue.isQuestNodeVisible(serverPlayer, guideNpc, n, npcProfile.dialogueGraph, node2)) continue;
                arrayList.add(node2);
            }
            arrayList.sort(Comparator.comparingInt(node -> node.id));
        }
        return arrayList;
    }

    public static List<NpcDialogueGraph.Node> graphQuestNodes(NpcProfile npcProfile, int n) {
        return GuideDialogue.graphQuestNodes(null, null, npcProfile, n);
    }

    private static void sendQuestList(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile.Topic topic) {
        GuideDialogue.sendQuestList(serverPlayer, session, guideNpc, topic, null, null);
    }

    private static void sendQuestList(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile.Topic topic, String string, String string2) {
        String string3;
        NpcProfile npcProfile = guideNpc.profile();
        NpcRelations npcRelations = null;
        try {
            npcRelations = NpcRelations.get(serverPlayer.server);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        List<NpcDialogueGraph.Node> list = GuideDialogue.graphQuestNodes(serverPlayer, guideNpc, npcProfile, session.relation);
        List<Integer> list2 = GuideDialogue.questList(serverPlayer, guideNpc, npcProfile, session.relation);
        ArrayList<String> arrayList = new ArrayList<String>();
        for (NpcDialogueGraph.Node node : list) {
            String object3 = node.text == null || node.text.isBlank() ? "#gui.settledlands.graph.quest #" + node.id : node.text;
            arrayList.add(object3);
        }
        for (int n : list2) {
            NpcProfile.Quest quest = npcProfile.quests.get(n);
            string3 = quest.title == null ? "" : quest.title;
            String takenMark = npcRelations != null && NpcQuests.isTaken(npcRelations, guideNpc, serverPlayer, n) ? QUEST_TAKEN_MARK : "";
            arrayList.add(string3 + takenMark);
        }
        String text = QUEST_LIST;
        if (arrayList.isEmpty() && string2 != null) {
            text = string2;
        } else if (string != null && !string.isEmpty()) {
            text = string;
        } else if (topic != null) {
            for (NpcProfile.Step step : topic.steps) {
                string3 = NpcProfile.lineFor(step, session.relation);
                if (string3.isEmpty()) continue;
                text = string3;
                break;
            }
        }
        session.state = 5;
        session.quest = -1;
        NpcNet.sendTo(serverPlayer, new NpcNet.DlgView(guideNpc.getId(), GuideDialogue.speaker(guideNpc), npcProfile.title, GuideDialogue.fill(text, serverPlayer, session, npcProfile), arrayList, List.of(), session.relation, 5, npcProfile.hasShop(), GuideDialogue.style(npcProfile, serverPlayer, session.relation)));
    }

    private static void chooseQuest(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile npcProfile, int n) {
        List<NpcDialogueGraph.Node> list = GuideDialogue.graphQuestNodes(serverPlayer, guideNpc, npcProfile, session.relation);
        if (n >= 0 && n < list.size()) {
            int n2;
            NpcDialogueGraph.Node node = list.get(n);
            NpcDialogueGraph npcDialogueGraph = npcProfile.dialogueGraph;
            HashSet<Integer> hashSet = new HashSet<Integer>();
            if (!node.action.isBlank()) {
                NpcActions.run(serverPlayer, guideNpc, session.relation, node.action);
            }
            GuideDialogue.executeGraphTriggers(serverPlayer, guideNpc, session.relation, npcDialogueGraph, node.triggers, hashSet);
            if (node.next >= 0 && (n2 = GuideDialogue.resolveExecutionTarget(serverPlayer, guideNpc, session, npcDialogueGraph, node.next, hashSet)) >= 0) {
                GuideDialogue.startAtLine(serverPlayer, guideNpc, n2, hashSet);
            }
            return;
        }
        int n3 = n - list.size();
        List<Integer> list2 = GuideDialogue.questList(serverPlayer, guideNpc, npcProfile, session.relation);
        if (n3 >= 0 && n3 < list2.size()) {
            int n4 = list2.get(n3);
            NpcRelations npcRelations = NpcRelations.get(serverPlayer.server);
            if (!NpcQuests.isTaken(npcRelations, guideNpc, serverPlayer, n4)) {
                GuideDialogue.playQuest(serverPlayer, session, guideNpc, n4, 1);
            } else {
                GuideDialogue.openQuestMenu(serverPlayer, session, guideNpc, npcProfile, n4, true);
            }
        }
    }

    public static int menuStart(boolean bl) {
        return bl ? 0 : -1;
    }

    private static void openQuestMenu(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile npcProfile, int n, boolean bl) {
        session.menuStep = GuideDialogue.menuStart(bl);
        GuideDialogue.sendQuestMenu(serverPlayer, session, guideNpc, npcProfile, n);
    }

    private static void sendQuestMenu(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile npcProfile, int n) {
        if (n >= 0 && n < npcProfile.quests.size()) {
            Object object;
            boolean bl;
            String string;
            NpcProfile.Quest quest = npcProfile.quests.get(n);
            NpcProfile.Topic topic = GuideDialogue.questTopic(npcProfile, n, 2);
            Object object2 = null;
            if (topic != null && session.menuStep >= 0 && session.menuStep < topic.steps.size() && !(string = NpcProfile.lineFor(topic.steps.get(session.menuStep), session.relation)).isEmpty()) {
                object2 = string;
            }
            boolean bl2 = bl = object2 != null && NpcProfile.nextText(topic, session.menuStep, session.relation) >= 0;
            if (object2 == null) {
                object = quest.title != null && !quest.title.isEmpty() ? quest.title : "?";
                object2 = QUEST_ACTIONS + ARG + (String)object;
            }
            object = new ArrayList();
            ArrayList<String> arrayList = new ArrayList<String>();
            if (!bl) {
                for (int n2 : GuideDialogue.questMenuActions(npcProfile, serverPlayer, guideNpc, n, session.relation)) {
                    ((ArrayList)object).add(n2 == 0 && quest.points() ? "#gui.settledlands.quest.handinpoints" : MENU_KEYS[n2]);
                    arrayList.add(HINT_SAY);
                }
            }
            session.state = 6;
            session.quest = n;
            session.questTopic = npcProfile.questTopicIndex(n, 1);
            session.chainFrom = -1;
            session.answerStep = -1;
            session.closeOnEnd = false;
            session.menuOnEnd = -1;
            session.menuButtons = !bl;
            NpcNet.sendTo(serverPlayer, new NpcNet.DlgView(guideNpc.getId(), GuideDialogue.speaker(guideNpc), npcProfile.title, GuideDialogue.fill((String)object2, serverPlayer, session, npcProfile), (List<String>)object, arrayList, session.relation, 6, npcProfile.hasShop(), GuideDialogue.style(npcProfile, serverPlayer, session.relation)));
        } else {
            GuideDialogue.sendWelcome(serverPlayer, session, guideNpc);
        }
    }

    private static NpcProfile.Topic questTopic(NpcProfile npcProfile, int n, int n2) {
        int n3 = npcProfile.questTopicIndex(n, n2);
        return n3 >= 0 && n3 < npcProfile.topics.size() ? npcProfile.topics.get(n3) : null;
    }

    private static List<Integer> questMenuActions(NpcProfile npcProfile, ServerPlayer serverPlayer, GuideNpc guideNpc, int n, int n2) {
        NpcProfile.Quest quest = npcProfile.quests.get(n);
        boolean bl = NpcQuests.ready(serverPlayer, quest) && GuideDialogue.usableQuestTopic(npcProfile, n, 3);
        boolean bl2 = GuideDialogue.usableQuestTopic(npcProfile, n, 4);
        return GuideDialogue.questMenuButtons(bl, bl2);
    }

    public static List<Integer> questMenuButtons(boolean bl, boolean bl2) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        if (bl) {
            arrayList.add(0);
        }
        if (bl2) {
            arrayList.add(1);
        }
        arrayList.add(2);
        return arrayList;
    }

    private static boolean usableQuestTopic(NpcProfile npcProfile, int n, int n2) {
        int n3 = npcProfile.questTopicIndex(n, n2);
        return n3 >= 0 && n3 < npcProfile.topics.size() && NpcProfile.usable(npcProfile.topics.get(n3));
    }

    private static void chooseQuestMenu(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile npcProfile, int n) {
        if (session.quest < 0 || session.quest >= npcProfile.quests.size()) {
            GuideDialogue.sendWelcome(serverPlayer, session, guideNpc);
        } else if (!session.menuButtons) {
            int n2 = NpcProfile.nextText(GuideDialogue.questTopic(npcProfile, session.quest, 2), session.menuStep, session.relation);
            if (n2 >= 0) {
                session.menuStep = n2;
            }
            GuideDialogue.sendQuestMenu(serverPlayer, session, guideNpc, npcProfile, session.quest);
        } else {
            List<Integer> list = GuideDialogue.questMenuActions(npcProfile, serverPlayer, guideNpc, session.quest, session.relation);
            if (n >= 0 && n < list.size()) {
                switch (list.get(n)) {
                    case 0: {
                        GuideDialogue.playQuest(serverPlayer, session, guideNpc, session.quest, 3);
                        break;
                    }
                    case 1: {
                        GuideDialogue.playQuest(serverPlayer, session, guideNpc, session.quest, 4);
                        break;
                    }
                    case 2: {
                        NpcQuests.drop(serverPlayer, guideNpc, session.quest);
                        GuideDialogue.stop(serverPlayer);
                    }
                }
            }
        }
    }

    private static void playQuest(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, int n, int n2) {
        NpcProfile.Topic topic;
        NpcProfile npcProfile = guideNpc.profile();
        session.quest = n;
        int n3 = npcProfile.questTopicIndex(n, n2);
        NpcProfile.Topic topic2 = topic = n3 < 0 ? null : npcProfile.topics.get(n3);
        if (!NpcProfile.usable(topic)) {
            GuideDialogue.questShortcut(serverPlayer, session, guideNpc, npcProfile, n, n2);
        } else {
            session.topic = n3;
            session.step = 0;
            session.chainFrom = -1;
            session.answerStep = -1;
            session.closeOnEnd = false;
            session.menuOnEnd = -1;
            session.remindOnEnd = true;
            GuideDialogue.sendStep(serverPlayer, session, guideNpc);
        }
    }

    private static void questShortcut(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile npcProfile, int n, int n2) {
        if (n2 == 1) {
            NpcQuests.take(serverPlayer, guideNpc, n);
            GuideDialogue.openQuestMenu(serverPlayer, session, guideNpc, npcProfile, n, false);
        } else if (n2 == 3) {
            NpcQuests.runAction(serverPlayer, guideNpc, n, "quest:hand");
            GuideDialogue.sendWelcome(serverPlayer, session, guideNpc);
        } else {
            int n3 = npcProfile.questTopicIndex(n, n2);
            GuideDialogue.sendSilent(serverPlayer, session, guideNpc, n3 < 0 ? null : npcProfile.topics.get(n3));
        }
    }

    private static void sendWelcome(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc) {
        session.quest = -1;
        GuideDialogue.sendWelcome(serverPlayer, session, guideNpc, null);
    }

    private static void finish(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, NpcProfile npcProfile) {
        NpcProfile.Topic topic = GuideDialogue.topicOf(npcProfile, session);
        if (topic != null && topic.questRole == 4) {
            if (session.quest >= 0 && session.quest < npcProfile.quests.size() && NpcQuests.isTaken(NpcRelations.get(serverPlayer.server), guideNpc, serverPlayer, session.quest)) {
                GuideDialogue.sendQuestMenu(serverPlayer, session, guideNpc, npcProfile, session.quest);
                return;
            }
            if (session.questTopic >= 0 && session.questTopic < npcProfile.topics.size()) {
                session.quest = -1;
                GuideDialogue.sendQuestList(serverPlayer, session, guideNpc, npcProfile.topics.get(session.questTopic));
                return;
            }
        }
        if (session.menuOnEnd >= 0 && session.menuOnEnd < npcProfile.quests.size()) {
            int n = session.menuOnEnd;
            boolean bl = session.remindOnEnd;
            session.menuOnEnd = -1;
            session.remindOnEnd = true;
            GuideDialogue.openQuestMenu(serverPlayer, session, guideNpc, npcProfile, n, bl);
        } else if (session.closeOnEnd) {
            GuideDialogue.stop(serverPlayer);
        } else {
            GuideDialogue.sendWelcome(serverPlayer, session, guideNpc);
        }
    }

    private static void sendWelcome(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, String string) {
        NpcProfile npcProfile = guideNpc.profile();
        session.state = 0;
        session.topic = -1;
        session.step = 0;
        session.closeOnEnd = false;
        session.menuOnEnd = -1;
        session.remindOnEnd = true;
        session.relation = guideNpc.relationTo(serverPlayer);
        ArrayList<String> arrayList = new ArrayList<String>();
        ArrayList<String> arrayList2 = new ArrayList<String>();
        for (int n : GuideDialogue.visibleTopics(npcProfile, guideNpc)) {
            NpcProfile.Topic topic;
            if (n == -2) {
                arrayList.add("#gui.settledlands.tab.quest");
                arrayList2.add("#gui.settledlands.type.quest");
                continue;
            }
            NpcProfile.Topic topic2 = topic = n < 0 ? null : npcProfile.topics.get(n);
            if (topic == null) {
                arrayList.add(LINE_LEGACY);
                arrayList2.add(KIND_LEGACY);
                continue;
            }
            arrayList.add(topic.title);
            arrayList2.add(GuideDialogue.kindOf(topic));
        }
        NpcNet.sendTo(serverPlayer, new NpcNet.DlgView(guideNpc.getId(), GuideDialogue.speaker(guideNpc), npcProfile.title, GuideDialogue.fill(string == null ? npcProfile.welcome : string, serverPlayer, session, npcProfile), arrayList, arrayList2, session.relation, 0, npcProfile.hasShop(), GuideDialogue.style(npcProfile, serverPlayer, session.relation)));
    }

    private static String fill(String string, ServerPlayer serverPlayer, Session session, NpcProfile npcProfile) {
        NpcProfile.Quest quest = session.quest >= 0 && session.quest < npcProfile.quests.size() ? npcProfile.quests.get(session.quest) : null;
        return NpcProfile.fillQuest(string, serverPlayer, session.relation, quest);
    }

    private static void sendStep(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc) {
        NpcProfile npcProfile = guideNpc.profile();
        NpcProfile.Topic topic = GuideDialogue.topicOf(npcProfile, session);
        NpcProfile.Step step = GuideDialogue.stepOf(topic, session);
        if (step == null) {
            GuideDialogue.sendWelcome(serverPlayer, session, guideNpc);
        } else {
            session.state = 1;
            boolean bl = topic != null && NpcProfile.isQuestTopic(topic);
            int n = session.step;
            if (bl && session.chainFrom >= 0 && session.chainFrom != session.step) {
                boolean bl2 = session.step > session.chainFrom;
                boolean bl3 = GuideDialogue.hasVisibleAnswers(serverPlayer, topic, session.step, session.relation);
                if (!bl2) {
                    session.chainFrom = -1;
                } else if (bl3) {
                    session.chainFrom = -1;
                } else {
                    n = NpcProfile.chainNext(topic, session.step) >= 0 ? -1 : session.chainFrom;
                }
            }
            if (bl && session.chainFrom < 0 && n == session.step && GuideDialogue.chainReads(serverPlayer, topic, session.step, session.relation)) {
                session.chainFrom = session.step;
                n = -1;
            }
            session.answerStep = n;
            ArrayList<String> arrayList = new ArrayList<String>();
            ArrayList<String> arrayList2 = new ArrayList<String>();
            if (n >= 0 && n < topic.steps.size()) {
                for (NpcProfile.Answer answer : GuideDialogue.visibleAnswers(serverPlayer, topic.steps.get(n), session.relation)) {
                    arrayList.add(GuideDialogue.fill(answer.player, serverPlayer, session, npcProfile));
                    arrayList2.add(HINT_SAY);
                }
            }
            NpcNet.sendTo(serverPlayer, new NpcNet.DlgView(guideNpc.getId(), GuideDialogue.speaker(guideNpc), npcProfile.title, GuideDialogue.fill(NpcProfile.lineFor(step, session.relation), serverPlayer, session, npcProfile), arrayList, arrayList2, session.relation, 1, npcProfile.hasShop(), GuideDialogue.style(npcProfile, serverPlayer, session.relation)));
        }
    }

    public static void resend(ServerPlayer serverPlayer, NpcProfile npcProfile) {
        GuideNpc guideNpc;
        Session session = SESSIONS.get(serverPlayer.getUUID());
        if (session != null && (guideNpc = GuideDialogue.npcOf(serverPlayer.server, session)) != null) {
            GuideDialogue.resend(serverPlayer, session, guideNpc);
        }
    }

    private static void resend(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc) {
        if (session.escortLine != 0) {
            GuideDialogue.sendEscortLine(serverPlayer, session, guideNpc);
            return;
        }
        if (guideNpc.isEscorting()) {
            GuideDialogue.startEscort(serverPlayer, guideNpc, false);
            return;
        }
        if (session.inShop) {
            NpcShop.send(serverPlayer, guideNpc);
            return;
        }
        if (session.graphNode >= 0 && GuideDialogue.graphActive(guideNpc.profile())) {
            GuideDialogue.sendGraph(serverPlayer, session, guideNpc);
            return;
        }
        switch (session.state) {
            case 1: {
                GuideDialogue.sendStep(serverPlayer, session, guideNpc);
                break;
            }
            case 2: {
                GuideDialogue.sendLine(serverPlayer.getServer(), serverPlayer, session, guideNpc, session.pendingReaction, 2);
                break;
            }
            case 3: {
                if (session.legacy.isEmpty()) {
                    GuideDialogue.sendWelcome(serverPlayer, session, guideNpc);
                    break;
                }
                GuideDialogue.sendLegacyLine(serverPlayer, session, guideNpc);
                break;
            }
            case 4: {
                GuideDialogue.sendLine(serverPlayer.getServer(), serverPlayer, session, guideNpc, session.rootLine.isEmpty() ? guideNpc.profile().welcome : session.rootLine, 4);
                break;
            }
            case 5: {
                NpcProfile npcProfile = guideNpc.profile();
                NpcProfile.Topic topic = session.questTopic >= 0 && session.questTopic < npcProfile.topics.size() ? npcProfile.topics.get(session.questTopic) : null;
                GuideDialogue.sendQuestList(serverPlayer, session, guideNpc, topic, null, QUEST_NONE);
                break;
            }
            case 6: {
                GuideDialogue.sendQuestMenu(serverPlayer, session, guideNpc, guideNpc.profile(), session.quest);
                break;
            }
            default: {
                GuideDialogue.sendWelcome(serverPlayer, session, guideNpc);
            }
        }
    }

    private static NpcNet.DlgStyle style(NpcProfile npcProfile, ServerPlayer serverPlayer, int n) {
        String string = npcProfile.reputationLabel(n);
        return new NpcNet.DlgStyle(npcProfile.style, npcProfile.textColor, npcProfile.nameColor, npcProfile.typingSpeed, npcProfile.showSpeaker, npcProfile.keyHints, npcProfile.answerNumbers, string, npcProfile.showDialogueTab, npcProfile.showTradeTab && npcProfile.hasShop(), npcProfile.showQuestTab && (!npcProfile.quests.isEmpty() || npcProfile.dialogueGraph != null && npcProfile.dialogueGraph.hasQuestNodes()), npcProfile.showPhrasesTab, npcProfile.defaultTab, npcProfile.zoom, npcProfile.offsetX, npcProfile.offsetY, npcProfile.cameraOnFace, npcProfile.blockMouseLook, npcProfile.dim, npcProfile.blur, npcProfile.muteHud, npcProfile.vignette, npcProfile.exitKey, npcProfile.blockMovement, npcProfile.pauseWorld, npcProfile.voice, npcProfile.voicePitch);
    }

    private static void startLegacy(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc) {
        session.legacy = GuideDialogue.group(guideNpc.sortedPhrases());
        session.legacyCursor = 0;
        if (session.legacy.isEmpty()) {
            GuideDialogue.sendWelcome(serverPlayer, session, guideNpc);
        } else {
            GuideDialogue.sendLegacyLine(serverPlayer, session, guideNpc);
        }
    }

    private static void advanceLegacy(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc) {
        if (session.legacyCursor + 1 >= session.legacy.size()) {
            GuideDialogue.sendWelcome(serverPlayer, session, guideNpc);
        } else {
            ++session.legacyCursor;
            GuideDialogue.sendLegacyLine(serverPlayer, session, guideNpc);
        }
    }

    private static void sendLegacyLine(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc) {
        List<GuidePhrase> list = session.legacy.get(session.legacyCursor);
        GuidePhrase guidePhrase = list.get(serverPlayer.getRandom().nextInt(list.size()));
        boolean bl = session.legacyCursor >= session.legacy.size() - 1;
        session.state = 3;
        NpcNet.sendTo(serverPlayer, new NpcNet.DlgView(guideNpc.getId(), GuideDialogue.speaker(guideNpc), guideNpc.profile().title, guidePhrase.text(), List.of(bl ? BTN_FINISH : BTN_MORE), List.of(HINT_NEXT), session.relation, 3, guideNpc.profile().hasShop(), GuideDialogue.style(guideNpc.profile(), serverPlayer, session.relation)));
    }

    private static List<List<GuidePhrase>> group(List<GuidePhrase> list) {
        ArrayList<List<GuidePhrase>> arrayList = new ArrayList<List<GuidePhrase>>();
        for (GuidePhrase guidePhrase : list) {
            if (arrayList.isEmpty() || arrayList.get(arrayList.size() - 1).get(0).number() != guidePhrase.number()) {
                arrayList.add(new ArrayList());
            }
            arrayList.get(arrayList.size() - 1).add(guidePhrase);
        }
        return arrayList;
    }

    private static List<Integer> visibleTopics(NpcProfile npcProfile, GuideNpc guideNpc) {
        if (npcProfile == null || npcProfile.topics == null) {
            return new ArrayList<Integer>();
        }
        List<Integer> list = GuideDialogue.collectTopics(npcProfile, true);
        if (list.isEmpty()) {
            list = GuideDialogue.collectTopics(npcProfile, false);
        }
        int n = npcProfile.defaultTab;
        list.sort(Comparator.comparingInt(n2 -> {
            NpcProfile.Topic topic = npcProfile.topics.get((int)n2);
            return GuideDialogue.rankOf(topic.type, n);
        }));
        if (list.isEmpty() && npcProfile.showQuestTab && !npcProfile.quests.isEmpty()) {
            list.add(-2);
        }
        if (list.isEmpty() && !guideNpc.sortedPhrases().isEmpty()) {
            list.add(-1);
        }
        return list;
    }

    private static List<Integer> collectTopics(NpcProfile npcProfile, boolean bl) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        if (npcProfile == null || npcProfile.topics == null) {
            return arrayList;
        }
        for (int i = 0; i < npcProfile.topics.size(); ++i) {
            NpcProfile.Topic topic = npcProfile.topics.get(i);
            if (NpcProfile.isQuestTopic(topic) || bl && !npcProfile.showsKind(topic.type) || topic.type == 1 && !npcProfile.hasShop() || bl && topic.type != 1 && topic.type != 4 && !NpcProfile.usable(topic)) continue;
            arrayList.add(i);
        }
        return arrayList;
    }

    private static String kindOf(NpcProfile.Topic topic) {
        if (topic.kind != null && !topic.kind.isEmpty()) {
            return topic.kind;
        }
        int n = NpcProfile.clamp(topic.type, 0, NpcProfile.TYPE_COUNT - 1);
        return "#" + NpcProfile.TYPE_KEYS[n];
    }

    private static List<NpcProfile.Answer> visibleAnswers(ServerPlayer serverPlayer, NpcProfile.Step step, int n) {
        ArrayList<NpcProfile.Answer> arrayList = new ArrayList<NpcProfile.Answer>();
        if (step == null || serverPlayer == null) {
            return arrayList;
        }
        NpcPoints npcPoints = serverPlayer.getServer() == null ? null : NpcPoints.get(serverPlayer.getServer());
        for (NpcProfile.Answer answer : step.answers) {
            if (answer.pointsName != null && !answer.pointsName.isBlank()) {
                int n2;
                if (npcPoints == null || answer.minPoints > (n2 = npcPoints.get(serverPlayer.getUUID(), answer.pointsName, answer.pointsShared)) || n2 > answer.maxPoints) continue;
                arrayList.add(answer);
                continue;
            }
            if (!NpcProfile.visible(answer, n)) continue;
            arrayList.add(answer);
        }
        return arrayList;
    }

    private static boolean hasVisibleAnswers(ServerPlayer serverPlayer, NpcProfile.Topic topic, int n, int n2) {
        return topic != null && n >= 0 && n < topic.steps.size() && !GuideDialogue.visibleAnswers(serverPlayer, topic.steps.get(n), n2).isEmpty();
    }

    private static boolean chainReads(ServerPlayer serverPlayer, NpcProfile.Topic topic, int n, int n2) {
        if (!GuideDialogue.hasVisibleAnswers(serverPlayer, topic, n, n2)) {
            return false;
        }
        int n3 = n;
        for (int i = 0; i < 64; ++i) {
            int n4 = NpcProfile.chainNext(topic, n3);
            if (n4 < 0) {
                return false;
            }
            if (GuideDialogue.hasVisibleAnswers(serverPlayer, topic, n4, n2)) {
                return false;
            }
            if (NpcProfile.chainNext(topic, n4) < 0) {
                return true;
            }
            n3 = n4;
        }
        return false;
    }

    private static NpcProfile.Topic topicOf(NpcProfile npcProfile, Session session) {
        return session.topic >= 0 && session.topic < npcProfile.topics.size() ? npcProfile.topics.get(session.topic) : null;
    }

    private static NpcProfile.Step stepOf(NpcProfile.Topic topic, Session session) {
        return topic != null && session.step >= 0 && session.step < topic.steps.size() ? topic.steps.get(session.step) : null;
    }

    private static String speaker(GuideNpc guideNpc) {
        if (guideNpc == null) {
            return "";
        }
        String string = guideNpc.profile().name;
        return string != null && !string.isEmpty() ? string : guideNpc.getDisplayName().getString();
    }

    private static GuideNpc npcOf(MinecraftServer minecraftServer, Session session) {
        GuideNpc guideNpc;
        ServerLevel serverLevel = minecraftServer.getLevel(session.dimension);
        if (serverLevel == null) {
            return null;
        }
        Entity entity = serverLevel.getEntity(session.entityId);
        return entity instanceof GuideNpc && (guideNpc = (GuideNpc)entity).isAlive() ? guideNpc : null;
    }

    private static boolean stillTalking(MinecraftServer minecraftServer, GuideNpc guideNpc, UUID uUID) {
        for (Map.Entry<UUID, Session> entry : SESSIONS.entrySet()) {
            ServerLevel serverLevel;
            if (entry.getKey().equals(uUID) || entry.getValue().entityId != guideNpc.getId() || (serverLevel = minecraftServer.getLevel(entry.getValue().dimension)) == null || serverLevel.getEntity(entry.getValue().entityId) != guideNpc) continue;
            return true;
        }
        return false;
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post post) {
        if (!SESSIONS.isEmpty()) {
            MinecraftServer minecraftServer = post.getServer();
            GuideDialogue.pruneListeners(minecraftServer);
            Iterator<Map.Entry<UUID, Session>> iterator = SESSIONS.entrySet().iterator();
            while (iterator.hasNext()) {
                boolean bl;
                NpcProfile npcProfile;
                Map.Entry<UUID, Session> entry = iterator.next();
                UUID uUID = entry.getKey();
                Session session = entry.getValue();
                ServerPlayer serverPlayer = minecraftServer.getPlayerList().getPlayer(uUID);
                GuideNpc guideNpc = GuideDialogue.npcOf(minecraftServer, session);
                NpcProfile npcProfile2 = npcProfile = guideNpc == null ? null : guideNpc.profile();
                double d = session.escortLine != 0 ? 8.0 : (session.graphNode >= 0 ? Math.max(npcProfile == null ? 4.0 : (double)npcProfile.radius, 16.0) : (npcProfile == null ? 4.0 : (double)npcProfile.radius));
                boolean bl2 = bl = guideNpc != null && serverPlayer != null && serverPlayer.level() == guideNpc.level() && serverPlayer.distanceToSqr(guideNpc) <= d * d;
                if (serverPlayer != null && serverPlayer.isAlive() && !serverPlayer.isRemoved() && guideNpc != null && bl && !serverPlayer.isSpectator()) {
                    if (npcProfile.blockMovement) {
                        Vec3 vec3 = serverPlayer.getDeltaMovement();
                        serverPlayer.setDeltaMovement(0.0, vec3.y, 0.0);
                        serverPlayer.xxa = 0.0f;
                        serverPlayer.yya = 0.0f;
                        serverPlayer.zza = 0.0f;
                    }
                    if (!guideNpc.isTalking()) {
                        guideNpc.setTalking(true);
                    }
                    if (!npcProfile.lookAtPlayer) continue;
                    guideNpc.getLookControl().setLookAt(serverPlayer, 30.0f, 30.0f);
                    continue;
                }
                if (serverPlayer != null && GuideDialogue.cutsceneConversationActive(serverPlayer)) continue;
                iterator.remove();
                if (guideNpc != null && serverPlayer != null && guideNpc.isEscorting()) {
                    guideNpc.escort().dialogueClosed(serverPlayer, session.escortLine == 2);
                }
                if (guideNpc != null && !GuideDialogue.stillTalking(minecraftServer, guideNpc, uUID)) {
                    guideNpc.setTalking(false);
                }
                GuideDialogue.closeListeners(minecraftServer, uUID, session.entityId);
                if (serverPlayer == null) continue;
                NpcNet.sendTo(serverPlayer, new NpcNet.DlgEnd(session.entityId));
            }
        }
    }

    private static void pruneListeners(MinecraftServer minecraftServer) {
        Iterator<Map.Entry<UUID, Set<UUID>>> iterator = LISTENERS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Set<UUID>> entry = iterator.next();
            UUID uUID = entry.getKey();
            Iterator<UUID> iterator2 = entry.getValue().iterator();
            while (iterator2.hasNext()) {
                UUID uUID2 = iterator2.next();
                if (minecraftServer.getPlayerList().getPlayer(uUID2) != null) continue;
                iterator2.remove();
                Observation observation = OBSERVING.get(uUID2);
                if (observation == null || !observation.owner.equals(uUID)) continue;
                OBSERVING.remove(uUID2);
            }
            if (!entry.getValue().isEmpty()) continue;
            iterator.remove();
        }
    }

    public static boolean graphActive(NpcProfile npcProfile) {
        if (npcProfile == null || npcProfile.dialogueGraph == null || !npcProfile.dialogueGraph.enabled) {
            return false;
        }
        NpcDialogueGraph npcDialogueGraph = npcProfile.dialogueGraph;
        return npcDialogueGraph.get(npcDialogueGraph.entry) != null;
    }

    public static boolean evalCondition(int n, int n2, int n3) {
        return switch (n2) {
            case 0 -> {
                if (n == n3) {
                    yield true;
                }
                yield false;
            }
            case 1 -> {
                if (n != n3) {
                    yield true;
                }
                yield false;
            }
            case 2 -> {
                if (n >= n3) {
                    yield true;
                }
                yield false;
            }
            case 3 -> {
                if (n > n3) {
                    yield true;
                }
                yield false;
            }
            case 4 -> {
                if (n <= n3) {
                    yield true;
                }
                yield false;
            }
            case 5 -> {
                if (n < n3) {
                    yield true;
                }
                yield false;
            }
            default -> false;
        };
    }

    public static int resolveExecutionTarget(ServerPlayer serverPlayer, GuideNpc guideNpc, Session session, NpcDialogueGraph npcDialogueGraph, int n, Set<Integer> set) {
        return GuideDialogue.resolveExecutionTarget(serverPlayer, null, guideNpc, session, npcDialogueGraph, n, set);
    }

    public static int resolveExecutionTarget(ServerPlayer serverPlayer, Entity entity, GuideNpc guideNpc, Session session, NpcDialogueGraph npcDialogueGraph, int n, Set<Integer> set) {
        if (npcDialogueGraph == null || n < 0) {
            return -1;
        }
        RADIUS_LOG.info("[graph] walk starts at node #{} for {}", (Object)n, (Object)(serverPlayer != null ? serverPlayer.getName().getString() : (entity != null ? entity.getName().getString() : "?")));
        HashSet<Integer> hashSet = new HashSet<Integer>();
        boolean bl = entity != null && serverPlayer == null;
        boolean bl2 = !bl;
        int n2 = n;
        while (n2 >= 0 && hashSet.add(n2) && hashSet.size() <= 256) {
            ServerLevel serverLevel;
            ServerLevel serverLevel2;
            ServerLevel serverLevel3;
            Object object;
            Vec3 vec3;
            boolean bl3;
            NpcDialogueGraph.Node node = npcDialogueGraph.get(n2);
            if (node == null) {
                RADIUS_LOG.info("[graph] walk: node #{} not found, stop", (Object)n2);
                return -1;
            }
            RADIUS_LOG.info("[graph] walk hits node #{} type {} ctx {}", node.id, node.type, bl ? "mob" : "player");
            int n3 = session != null ? session.relation : (guideNpc != null && serverPlayer != null ? guideNpc.relationTo(serverPlayer) : 0);
            List<NpcDialogueGraph.Node> list = Collections.emptyList();
            if (bl2 && (set == null || !set.contains(-999999))) {
                list = GuideDialogue.findRadiusAttachments(npcDialogueGraph, node, set);
            }
            GuideDialogue.expandRadiusAttachments(serverPlayer, guideNpc, npcDialogueGraph, node, list, set);
            boolean bl4 = bl3 = !list.isEmpty() && !GuideDialogue.initiatorExecutesWithRadiusGate(serverPlayer, guideNpc, list);
            if (node.type != 3 && !GuideDialogue.isIncomingIfSatisfied(serverPlayer, guideNpc, n3, npcDialogueGraph, node)) {
                return -1;
            }
            if (node.type == 0) {
                return bl ? -1 : node.id;
            }
            if (node.type == 2) {
                if (set != null) {
                    set.add(node.id);
                }
                if (!(node.action.isBlank() || guideNpc == null || serverPlayer == null && !bl || bl3)) {
                    GuideDialogue.runNodeAction(serverPlayer, entity, guideNpc, n3, node.action);
                }
                GuideDialogue.executeGraphTriggers(serverPlayer, entity, guideNpc, n3, npcDialogueGraph, node.triggers, set);
                n2 = node.next;
                continue;
            }
            if (node.type == 4) {
                if (set != null) {
                    set.add(node.id);
                }
                if (!node.pointsName.isBlank() && node.varValue != 0 && serverPlayer != null && serverPlayer.getServer() != null) {
                    GuideDialogue.addVarValue(serverPlayer, guideNpc, node.pointsName, node.pointsShared, node.varLocal, node.varValue);
                }
                if (!node.action.isBlank() && guideNpc != null && (serverPlayer != null || bl)) {
                    GuideDialogue.runNodeAction(serverPlayer, entity, guideNpc, n3, node.action);
                }
                GuideDialogue.executeGraphTriggers(serverPlayer, entity, guideNpc, n3, npcDialogueGraph, node.triggers, set);
                n2 = node.next;
                continue;
            }
            if (node.type == 3) {
                NpcDialogueGraph.Node node2;
                if (set != null) {
                    set.add(node.id);
                }
                String string = node.pointsName;
                boolean bl5 = node.pointsShared;
                boolean varLocal = node.varLocal;
                if (node.varInputNode >= 0 && (node2 = npcDialogueGraph.get(node.varInputNode)) != null && node2.type == 4 && !node2.pointsName.isBlank()) {
                    string = node2.pointsName;
                    bl5 = node2.pointsShared;
                    varLocal = node2.varLocal;
                }
                int n4 = 0;
                if (!string.isBlank()) {
                    n4 = GuideDialogue.readVarValue(serverPlayer, guideNpc, string, bl5, varLocal);
                }
                boolean bl6 = GuideDialogue.evalCondition(n4, node.varOp, node.varCompare);
                if (!node.action.isBlank() && guideNpc != null && (serverPlayer != null || bl)) {
                    GuideDialogue.runNodeAction(serverPlayer, entity, guideNpc, n3, node.action);
                }
                GuideDialogue.executeGraphTriggers(serverPlayer, entity, guideNpc, n3, npcDialogueGraph, node.triggers, set);
                n2 = bl6 ? node.next : node.falseNext;
                continue;
            }
            if (node.type == 5) {
                boolean bl7;
                if (set != null) {
                    set.add(node.id);
                }
                if (bl7 = GuideDialogue.checkProximityCondition(guideNpc, serverPlayer, node)) {
                    if (!node.action.isBlank() && guideNpc != null && (serverPlayer != null || bl)) {
                        GuideDialogue.runNodeAction(serverPlayer, entity, guideNpc, n3, node.action);
                    }
                    GuideDialogue.executeGraphTriggers(serverPlayer, entity, guideNpc, n3, npcDialogueGraph, node.triggers, set);
                    n2 = node.next;
                    continue;
                }
                n2 = -1;
                continue;
            }
            if (node.type == 6 || node.type == 7 || node.type == 8) {
                if (set != null) {
                    set.add(node.id);
                }
                if (!node.action.isBlank() && guideNpc != null && (serverPlayer != null || bl)) {
                    GuideDialogue.runNodeAction(serverPlayer, entity, guideNpc, n3, node.action);
                }
                GuideDialogue.executeGraphTriggers(serverPlayer, entity, guideNpc, n3, npcDialogueGraph, node.triggers, set);
                n2 = node.next;
                continue;
            }
            if (node.type == 9 || node.type == 10) {
                if (set != null) {
                    set.add(node.id);
                }
                if (node.type == 9 && guideNpc != null && !node.animName.isBlank()) {
                    guideNpc.playCustomAnimation(node.animName, node.animLoop, node.animBone);
                }
                if (!(node.action.isBlank() || serverPlayer == null && guideNpc == null)) {
                    GuideDialogue.runNodeAction(serverPlayer, entity, guideNpc, n3, node.action);
                }
                GuideDialogue.executeGraphTriggers(serverPlayer, entity, guideNpc, n3, npcDialogueGraph, node.triggers, set);
                n2 = node.next;
                continue;
            }
            if (node.type == 11) {
                if (set != null) {
                    set.add(node.id);
                }
                if (guideNpc != null) {
                    GuideDialogue.executeMoveNode(guideNpc, serverPlayer, node);
                }
                if (!(node.action.isBlank() || serverPlayer == null && guideNpc == null)) {
                    GuideDialogue.runNodeAction(serverPlayer, entity, guideNpc, n3, node.action);
                }
                GuideDialogue.executeGraphTriggers(serverPlayer, entity, guideNpc, n3, npcDialogueGraph, node.triggers, set);
                n2 = node.next;
                continue;
            }
            if (node.type == 12) {
                if (set != null) {
                    set.add(node.id);
                }
                if (guideNpc != null) {
                    GuideDialogue.executeMobilityNode(guideNpc, node);
                }
                if (!(node.action.isBlank() || serverPlayer == null && guideNpc == null)) {
                    GuideDialogue.runNodeAction(serverPlayer, entity, guideNpc, n3, node.action);
                }
                n2 = -1;
                continue;
            }
            if (node.type == 14) {
                if (set != null) {
                    set.add(node.id);
                }
                if (!(node.action.isBlank() || serverPlayer == null && guideNpc == null)) {
                    GuideDialogue.runNodeAction(serverPlayer, entity, guideNpc, n3, node.action);
                }
                if (serverPlayer != null && !node.cutsceneName.isBlank()) {
                    boolean bl8 = CutsceneCamera.play(serverPlayer, node.cutsceneName);
                    if (session != null && !bl) {
                        boolean bl9;
                        ArrayList<String> arrayList = new ArrayList<String>();
                        NpcDialogueGraph.Node node3 = bl8 ? npcDialogueGraph.get(node.next) : null;
                        HashSet<Integer> hashSet2 = new HashSet<Integer>();
                        hashSet2.add(node.id);
                        while (node3 != null && node3.type == 14 && hashSet2.add(node3.id)) {
                            if (set != null) {
                                set.add(node3.id);
                            }
                            if (!node3.cutsceneName.isBlank()) {
                                arrayList.add(node3.cutsceneName);
                            }
                            if (!(node3.action.isBlank() || serverPlayer == null && guideNpc == null)) {
                                GuideDialogue.runNodeAction(serverPlayer, entity, guideNpc, n3, node3.action);
                            }
                            GuideDialogue.executeGraphTriggers(serverPlayer, entity, guideNpc, n3, npcDialogueGraph, node3.triggers, set);
                            node3 = npcDialogueGraph.get(node3.next);
                        }
                        boolean bl10 = node3 != null && node3.type == 0;
                        boolean bl5 = bl9 = bl10 && node3.cutsceneLine;
                        if (bl10) {
                            session.graphNode = node3.id;
                        }
                        if (bl10 || !arrayList.isEmpty()) {
                            PENDING_CUTSCENE_REPLICA.put(serverPlayer.getUUID(), new PendingCutsceneReplica(guideNpc, session, bl9, bl10 && !bl9, arrayList));
                            RADIUS_LOG.info("[cutscene] replica ARMED for {} -> line {} after scene '{}' (+{} chained scene(s), replica={})", serverPlayer.getName().getString(), bl10 ? "#" + node3.id : "none", node.cutsceneName, arrayList.size(), bl9);
                        } else {
                            RADIUS_LOG.info("[cutscene] replica NOT armed node #{}: started={} cont={} contType={} flag={} session={} mobCtx={}", node.id, bl8, node3 != null, node3 != null ? node3.type : -1, node3 != null && node3.cutsceneLine, session != null, bl);
                        }
                    }
                }
                GuideDialogue.executeGraphTriggers(serverPlayer, entity, guideNpc, n3, npcDialogueGraph, node.triggers, set);
                n2 = -1;
                continue;
            }
            if (node.type == 13) {
                if (set != null) {
                    set.add(node.id);
                }
                int n5 = Math.max(1, node.randomMin);
                int n6 = Math.max(n5, node.randomMax);
                int n7 = n5 + ThreadLocalRandom.current().nextInt(n6 - n5 + 1);
                int n8 = n7 - 1;
                if (!(node.action.isBlank() || serverPlayer == null && guideNpc == null)) {
                    GuideDialogue.runNodeAction(serverPlayer, entity, guideNpc, n3, node.action);
                }
                GuideDialogue.executeGraphTriggers(serverPlayer, entity, guideNpc, n3, npcDialogueGraph, node.triggers, set);
                if (n8 >= 0 && n8 < node.randomBranches.size()) {
                    n2 = node.randomBranches.get(n8);
                    continue;
                }
                n2 = -1;
                continue;
            }
            if (node.type != 15) break;
            if (set != null && !set.add(node.id)) {
                n2 = -1;
                continue;
            }
            if (!(node.action.isBlank() || serverPlayer == null && guideNpc == null)) {
                GuideDialogue.runNodeAction(serverPlayer, entity, guideNpc, n3, node.action);
            }
            int n9 = Math.max(1, Math.min(96, node.radius));
            int n10 = Math.max(0, Math.min(4, node.radiusTarget));
            vec3 = guideNpc != null ? guideNpc.position() : (serverPlayer != null ? serverPlayer.position() : null);
            if (guideNpc != null && guideNpc.level() instanceof ServerLevel) {
                serverLevel2 = (ServerLevel)guideNpc.level();
            } else if (serverPlayer != null && serverPlayer.level() instanceof ServerLevel) {
                serverLevel2 = (ServerLevel)serverPlayer.level();
            } else {
                serverLevel2 = null;
            }
            if (vec3 != null && serverLevel2 != null) {
                Set<Integer> throwable;
                double d = (double)n9 * (double)n9;
                object = new AABB(vec3.x - (double)n9, vec3.y - (double)n9, vec3.z - (double)n9, vec3.x + (double)n9, vec3.y + (double)n9, vec3.z + (double)n9);
                boolean bl12 = n10 == 0 || n10 == 3;
                boolean bl13 = serverPlayer != null && serverPlayer.distanceToSqr(vec3) <= d;
                int[] nArray = new int[]{0};
                RADIUS_LOG.info("[radius] node #{} type {} - mode {}, radius {}, center {}, attached triggers {}", node.id, node.type, n10, n9, vec3, node.triggers.size());
                if (bl12) {
                    for (ServerPlayer serverPlayer2 : serverLevel2.getEntitiesOfClass(ServerPlayer.class, (AABB)object)) {
                        if (serverPlayer2 == serverPlayer || serverPlayer2.distanceToSqr(vec3) > d) continue;
                        try {
                            throwable = GuideDialogue.fanSnapshot(set);
                            GuideDialogue.executeGraphTriggers(serverPlayer2, null, guideNpc, guideNpc != null ? guideNpc.relationTo(serverPlayer2) : 0, npcDialogueGraph, node.triggers, throwable);
                            GuideDialogue.resolveExecutionTarget(serverPlayer2, guideNpc, null, npcDialogueGraph, node.next, throwable);
                            nArray[0] = nArray[0] + 1;
                        }
                        catch (Throwable throwable2) {
                            RADIUS_LOG.warn("[radius] fan-out failed for player {}: {}", (Object)serverPlayer2.getName().getString(), (Object)String.valueOf(throwable2));
                        }
                    }
                }
                if (n10 == 1 || n10 == 3) {
                    for (GuideNpc guideNpc2 : serverLevel2.getEntitiesOfClass(GuideNpc.class, (AABB)object)) {
                        if (guideNpc2 == guideNpc || !guideNpc2.isAlive() || guideNpc2.distanceToSqr(vec3) > d) continue;
                        try {
                            throwable = GuideDialogue.fanSnapshot(set);
                            GuideDialogue.executeGraphTriggers(null, guideNpc2, guideNpc, 0, npcDialogueGraph, node.triggers, throwable);
                            GuideDialogue.resolveExecutionTarget(null, guideNpc2, guideNpc, null, npcDialogueGraph, node.next, throwable);
                            nArray[0] = nArray[0] + 1;
                        }
                        catch (Throwable throwable3) {
                            RADIUS_LOG.warn("[radius] fan-out failed for npc {}: {}", (Object)guideNpc2.getName().getString(), (Object)String.valueOf(throwable3));
                        }
                    }
                }
                if (n10 == 2 || n10 == 3) {
                    for (Entity entity2 : serverLevel2.getEntitiesOfClass(Mob.class, (AABB)object)) {
                        if (!(entity2 instanceof Enemy) || entity2 instanceof GuideNpc || !entity2.isAlive() || entity2.distanceToSqr(vec3) > d) continue;
                        try {
                            throwable = GuideDialogue.fanSnapshot(set);
                            GuideDialogue.executeGraphTriggers(null, entity2, guideNpc, 0, npcDialogueGraph, node.triggers, throwable);
                            GuideDialogue.resolveExecutionTarget(null, entity2, guideNpc, null, npcDialogueGraph, node.next, throwable);
                            nArray[0] = nArray[0] + 1;
                        }
                        catch (Throwable throwable4) {
                            RADIUS_LOG.warn("[radius] fan-out failed for monster {}: {}", (Object)entity2.getName().getString(), (Object)String.valueOf(throwable4));
                        }
                    }
                }
                if (n10 == 4 || n10 == 3) {
                    for (Entity entity3 : serverLevel2.getEntitiesOfClass(Mob.class, (AABB)object)) {
                        if (entity3 instanceof Enemy || entity3 instanceof GuideNpc || !entity3.isAlive() || entity3.distanceToSqr(vec3) > d) continue;
                        try {
                            throwable = GuideDialogue.fanSnapshot(set);
                            GuideDialogue.executeGraphTriggers(null, entity3, guideNpc, 0, npcDialogueGraph, node.triggers, throwable);
                            GuideDialogue.resolveExecutionTarget(null, entity3, guideNpc, null, npcDialogueGraph, node.next, throwable);
                            nArray[0] = nArray[0] + 1;
                        }
                        catch (Throwable throwable5) {
                            RADIUS_LOG.warn("[radius] fan-out failed for passive {}: {}", (Object)entity3.getName().getString(), (Object)String.valueOf(throwable5));
                        }
                    }
                }
                RADIUS_LOG.info("[radius] node #{} fan-out finished: {} entities affected", (Object)node.id, (Object)nArray[0]);
                if (bl12) {
                    GuideDialogue.executeGraphTriggers(serverPlayer, entity, guideNpc, n3, npcDialogueGraph, node.triggers, set);
                } else {
                    RADIUS_LOG.info("[radius] node #{} initiator trigger pass skipped (mob-only mode {})", (Object)node.id, (Object)n10);
                }
                n2 = bl12 ? (bl13 ? node.next : -1) : node.next;
                continue;
            }
            GuideDialogue.executeGraphTriggers(serverPlayer, entity, guideNpc, n3, npcDialogueGraph, node.triggers, set);
            n2 = node.next;
        }
        return -1;
    }

    public static int peekExecutionTarget(ServerPlayer serverPlayer, NpcDialogueGraph npcDialogueGraph, int n) {
        if (npcDialogueGraph == null || n < 0) {
            return -1;
        }
        HashSet<Integer> hashSet = new HashSet<Integer>();
        int n2 = n;
        while (n2 >= 0 && hashSet.add(n2) && hashSet.size() <= 256) {
            NpcDialogueGraph.Node node;
            int n3;
            int n4;
            int n5;
            NpcDialogueGraph.Node node2 = npcDialogueGraph.get(n2);
            if (node2 == null) {
                return -1;
            }
            if (node2.type != 3 && !GuideDialogue.isIncomingIfSatisfied(serverPlayer, null, 0, npcDialogueGraph, node2)) {
                return -1;
            }
            if (node2.type == 0) {
                return node2.id;
            }
            if (node2.type == 2 || node2.type == 4) {
                n2 = node2.next;
                continue;
            }
            if (node2.type == 5 || node2.type == 6 || node2.type == 7 || node2.type == 8 || node2.type == 9 || node2.type == 10 || node2.type == 11 || node2.type == 14 || node2.type == 15) {
                n2 = node2.next;
                continue;
            }
            if (node2.type == 13) {
                int n6 = Math.max(1, node2.randomMin);
                n5 = Math.max(n6, node2.randomMax);
                n4 = n6 + ThreadLocalRandom.current().nextInt(n5 - n6 + 1);
                n3 = n4 - 1;
                if (n3 >= 0 && n3 < node2.randomBranches.size()) {
                    n2 = node2.randomBranches.get(n3);
                    continue;
                }
                n2 = -1;
                continue;
            }
            if (node2.type != 3) break;
            String varName = node2.pointsName;
            boolean shared = node2.pointsShared;
            boolean local = node2.varLocal;
            if (node2.varInputNode >= 0 && (node = npcDialogueGraph.get(node2.varInputNode)) != null && node.type == 4 && !node.pointsName.isBlank()) {
                varName = node.pointsName;
                shared = node.pointsShared;
                local = node.varLocal;
            }
            int value = 0;
            if (!varName.isBlank()) {
                value = GuideDialogue.readVarValue(serverPlayer, null, varName, shared, local);
            }
            n2 = GuideDialogue.evalCondition(value, node2.varOp, node2.varCompare) ? node2.next : node2.falseNext;
        }
        return -1;
    }

    public static void startAtLine(ServerPlayer serverPlayer, GuideNpc guideNpc, int n, Set<Integer> set) {
        if (serverPlayer == null || guideNpc == null || guideNpc.level().isClientSide() || !guideNpc.isAlive()) {
            return;
        }
        if (guideNpc.isEscorting()) {
            return;
        }
        if (GuideDialogue.cutsceneConversationActive(serverPlayer)) {
            RADIUS_LOG.info("[cutscene] new dialogue SUPPRESSED (frozen/pending) for {}", (Object)serverPlayer.getName().getString());
            return;
        }
        GuideDialogue.stop(serverPlayer);
        NpcProfile npcProfile = guideNpc.profile();
        Session session = new Session(guideNpc.getId(), guideNpc.level().dimension(), guideNpc.relationTo(serverPlayer));
        session.focusEntityId = guideNpc.getId();
        session.focusSpeaker = GuideDialogue.speaker(guideNpc);
        session.focusTitle = npcProfile.title == null ? "" : npcProfile.title;
        session.focusNameColor = NpcProfile.clamp(npcProfile.nameColor, 0, 3);
        SESSIONS.put(serverPlayer.getUUID(), session);
        guideNpc.setTalking(true);
        if (!guideNpc.isMovingToCustomTarget()) {
            guideNpc.getNavigation().stop();
        }
        if (npcProfile.lookAtPlayer && !guideNpc.isMovingToCustomTarget()) {
            guideNpc.getLookControl().setLookAt(serverPlayer, 40.0f, 40.0f);
        }
        session.rootCursor = 0;
        session.defaultTabDone = true;
        session.inShop = false;
        session.graphNode = n;
        GuideDialogue.executeIncomingTriggers(serverPlayer, guideNpc, session.relation, npcProfile.dialogueGraph, n, set);
        if (SESSIONS.get(serverPlayer.getUUID()) != session || guideNpc.isEscorting() || session.inShop) {
            return;
        }
        GuideDialogue.sendGraph(serverPlayer, session, guideNpc);
    }

    public static void triggerCheckChain(GuideNpc guideNpc, ServerPlayer serverPlayer, NpcDialogueGraph.Node node) {
        GuideDialogue.triggerCheckChain(guideNpc, serverPlayer, guideNpc == null || guideNpc.profile() == null ? null : guideNpc.profile().dialogueGraph, node);
    }

    public static void triggerCheckChain(GuideNpc guideNpc, ServerPlayer serverPlayer, NpcDialogueGraph npcDialogueGraph, NpcDialogueGraph.Node node) {
        int n;
        int n2;
        if (guideNpc == null || node == null) {
            return;
        }
        if (npcDialogueGraph == null) {
            return;
        }
        int n3 = n2 = serverPlayer != null ? guideNpc.relationTo(serverPlayer) : 0;
        if (!GuideDialogue.isIncomingIfSatisfied(serverPlayer, guideNpc, n2, npcDialogueGraph, node)) {
            return;
        }
        HashSet<Integer> hashSet = new HashSet<Integer>();
        if (!(node.action.isBlank() || serverPlayer == null && guideNpc == null)) {
            NpcActions.run(serverPlayer, guideNpc, n2, node.action);
        }
        GuideDialogue.executeGraphTriggers(serverPlayer, guideNpc, n2, npcDialogueGraph, node.triggers, hashSet);
        if (node.next >= 0 && (n = GuideDialogue.resolveExecutionTarget(serverPlayer, guideNpc, null, npcDialogueGraph, node.next, hashSet)) >= 0 && serverPlayer != null && guideNpc.profile() != null && guideNpc.profile().dialogueGraph == npcDialogueGraph) {
            GuideDialogue.startAtLine(serverPlayer, guideNpc, n, hashSet);
        }
    }

    public static void triggerDamageChain(GuideNpc guideNpc, ServerPlayer serverPlayer, NpcDialogueGraph.Node node) {
        GuideDialogue.triggerDamageChain(guideNpc, serverPlayer, node, serverPlayer != null);
    }

    public static void triggerDamageChain(GuideNpc guideNpc, ServerPlayer serverPlayer, NpcDialogueGraph.Node node, boolean bl) {
        GuideDialogue.triggerDamageChain(guideNpc, serverPlayer, guideNpc == null || guideNpc.profile() == null ? null : guideNpc.profile().dialogueGraph, node, bl);
    }

    public static void triggerDamageChain(GuideNpc guideNpc, ServerPlayer serverPlayer, NpcDialogueGraph npcDialogueGraph, NpcDialogueGraph.Node node, boolean bl) {
        int n;
        int n2;
        if (guideNpc == null || node == null) {
            return;
        }
        if (npcDialogueGraph == null) {
            return;
        }
        int n3 = n2 = serverPlayer != null ? guideNpc.relationTo(serverPlayer) : 0;
        if (!GuideDialogue.isIncomingIfSatisfied(serverPlayer, guideNpc, n2, npcDialogueGraph, node)) {
            return;
        }
        HashSet<Integer> hashSet = new HashSet<Integer>();
        if (!(node.action.isBlank() || serverPlayer == null && guideNpc == null)) {
            NpcActions.run(serverPlayer, guideNpc, n2, node.action);
        }
        GuideDialogue.executeGraphTriggers(serverPlayer, guideNpc, n2, npcDialogueGraph, node.triggers, hashSet);
        if (node.next >= 0 && (n = GuideDialogue.resolveExecutionTarget(serverPlayer, guideNpc, null, npcDialogueGraph, node.next, hashSet)) >= 0 && bl && serverPlayer != null && guideNpc.profile() != null && guideNpc.profile().dialogueGraph == npcDialogueGraph) {
            GuideDialogue.startAtLine(serverPlayer, guideNpc, n, hashSet);
        }
    }

    public static boolean matchesDamageFilter(int n, DamageSource damageSource) {
        Entity entity = damageSource != null ? (damageSource.getEntity() != null ? damageSource.getEntity() : damageSource.getDirectEntity()) : null;
        boolean bl = entity instanceof Player;
        boolean bl2 = entity instanceof Enemy;
        return switch (n) {
            case 1 -> bl;
            case 2 -> bl2;
            case 3 -> {
                if (!bl) {
                    yield true;
                }
                yield false;
            }
            case 0 -> true;
            default -> true;
        };
    }

    public static void handleNpcDamaged(GuideNpc guideNpc, DamageSource damageSource, float f, Map<Integer, Long> map) {
        GuideDialogue.handleNpcDamaged(guideNpc, damageSource, f, map, guideNpc != null && guideNpc.profile() != null && GuideDialogue.graphActive(guideNpc.profile()) ? guideNpc.profile().dialogueGraph : null);
    }

    public static void handleNpcDamaged(GuideNpc guideNpc, DamageSource damageSource, float f, Map<Integer, Long> map, NpcDialogueGraph npcDialogueGraph) {
        Player player;
        Object object2;
        if (guideNpc == null || guideNpc.level().isClientSide() || !guideNpc.isAlive()) {
            return;
        }
        Level level = guideNpc.level();
        if (!(level instanceof ServerLevel)) {
            return;
        }
        ServerLevel serverLevel = (ServerLevel)level;
        if (npcDialogueGraph == null) {
            return;
        }
        long l = serverLevel.getGameTime();
        boolean bl = false;
        Object object3 = null;
        if (damageSource != null) {
            Entity entity = damageSource.getEntity();
            if (entity instanceof ServerPlayer) {
                object3 = object2 = (ServerPlayer)entity;
                bl = true;
            } else {
                entity = damageSource.getDirectEntity();
                if (entity instanceof ServerPlayer) {
                    ServerPlayer object4 = (ServerPlayer)entity;
                    object3 = object4;
                    bl = true;
                }
            }
        }
        if (object3 == null && (player = serverLevel.getNearestPlayer(guideNpc, 16.0)) instanceof ServerPlayer) {
            object3 = object2 = (ServerPlayer)player;
        }
        for (NpcDialogueGraph.Node node : npcDialogueGraph.nodes.values()) {
            int n;
            if (node.type != 6 || f < (float)Math.max(0, node.minDamage) || !GuideDialogue.matchesDamageFilter(node.damageFilter, damageSource)) continue;
            long l2 = (long)Math.max(0, node.damageCooldown) * 20L;
            Long l3 = map.get(node.id);
            if (l3 != null && l - l3 < l2) continue;
            int n2 = n = object3 != null ? guideNpc.relationTo((ServerPlayer)object3) : 0;
            if (!GuideDialogue.isIncomingIfSatisfied((ServerPlayer)object3, guideNpc, n, npcDialogueGraph, node)) continue;
            map.put(node.id, l);
            GuideDialogue.triggerDamageChain(guideNpc, (ServerPlayer)object3, npcDialogueGraph, node, bl);
        }
    }

    public static boolean checkProximityCondition(GuideNpc guideNpc, ServerPlayer serverPlayer, NpcDialogueGraph.Node node) {
        if (guideNpc == null || node == null) {
            return false;
        }
        int n = Math.max(1, Math.min(64, node.checkRadius));
        double d = (double)n * (double)n;
        if ((node.checkTarget == 0 || node.checkTarget == 3) && serverPlayer != null && serverPlayer.isAlive() && !serverPlayer.isSpectator()) {
            return guideNpc.distanceToSqr(serverPlayer) <= d;
        }
        Level level = guideNpc.level();
        if (level instanceof ServerLevel) {
            ServerLevel serverLevel = (ServerLevel)level;
            return GuideDialogue.findCheckTarget(guideNpc, serverLevel, node.checkTarget, n, Map.of(), 0L, 0L) != null;
        }
        return false;
    }

    public static void tickGraphCheckNodes(GuideNpc guideNpc, NpcDialogueGraph npcDialogueGraph, Map<Integer, Map<UUID, Long>> map) {
        if (guideNpc == null || npcDialogueGraph == null || guideNpc.level().isClientSide() || guideNpc.isTalking() || !guideNpc.isAlive()) {
            return;
        }
        Level level = guideNpc.level();
        if (!(level instanceof ServerLevel)) {
            return;
        }
        ServerLevel serverLevel = (ServerLevel)level;
        long l = serverLevel.getGameTime();
        for (NpcDialogueGraph.Node node : npcDialogueGraph.nodes.values()) {
            int n2;
            ServerPlayer serverPlayer;
            Player player;
            ServerPlayer serverPlayer2;
            if (node.type != 5 || node.next < 0 && node.triggers.isEmpty() && node.action.isBlank()) continue;
            int n3 = Math.max(1, Math.min(64, node.checkRadius));
            long l2 = (long)Math.max(0, node.checkCooldown) * 20L;
            Map<UUID, Long> map2 = map.computeIfAbsent(node.id, n -> new HashMap<UUID, Long>());
            if (map2.size() > 64) {
                map2.entrySet().removeIf(entry -> l - (Long)entry.getValue() > Math.max(l2, 200L));
            }
            RADIUS_LOG.info("[graph] check node #{} target {} radius {} scanning...", node.id, node.checkTarget, n3);
            Entity entity = GuideDialogue.findCheckTarget(guideNpc, serverLevel, node.checkTarget, n3, map2, l, l2);
            if (entity != null) {
                RADIUS_LOG.info("[graph] check node #{} FIRED on {}", (Object)node.id, (Object)entity.getName().getString());
            }
            if (entity == null) continue;
            map2.put(entity.getUUID(), l);
            ServerPlayer serverPlayer3 = entity instanceof ServerPlayer ? (serverPlayer2 = (ServerPlayer)entity) : ((player = serverLevel.getNearestPlayer(guideNpc, (double)n3 + 8.0)) instanceof ServerPlayer ? (serverPlayer = (ServerPlayer)player) : null);
            int n4 = n2 = serverPlayer3 != null ? guideNpc.relationTo(serverPlayer3) : 0;
            if (!GuideDialogue.isIncomingIfSatisfied(serverPlayer3, guideNpc, n2, npcDialogueGraph, node)) continue;
            GuideDialogue.triggerCheckChain(guideNpc, serverPlayer3, npcDialogueGraph, node);
            if (!guideNpc.isTalking()) continue;
            break;
        }
    }

    private static Entity findCheckTarget(GuideNpc guideNpc, ServerLevel serverLevel, int n, int n2, Map<UUID, Long> map, long l, long l2) {
        double d = n2;
        AABB aABB = guideNpc.getBoundingBox().inflate(d);
        switch (n) {
            case 1: {
                List<GuideNpc> list = serverLevel.getEntitiesOfClass(GuideNpc.class, aABB, guideNpc2 -> guideNpc2 != guideNpc && guideNpc2.isAlive() && guideNpc.distanceToSqr((Entity)guideNpc2) <= d * d);
                for (GuideNpc guideNpc3 : list) {
                    Long l3 = map.get(guideNpc3.getUUID());
                    if (l3 != null && l - l3 < l2) continue;
                    return guideNpc3;
                }
                return null;
            }
            case 2: {
                List<Entity> list = serverLevel.getEntitiesOfClass(Entity.class, aABB, entity -> entity instanceof Enemy && entity.isAlive() && guideNpc.distanceToSqr((Entity)entity) <= d * d);
                for (Entity entity2 : list) {
                    Long l4 = map.get(entity2.getUUID());
                    if (l4 != null && l - l4 < l2) continue;
                    return entity2;
                }
                return null;
            }
            case 3: {
                List<Entity> list = serverLevel.getEntitiesOfClass(Entity.class, aABB, entity -> {
                    Player player;
                    return entity != guideNpc && entity.isAlive() && (!(entity instanceof Player) || !(player = (Player)entity).isSpectator()) && guideNpc.distanceToSqr((Entity)entity) <= d * d;
                });
                for (Entity entity3 : list) {
                    Object object;
                    if (entity3 instanceof ServerPlayer && (GuideDialogue.isInDialogue((ServerPlayer)(object = (ServerPlayer)entity3)) || ((ServerPlayer)object).isSpectator()) || (object = map.get(entity3.getUUID())) != null && l - (Long)object < l2) continue;
                    return entity3;
                }
                return null;
            }
        }
        List<ServerPlayer> list = serverLevel.getEntitiesOfClass(ServerPlayer.class, aABB, serverPlayer -> !serverPlayer.isSpectator() && serverPlayer.isAlive() && guideNpc.distanceToSqr((Entity)serverPlayer) <= d * d);
        for (ServerPlayer serverPlayer2 : list) {
            Long l5;
            if (GuideDialogue.isInDialogue(serverPlayer2) || (l5 = map.get(serverPlayer2.getUUID())) != null && l - l5 < l2) continue;
            return serverPlayer2;
        }
        return null;
    }

    public static void triggerTimeChain(GuideNpc guideNpc, ServerPlayer serverPlayer, NpcDialogueGraph.Node node) {
        GuideDialogue.triggerTimeChain(guideNpc, serverPlayer, guideNpc == null || guideNpc.profile() == null ? null : guideNpc.profile().dialogueGraph, node);
    }

    public static void triggerTimeChain(GuideNpc guideNpc, ServerPlayer serverPlayer, NpcDialogueGraph npcDialogueGraph, NpcDialogueGraph.Node node) {
        int n;
        int n2;
        if (guideNpc == null || node == null) {
            return;
        }
        if (npcDialogueGraph == null) {
            return;
        }
        int n3 = n2 = serverPlayer != null ? guideNpc.relationTo(serverPlayer) : 0;
        if (!GuideDialogue.isIncomingIfSatisfied(serverPlayer, guideNpc, n2, npcDialogueGraph, node)) {
            return;
        }
        HashSet<Integer> hashSet = new HashSet<Integer>();
        if (!(node.action.isBlank() || serverPlayer == null && guideNpc == null)) {
            NpcActions.run(serverPlayer, guideNpc, n2, node.action);
        }
        GuideDialogue.executeGraphTriggers(serverPlayer, guideNpc, n2, npcDialogueGraph, node.triggers, hashSet);
        if (node.next >= 0 && (n = GuideDialogue.resolveExecutionTarget(serverPlayer, guideNpc, null, npcDialogueGraph, node.next, hashSet)) >= 0 && serverPlayer != null && guideNpc.profile() != null && guideNpc.profile().dialogueGraph == npcDialogueGraph) {
            GuideDialogue.startAtLine(serverPlayer, guideNpc, n, hashSet);
        }
    }

    public static void tickGraphTimeNodes(GuideNpc guideNpc, NpcDialogueGraph npcDialogueGraph, Map<Integer, Long> map) {
        if (guideNpc == null || npcDialogueGraph == null || guideNpc.level().isClientSide() || guideNpc.isTalking() || !guideNpc.isAlive()) {
            return;
        }
        Level level = guideNpc.level();
        if (!(level instanceof ServerLevel)) {
            return;
        }
        ServerLevel serverLevel = (ServerLevel)level;
        long l = serverLevel.getDayTime();
        long l2 = l / 24000L;
        long l3 = (l % 24000L + 24000L) % 24000L;
        for (NpcDialogueGraph.Node node : npcDialogueGraph.nodes.values()) {
            int n;
            ServerPlayer serverPlayer;
            Long l4;
            long l5;
            if (node.type != 7 || node.next < 0 && node.triggers.isEmpty() && node.action.isBlank()) continue;
            switch (node.timeMode) {
                case 0: {
                    l5 = 0L;
                    break;
                }
                case 1: {
                    l5 = 6000L;
                    break;
                }
                case 2: {
                    l5 = 12000L;
                    break;
                }
                case 3: {
                    l5 = 18000L;
                    break;
                }
                case 4: {
                    l5 = Math.max(0, Math.min(23999, node.timeTicks));
                    break;
                }
                default: {
                    l5 = Math.max(0, Math.min(23999, node.timeTicks));
                }
            }
            if ((l4 = map.get(node.id)) != null && l4 == l2 || l3 < l5 || l3 >= l5 + 400L) continue;
            map.put(node.id, l2);
            Player player = serverLevel.getNearestPlayer(guideNpc, 32.0);
            ServerPlayer serverPlayer2 = player instanceof ServerPlayer && !(serverPlayer = (ServerPlayer)player).isSpectator() ? serverPlayer : null;
            int n2 = n = serverPlayer2 != null ? guideNpc.relationTo(serverPlayer2) : 0;
            if (!GuideDialogue.isIncomingIfSatisfied(serverPlayer2, guideNpc, n, npcDialogueGraph, node)) continue;
            GuideDialogue.triggerTimeChain(guideNpc, serverPlayer2, npcDialogueGraph, node);
            if (!guideNpc.isTalking()) continue;
            break;
        }
    }

    public static void triggerTimerChain(GuideNpc guideNpc, ServerPlayer serverPlayer, NpcDialogueGraph.Node node) {
        GuideDialogue.triggerTimerChain(guideNpc, serverPlayer, guideNpc == null || guideNpc.profile() == null ? null : guideNpc.profile().dialogueGraph, node);
    }

    public static void triggerTimerChain(GuideNpc guideNpc, ServerPlayer serverPlayer, NpcDialogueGraph npcDialogueGraph, NpcDialogueGraph.Node node) {
        int n;
        int n2;
        if (guideNpc == null || node == null) {
            return;
        }
        if (npcDialogueGraph == null) {
            return;
        }
        int n3 = n2 = serverPlayer != null ? guideNpc.relationTo(serverPlayer) : 0;
        if (!GuideDialogue.isIncomingIfSatisfied(serverPlayer, guideNpc, n2, npcDialogueGraph, node)) {
            return;
        }
        HashSet<Integer> hashSet = new HashSet<Integer>();
        if (!(node.action.isBlank() || serverPlayer == null && guideNpc == null)) {
            NpcActions.run(serverPlayer, guideNpc, n2, node.action);
        }
        GuideDialogue.executeGraphTriggers(serverPlayer, guideNpc, n2, npcDialogueGraph, node.triggers, hashSet);
        if (node.next >= 0 && (n = GuideDialogue.resolveExecutionTarget(serverPlayer, guideNpc, null, npcDialogueGraph, node.next, hashSet)) >= 0 && serverPlayer != null && guideNpc.profile() != null && guideNpc.profile().dialogueGraph == npcDialogueGraph) {
            GuideDialogue.startAtLine(serverPlayer, guideNpc, n, hashSet);
        }
    }

    public static void tickGraphTimerNodes(GuideNpc guideNpc, NpcDialogueGraph npcDialogueGraph, Map<Integer, Long> map) {
        if (guideNpc == null || npcDialogueGraph == null || guideNpc.level().isClientSide() || guideNpc.isTalking() || !guideNpc.isAlive()) {
            return;
        }
        Level level = guideNpc.level();
        if (!(level instanceof ServerLevel)) {
            return;
        }
        ServerLevel serverLevel = (ServerLevel)level;
        long l = serverLevel.getGameTime();
        for (NpcDialogueGraph.Node node : npcDialogueGraph.nodes.values()) {
            int n;
            ServerPlayer serverPlayer;
            if (node.type != 8 || node.next < 0 && node.triggers.isEmpty() && node.action.isBlank()) continue;
            long l2 = (long)Math.max(1, node.timerInterval) * 20L;
            Long l3 = map.get(node.id);
            if (l3 == null) {
                map.put(node.id, l);
                continue;
            }
            if (l3 == Long.MAX_VALUE || l - l3 < l2) continue;
            if (node.timerRepeat) {
                map.put(node.id, l);
            } else {
                map.put(node.id, Long.MAX_VALUE);
            }
            Player player = serverLevel.getNearestPlayer(guideNpc, 32.0);
            ServerPlayer serverPlayer2 = player instanceof ServerPlayer && !(serverPlayer = (ServerPlayer)player).isSpectator() ? serverPlayer : null;
            int n2 = n = serverPlayer2 != null ? guideNpc.relationTo(serverPlayer2) : 0;
            if (!GuideDialogue.isIncomingIfSatisfied(serverPlayer2, guideNpc, n, npcDialogueGraph, node)) continue;
            GuideDialogue.triggerTimerChain(guideNpc, serverPlayer2, npcDialogueGraph, node);
            if (!guideNpc.isTalking()) continue;
            break;
        }
    }

    private static void startGraph(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc) {
        NpcDialogueGraph npcDialogueGraph = guideNpc.profile().dialogueGraph;
        session.inShop = false;
        session.defaultTabDone = true;
        HashSet<Integer> hashSet = new HashSet<Integer>();
        int n = GuideDialogue.resolveExecutionTarget(serverPlayer, guideNpc, session, npcDialogueGraph, npcDialogueGraph.entry, hashSet);
        if (n < 0) {
            GuideDialogue.stop(serverPlayer);
            return;
        }
        session.graphNode = n;
        GuideDialogue.executeIncomingTriggers(serverPlayer, guideNpc, session.relation, npcDialogueGraph, n, hashSet);
        if (SESSIONS.get(serverPlayer.getUUID()) != session || guideNpc.isEscorting() || session.inShop) {
            return;
        }
        GuideDialogue.sendGraph(serverPlayer, session, guideNpc);
    }

    private static boolean graphButtonVisible(ServerPlayer serverPlayer, GuideNpc guideNpc, NpcDialogueGraph.Node node, int n) {
        NpcDialogueGraph npcDialogueGraph;
        if (node == null || node.type != 1 || node.text.isBlank()) {
            return false;
        }
        NpcDialogueGraph npcDialogueGraph2 = npcDialogueGraph = guideNpc != null && guideNpc.profile() != null ? guideNpc.profile().dialogueGraph : null;
        if (!GuideDialogue.isIncomingIfSatisfied(serverPlayer, guideNpc, n, npcDialogueGraph, node)) {
            return false;
        }
        if (!node.pointsName.isBlank()) {
            NpcPoints npcPoints = NpcPoints.get(serverPlayer.getServer());
            int n2 = npcPoints.get(serverPlayer.getUUID(), node.pointsName, node.pointsShared);
            return node.minPoints <= n2 && n2 <= node.maxPoints;
        }
        return node.relationVisible(n);
    }

    private static boolean graphButtonVisible(ServerPlayer serverPlayer, NpcDialogueGraph.Node node, int n) {
        return GuideDialogue.graphButtonVisible(serverPlayer, null, node, n);
    }

    public static int effectiveNext(ServerPlayer serverPlayer, NpcDialogueGraph npcDialogueGraph, NpcDialogueGraph.Node node) {
        if (node == null || npcDialogueGraph == null) {
            return -1;
        }
        int n = node.next;
        if (n < 0 && node.builtinTopic < 0) {
            for (int n2 : node.triggers) {
                int n3;
                NpcDialogueGraph.Node node2 = npcDialogueGraph.get(n2);
                if (node2 == null || node2.type != 2 || (n3 = GuideDialogue.resolveTriggerNext(npcDialogueGraph, node2)) < 0) continue;
                n = n3;
                break;
            }
        }
        if (n < 0) {
            return -1;
        }
        return GuideDialogue.peekExecutionTarget(serverPlayer, npcDialogueGraph, n);
    }

    public static int effectiveNext(NpcDialogueGraph npcDialogueGraph, NpcDialogueGraph.Node node) {
        return GuideDialogue.effectiveNext(null, npcDialogueGraph, node);
    }

    private static int resolveTriggerNext(NpcDialogueGraph npcDialogueGraph, NpcDialogueGraph.Node node) {
        HashSet<Integer> hashSet = new HashSet<Integer>();
        NpcDialogueGraph.Node node2 = node;
        while (node2 != null && node2.type == 2 && hashSet.add(node2.id)) {
            if (node2.next >= 0) {
                return node2.next;
            }
            NpcDialogueGraph.Node node3 = null;
            for (int n : node2.triggers) {
                NpcDialogueGraph.Node node4 = npcDialogueGraph.get(n);
                if (node4 == null || node4.type != 2) continue;
                node3 = node4;
                break;
            }
            node2 = node3;
        }
        return -1;
    }

    private static void sendGraph(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc) {
        Object object;
        int n2;
        NpcProfile npcProfile = guideNpc.profile();
        NpcDialogueGraph npcDialogueGraph = npcProfile.dialogueGraph;
        if (!GuideDialogue.graphActive(npcProfile)) {
            session.graphNode = -1;
            GuideDialogue.sendRoot(serverPlayer, session, guideNpc);
            return;
        }
        NpcDialogueGraph.Node node = npcDialogueGraph.get(session.graphNode);
        if (node == null || node.type != 0 || node.special != 0) {
            node = npcDialogueGraph.get(npcDialogueGraph.entry);
            if (node == null) {
                GuideDialogue.stop(serverPlayer);
                return;
            }
            session.graphNode = node.id;
        }
        session.relation = guideNpc.relationTo(serverPlayer);
        ArrayList<String> arrayList = new ArrayList<String>();
        ArrayList<String> arrayList2 = new ArrayList<String>();
        ArrayList<Integer> arrayList3 = new ArrayList<Integer>();
        for (int choiceId : node.choices) {
            object = npcDialogueGraph.get(choiceId);
            if (!GuideDialogue.graphButtonVisible(serverPlayer, guideNpc, (NpcDialogueGraph.Node)object, session.relation)) continue;
            arrayList.add(NpcProfile.fill(((NpcDialogueGraph.Node)object).text, serverPlayer, session.relation));
            arrayList2.add("");
            arrayList3.add(choiceId);
        }
        int n3 = GuideDialogue.effectiveNext(serverPlayer, npcDialogueGraph, node);
        int n4 = n2 = n3 >= 0 || node.builtinTopic >= 0 || node.choices.isEmpty() && node.next >= 0 ? 1 : 0;
        if (node.choices.isEmpty()) {
            arrayList3.add(n2 != 0 ? -1 : -2);
        } else if (n3 >= 0 || node.builtinTopic >= 0) {
            arrayList.add(BTN_NEXT);
            arrayList2.add(HINT_NEXT);
            arrayList3.add(-1);
        } else if (arrayList.isEmpty()) {
            arrayList.add(BTN_FINISH);
            arrayList2.add("");
            arrayList3.add(-2);
        }
        session.graphOptions = arrayList3.stream().mapToInt(Integer::intValue).toArray();
        session.state = 1;
        object = node.lineFor(session.relation);
        NpcNet.sendTo(serverPlayer, new NpcNet.DlgView(guideNpc.getId(), GuideDialogue.speaker(guideNpc), npcProfile.title, GuideDialogue.fill((String)object, serverPlayer, session, npcProfile), arrayList, arrayList2, session.relation, 1, npcProfile.hasShop(), GuideDialogue.style(npcProfile, serverPlayer, session.relation)));
    }

    private static void runNodeAction(ServerPlayer serverPlayer, Entity entity, GuideNpc guideNpc, int n, String string) {
        if (string == null || string.isBlank()) {
            return;
        }
        if (serverPlayer != null) {
            NpcActions.run(serverPlayer, guideNpc, n, string);
            return;
        }
        if (entity != null) {
            NpcActions.runForEntity(entity, guideNpc, n, string);
            return;
        }
        if (guideNpc != null) {
            NpcActions.run(null, guideNpc, n, string);
        }
    }

    private static void executeGraphTriggers(ServerPlayer serverPlayer, GuideNpc guideNpc, int n, NpcDialogueGraph npcDialogueGraph, List<Integer> list) {
        GuideDialogue.executeGraphTriggers(serverPlayer, guideNpc, n, npcDialogueGraph, list, null);
    }

    private static void executeGraphTriggers(ServerPlayer serverPlayer, GuideNpc guideNpc, int n, NpcDialogueGraph npcDialogueGraph, List<Integer> list, Set<Integer> set) {
        GuideDialogue.executeGraphTriggers(serverPlayer, null, guideNpc, n, npcDialogueGraph, list, set);
    }

    private static void executeGraphTriggers(ServerPlayer serverPlayer, Entity entity, GuideNpc guideNpc, int n, NpcDialogueGraph npcDialogueGraph, List<Integer> list, Set<Integer> set) {
        if (list == null || list.isEmpty()) {
            return;
        }
        HashSet<Integer> hashSet = new HashSet<Integer>();
        ArrayDeque<Integer> arrayDeque = new ArrayDeque<Integer>(list);
        while (!arrayDeque.isEmpty()) {
            NpcDialogueGraph.Node node;
            boolean bl;
            NpcDialogueGraph.Node node2;
            int n2 = arrayDeque.poll();
            if (!hashSet.add(n2) || set != null && !set.add(n2) || (node2 = npcDialogueGraph.get(n2)) == null || !GuideDialogue.isIncomingIfSatisfied(serverPlayer, guideNpc, n, npcDialogueGraph, node2)) continue;
            List<NpcDialogueGraph.Node> list2 = Collections.emptyList();
            if (!(entity != null || set != null && set.contains(-999999))) {
                list2 = GuideDialogue.findRadiusAttachments(npcDialogueGraph, node2, set);
            }
            GuideDialogue.expandRadiusAttachments(serverPlayer, guideNpc, npcDialogueGraph, node2, list2, set);
            boolean bl2 = bl = !list2.isEmpty() && !GuideDialogue.initiatorExecutesWithRadiusGate(serverPlayer, guideNpc, list2);
            if (node2.type != 2 && node2.type != 9 && node2.type != 11) continue;
            if (node2.type == 9 && guideNpc != null && !node2.animName.isBlank()) {
                guideNpc.playCustomAnimation(node2.animName, node2.animLoop, node2.animBone);
            }
            if (node2.type == 11 && guideNpc != null) {
                GuideDialogue.executeMoveNode(guideNpc, serverPlayer, node2);
            }
            if (!node2.action.isBlank() && !bl) {
                GuideDialogue.runNodeAction(serverPlayer, entity, guideNpc, n, node2.action);
            }
            arrayDeque.addAll(node2.triggers);
            if (node2.next < 0 || (node = npcDialogueGraph.get(node2.next)) == null || node.type != 2 && node.type != 9 && node.type != 11) continue;
            arrayDeque.add(node2.next);
        }
    }

    private static void executeIncomingTriggers(ServerPlayer serverPlayer, GuideNpc guideNpc, int n, NpcDialogueGraph npcDialogueGraph, int n2, Set<Integer> set) {
        if (npcDialogueGraph == null || n2 < 0) {
            return;
        }
        HashSet<Integer> hashSet = new HashSet<Integer>();
        for (NpcDialogueGraph.Node iterator2 : npcDialogueGraph.nodes.values()) {
            if (iterator2.type != 2 && iterator2.type != 9 && iterator2.type != 11 || iterator2.next != n2) continue;
            hashSet.add(iterator2.id);
        }
        if (hashSet.isEmpty()) {
            return;
        }
        boolean bl = true;
        while (bl) {
            bl = false;
            for (NpcDialogueGraph.Node node : npcDialogueGraph.nodes.values()) {
                if (node.type != 2 && node.type != 9 && node.type != 11 || hashSet.contains(node.id)) continue;
                if (!hashSet.contains(node.next)) {
                    if (!node.triggers.stream().anyMatch(hashSet::contains)) continue;
                }
                hashSet.add(node.id);
                bl = true;
            }
        }
        HashSet<Integer> hashSet2 = new HashSet<Integer>();
        Iterator iterator = hashSet.iterator();
        while (iterator.hasNext()) {
            int n3 = (Integer)iterator.next();
            NpcDialogueGraph.Node node = npcDialogueGraph.get(n3);
            if (node == null) continue;
            if (hashSet.contains(node.next)) {
                hashSet2.add(node.next);
            }
            for (int n4 : node.triggers) {
                if (!hashSet.contains(n4)) continue;
                hashSet2.add(n4);
            }
        }
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        Iterator iterator2 = hashSet.iterator();
        while (iterator2.hasNext()) {
            int n5 = (Integer)iterator2.next();
            if (hashSet2.contains(n5)) continue;
            arrayList.add(n5);
        }
        if (arrayList.isEmpty()) {
            arrayList.addAll(hashSet);
        }
        GuideDialogue.executeGraphTriggers(serverPlayer, guideNpc, n, npcDialogueGraph, arrayList, set);
    }

    private static void pickGraph(ServerPlayer serverPlayer, Session session, GuideNpc guideNpc, int n) {
        int n2;
        int n3;
        NpcDialogueGraph.Node node;
        NpcDialogueGraph npcDialogueGraph = guideNpc.profile().dialogueGraph;
        NpcDialogueGraph.Node node2 = npcDialogueGraph.get(session.graphNode);
        if (node2 == null || n < 0 || n >= session.graphOptions.length) {
            GuideDialogue.sendGraph(serverPlayer, session, guideNpc);
            return;
        }
        int n4 = session.graphOptions[n];
        NpcDialogueGraph.Node node3 = node = n4 >= 0 ? npcDialogueGraph.get(n4) : null;
        if (!(n4 < 0 || node2.choices.contains(n4) && GuideDialogue.graphButtonVisible(serverPlayer, guideNpc, node, guideNpc.relationTo(serverPlayer)))) {
            GuideDialogue.sendGraph(serverPlayer, session, guideNpc);
            return;
        }
        int n5 = GuideDialogue.effectiveNext(serverPlayer, npcDialogueGraph, node2);
        int n6 = n3 = node2.next >= 0 ? node2.next : n5;
        if (n4 == -1 && n3 < 0 && node2.builtinTopic < 0) {
            GuideDialogue.sendGraph(serverPlayer, session, guideNpc);
            return;
        }
        HashSet<Integer> hashSet = new HashSet<Integer>();
        if (!node2.action.isBlank()) {
            NpcActions.run(serverPlayer, guideNpc, session.relation, node2.action);
        }
        session.lastExecutedTriggersNode = node2.id;
        GuideDialogue.executeGraphTriggers(serverPlayer, guideNpc, session.relation, npcDialogueGraph, node2.triggers, hashSet);
        if (SESSIONS.get(serverPlayer.getUUID()) != session || guideNpc.isEscorting() || session.inShop) {
            return;
        }
        if (n4 == -2) {
            GuideDialogue.stop(serverPlayer);
            return;
        }
        if (n4 == -1) {
            if (n3 >= 0) {
                int n7 = GuideDialogue.resolveExecutionTarget(serverPlayer, guideNpc, session, npcDialogueGraph, n3, hashSet);
                if (n7 >= 0) {
                    session.graphNode = n7;
                    GuideDialogue.executeIncomingTriggers(serverPlayer, guideNpc, session.relation, npcDialogueGraph, n7, hashSet);
                    if (SESSIONS.get(serverPlayer.getUUID()) != session || guideNpc.isEscorting() || session.inShop) {
                        return;
                    }
                    GuideDialogue.sendGraph(serverPlayer, session, guideNpc);
                    return;
                }
                GuideDialogue.stop(serverPlayer);
                return;
            }
            if (node2.builtinTopic >= 0) {
                session.graphNode = -1;
                GuideDialogue.openTopic(serverPlayer, session, guideNpc, node2.builtinTopic);
                return;
            }
            GuideDialogue.sendGraph(serverPlayer, session, guideNpc);
            return;
        }
        if (node.relation != 0) {
            GuideNpc.addRelation(serverPlayer, guideNpc, node.relation);
            session.relation = guideNpc.relationTo(serverPlayer);
        }
        if (!node.action.isBlank()) {
            NpcActions.run(serverPlayer, guideNpc, session.relation, node.action);
        }
        GuideDialogue.executeGraphTriggers(serverPlayer, guideNpc, session.relation, npcDialogueGraph, node.triggers, hashSet);
        if (SESSIONS.get(serverPlayer.getUUID()) != session || guideNpc.isEscorting() || session.inShop) {
            return;
        }
        int n8 = GuideDialogue.effectiveNext(serverPlayer, npcDialogueGraph, node);
        int n9 = n2 = node.next >= 0 ? node.next : n8;
        if (n2 >= 0) {
            int n10 = GuideDialogue.resolveExecutionTarget(serverPlayer, guideNpc, session, npcDialogueGraph, n2, hashSet);
            if (n10 >= 0) {
                session.graphNode = n10;
                GuideDialogue.executeIncomingTriggers(serverPlayer, guideNpc, session.relation, npcDialogueGraph, n10, hashSet);
                if (SESSIONS.get(serverPlayer.getUUID()) != session || guideNpc.isEscorting() || session.inShop) {
                    return;
                }
                GuideDialogue.sendGraph(serverPlayer, session, guideNpc);
            } else {
                GuideDialogue.stop(serverPlayer);
            }
        } else if (node.builtinTopic >= 0) {
            session.graphNode = -1;
            GuideDialogue.openTopic(serverPlayer, session, guideNpc, node.builtinTopic);
        } else {
            GuideDialogue.stop(serverPlayer);
        }
    }

    public static void resumeGraphAfterCutscene(ServerPlayer serverPlayer) {
        PendingCutsceneReplica pendingCutsceneReplica = PENDING_CUTSCENE_REPLICA.remove(serverPlayer.getUUID());
        if (pendingCutsceneReplica == null || pendingCutsceneReplica.session.graphNode < 0) {
            return;
        }
        RADIUS_LOG.info("[cutscene] resumed dialogue at line #{} for {}", (Object)pendingCutsceneReplica.session.graphNode, (Object)serverPlayer.getName().getString());
        GuideDialogue.sendGraph(serverPlayer, pendingCutsceneReplica.session, pendingCutsceneReplica.npc);
    }

    public static boolean cutsceneConversationActive(ServerPlayer serverPlayer) {
        if (serverPlayer == null) {
            return false;
        }
        if (PENDING_CUTSCENE_REPLICA.containsKey(serverPlayer.getUUID())) {
            return true;
        }
        try {
            return CutsceneCamera.hasDeferral(serverPlayer);
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    public static int onCutscenePlaybackEnded(ServerPlayer serverPlayer) {
        boolean bl;
        PendingCutsceneReplica pendingCutsceneReplica = PENDING_CUTSCENE_REPLICA.remove(serverPlayer.getUUID());
        if (pendingCutsceneReplica == null) {
            RADIUS_LOG.info("[cutscene] playback ended for {}: NO pending replica", (Object)serverPlayer.getName().getString());
            return 0;
        }
        boolean bl2 = SESSIONS.get(serverPlayer.getUUID()) == pendingCutsceneReplica.session;
        boolean bl3 = bl = pendingCutsceneReplica.npc != null && pendingCutsceneReplica.npc.isAlive();
        if (bl2 && bl) {
            if (!pendingCutsceneReplica.extraScenes.isEmpty()) {
                String string = pendingCutsceneReplica.extraScenes.remove(0);
                if (CutsceneCamera.playChained(serverPlayer, string)) {
                    PENDING_CUTSCENE_REPLICA.put(serverPlayer.getUUID(), pendingCutsceneReplica);
                    RADIUS_LOG.info("[cutscene] chain step for {}: playing '{}', {} scene(s) left", serverPlayer.getName().getString(), string, pendingCutsceneReplica.extraScenes.size());
                    return 2;
                }
                RADIUS_LOG.info("[cutscene] chain step scene '{}' missing - continuing as if the last scene ended", (Object)string);
            }
            if (!pendingCutsceneReplica.replicaFlagged) {
                if (pendingCutsceneReplica.continueAtLine) {
                    PENDING_CUTSCENE_REPLICA.put(serverPlayer.getUUID(), pendingCutsceneReplica);
                    RADIUS_LOG.info("[cutscene] chain finished for {}: dialogue resumes at line #{} after the return", (Object)serverPlayer.getName().getString(), (Object)pendingCutsceneReplica.session.graphNode);
                    return 3;
                }
                RADIUS_LOG.info("[cutscene] chain finished for {} with no replica - full exit", (Object)serverPlayer.getName().getString());
                return 0;
            }
            RADIUS_LOG.info("[cutscene] replica CLAIMS the frozen frame for {} (line #{})", (Object)serverPlayer.getName().getString(), (Object)pendingCutsceneReplica.session.graphNode);
            GuideDialogue.sendGraph(serverPlayer, pendingCutsceneReplica.session, pendingCutsceneReplica.npc);
            return 1;
        }
        RADIUS_LOG.info("[cutscene] replica STALE for {}: sessionAlive={} npcAlive={} - camera exits fully", serverPlayer.getName().getString(), bl2, bl);
        return 0;
    }

    private static final class Session {
        final int entityId;
        final ResourceKey<Level> dimension;
        int relation;
        int state = 4;
        int escortLine;
        int graphNode = -1;
        int lastExecutedTriggersNode = -1;
        int[] graphOptions = new int[0];
        int topic = -1;
        int step = 0;
        int pendingNext = -1;
        int pendingTopic = -1;
        String pendingReaction = "";
        int legacyCursor = 0;
        int rootCursor = 0;
        String rootLine = "";
        int questTopic = -1;
        int quest = -1;
        boolean closeOnEnd;
        int menuOnEnd = -1;
        int menuStep = 0;
        boolean remindOnEnd = true;
        boolean menuButtons = true;
        long lastPick;
        boolean defaultTabDone;
        boolean inShop;
        NpcNet.DlgView lastView;
        int chainFrom = -1;
        int answerStep = -1;
        int focusEntityId;
        String focusSpeaker = "";
        String focusTitle = "";
        int focusNameColor = 1;
        List<List<GuidePhrase>> legacy = List.of();

        Session(int n, ResourceKey<Level> resourceKey, int n2) {
            this.entityId = n;
            this.dimension = resourceKey;
            this.relation = n2;
        }
    }

    private record Observation(UUID owner, int entityId) {
    }

    private static final class PendingCutsceneReplica {
        final GuideNpc npc;
        final Session session;
        final boolean replicaFlagged;
        final boolean continueAtLine;
        final ArrayList<String> extraScenes;

        PendingCutsceneReplica(GuideNpc guideNpc, Session session, boolean bl, boolean bl2, ArrayList<String> arrayList) {
            this.npc = guideNpc;
            this.session = session;
            this.replicaFlagged = bl;
            this.continueAtLine = bl2;
            this.extraScenes = arrayList;
        }
    }
}

