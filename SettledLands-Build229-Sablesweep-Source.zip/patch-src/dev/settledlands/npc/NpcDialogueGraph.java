/*
 * Decompiled with CFR 0.152.
 */
package dev.settledlands.npc;

import dev.settledlands.npc.NpcProfile;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtIo;

public final class NpcDialogueGraph {
    public static final int LINE = 0;
    public static final int BUTTON = 1;
    public static final int TRIGGER = 2;
    public static final int IF = 3;
    public static final int VARIABLE = 4;
    public static final int CHECK = 5;
    public static final int DAMAGE = 6;
    public static final int TIME = 7;
    public static final int TIMER = 8;
    public static final int ANIMATION = 9;
    public static final int QUEST = 10;
    public static final int MOVE = 11;
    public static final int MOBILITY = 12;
    public static final int RANDOM = 13;
    public static final int CUTSCENE = 14;
    public static final int RADIUS = 15;
    public static final int TARGET_PLAYER = 0;
    public static final int TARGET_NPC = 1;
    public static final int TARGET_MONSTER = 2;
    public static final int TARGET_ANY = 3;
    public static final int TARGET_PASSIVE = 4;
    public static final int DAMAGE_ANY = 0;
    public static final int DAMAGE_PLAYER = 1;
    public static final int DAMAGE_MONSTER = 2;
    public static final int DAMAGE_NON_PLAYER = 3;
    public static final int TIME_DAWN = 0;
    public static final int TIME_NOON = 1;
    public static final int TIME_SUNSET = 2;
    public static final int TIME_MIDNIGHT = 3;
    public static final int TIME_CUSTOM = 4;
    public static final int NORMAL = 0;
    public static final int TRAVEL = 1;
    public static final int ARRIVAL = 2;
    public static final int MAX_NODES = 2048;
    public static final int MAX_ID = 16383;
    public static final int MAX_CHOICES = 16;
    public static final int MAX_COORD = 32768;
    public static final int MAX_TEXT_UNITS = 600000;
    public static final int MAX_PACKET_BYTES = 1000000;
    public boolean enabled;
    public int entry = -1;
    public boolean hasCamera = false;
    public double panX = 60.0;
    public double panY = 90.0;
    public double zoom = 1.0;
    public final LinkedHashMap<Integer, Node> nodes = new LinkedHashMap();

    public Node get(int n) {
        return this.nodes.get(n);
    }

    public Node add(int n, int n2, int n3) {
        if (this.nodes.size() >= 2048) {
            return null;
        }
        for (int i = 0; i <= 16383; ++i) {
            if (this.nodes.containsKey(i)) continue;
            Node node = new Node(i, n, n2, n3);
            this.nodes.put(i, node);
            return node;
        }
        return null;
    }

    public int specialNode(int n) {
        for (Node node : this.nodes.values()) {
            if (node.special != n) continue;
            return node.id;
        }
        return -1;
    }

    public int topicNode(int n) {
        for (Node node : this.nodes.values()) {
            if (node.originTopic != n || node.originStep >= 0) continue;
            return node.id;
        }
        return -1;
    }

    public boolean connect(int n, int n2) {
        return this.connect(n, n2, 0);
    }

    public boolean connect(int n, int n2, int n3) {
        Node node = this.get(n);
        Node node2 = this.get(n2);
        if (node == null || node2 == null || node.special != 0 || node2.special != 0) {
            return false;
        }
        if (node.type == 4 && node2.type == 3) {
            node2.varInputNode = node.id;
            node2.varLocal = node.varLocal;
            if (!node.pointsName.isBlank()) {
                node2.pointsName = node.pointsName;
                node2.pointsShared = node.pointsShared;
            }
            node.next = node2.id;
            return true;
        }
        if (node.type == 3) {
            if (n3 == 1) {
                node.falseNext = n2;
            } else {
                node.next = n2;
            }
            return true;
        }
        if (node2.type == 2) {
            if (node.triggers.contains(n2)) {
                return true;
            }
            node.triggers.add(n2);
            return true;
        }
        if (node.type == 13) {
            while (node.randomBranches.size() <= n3) {
                node.randomBranches.add(-1);
            }
            node.randomBranches.set(n3, n2);
            return true;
        }
        if (node.type == 2) {
            if (node2.type == 2) {
                if (node.triggers.contains(n2)) {
                    return true;
                }
                node.triggers.add(n2);
                return true;
            }
            node.next = n2;
            return true;
        }
        if (node2.type == 1) {
            if (node.type != 0) {
                return false;
            }
            if (node.choices.contains(n2)) {
                return true;
            }
            if (node.choices.size() >= 16) {
                return false;
            }
            node.choices.add(n2);
            return true;
        }
        node.next = n2;
        return true;
    }

    public void disconnect(int n, int n2) {
        Node node = this.get(n);
        if (node == null) {
            return;
        }
        if (node.next == n2) {
            node.next = -1;
        }
        if (node.falseNext == n2) {
            node.falseNext = -1;
        }
        if (node.varInputNode == n2) {
            node.varInputNode = -1;
        }
        if (node.type == 13) {
            for (int i = 0; i < node.randomBranches.size(); ++i) {
                if (node.randomBranches.get(i) != n2) continue;
                node.randomBranches.set(i, -1);
            }
        }
        node.choices.remove((Object)n2);
        node.triggers.remove((Object)n2);
    }

    public void disconnectOutputs(int n) {
        Node node = this.get(n);
        if (node != null) {
            node.next = -1;
            node.falseNext = -1;
            node.varInputNode = -1;
            node.choices.clear();
            node.triggers.clear();
            node.randomBranches.clear();
        }
    }

    public boolean remove(int n) {
        Node node = this.get(n);
        if (node == null || node.special != 0) {
            return false;
        }
        this.nodes.remove(n);
        for (Node node2 : this.nodes.values()) {
            if (node2.next == n) {
                node2.next = -1;
            }
            if (node2.falseNext == n) {
                node2.falseNext = -1;
            }
            if (node2.varInputNode == n) {
                node2.varInputNode = -1;
            }
            for (int i = 0; i < node2.randomBranches.size(); ++i) {
                if (node2.randomBranches.get(i) != n) continue;
                node2.randomBranches.set(i, -1);
            }
            node2.choices.remove((Object)n);
            node2.triggers.remove((Object)n);
        }
        if (this.entry == n) {
            this.entry = -1;
        }
        return true;
    }

    public NpcDialogueGraph copy() {
        NpcDialogueGraph npcDialogueGraph = new NpcDialogueGraph();
        npcDialogueGraph.enabled = this.enabled;
        npcDialogueGraph.entry = this.entry;
        npcDialogueGraph.hasCamera = this.hasCamera;
        npcDialogueGraph.panX = this.panX;
        npcDialogueGraph.panY = this.panY;
        npcDialogueGraph.zoom = this.zoom;
        for (Node node : this.nodes.values()) {
            npcDialogueGraph.nodes.put(node.id, node.copy());
        }
        return npcDialogueGraph;
    }

    public boolean hasQuestNodes() {
        for (Node node : this.nodes.values()) {
            if (node.type != 10) continue;
            return true;
        }
        return false;
    }

    public String error() {
        if (this.nodes.size() > 2048) {
            return "nodes";
        }
        Node node = this.get(this.entry);
        if (this.enabled && (node == null || node.type != 0 || node.special != 0)) {
            return "entry";
        }
        int n = 0;
        int n2 = 0;
        int n3 = 0;
        for (Map.Entry<Integer, Node> entry : this.nodes.entrySet()) {
            HashSet<Integer> hashSet;
            Node node2 = entry.getValue();
            if (node2 == null || node2.id != entry.getKey() || node2.id < 0 || node2.id > 16383 || node2.type < 0 || node2.type > 15) {
                return "node";
            }
            if (node2.x < Short.MIN_VALUE || node2.x > 32768 || node2.y < Short.MIN_VALUE || node2.y > 32768) {
                return "position";
            }
            if (node2.text == null || node2.action == null || node2.pointsName == null || node2.cutsceneName == null || node2.text.length() > (node2.type == 0 ? 480 : 240) || node2.action.length() > 2048 || node2.pointsName.length() > 32 || node2.cutsceneName.length() > 64) {
                return "text";
            }
            n += node2.text.length() + node2.action.length() + node2.pointsName.length();
            if (node2.minRelation < 0 || node2.maxRelation > 100 || node2.minRelation > node2.maxRelation || node2.relation < -100 || node2.relation > 100) {
                return "relation";
            }
            if (node2.minPoints < 0 || node2.maxPoints > 1000000 || node2.minPoints > node2.maxPoints) {
                return "points";
            }
            if (node2.builtinTopic < -1 || node2.builtinTopic > 128) {
                return "builtin";
            }
            if (node2.special < 0 || node2.special > 2 || node2.special != 0 && node2.type != 0) {
                return "special";
            }
            if (node2.special == 1) {
                ++n2;
            }
            if (node2.special == 2) {
                ++n3;
            }
            if (!(node2.special == 0 || node2.next == -1 && node2.choices.isEmpty() && node2.triggers.isEmpty() && node2.falseNext == -1)) {
                return "special_links";
            }
            if (node2.type == 5) {
                if (node2.checkRadius < 1 || node2.checkRadius > 64) {
                    return "check_radius";
                }
                if (node2.checkCooldown < 0 || node2.checkCooldown > 3600) {
                    return "check_cooldown";
                }
                if (node2.checkTarget < 0 || node2.checkTarget > 3) {
                    return "check_target";
                }
            }
            if (node2.type == 6) {
                if (node2.damageFilter < 0 || node2.damageFilter > 3) {
                    return "damage_filter";
                }
                if (node2.damageCooldown < 0 || node2.damageCooldown > 3600) {
                    return "damage_cooldown";
                }
                if (node2.minDamage < 0 || node2.minDamage > 1000) {
                    return "min_damage";
                }
            }
            if (node2.type == 7) {
                if (node2.timeMode < 0 || node2.timeMode > 4) {
                    return "time_mode";
                }
                if (node2.timeTicks < 0 || node2.timeTicks > 23999) {
                    return "time_ticks";
                }
            }
            if (node2.type == 8 && (node2.timerInterval < 1 || node2.timerInterval > 86400)) {
                return "timer_interval";
            }
            if (node2.type == 13 && (node2.randomMin < 1 || node2.randomMax > 64 || node2.randomMin > node2.randomMax)) {
                return "random_range";
            }
            if (node2.type == 9) {
                if (node2.animName == null || node2.animName.length() > 64) {
                    return "anim_name";
                }
                n += node2.animName.length();
            }
            if (node2.type == 11) {
                if (node2.moveCoords == null || node2.moveCoords.length() > 64) {
                    return "move_coords";
                }
                if (node2.moveSpeed < 0.1 || node2.moveSpeed > 10.0) {
                    return "move_speed";
                }
                n += node2.moveCoords.length();
            }
            if (node2.type == 12) {
                if (node2.mobilityGroupId != null && node2.mobilityGroupId.length() > 36) {
                    return "mobility_group_id";
                }
                if (node2.mobilityGroupName != null && node2.mobilityGroupName.length() > 32) {
                    return "mobility_group_name";
                }
            }
            Node linkTarget;
            if (node2.next != -1 && ((linkTarget = this.get(node2.next)) == null || linkTarget.type == 1 || linkTarget.special != 0)) {
                return "link";
            }
            if (node2.falseNext != -1 && ((linkTarget = this.get(node2.falseNext)) == null || linkTarget.type == 1 || linkTarget.special != 0)) {
                return "false_link";
            }
            if (node2.varInputNode != -1 && ((linkTarget = this.get(node2.varInputNode)) == null || linkTarget.special != 0 || linkTarget.type != 4)) {
                return "var_input_link";
            }
            for (Integer n4 : node2.triggers) {
                Node node3;
                Node node4 = node3 = n4 == null ? null : this.get(n4);
                if (node3 != null && node3.type == 2 && node3.special == 0) continue;
                return "trigger_link";
            }
            if (node2.type != 0 && !node2.choices.isEmpty() || node2.choices.size() > 16) {
                return "choices";
            }
            hashSet = new HashSet<Integer>();
            for (Integer n5 : node2.choices) {
                Node node5;
                Node node6 = node5 = n5 == null ? null : this.get(n5);
                if (node5 != null && node5.type == 1 && node5.special == 0 && hashSet.add(n5)) continue;
                return "choice_link";
            }
            if (node2.variants.size() > 5) {
                return "variants";
            }
            for (NpcProfile.Variant variant : node2.variants) {
                if (variant == null || variant.text == null || variant.text.length() > 480 || variant.minRelation < 0 || variant.minRelation > 100) {
                    return "variant";
                }
                n += variant.text.length();
            }
            if (n <= 600000) continue;
            return "size";
        }
        return n2 > 1 || n3 > 1 ? "special_duplicate" : "";
    }

    public static int encodedSize(CompoundTag compoundTag) {
        final int[] nArray = new int[]{0};
        try {
            NbtIo.write(compoundTag, new DataOutputStream(new OutputStream(){

                @Override
                public void write(int n) {
                    nArray[0] = nArray[0] + 1;
                }

                @Override
                public void write(byte[] byArray, int n, int n2) {
                    nArray[0] = nArray[0] + n2;
                }
            }));
            return nArray[0];
        }
        catch (IOException iOException) {
            return Integer.MAX_VALUE;
        }
    }

    public CompoundTag save() {
        CompoundTag compoundTag = new CompoundTag();
        compoundTag.putInt("Version", 1);
        compoundTag.putBoolean("Enabled", this.enabled);
        compoundTag.putInt("Entry", this.entry);
        compoundTag.putBoolean("HasCamera", this.hasCamera);
        compoundTag.putDouble("PanX", this.panX);
        compoundTag.putDouble("PanY", this.panY);
        compoundTag.putDouble("Zoom", this.zoom);
        ListTag listTag = new ListTag();
        for (Node node : this.nodes.values()) {
            CompoundTag compoundTag2 = new CompoundTag();
            compoundTag2.putInt("Id", node.id);
            compoundTag2.putInt("Type", node.type);
            compoundTag2.putInt("X", node.x);
            compoundTag2.putInt("Y", node.y);
            compoundTag2.putInt("Next", node.next);
            compoundTag2.putInt("Special", node.special);
            compoundTag2.putString("Text", node.text);
            compoundTag2.putString("Action", node.action);
            compoundTag2.putInt("BuiltinTopic", node.builtinTopic);
            compoundTag2.putInt("OriginTopic", node.originTopic);
            compoundTag2.putInt("OriginStep", node.originStep);
            compoundTag2.putInt("OriginAnswer", node.originAnswer);
            compoundTag2.putInt("Relation", node.relation);
            compoundTag2.putInt("MinRelation", node.minRelation);
            compoundTag2.putInt("MaxRelation", node.maxRelation);
            compoundTag2.putString("PointsName", node.pointsName);
            compoundTag2.putInt("MinPoints", node.minPoints);
            compoundTag2.putInt("MaxPoints", node.maxPoints);
            compoundTag2.putBoolean("PointsShared", node.pointsShared);
            compoundTag2.putBoolean("VarLocal", node.varLocal);
            compoundTag2.putInt("FalseNext", node.falseNext);
            compoundTag2.putInt("VarValue", node.varValue);
            compoundTag2.putInt("VarCompare", node.varCompare);
            compoundTag2.putInt("VarOp", node.varOp);
            compoundTag2.putInt("VarInputNode", node.varInputNode);
            compoundTag2.putInt("CheckTarget", node.checkTarget);
            compoundTag2.putInt("CheckRadius", node.checkRadius);
            compoundTag2.putInt("CheckCooldown", node.checkCooldown);
            compoundTag2.putInt("DamageFilter", node.damageFilter);
            compoundTag2.putInt("DamageCooldown", node.damageCooldown);
            compoundTag2.putInt("MinDamage", node.minDamage);
            if (node.type == 7) {
                compoundTag2.putInt("TimeMode", node.timeMode);
                compoundTag2.putInt("TimeTicks", node.timeTicks);
            }
            if (node.type == 8) {
                compoundTag2.putInt("TimerInterval", node.timerInterval);
                compoundTag2.putBoolean("TimerRepeat", node.timerRepeat);
            }
            if (node.type == 9) {
                compoundTag2.putString("AnimName", node.animName);
                compoundTag2.putBoolean("AnimLoop", node.animLoop);
                compoundTag2.putString("AnimBone", node.animBone);
            }
            if (node.type == 11) {
                if (!node.moveCoords.isBlank()) {
                    compoundTag2.putString("MoveCoords", node.moveCoords);
                }
                if (node.moveSpeed != 1.0) {
                    compoundTag2.putDouble("MoveSpeed", node.moveSpeed);
                }
                if (node.moveEscort) {
                    compoundTag2.putBoolean("MoveEscort", true);
                }
            }
            if (node.type == 12) {
                if (!node.mobilityGroupId.isBlank()) {
                    compoundTag2.putString("MobilityGroupId", node.mobilityGroupId);
                }
                if (!node.mobilityGroupName.isBlank()) {
                    compoundTag2.putString("MobilityGroupName", node.mobilityGroupName);
                }
            }
            if (node.type == 14 && !node.cutsceneName.isBlank()) {
                compoundTag2.putString("CutsceneName", node.cutsceneName);
            }
            if (node.type == 0 && node.cutsceneLine) {
                compoundTag2.putBoolean("CutsceneLine", true);
            }
            if (node.type == 15) {
                compoundTag2.putInt("Radius", node.radius);
                compoundTag2.putInt("RadiusTarget", Math.max(0, Math.min(4, node.radiusTarget)));
            }
            if (node.type == 13) {
                compoundTag2.putInt("RandomMin", node.randomMin);
                compoundTag2.putInt("RandomMax", node.randomMax);
                compoundTag2.putIntArray("RandomBranches", node.randomBranches.stream().mapToInt(Integer::intValue).toArray());
            }
            compoundTag2.putIntArray("Choices", node.choices.stream().mapToInt(Integer::intValue).toArray());
            compoundTag2.putIntArray("Triggers", node.triggers.stream().mapToInt(Integer::intValue).toArray());
            ListTag listTag2 = new ListTag();
            for (NpcProfile.Variant variant : node.variants) {
                CompoundTag compoundTag3 = new CompoundTag();
                compoundTag3.putInt("Min", variant.minRelation);
                compoundTag3.putString("Text", variant.text);
                listTag2.add(compoundTag3);
            }
            compoundTag2.put("Variants", listTag2);
            listTag.add(compoundTag2);
        }
        compoundTag.put("Nodes", listTag);
        return compoundTag;
    }

    public static NpcDialogueGraph load(CompoundTag compoundTag) {
        if (compoundTag == null || compoundTag.getInt("Version") != 1) {
            return null;
        }
        ListTag listTag = compoundTag.getList("Nodes", 10);
        if (listTag.size() > 2048) {
            return null;
        }
        NpcDialogueGraph npcDialogueGraph = new NpcDialogueGraph();
        npcDialogueGraph.enabled = compoundTag.getBoolean("Enabled");
        npcDialogueGraph.entry = compoundTag.getInt("Entry");
        if (compoundTag.contains("HasCamera", 1)) {
            npcDialogueGraph.hasCamera = compoundTag.getBoolean("HasCamera");
        } else if (compoundTag.contains("PanX") || compoundTag.contains("Zoom")) {
            npcDialogueGraph.hasCamera = true;
        }
        if (compoundTag.contains("PanX", 6)) {
            npcDialogueGraph.panX = compoundTag.getDouble("PanX");
        } else if (compoundTag.contains("PanX", 3)) {
            npcDialogueGraph.panX = compoundTag.getInt("PanX");
        }
        if (compoundTag.contains("PanY", 6)) {
            npcDialogueGraph.panY = compoundTag.getDouble("PanY");
        } else if (compoundTag.contains("PanY", 3)) {
            npcDialogueGraph.panY = compoundTag.getInt("PanY");
        }
        if (compoundTag.contains("Zoom", 6)) {
            npcDialogueGraph.zoom = compoundTag.getDouble("Zoom");
        }
        npcDialogueGraph.zoom = Math.max(0.05, Math.min(2.0, npcDialogueGraph.zoom <= 0.001 ? 1.0 : npcDialogueGraph.zoom));
        npcDialogueGraph.panX = Math.max(-100000.0, Math.min(100000.0, npcDialogueGraph.panX));
        npcDialogueGraph.panY = Math.max(-100000.0, Math.min(100000.0, npcDialogueGraph.panY));
        for (int i = 0; i < listTag.size(); ++i) {
            int[] nArray;
            CompoundTag compoundTag2 = listTag.getCompound(i);
            Node node = new Node(compoundTag2.getInt("Id"), compoundTag2.getInt("Type"), compoundTag2.getInt("X"), compoundTag2.getInt("Y"));
            if (npcDialogueGraph.nodes.containsKey(node.id)) {
                return null;
            }
            node.next = compoundTag2.getInt("Next");
            node.special = compoundTag2.getInt("Special");
            node.text = compoundTag2.getString("Text");
            node.action = compoundTag2.getString("Action");
            node.builtinTopic = compoundTag2.getInt("BuiltinTopic");
            node.originTopic = compoundTag2.getInt("OriginTopic");
            node.originStep = compoundTag2.getInt("OriginStep");
            node.originAnswer = compoundTag2.getInt("OriginAnswer");
            node.relation = compoundTag2.getInt("Relation");
            node.minRelation = compoundTag2.getInt("MinRelation");
            node.maxRelation = compoundTag2.getInt("MaxRelation");
            node.pointsName = compoundTag2.getString("PointsName");
            node.minPoints = compoundTag2.getInt("MinPoints");
            node.maxPoints = compoundTag2.getInt("MaxPoints");
            node.pointsShared = compoundTag2.getBoolean("PointsShared");
            node.varLocal = compoundTag2.getBoolean("VarLocal");
            node.falseNext = compoundTag2.contains("FalseNext") ? compoundTag2.getInt("FalseNext") : -1;
            node.varValue = compoundTag2.getInt("VarValue");
            node.varCompare = compoundTag2.getInt("VarCompare");
            node.varOp = compoundTag2.getInt("VarOp");
            node.varInputNode = compoundTag2.contains("VarInputNode") ? compoundTag2.getInt("VarInputNode") : -1;
            node.checkTarget = compoundTag2.contains("CheckTarget") ? compoundTag2.getInt("CheckTarget") : 0;
            int n = node.checkRadius = compoundTag2.contains("CheckRadius") ? compoundTag2.getInt("CheckRadius") : 5;
            if (node.checkRadius < 1) {
                node.checkRadius = 5;
            }
            node.checkCooldown = compoundTag2.contains("CheckCooldown") ? compoundTag2.getInt("CheckCooldown") : 10;
            node.damageFilter = compoundTag2.contains("DamageFilter") ? compoundTag2.getInt("DamageFilter") : 1;
            node.damageCooldown = compoundTag2.contains("DamageCooldown") ? compoundTag2.getInt("DamageCooldown") : 1;
            node.minDamage = compoundTag2.contains("MinDamage") ? compoundTag2.getInt("MinDamage") : 1;
            int n2 = node.timeMode = compoundTag2.contains("TimeMode") ? compoundTag2.getInt("TimeMode") : 4;
            if (node.timeMode < 0 || node.timeMode > 4) {
                node.timeMode = 4;
            }
            int n3 = node.timeTicks = compoundTag2.contains("TimeTicks") ? compoundTag2.getInt("TimeTicks") : 6000;
            if (node.timeTicks < 0 || node.timeTicks > 23999) {
                node.timeTicks = 6000;
            }
            int n4 = node.timerInterval = compoundTag2.contains("TimerInterval") ? compoundTag2.getInt("TimerInterval") : 10;
            if (node.timerInterval < 1) {
                node.timerInterval = 10;
            }
            node.timerRepeat = !compoundTag2.contains("TimerRepeat") || compoundTag2.getBoolean("TimerRepeat");
            node.animName = compoundTag2.contains("AnimName") ? compoundTag2.getString("AnimName") : "";
            node.animLoop = compoundTag2.contains("AnimLoop") && compoundTag2.getBoolean("AnimLoop");
            node.animBone = compoundTag2.contains("AnimBone") ? compoundTag2.getString("AnimBone") : "";
            node.cutsceneName = compoundTag2.contains("CutsceneName") ? compoundTag2.getString("CutsceneName") : "";
            node.cutsceneLine = compoundTag2.contains("CutsceneLine") && compoundTag2.getBoolean("CutsceneLine");
            node.radius = compoundTag2.contains("Radius") ? Math.max(1, Math.min(96, compoundTag2.getInt("Radius"))) : 10;
            node.radiusTarget = compoundTag2.contains("RadiusTarget") ? Math.max(0, Math.min(4, compoundTag2.getInt("RadiusTarget"))) : 0;
            node.moveCoords = compoundTag2.contains("MoveCoords") ? compoundTag2.getString("MoveCoords") : "";
            node.moveSpeed = compoundTag2.contains("MoveSpeed") ? compoundTag2.getDouble("MoveSpeed") : 1.0;
            node.moveEscort = compoundTag2.contains("MoveEscort") && compoundTag2.getBoolean("MoveEscort");
            node.mobilityGroupId = compoundTag2.contains("MobilityGroupId") ? compoundTag2.getString("MobilityGroupId") : "";
            node.mobilityGroupName = compoundTag2.contains("MobilityGroupName") ? compoundTag2.getString("MobilityGroupName") : "";
            node.randomMin = compoundTag2.contains("RandomMin") ? compoundTag2.getInt("RandomMin") : 1;
            int n5 = node.randomMax = compoundTag2.contains("RandomMax") ? compoundTag2.getInt("RandomMax") : 2;
            if (node.randomMax < 2) {
                node.randomMax = 2;
            }
            if (node.randomMin < 1) {
                node.randomMin = 1;
            }
            if (compoundTag2.contains("RandomBranches")) {
                for (int n6 : nArray = compoundTag2.getIntArray("RandomBranches")) {
                    node.randomBranches.add(n6);
                }
            }
            if ((nArray = compoundTag2.getIntArray("Choices")).length > 16) {
                return null;
            }
            for (int n6 : nArray) {
                node.choices.add(n6);
            }
            int[] nArray2 = compoundTag2.getIntArray("Triggers");
            for (int n7 : nArray2) {
                node.triggers.add(n7);
            }
            Object object = compoundTag2.getList("Variants", 10);
            if (((ListTag)object).size() > 5) {
                return null;
            }
            for (int j = 0; j < ((ListTag)object).size(); ++j) {
                CompoundTag compoundTag3 = ((ListTag)object).getCompound(j);
                node.variants.add(new NpcProfile.Variant(compoundTag3.getInt("Min"), compoundTag3.getString("Text")));
            }
            npcDialogueGraph.nodes.put(node.id, node);
        }
        return npcDialogueGraph;
    }

    public static NpcDialogueGraph fromLegacy(NpcProfile npcProfile) {
        NpcProfile.Step step;
        Node node;
        NpcProfile.Topic topic;
        int n;
        Node node2;
        NpcDialogueGraph npcDialogueGraph = new NpcDialogueGraph();
        Node node3 = npcDialogueGraph.add(0, 0, 0);
        node3.text = npcProfile.welcome;
        npcDialogueGraph.entry = node3.id;
        Node node4 = node3;
        for (int i = 0; i < npcProfile.welcomeLines.size(); ++i) {
            node2 = NpcDialogueGraph.required(npcDialogueGraph.add(0, (i + 1) * 280, 0));
            node2.text = npcProfile.welcomeLines.get(i);
            node4.next = node2.id;
            node4 = node2;
        }
        Node node5 = NpcDialogueGraph.required(npcDialogueGraph.add(0, 0, -240));
        node5.text = npcProfile.escortTravelLine;
        node5.special = 1;
        node2 = NpcDialogueGraph.required(npcDialogueGraph.add(0, 280, -240));
        node2.text = npcProfile.escortArrivalLine;
        node2.special = 2;
        int n2 = node4.id;
        int[] nArray = new int[npcProfile.topics.size()];
        Arrays.fill(nArray, -1);
        int[][] nArrayArray = new int[npcProfile.topics.size()][];
        for (n = 0; n < npcProfile.topics.size(); ++n) {
            topic = npcProfile.topics.get(n);
            Node node6 = NpcDialogueGraph.required(npcDialogueGraph.add(1, 280, 180 + n * 1050));
            node6.text = topic.title;
            node6.originTopic = n;
            nArray[n] = node6.id;
            if (node4.choices.size() >= 16) {
                node = NpcDialogueGraph.required(npcDialogueGraph.add(0, node4.x + 280, node4.y));
                node.text = node4.text;
                node4.next = node.id;
                node4 = node;
            }
            node4.choices.add(node6.id);
            if (topic.type != 0) {
                node6.builtinTopic = n;
                nArrayArray[n] = new int[0];
                continue;
            }
            nArrayArray[n] = new int[topic.steps.size()];
            for (int i = 0; i < topic.steps.size(); ++i) {
                step = topic.steps.get(i);
                Node node7 = NpcDialogueGraph.required(npcDialogueGraph.add(0, 560 + i * 560, 180 + n * 1050));
                node7.text = step.line;
                node7.action = step.action;
                node7.originTopic = n;
                node7.originStep = i;
                for (NpcProfile.Variant object : step.variants) {
                    node7.variants.add(new NpcProfile.Variant(object.minRelation, object.text));
                }
                nArrayArray[n][i] = node7.id;
            }
            if (nArrayArray[n].length <= 0) continue;
            node6.next = nArrayArray[n][0];
        }
        for (n = 0; n < npcProfile.topics.size(); ++n) {
            topic = npcProfile.topics.get(n);
            if (topic.type != 0) continue;
            for (int i = 0; i < topic.steps.size(); ++i) {
                node = npcDialogueGraph.get(nArrayArray[n][i]);
                step = topic.steps.get(i);
                int n3 = NpcProfile.chainNext(topic, i);
                node.next = n3 >= 0 ? nArrayArray[n][n3] : n2;
                for (int j = 0; j < step.answers.size(); ++j) {
                    NpcProfile.Answer answer = step.answers.get(j);
                    Node node6 = NpcDialogueGraph.required(npcDialogueGraph.add(1, node.x + 110, node.y + 110 + j * 120));
                    node6.text = answer.player;
                    node6.action = answer.action;
                    node6.relation = answer.relation;
                    node6.minRelation = answer.minRelation;
                    node6.maxRelation = answer.maxRelation;
                    node6.pointsName = answer.pointsName;
                    node6.minPoints = answer.minPoints;
                    node6.maxPoints = answer.maxPoints;
                    node6.pointsShared = answer.pointsShared;
                    node6.originTopic = n;
                    node6.originStep = i;
                    node6.originAnswer = j;
                    node.choices.add(node6.id);
                    int n4 = n2;
                    int n5 = -1;
                    if (answer.next >= 1000) {
                        int n6 = answer.next - 1000;
                        if (n6 < nArray.length) {
                            Node node7 = npcDialogueGraph.get(nArray[n6]);
                            int n7 = n4 = node7 != null ? node7.next : n2;
                            if (node7 != null && node7.builtinTopic >= 0) {
                                n5 = node7.builtinTopic;
                            }
                        }
                    } else if (answer.next >= 0 && answer.next < nArrayArray[n].length) {
                        n4 = nArrayArray[n][answer.next];
                    }
                    if (!answer.reaction.isEmpty()) {
                        Node node8 = NpcDialogueGraph.required(npcDialogueGraph.add(0, node6.x + 280, node6.y));
                        node8.text = answer.reaction;
                        node8.next = n5 >= 0 ? -1 : n4;
                        node8.builtinTopic = n5;
                        node6.next = node8.id;
                        continue;
                    }
                    node6.next = n5 >= 0 ? -1 : n4;
                    node6.builtinTopic = n5;
                }
            }
        }
        if (!npcDialogueGraph.error().isEmpty()) {
            throw new IllegalArgumentException("Legacy dialogue exceeds graph limits: " + npcDialogueGraph.error());
        }
        return npcDialogueGraph;
    }

    private static Node required(Node node) {
        if (node == null) {
            throw new IllegalArgumentException("Legacy dialogue exceeds graph node limit");
        }
        return node;
    }

    public void applySpecialLines(NpcProfile npcProfile) {
        Node node = this.get(this.specialNode(1));
        Node node2 = this.get(this.specialNode(2));
        if (node != null) {
            npcProfile.escortTravelLine = node.text;
        }
        if (node2 != null) {
            npcProfile.escortArrivalLine = node2.text;
        }
    }

    public static final class Node {
        public int id;
        public int type;
        public int x;
        public int y;
        public int next = -1;
        public int special;
        public int builtinTopic = -1;
        public int originTopic = -1;
        public int originStep = -1;
        public int originAnswer = -1;
        public String text = "";
        public String action = "";
        public String pointsName = "";
        public int relation;
        public int minRelation;
        public int maxRelation = 100;
        public int minPoints;
        public int maxPoints = 1000000;
        public boolean pointsShared;
        public boolean varLocal;
        public int falseNext = -1;
        public int varValue = 0;
        public int varCompare = 0;
        public int varOp = 0;
        public int varInputNode = -1;
        public int checkTarget = 0;
        public int checkRadius = 5;
        public int radius = 10;
        public int radiusTarget = 0;
        public int checkCooldown = 10;
        public int damageFilter = 1;
        public int damageCooldown = 1;
        public int minDamage = 1;
        public int timeMode = 4;
        public int timeTicks = 6000;
        public int timerInterval = 10;
        public boolean timerRepeat = true;
        public String animName = "";
        public String cutsceneName = "";
        public boolean cutsceneLine = false;
        public boolean animLoop = false;
        public String animBone = "";
        public String moveCoords = "";
        public double moveSpeed = 1.0;
        public boolean moveEscort = false;
        public String mobilityGroupId = "";
        public String mobilityGroupName = "";
        public int randomMin = 1;
        public int randomMax = 2;
        public final List<Integer> randomBranches = new ArrayList<Integer>();
        public final List<Integer> choices = new ArrayList<Integer>();
        public final List<Integer> triggers = new ArrayList<Integer>();
        public final List<NpcProfile.Variant> variants = new ArrayList<NpcProfile.Variant>();

        public Node(int n, int n2, int n3, int n4) {
            this.id = n;
            this.type = n2;
            this.x = n3;
            this.y = n4;
        }

        public Node copy() {
            Node node = new Node(this.id, this.type, this.x, this.y);
            node.next = this.next;
            node.special = this.special;
            node.builtinTopic = this.builtinTopic;
            node.originTopic = this.originTopic;
            node.originStep = this.originStep;
            node.originAnswer = this.originAnswer;
            node.text = this.text;
            node.action = this.action;
            node.pointsName = this.pointsName;
            node.relation = this.relation;
            node.minRelation = this.minRelation;
            node.maxRelation = this.maxRelation;
            node.minPoints = this.minPoints;
            node.maxPoints = this.maxPoints;
            node.pointsShared = this.pointsShared;
            node.varLocal = this.varLocal;
            node.falseNext = this.falseNext;
            node.varValue = this.varValue;
            node.varCompare = this.varCompare;
            node.varOp = this.varOp;
            node.varInputNode = this.varInputNode;
            node.checkTarget = this.checkTarget;
            node.checkRadius = this.checkRadius;
            node.checkCooldown = this.checkCooldown;
            node.radius = this.radius;
            node.radiusTarget = this.radiusTarget;
            node.damageFilter = this.damageFilter;
            node.damageCooldown = this.damageCooldown;
            node.minDamage = this.minDamage;
            node.timeMode = this.timeMode;
            node.timeTicks = this.timeTicks;
            node.timerInterval = this.timerInterval;
            node.timerRepeat = this.timerRepeat;
            node.animName = this.animName;
            node.animLoop = this.animLoop;
            node.animBone = this.animBone;
            node.cutsceneName = this.cutsceneName;
            node.cutsceneLine = this.cutsceneLine;
            node.moveCoords = this.moveCoords;
            node.moveSpeed = this.moveSpeed;
            node.moveEscort = this.moveEscort;
            node.mobilityGroupId = this.mobilityGroupId;
            node.mobilityGroupName = this.mobilityGroupName;
            node.randomMin = this.randomMin;
            node.randomMax = this.randomMax;
            node.randomBranches.addAll(this.randomBranches);
            node.choices.addAll(this.choices);
            node.triggers.addAll(this.triggers);
            for (NpcProfile.Variant variant : this.variants) {
                node.variants.add(new NpcProfile.Variant(variant.minRelation, variant.text));
            }
            return node;
        }

        public String lineFor(int n) {
            String string = this.text;
            int n2 = -1;
            for (NpcProfile.Variant variant : this.variants) {
                if (variant.minRelation > n || variant.minRelation < n2) continue;
                string = variant.text;
                n2 = variant.minRelation;
            }
            return string;
        }

        public boolean relationVisible(int n) {
            return this.minRelation <= n && n <= this.maxRelation;
        }
    }
}

