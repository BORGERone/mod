package dev.settledlands.npc;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.extensions.IEntityExtension;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

/**
 * Build 220 «cult-bridge»: стоковый гейт вселения (PossessionSystem) проверяет
 * ТОЛЬКО локальную переменную «культ» в persistent-NBT NPC (settledlands_local_vars).
 * Нода «переменная» (215) умеет писать в ТРИ хранилища: local (NPC NBT),
 * personal/shared (NpcPoints, мировые данные). Если культ записан в personal/shared
 * скоуп — NPC-local остаётся 0 и гейт отвечает «культ не стоит на 1».
 *
 * Этот обработчик срабатывает ДО стокового (EventPriority.HIGHEST) и зеркалит:
 * если где-либо (NpcPoints shared/personal) «культ» равен 1 — копируем значение
 * в settledlands_local_vars NPC (гейт 221: культ >= 1). Стоковый гейт проходит своим кодом,
 * двойного вселения нет. Если культ нигде не равен 1 — просто пишем значения в лог,
 * чтобы было видно, куда именно он записан.
 */
@EventBusSubscriber(modid = "settledlands")
public final class PossessionCultBridge {

    private PossessionCultBridge() {}

    private static final Logger LOGGER = LogUtils.getLogger();

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onInteractSpecific(PlayerInteractEvent.EntityInteractSpecific event) {
        mirror(event.getEntity(), event.getTarget());
    }

    private static void mirror(net.minecraft.world.entity.player.Player player, Entity target) {
        if (!(player instanceof ServerPlayer sp)) return;
        if (!(target instanceof GuideNpc npc)) return;
        if (target instanceof GuideCorpseNpc) return;
        if (sp.level().isClientSide()) return;
        // Спам-фильтр: интересны только попытки вселения бестелесного игрока.
        if (!PossessionSystem.isBodiless(sp)) return;
        CompoundTag local = ((IEntityExtension) npc).getPersistentData()
                .getCompound("settledlands_local_vars");
        int localVal = local.getInt("культ");
        int sharedVal = 0;
        int personalVal = 0;
        MinecraftServer server = sp.getServer();
        if (server != null) {
            try {
                NpcPoints points = NpcPoints.get(server);
                personalVal = points.get(sp.getUUID(), "культ", false);
                sharedVal = points.get(sp.getUUID(), "культ", true);
            } catch (Throwable t) {
                LOGGER.warn("[SettledLands] cult-bridge: NpcPoints read failed: {}", t.toString());
            }
        }
        if (localVal < 1 && (sharedVal >= 1 || personalVal >= 1)) {
            local.putInt("культ", 1);
            ((IEntityExtension) npc).getPersistentData().put("settledlands_local_vars", local);
            LOGGER.info("[SettledLands] cult-bridge: mirrored культ=1 into npc '{}' (was local={}, shared={}, personal={})",
                    npc.getName().getString(), localVal, sharedVal, personalVal);
        } else {
            LOGGER.info("[SettledLands] possess attempt on '{}': культ local={}, shared={}, personal={}"
                    + (localVal >= 1 ? " -> gate ok" : " -> gate will deny, var is stored elsewhere or absent"),
                    npc.getName().getString(), localVal, sharedVal, personalVal);
        }
    }
}
