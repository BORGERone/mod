/*
 * Decompiled with CFR 0.152.
 */
package dev.settledlands.npc.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.settledlands.model.BbModel;
import dev.settledlands.model.BbModelManager;
import dev.settledlands.npc.CutsceneDeletePayload;
import dev.settledlands.npc.CutsceneStudioRequestPayload;
import dev.settledlands.npc.NpcDialogueGraph;
import dev.settledlands.npc.NpcNet;
import dev.settledlands.npc.NpcProfile;
import dev.settledlands.npc.client.CommandTabCompleter;
import dev.settledlands.npc.client.CutsceneCameraClient;
import dev.settledlands.npc.client.NpcConfigScreen;
import dev.settledlands.npc.client.NpcGraphCanvas;
import dev.settledlands.npc.client.NpcGraphContextMenu;
import dev.settledlands.npc.client.NpcUi;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.MultiLineEditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.PacketDistributor;
import org.joml.Matrix4f;

public final class NpcDialogueGraphScreen
extends Screen
implements NpcUi.PopupHost {
    private final int entityId;
    private final int focus;
    private final Screen parent;
    public final List<NpcConfigScreen.MobilityGroupOption> mobilityGroups = new ArrayList<NpcConfigScreen.MobilityGroupOption>();
    private NpcProfile profile;
    private NpcDialogueGraph graph;
    private static final int TAB_MAIN = 0;
    private static final int TAB_WALK = 1;
    private static final int TAB_ANIM = 2;
    private final NpcDialogueGraph[] graphs = new NpcDialogueGraph[3];
    private int tab = 0;
    private final NpcGraphCanvas canvas = new NpcGraphCanvas();
    private final NpcGraphContextMenu contextMenu = new NpcGraphContextMenu();
    private final Deque<NpcDialogueGraph> undo = new ArrayDeque<NpcDialogueGraph>();
    private final Deque<NpcDialogueGraph> redo = new ArrayDeque<NpcDialogueGraph>();
    private final Map<Integer, String> summaries = new HashMap<Integer, String>();
    private final List<Label> labels = new ArrayList<Label>();
    private final List<AbstractWidget> inspectorWidgets = new ArrayList<AbstractWidget>();
    private boolean buildingInspector;
    private int panelTop = 38;
    private int topBarRight = 64;
    public final Set<Integer> multiSelected = new LinkedHashSet<Integer>();
    private boolean spaceDown;
    private boolean selectingBox;
    private double boxStartX;
    private double boxStartY;
    private double boxCurrentX;
    private double boxCurrentY;
    private double dragMouseWorldX;
    private double dragMouseWorldY;
    private final Map<Integer, int[]> dragOrigins = new HashMap<Integer, int[]>();
    private int selected = -1;
    private int linkFrom = -1;
    private int linkFromPort = 0;
    private int dragging = -1;
    private int sidebarScroll;
    private int sidebarHeight;
    private int revision;
    private int lastSent = -1;
    private boolean sentMain;
    private boolean sentWalk;
    private boolean sentAnim;
    private long closeWarnAt;
    private double dragX;
    private double dragY;
    private double panStartX;
    private double panStartY;
    private boolean panning;
    private boolean canvasPanMoved;
    private boolean dirty;
    private boolean suppress;
    private boolean focusOnInit = true;
    private long propertyUndoAt;
    private String status = "";
    private String importError = "";
    private int inspectorX;
    private int inspectorY;
    private int inspectorW;
    private int inspectorH;
    private AbstractWidget triggerBox;
    private NpcUi.NpcDropdown openDropdown;
    private String pendingSceneDelete;
    private boolean pendingSceneDeleteAll;

    private boolean isSpaceDown() {
        if (this.getFocused() instanceof EditBox || this.getFocused() instanceof MultiLineEditBox) {
            return false;
        }
        try {
            long l = Minecraft.getInstance().getWindow().getWindow();
            if (l != 0L && InputConstants.isKeyDown(l, 32)) {
                return true;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return this.spaceDown;
    }

    private boolean isControlDownSafe() {
        try {
            return NpcDialogueGraphScreen.hasControlDown();
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    private boolean isShiftDownSafe() {
        try {
            return NpcDialogueGraphScreen.hasShiftDown();
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    private void updateBoxSelection() {
        double d = Math.min(this.boxStartX, this.boxCurrentX);
        double d2 = Math.max(this.boxStartX, this.boxCurrentX);
        double d3 = Math.min(this.boxStartY, this.boxCurrentY);
        double d4 = Math.max(this.boxStartY, this.boxCurrentY);
        this.multiSelected.clear();
        for (NpcDialogueGraph.Node node : this.graph.nodes.values()) {
            double d5 = this.canvas.screenX(node.x);
            double d6 = this.canvas.screenY(node.y);
            double d7 = d5 + 220.0 * this.canvas.zoom;
            double d8 = d6 + 100.0 * this.canvas.zoom;
            if (d7 < d || d5 > d2 || d8 < d3 || d6 > d4) continue;
            this.multiSelected.add(node.id);
        }
        if (this.multiSelected.size() == 1) {
            this.selected = this.multiSelected.iterator().next();
        } else if (this.multiSelected.isEmpty()) {
            this.selected = -1;
        } else if (!this.multiSelected.contains(this.selected)) {
            this.selected = this.multiSelected.iterator().next();
        }
    }

    @Override
    public void openDropdown(NpcUi.NpcDropdown npcDropdown) {
        this.openDropdown = npcDropdown;
    }

    @Override
    public NpcUi.NpcDropdown activeDropdown() {
        return this.openDropdown;
    }

    public NpcDialogueGraphScreen(int n, NpcProfile npcProfile, Screen screen, int n2) {
        super(Component.translatable("gui.settledlands.graph.title"));
        this.entityId = n;
        this.focus = n2;
        this.profile = npcProfile.copy();
        this.parent = screen;
        if (screen instanceof NpcConfigScreen) {
            NpcConfigScreen npcConfigScreen = (NpcConfigScreen)screen;
            this.mobilityGroups.addAll(npcConfigScreen.mobilityGroups);
        }
        try {
            this.graph = npcProfile.dialogueGraph == null ? NpcDialogueGraph.fromLegacy(npcProfile) : npcProfile.dialogueGraph.copy();
        }
        catch (IllegalArgumentException illegalArgumentException) {
            this.graph = new NpcDialogueGraph();
            this.importError = illegalArgumentException.getMessage();
            this.status = this.tr("gui.settledlands.graph.import_failed");
        }
        this.graphs[0] = this.graph;
        this.graphs[1] = this.profile.walkGraph == null ? null : this.profile.walkGraph.copy();
        NpcDialogueGraph npcDialogueGraph = this.graphs[2] = this.profile.animGraph == null ? null : this.profile.animGraph.copy();
        if (this.importError.isEmpty()) {
            this.selected = n2 == -2 || n2 == -3 ? this.graph.specialNode(n2 == -2 ? 1 : 2) : (n2 >= 0 ? this.graph.topicNode(n2) : this.graph.entry);
            if (n2 != -2 && n2 != -3 && !this.graph.enabled) {
                this.graph.enabled = true;
                this.dirty = true;
            }
        }
    }

    public int entityId() {
        return this.entityId;
    }

    public static void open(int n, NpcProfile npcProfile, Screen screen, int n2) {
        if (npcProfile != null) {
            Minecraft.getInstance().setScreen(new NpcDialogueGraphScreen(n, npcProfile, screen, n2));
        }
    }

    private String tr(String string) {
        return Component.translatable(string).getString();
    }

    private NpcDialogueGraph.Node node() {
        return this.graph.get(this.selected);
    }

    private void changed() {
        this.dirty = true;
        ++this.revision;
        this.summaries.remove(this.selected);
    }

    private void switchTab(int n) {
        if (n == this.tab || n < 0 || n > 2) {
            return;
        }
        this.syncCamera();
        this.graphs[this.tab] = this.graph;
        this.tab = n;
        if (this.graphs[this.tab] == null) {
            this.graphs[this.tab] = new NpcDialogueGraph();
            this.graphs[this.tab].enabled = false;
        }
        this.graph = this.graphs[this.tab];
        this.undo.clear();
        this.redo.clear();
        this.summaries.clear();
        this.multiSelected.clear();
        this.selected = -1;
        this.sidebarScroll = 0;
        this.linkFrom = -1;
        this.dragging = -1;
        this.panning = false;
        this.selectingBox = false;
        this.contextMenu.cancel();
        if (this.openDropdown != null) {
            this.openDropdown.closePopup();
            this.openDropdown = null;
        }
        if (this.graph.hasCamera) {
            this.canvas.panX = this.graph.panX;
            this.canvas.panY = this.graph.panY;
            this.canvas.zoom = this.graph.zoom <= 0.001 ? 1.0 : this.graph.zoom;
        } else {
            this.canvas.frameAll(this.graph);
        }
        this.changed();
        this.widgets();
    }

    private void remember() {
        this.undo.addLast(this.graph.copy());
        while (this.undo.size() > 24) {
            this.undo.removeFirst();
        }
        this.redo.clear();
    }

    private void propertyChange(Runnable runnable) {
        if (this.suppress) {
            return;
        }
        long l = System.currentTimeMillis();
        if (l - this.propertyUndoAt > 700L) {
            this.remember();
            this.propertyUndoAt = l;
        }
        runnable.run();
        this.changed();
    }

    @Override
    protected void init() {
        this.contextMenu.cancel();
        this.inspectorW = Math.min(230, Math.max(180, this.width / 4));
        this.inspectorX = this.width - this.inspectorW - 10;
        this.inspectorY = 10;
        this.inspectorH = this.height - 20;
        this.canvas.bounds(0, 0, this.width, this.height);
        if (this.focusOnInit) {
            if (this.graph.hasCamera) {
                this.canvas.panX = this.graph.panX;
                this.canvas.panY = this.graph.panY;
                double d = this.canvas.zoom = this.graph.zoom <= 0.001 ? 1.0 : this.graph.zoom;
            }
            if (this.focus == -2 || this.focus == -3 || this.focus >= 0) {
                this.canvas.focus(this.node());
            } else if (!this.graph.hasCamera) {
                this.canvas.focus(this.node());
            }
            this.focusOnInit = false;
        }
        this.widgets();
    }

    private Button button(String string, int n, int n2, int n3, Runnable runnable) {
        return this.button(string, n, n2, n3, 20, runnable);
    }

    private Button button(String string, int n, int n2, int n3, int n4, Runnable runnable) {
        Button button2 = this.addRenderableWidget(Button.builder(Component.translatable(string), button -> runnable.run()).bounds(n, n2, n3, n4).build());
        if (this.buildingInspector) {
            this.inspectorWidgets.add(button2);
        }
        return button2;
    }

    private void widgets() {
        int n2;
        if (this.openDropdown != null) {
            this.openDropdown.closePopup();
            this.openDropdown = null;
        }
        this.clearWidgets();
        this.triggerBox = null;
        this.labels.clear();
        this.inspectorWidgets.clear();
        this.buildingInspector = false;
        this.suppress = true;
        this.button("gui.settledlands.graph.undo", 10, 10, 24, 20, () -> this.history(false));
        this.button("gui.settledlands.graph.redo", 38, 10, 24, 20, () -> this.history(true));
        String[] stringArray = new String[]{"gui.settledlands.graph.tab_main", "gui.settledlands.graph.tab_walk", "gui.settledlands.graph.tab_anim"};
        int[] nArray = new int[]{62, 94, 84};
        int n3 = 66;
        for (int i = 0; i < 3; ++i) {
            int tabIndex = i;
            Button button = this.button(stringArray[i], n3, 10, nArray[i], 20, () -> this.switchTab(tabIndex));
            button.active = i != this.tab;
            n3 += nArray[i] + 4;
        }
        this.topBarRight = n3 - 4;
        this.inspectorW = Math.min(230, Math.max(180, this.width / 4));
        this.inspectorX = this.width - this.inspectorW - 10;
        this.inspectorY = 10;
        this.inspectorH = this.height - 20;
        NpcDialogueGraph.Node node = this.node();
        n2 = this.inspectorX + 8;
        int n4 = this.inspectorW - 16;
        int n5 = this.inspectorY + 24 - this.sidebarScroll;
        if (this.selected >= 0 && node != null) {
            this.buildingInspector = true;
            if (node.type == 2) {
                this.label("gui.settledlands.graph.trigger_presets", n2, n5);
                List<Component> list = List.of(Component.translatable("gui.settledlands.graph.preset_choose"), Component.translatable("gui.settledlands.graph.preset_play"), Component.translatable("gui.settledlands.graph.preset_go"), Component.translatable("gui.settledlands.graph.preset_give"), Component.translatable("gui.settledlands.graph.preset_relation"), Component.translatable("gui.settledlands.graph.preset_shop"), Component.translatable("gui.settledlands.graph.preset_close"), Component.translatable("gui.settledlands.graph.preset_purgatory"), Component.translatable("gui.settledlands.graph.preset_sound"), Component.translatable("gui.settledlands.graph.preset_say"));
                AbstractWidget abstractWidget = this.addRenderableWidget(NpcUi.dropdown(n2, n5 += 11, n4, list, 0, n -> {
                    String string;
                    if (n <= 0) {
                        return;
                    }
                    switch (n) {
                        case 1: {
                            string = "/play ";
                            break;
                        }
                        case 2: {
                            string = "/go ";
                            break;
                        }
                        case 3: {
                            string = "/give @p ";
                            break;
                        }
                        case 4: {
                            string = "trigger:relation 5";
                            break;
                        }
                        case 5: {
                            string = "trigger:shop";
                            break;
                        }
                        case 6: {
                            string = "trigger:close";
                            break;
                        }
                        case 7: {
                            string = "trigger:purgatory";
                            break;
                        }
                        case 8: {
                            string = "/playsound ";
                            break;
                        }
                        case 9: {
                            string = "/say ";
                            break;
                        }
                        default: {
                            string = "";
                        }
                    }
                    if (!string.isEmpty()) {
                        this.remember();
                        node.action = string;
                        this.changed();
                        this.widgets();
                        if (this.triggerBox != null) {
                            this.triggerBox.setFocused(true);
                            this.setFocused(this.triggerBox);
                        }
                    }
                }));
                if (this.buildingInspector) {
                    this.inspectorWidgets.add(abstractWidget);
                }
                this.label("gui.settledlands.graph.trigger_command", n2, n5 += 20);
                int n6 = this.calcBoxHeight(this.calcTextLines(node.action, n4), 20, 80);
                MultiLineEditBox multiLineEditBox = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 20, 80, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                    node.action = string;
                });
                this.triggerBox = multiLineEditBox;
                n5 += n6 + 4;
                n5 = this.incomingIfSection(node, n2, n5, n4);
                int n7 = (n4 - 4) / 2;
                this.button("gui.settledlands.graph.unlink", n2, n5, n7, 16, () -> {
                    this.remember();
                    this.graph.disconnectOutputs(node.id);
                    this.changed();
                });
                this.button("gui.settledlands.graph.delete", n2 + n7 + 4, n5, n4 - n7 - 4, 16, () -> {
                    this.remember();
                    this.graph.remove(node.id);
                    this.selected = -1;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
            } else if (node.type == 4) {
                this.label("gui.settledlands.graph.var_name", n2, n5);
                this.textBox(node.pointsName, 32, n2, n5 += 11, n4, 16, string -> {
                    node.pointsName = string;
                });
                this.label("gui.settledlands.graph.var_delta", n2, n5 += 20);
                this.numberBox(node.varValue, -1000000, 1000000, n2, n5 += 11, n4, 16, n -> {
                    node.varValue = n;
                });
                this.button(node.pointsShared ? "gui.settledlands.graph.shared_on" : "gui.settledlands.graph.shared_off", n2, n5 += 20, n4, 16, () -> {
                    this.remember();
                    node.pointsShared = !node.pointsShared;
                    this.changed();
                    this.widgets();
                });
                this.button(node.varLocal ? "gui.settledlands.graph.local_on" : "gui.settledlands.graph.local_off", n2, n5 += 20, n4, 16, () -> {
                    this.remember();
                    node.varLocal = !node.varLocal;
                    this.changed();
                    this.widgets();
                });
                this.label("gui.settledlands.graph.action", n2, n5 += 20);
                int n8 = this.calcBoxHeight(this.calcTextLines(node.action, n4), 16, 60);
                MultiLineEditBox multiLineEditBox = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 16, 60, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                    node.action = string;
                });
                this.triggerBox = multiLineEditBox;
                int n9 = (n4 - 4) / 2;
                this.button("gui.settledlands.graph.unlink", n2, n5 += n8 + 4, n9, 16, () -> {
                    this.remember();
                    this.graph.disconnectOutputs(node.id);
                    this.changed();
                });
                this.button("gui.settledlands.graph.delete", n2 + n9 + 4, n5, n4 - n9 - 4, 16, () -> {
                    this.remember();
                    this.graph.remove(node.id);
                    this.selected = -1;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
            } else if (node.type == 3) {
                Object object;
                this.label("gui.settledlands.graph.var_op", n2, n5);
                List<Component> list = List.of(Component.literal("==  (\u0420\u0430\u0432\u043d\u043e)"), Component.literal("!=  (\u041d\u0435 \u0440\u0430\u0432\u043d\u043e)"), Component.literal(">=  (\u0411\u043e\u043b\u044c\u0448\u0435 \u0438\u043b\u0438 \u0440\u0430\u0432\u043d\u043e)"), Component.literal(">   (\u0411\u043e\u043b\u044c\u0448\u0435)"), Component.literal("<=  (\u041c\u0435\u043d\u044c\u0448\u0435 \u0438\u043b\u0438 \u0440\u0430\u0432\u043d\u043e)"), Component.literal("<   (\u041c\u0435\u043d\u044c\u0448\u0435)"));
                AbstractWidget abstractWidget = this.addRenderableWidget(NpcUi.dropdown(n2, n5 += 11, n4, list, node.varOp, n -> {
                    this.remember();
                    node.varOp = n;
                    this.changed();
                }));
                if (this.buildingInspector) {
                    this.inspectorWidgets.add(abstractWidget);
                }
                this.label("gui.settledlands.graph.var_compare", n2, n5 += 20);
                this.numberBox(node.varCompare, -1000000, 1000000, n2, n5 += 11, n4, 16, n -> {
                    node.varCompare = n;
                });
                this.label("gui.settledlands.graph.var_input", n2, n5 += 20);
                n5 += 11;
                if (node.varInputNode >= 0) {
                    NpcDialogueGraph.Node node2 = this.graph.get(node.varInputNode);
                    object = node2 != null ? "#" + node2.id + (String)(!node2.pointsName.isBlank() ? " (" + node2.pointsName + ")" : "") : "#" + node.varInputNode;
                    this.label(Component.translatable("gui.settledlands.graph.var_input_linked", node.varInputNode).getString() + " " + (String)object, n2, n5);
                    this.button("gui.settledlands.graph.unlink", n2, n5 += 12, n4, 16, () -> {
                        this.remember();
                        node.varInputNode = -1;
                        this.changed();
                        this.widgets();
                    });
                    n5 += 20;
                } else {
                    this.label("gui.settledlands.graph.var_input_none", n2, n5);
                    this.label("gui.settledlands.graph.var_name", n2, n5 += 12);
                    this.textBox(node.pointsName, 32, n2, n5 += 11, n4, 16, string -> {
                        node.pointsName = string;
                    });
                    this.button(node.pointsShared ? "gui.settledlands.graph.shared_on" : "gui.settledlands.graph.shared_off", n2, n5 += 20, n4, 16, () -> {
                        this.remember();
                        node.pointsShared = !node.pointsShared;
                        this.changed();
                        this.widgets();
                    });
                    this.button(node.varLocal ? "gui.settledlands.graph.local_on" : "gui.settledlands.graph.local_off", n2, n5 += 20, n4, 16, () -> {
                        this.remember();
                        node.varLocal = !node.varLocal;
                        this.changed();
                        this.widgets();
                    });
                    n5 += 20;
                }
                this.label("gui.settledlands.graph.action", n2, n5);
                int n10 = this.calcBoxHeight(this.calcTextLines(node.action, n4), 16, 60);
                this.triggerBox = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 16, 60, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                    node.action = string;
                });
                int n11 = (n4 - 4) / 2;
                this.button("gui.settledlands.graph.unlink", n2, n5 += n10 + 4, n11, 16, () -> {
                    this.remember();
                    this.graph.disconnectOutputs(node.id);
                    this.changed();
                });
                this.button("gui.settledlands.graph.delete", n2 + n11 + 4, n5, n4 - n11 - 4, 16, () -> {
                    this.remember();
                    this.graph.remove(node.id);
                    this.selected = -1;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
            } else if (node.type == 5) {
                this.label("gui.settledlands.graph.check_target", n2, n5);
                List<Component> list = List.of(Component.translatable("gui.settledlands.graph.target_player"), Component.translatable("gui.settledlands.graph.target_npc"), Component.translatable("gui.settledlands.graph.target_monster"), Component.translatable("gui.settledlands.graph.target_any"));
                AbstractWidget abstractWidget = this.addRenderableWidget(NpcUi.dropdown(n2, n5 += 11, n4, list, Math.max(0, Math.min(3, node.checkTarget)), n -> {
                    this.remember();
                    node.checkTarget = n;
                    this.changed();
                }));
                if (this.buildingInspector) {
                    this.inspectorWidgets.add(abstractWidget);
                }
                this.label("gui.settledlands.graph.check_radius", n2, n5 += 20);
                this.numberBox(node.checkRadius, 1, 64, n2, n5 += 11, n4, 16, n -> {
                    node.checkRadius = Math.max(1, Math.min(64, n));
                });
                this.label("gui.settledlands.graph.check_cooldown", n2, n5 += 20);
                this.numberBox(node.checkCooldown, 0, 3600, n2, n5 += 11, n4, 16, n -> {
                    node.checkCooldown = Math.max(0, Math.min(3600, n));
                });
                n5 += 20;
                n5 = this.incomingIfSection(node, n2, n5, n4);
                this.label("gui.settledlands.graph.action", n2, n5);
                int n12 = this.calcBoxHeight(this.calcTextLines(node.action, n4), 16, 60);
                MultiLineEditBox multiLineEditBox = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 16, 60, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                    node.action = string;
                });
                this.triggerBox = multiLineEditBox;
                int n13 = (n4 - 4) / 2;
                this.button("gui.settledlands.graph.unlink", n2, n5 += n12 + 4, n13, 16, () -> {
                    this.remember();
                    this.graph.disconnectOutputs(node.id);
                    this.changed();
                });
                this.button("gui.settledlands.graph.delete", n2 + n13 + 4, n5, n4 - n13 - 4, 16, () -> {
                    this.remember();
                    this.graph.remove(node.id);
                    this.selected = -1;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
            } else if (node.type == 6) {
                this.label("gui.settledlands.graph.damage_source", n2, n5);
                List<Component> list = List.of(Component.translatable("gui.settledlands.graph.damage_any"), Component.translatable("gui.settledlands.graph.damage_player"), Component.translatable("gui.settledlands.graph.damage_monster"), Component.translatable("gui.settledlands.graph.damage_non_player"));
                AbstractWidget abstractWidget = this.addRenderableWidget(NpcUi.dropdown(n2, n5 += 11, n4, list, Math.max(0, Math.min(3, node.damageFilter)), n -> {
                    this.remember();
                    node.damageFilter = n;
                    this.changed();
                }));
                if (this.buildingInspector) {
                    this.inspectorWidgets.add(abstractWidget);
                }
                this.label("gui.settledlands.graph.min_damage", n2, n5 += 20);
                this.numberBox(node.minDamage, 0, 1000, n2, n5 += 11, n4, 16, n -> {
                    node.minDamage = Math.max(0, Math.min(1000, n));
                });
                this.label("gui.settledlands.graph.check_cooldown", n2, n5 += 20);
                this.numberBox(node.damageCooldown, 0, 3600, n2, n5 += 11, n4, 16, n -> {
                    node.damageCooldown = Math.max(0, Math.min(3600, n));
                });
                n5 += 20;
                n5 = this.incomingIfSection(node, n2, n5, n4);
                this.label("gui.settledlands.graph.action", n2, n5);
                int n14 = this.calcBoxHeight(this.calcTextLines(node.action, n4), 16, 60);
                MultiLineEditBox multiLineEditBox = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 16, 60, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                    node.action = string;
                });
                this.triggerBox = multiLineEditBox;
                int n15 = (n4 - 4) / 2;
                this.button("gui.settledlands.graph.unlink", n2, n5 += n14 + 4, n15, 16, () -> {
                    this.remember();
                    this.graph.disconnectOutputs(node.id);
                    this.changed();
                });
                this.button("gui.settledlands.graph.delete", n2 + n15 + 4, n5, n4 - n15 - 4, 16, () -> {
                    this.remember();
                    this.graph.remove(node.id);
                    this.selected = -1;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
            } else if (node.type == 7) {
                this.label("gui.settledlands.graph.time_mode", n2, n5);
                List<Component> list = List.of(Component.translatable("gui.settledlands.graph.time_dawn"), Component.translatable("gui.settledlands.graph.time_noon"), Component.translatable("gui.settledlands.graph.time_sunset"), Component.translatable("gui.settledlands.graph.time_midnight"), Component.translatable("gui.settledlands.graph.time_custom"));
                AbstractWidget abstractWidget = this.addRenderableWidget(NpcUi.dropdown(n2, n5 += 11, n4, list, Math.max(0, Math.min(4, node.timeMode)), n -> {
                    this.remember();
                    node.timeMode = n;
                    this.changed();
                    this.widgets();
                }));
                if (this.buildingInspector) {
                    this.inspectorWidgets.add(abstractWidget);
                }
                n5 += 20;
                if (node.timeMode == 4) {
                    this.label("gui.settledlands.graph.time_ticks", n2, n5);
                    this.numberBox(node.timeTicks, 0, 23999, n2, n5 += 11, n4, 16, n -> {
                        node.timeTicks = Math.max(0, Math.min(23999, n));
                    });
                    n5 += 20;
                }
                n5 = this.incomingIfSection(node, n2, n5, n4);
                this.label("gui.settledlands.graph.action", n2, n5);
                int n16 = this.calcBoxHeight(this.calcTextLines(node.action, n4), 16, 60);
                MultiLineEditBox multiLineEditBox = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 16, 60, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                    node.action = string;
                });
                this.triggerBox = multiLineEditBox;
                int n17 = (n4 - 4) / 2;
                this.button("gui.settledlands.graph.unlink", n2, n5 += n16 + 4, n17, 16, () -> {
                    this.remember();
                    this.graph.disconnectOutputs(node.id);
                    this.changed();
                });
                this.button("gui.settledlands.graph.delete", n2 + n17 + 4, n5, n4 - n17 - 4, 16, () -> {
                    this.remember();
                    this.graph.remove(node.id);
                    this.selected = -1;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
            } else if (node.type == 8) {
                this.label("gui.settledlands.graph.timer_interval", n2, n5);
                this.numberBox(node.timerInterval, 1, 86400, n2, n5 += 11, n4, 16, n -> {
                    node.timerInterval = Math.max(1, Math.min(86400, n));
                });
                this.label("gui.settledlands.graph.timer_repeat", n2, n5 += 20);
                Button button = this.button(node.timerRepeat ? "gui.settledlands.graph.timer_repeat_on" : "gui.settledlands.graph.timer_repeat_off", n2, n5 += 11, n4, 16, () -> {
                    this.remember();
                    node.timerRepeat = !node.timerRepeat;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
                n5 = this.incomingIfSection(node, n2, n5, n4);
                this.label("gui.settledlands.graph.action", n2, n5);
                int n18 = this.calcBoxHeight(this.calcTextLines(node.action, n4), 16, 60);
                MultiLineEditBox multiLineEditBox = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 16, 60, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                    node.action = string;
                });
                this.triggerBox = multiLineEditBox;
                int n19 = (n4 - 4) / 2;
                this.button("gui.settledlands.graph.unlink", n2, n5 += n18 + 4, n19, 16, () -> {
                    this.remember();
                    this.graph.disconnectOutputs(node.id);
                    this.changed();
                });
                this.button("gui.settledlands.graph.delete", n2 + n19 + 4, n5, n4 - n19 - 4, 16, () -> {
                    this.remember();
                    this.graph.remove(node.id);
                    this.selected = -1;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
            } else if (node.type == 9) {
                BbModel bbModel;
                Object object2;
                Object object3;
                this.label("gui.settledlands.graph.anim_select", n2, n5);
                n5 += 11;
                ArrayList<String> arrayList = new ArrayList<String>();
                if (this.profile != null && this.profile.texture != null && !this.profile.texture.isBlank() && (object3 = BbModelManager.getModel(this.profile.texture)) != null) {
                    arrayList.addAll(((BbModel)object3).getAnimations().keySet());
                }
                if (arrayList.isEmpty() && (object3 = BbModelManager.getModel("provodnik.bbmodel")) != null) {
                    arrayList.addAll(((BbModel)object3).getAnimations().keySet());
                }
                Collections.sort(arrayList);
                if (arrayList.isEmpty()) {
                    arrayList.add("idle");
                    arrayList.add("walk");
                    arrayList.add("talk");
                }
                if (node.animName.isBlank() && !arrayList.isEmpty()) {
                    node.animName = (String)arrayList.get(0);
                }
                ArrayList<Component> animLabels = new ArrayList<Component>();
                int n20 = 0;
                for (int i = 0; i < arrayList.size(); ++i) {
                    object2 = (String)arrayList.get(i);
                    animLabels.add(Component.literal((String)object2));
                    if (!((String)object2).equalsIgnoreCase(node.animName)) continue;
                    n20 = i;
                }
                ArrayList<String> arrayList2 = arrayList;
                object2 = this.addRenderableWidget(NpcUi.dropdown(n2, n5, n4, animLabels, n20, n -> {
                    this.remember();
                    if (n >= 0 && n < arrayList2.size()) {
                        node.animName = (String)arrayList2.get(n);
                    }
                    this.changed();
                    this.widgets();
                }));
                if (this.buildingInspector) {
                    this.inspectorWidgets.add((AbstractWidget)object2);
                }
                this.label("gui.settledlands.graph.anim_repeat", n2, n5 += 20);
                Button button = this.button(node.animLoop ? "gui.settledlands.graph.anim_repeat_on" : "gui.settledlands.graph.anim_repeat_off", n2, n5 += 11, n4, 16, () -> {
                    this.remember();
                    node.animLoop = !node.animLoop;
                    this.changed();
                    this.widgets();
                });
                this.label("gui.settledlands.graph.anim_bone", n2, n5 += 20);
                n5 += 11;
                ArrayList<String> arrayList3 = new ArrayList<String>();
                ArrayList<Component> boneLabels = new ArrayList<Component>();
                arrayList3.add("");
                boneLabels.add(Component.translatable("gui.settledlands.graph.anim_bone_all"));
                arrayList3.add("head");
                boneLabels.add(Component.translatable("gui.settledlands.graph.anim_bone_head"));
                arrayList3.add("right_arm");
                boneLabels.add(Component.translatable("gui.settledlands.graph.anim_bone_right_arm"));
                arrayList3.add("left_arm");
                boneLabels.add(Component.translatable("gui.settledlands.graph.anim_bone_left_arm"));
                arrayList3.add("body");
                boneLabels.add(Component.translatable("gui.settledlands.graph.anim_bone_body"));
                arrayList3.add("legs");
                boneLabels.add(Component.translatable("gui.settledlands.graph.anim_bone_legs"));
                if (this.profile != null && this.profile.texture != null && !this.profile.texture.isBlank() && (bbModel = BbModelManager.getModel(this.profile.texture)) != null) {
                    for (String object4 : bbModel.getPartsByName().keySet()) {
                        if (arrayList3.contains(object4) || object4.length() <= 1) continue;
                        arrayList3.add(object4);
                        boneLabels.add(Component.literal("\ud83e\uddb4 " + object4));
                    }
                }
                int n21 = 0;
                for (int i = 0; i < arrayList3.size(); ++i) {
                    if (!((String)arrayList3.get(i)).equalsIgnoreCase(node.animBone)) continue;
                    n21 = i;
                    break;
                }
                ArrayList<String> boneIds = arrayList3;
                AbstractWidget n26 = this.addRenderableWidget(NpcUi.dropdown(n2, n5, n4, boneLabels, n21, sel -> {
                    this.remember();
                    if (sel >= 0 && sel < boneIds.size()) {
                        node.animBone = (String)boneIds.get(sel);
                    }
                    this.changed();
                    this.widgets();
                }));
                if (this.buildingInspector) {
                    this.inspectorWidgets.add(n26);
                }
                n5 += 20;
                n5 = this.incomingIfSection(node, n2, n5, n4);
                this.label("gui.settledlands.graph.action", n2, n5);
                int multiLineEditBox = this.calcBoxHeight(this.calcTextLines(node.action, n4), 16, 60);
                MultiLineEditBox n27 = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 16, 60, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                    node.action = string;
                });
                this.triggerBox = n27;
                int n6 = (n4 - 4) / 2;
                this.button("gui.settledlands.graph.unlink", n2, n5 += multiLineEditBox + 4, n6, 16, () -> {
                    this.remember();
                    this.graph.disconnectOutputs(node.id);
                    this.changed();
                });
                this.button("gui.settledlands.graph.delete", n2 + n6 + 4, n5, n4 - n6 - 4, 16, () -> {
                    this.remember();
                    this.graph.remove(node.id);
                    this.selected = -1;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
            } else if (node.type == 14) {
                this.label("gui.settledlands.graph.cutscene_select", n2, n5);
                n5 += 11;
                ArrayList<String> arrayList = new ArrayList<String>(CutsceneCameraClient.scenes());
                ArrayList<Component> arrayList4 = new ArrayList<Component>();
                for (String string2 : arrayList) {
                    arrayList4.add(Component.literal(string2));
                }
                int n24 = -1;
                for (int i = 0; i < arrayList.size(); ++i) {
                    if (!((String)arrayList.get(i)).equalsIgnoreCase(node.cutsceneName)) continue;
                    n24 = i;
                    break;
                }
                if (n24 < 0 && !arrayList.isEmpty() && node.cutsceneName.isBlank()) {
                    n24 = 0;
                    node.cutsceneName = (String)arrayList.get(0);
                }
                ArrayList<String> arrayList5 = arrayList;
                AbstractWidget abstractWidget = this.addRenderableWidget(NpcUi.dropdown(n2, n5, n4, arrayList4, Math.max(0, n24), n -> {
                    this.remember();
                    if (n >= 0 && n < arrayList5.size()) {
                        node.cutsceneName = (String)arrayList5.get(n);
                    }
                    this.pendingSceneDelete = null;
                    this.changed();
                    this.widgets();
                }));
                if (this.buildingInspector) {
                    this.inspectorWidgets.add(abstractWidget);
                }
                int n25 = (n4 - 4) / 2;
                boolean bl = node.cutsceneName != null && node.cutsceneName.equals(this.pendingSceneDelete);
                Button delOneButton = this.button(bl ? "gui.settledlands.graph.cutscene_del_confirm" : "gui.settledlands.graph.cutscene_del_one", n2, n5 += 20, n25, 16, () -> {
                    if (node.cutsceneName == null || node.cutsceneName.isBlank()) {
                        return;
                    }
                    if (node.cutsceneName.equals(this.pendingSceneDelete)) {
                        this.pendingSceneDelete = null;
                        PacketDistributor.sendToServer(new CutsceneDeletePayload(node.cutsceneName), new CustomPacketPayload[0]);
                        node.cutsceneName = "";
                        this.changed();
                    } else {
                        this.pendingSceneDelete = node.cutsceneName;
                    }
                    this.widgets();
                });
                if (this.buildingInspector) {
                    this.inspectorWidgets.add(delOneButton);
                }
                Button button = this.button(this.pendingSceneDeleteAll ? "gui.settledlands.graph.cutscene_del_confirm" : "gui.settledlands.graph.cutscene_del_all", n2 + n25 + 4, n5, n4 - n25 - 4, 16, () -> {
                    if (this.pendingSceneDeleteAll) {
                        this.pendingSceneDeleteAll = false;
                        PacketDistributor.sendToServer(new CutsceneDeletePayload("*"), new CustomPacketPayload[0]);
                        node.cutsceneName = "";
                        this.changed();
                    } else {
                        this.pendingSceneDeleteAll = true;
                    }
                    this.widgets();
                });
                if (this.buildingInspector) {
                    this.inspectorWidgets.add(button);
                }
                Button studioButton = this.button("gui.settledlands.graph.cutscene_studio", n2, n5 += 20, n4, 16, () -> PacketDistributor.sendToServer(new CutsceneStudioRequestPayload(), new CustomPacketPayload[0]));
                if (this.buildingInspector) {
                    this.inspectorWidgets.add(studioButton);
                }
                n5 += 20;
                n5 = this.incomingIfSection(node, n2, n5, n4);
                this.label("gui.settledlands.graph.action", n2, n5);
                int n7 = this.calcBoxHeight(this.calcTextLines(node.action, n4), 16, 60);
                MultiLineEditBox multiLineEditBox = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 16, 60, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                    node.action = string;
                });
                this.triggerBox = multiLineEditBox;
                int n8 = (n4 - 4) / 2;
                this.button("gui.settledlands.graph.unlink", n2, n5 += n7 + 4, n8, 16, () -> {
                    this.remember();
                    this.graph.disconnectOutputs(node.id);
                    this.changed();
                });
                this.button("gui.settledlands.graph.delete", n2 + n8 + 4, n5, n4 - n8 - 4, 16, () -> {
                    this.remember();
                    this.graph.remove(node.id);
                    this.selected = -1;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
            } else if (node.type == 15) {
                this.label("gui.settledlands.graph.radius_target", n2, n5);
                List<Component> list = List.of(Component.translatable("gui.settledlands.graph.target_player"), Component.translatable("gui.settledlands.graph.target_npc"), Component.translatable("gui.settledlands.graph.target_monster"), Component.translatable("gui.settledlands.graph.target_any"), Component.translatable("gui.settledlands.graph.target_passive"));
                AbstractWidget abstractWidget = this.addRenderableWidget(NpcUi.dropdown(n2, n5 += 11, n4, list, Math.max(0, Math.min(4, node.radiusTarget)), n -> {
                    this.remember();
                    node.radiusTarget = n;
                    this.changed();
                }));
                if (this.buildingInspector) {
                    this.inspectorWidgets.add(abstractWidget);
                }
                this.label("gui.settledlands.graph.radius", n2, n5 += 20);
                this.numberBox(node.radius, 1, 96, n2, n5 += 11, n4, 16, n -> {
                    node.radius = Math.max(1, Math.min(96, n));
                });
                n5 += 20;
            } else if (node.type == 10) {
                this.label("gui.settledlands.graph.quest_title", n2, n5);
                int n28 = this.calcBoxHeight(this.calcTextLines(node.text, n4), 16, 50);
                this.multiLineTextBox(node.text, 240, n2, n5 += 11, n4, 16, 50, string -> {
                    node.text = string;
                });
                this.label("gui.settledlands.graph.min_relation", n2, n5 += n28 + 4);
                this.numberBox(node.minRelation, 0, 100, n2, n5 += 11, n4, 16, n -> {
                    node.minRelation = Math.max(0, Math.min(100, n));
                });
                n5 += 20;
                n5 = this.incomingIfSection(node, n2, n5, n4);
                this.label("gui.settledlands.graph.action", n2, n5);
                int n29 = this.calcBoxHeight(this.calcTextLines(node.action, n4), 16, 60);
                MultiLineEditBox multiLineEditBox = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 16, 60, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                    node.action = string;
                });
                this.triggerBox = multiLineEditBox;
                this.label("gui.settledlands.graph.quest_hint", n2, n5 += n29 + 4);
                int n30 = (n4 - 4) / 2;
                this.button("gui.settledlands.graph.unlink", n2, n5 += 14, n30, 16, () -> {
                    this.remember();
                    this.graph.disconnectOutputs(node.id);
                    this.changed();
                });
                this.button("gui.settledlands.graph.delete", n2 + n30 + 4, n5, n4 - n30 - 4, 16, () -> {
                    this.remember();
                    this.graph.remove(node.id);
                    this.selected = -1;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
            } else if (node.type == 11) {
                this.label("gui.settledlands.graph.move_coords", n2, n5);
                this.textBox(node.moveCoords, 64, n2, n5 += 11, n4, 16, string -> {
                    node.moveCoords = string;
                });
                this.label("gui.settledlands.graph.move_speed", n2, n5 += 20);
                this.doubleBox(node.moveSpeed, 0.1, 5.0, n2, n5 += 11, n4, 16, d -> {
                    node.moveSpeed = Math.max(0.1, Math.min(5.0, d));
                });
                this.label("gui.settledlands.graph.move_escort", n2, n5 += 20);
                this.button(node.moveEscort ? "gui.settledlands.graph.move_escort_on" : "gui.settledlands.graph.move_escort_off", n2, n5 += 11, n4, 16, () -> {
                    this.remember();
                    node.moveEscort = !node.moveEscort;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
                n5 = this.incomingIfSection(node, n2, n5, n4);
                this.label("gui.settledlands.graph.action", n2, n5);
                int n31 = this.calcBoxHeight(this.calcTextLines(node.action, n4), 16, 60);
                MultiLineEditBox multiLineEditBox = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 16, 60, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                    node.action = string;
                });
                this.triggerBox = multiLineEditBox;
                this.label("gui.settledlands.graph.move_hint", n2, n5 += n31 + 4);
                int n32 = (n4 - 4) / 2;
                this.button("gui.settledlands.graph.unlink", n2, n5 += 14, n32, 16, () -> {
                    this.remember();
                    this.graph.disconnectOutputs(node.id);
                    this.changed();
                });
                this.button("gui.settledlands.graph.delete", n2 + n32 + 4, n5, n4 - n32 - 4, 16, () -> {
                    this.remember();
                    this.graph.remove(node.id);
                    this.selected = -1;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
            } else if (node.type == 12) {
                this.label("gui.settledlands.graph.mobility_group", n2, n5);
                n5 += 11;
                if (!this.mobilityGroups.isEmpty()) {
                    ArrayList<Component> arrayList = new ArrayList<Component>();
                    arrayList.add(Component.translatable("gui.settledlands.graph.no_group"));
                    for (NpcConfigScreen.MobilityGroupOption mobilityGroupOption : this.mobilityGroups) {
                        arrayList.add(Component.literal(mobilityGroupOption.name().isEmpty() ? mobilityGroupOption.id() : mobilityGroupOption.name()));
                    }
                    int n33 = 0;
                    for (int i = 0; i < this.mobilityGroups.size(); ++i) {
                        if (!this.mobilityGroups.get(i).id().equals(node.mobilityGroupId)) continue;
                        n33 = i + 1;
                        break;
                    }
                    NpcUi.NpcDropdown npcDropdown = new NpcUi.NpcDropdown(n2, n5, n4, arrayList, n33, n -> {
                        this.remember();
                        if (n <= 0) {
                            node.mobilityGroupId = "";
                            node.mobilityGroupName = "";
                        } else {
                            NpcConfigScreen.MobilityGroupOption mobilityGroupOption = this.mobilityGroups.get(n - 1);
                            node.mobilityGroupId = mobilityGroupOption.id();
                            node.mobilityGroupName = mobilityGroupOption.name();
                        }
                        this.changed();
                        this.widgets();
                    });
                    this.addRenderableWidget(npcDropdown);
                    n5 += 22;
                } else {
                    this.textBox(node.mobilityGroupName.isEmpty() ? node.mobilityGroupId : node.mobilityGroupName, 32, n2, n5, n4, 16, string -> {
                        node.mobilityGroupName = string;
                        if (node.mobilityGroupId.isEmpty()) {
                            node.mobilityGroupId = string;
                        }
                    });
                    n5 += 20;
                }
                n5 = this.incomingIfSection(node, n2, n5, n4);
                this.label("gui.settledlands.graph.action", n2, n5);
                int n34 = this.calcBoxHeight(this.calcTextLines(node.action, n4), 16, 60);
                MultiLineEditBox multiLineEditBox = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 16, 60, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                    node.action = string;
                });
                this.triggerBox = multiLineEditBox;
                this.label("gui.settledlands.graph.mobility_hint", n2, n5 += n34 + 4);
                int n35 = (n4 - 4) / 2;
                this.button("gui.settledlands.graph.unlink", n2, n5 += 24, n35, 16, () -> {
                    this.remember();
                    this.graph.disconnectOutputs(node.id);
                    this.changed();
                });
                this.button("gui.settledlands.graph.delete", n2 + n35 + 4, n5, n4 - n35 - 4, 16, () -> {
                    this.remember();
                    this.graph.remove(node.id);
                    this.selected = -1;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
            } else if (node.type == 13) {
                this.label("gui.settledlands.graph.random_range", n2, n5);
                int n36 = (n4 - 6) / 2;
                this.numberBox(node.randomMin, 1, 64, n2, n5 += 11, n36, 16, n -> {
                    this.remember();
                    node.randomMin = Math.max(1, Math.min(node.randomMax, n));
                    this.changed();
                });
                this.numberBox(node.randomMax, 1, 64, n2 + n36 + 6, n5, n36, 16, n -> {
                    this.remember();
                    node.randomMax = Math.max(node.randomMin, Math.min(64, n));
                    while (node.randomBranches.size() < node.randomMax) {
                        node.randomBranches.add(-1);
                    }
                    while (node.randomBranches.size() > node.randomMax) {
                        node.randomBranches.remove(node.randomBranches.size() - 1);
                    }
                    this.changed();
                    this.widgets();
                });
                this.label("gui.settledlands.graph.random_outputs", n2, n5 += 20);
                this.label("1 .. " + node.randomMax + " (" + node.randomMax + " " + this.tr("gui.settledlands.graph.outputs") + ")", n2, n5 += 11);
                n5 += 14;
                n5 = this.incomingIfSection(node, n2, n5, n4);
                this.label("gui.settledlands.graph.action", n2, n5);
                int n37 = this.calcBoxHeight(this.calcTextLines(node.action, n4), 16, 60);
                MultiLineEditBox multiLineEditBox = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 16, 60, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                    node.action = string;
                });
                this.triggerBox = multiLineEditBox;
                int n38 = (n4 - 4) / 2;
                this.button("gui.settledlands.graph.unlink", n2, n5 += n37 + 4, n38, 16, () -> {
                    this.remember();
                    this.graph.disconnectOutputs(node.id);
                    this.changed();
                });
                this.button("gui.settledlands.graph.delete", n2 + n38 + 4, n5, n4 - n38 - 4, 16, () -> {
                    this.remember();
                    this.graph.remove(node.id);
                    this.selected = -1;
                    this.changed();
                    this.widgets();
                });
                n5 += 20;
            } else {
                int n39;
                this.label("gui.settledlands.graph.text", n2, n5);
                n5 += 11;
                if (node.type == 0) {
                    n39 = Math.min(100, Math.max(50, this.inspectorH - 140));
                    int n40 = this.calcBoxHeight(this.calcTextLines(node.text, n4), 20, n39);
                    this.multiLineTextBox(node.text, 480, n2, n5, n4, 20, n39, string -> {
                        node.text = string;
                    });
                    n5 += n40 + 4;
                } else {
                    n39 = this.calcBoxHeight(this.calcTextLines(node.text, n4), 16, 50);
                    this.multiLineTextBox(node.text, 240, n2, n5, n4, 16, 50, string -> {
                        node.text = string;
                    });
                    n5 += n39 + 4;
                }
                if (node.type == 0) {
                    n39 = 0;
                    for (NpcDialogueGraph.Node node3 : this.graph.nodes.values()) {
                        if (node3.type != 14 || node3.next != node.id) continue;
                        n39 = 1;
                        break;
                    }
                    if (n39 != 0) {
                        this.button(node.cutsceneLine ? "gui.settledlands.graph.cutscene_line_on" : "gui.settledlands.graph.cutscene_line_off", n2, n5, n4, 16, () -> {
                            this.remember();
                            node.cutsceneLine = !node.cutsceneLine;
                            this.changed();
                            this.widgets();
                        });
                        n5 += 20;
                    }
                }
                if (node.special == 0) {
                    this.label("gui.settledlands.graph.action", n2, n5);
                    n39 = this.calcBoxHeight(this.calcTextLines(node.action, n4), 16, 60);
                    MultiLineEditBox multiLineEditBox = this.multiLineTextBox(node.action, 2048, n2, n5 += 11, n4, 16, 60, Component.translatable("gui.settledlands.graph.trigger_hint"), string -> {
                        node.action = string;
                    });
                    this.triggerBox = multiLineEditBox;
                    n5 += n39 + 4;
                }
                if (node.special == 0) {
                    if (node.type == 0) {
                        this.button("gui.settledlands.graph.entry", n2, n5, n4, 16, () -> {
                            this.remember();
                            this.graph.entry = node.id;
                            this.changed();
                        });
                        n5 += 20;
                        for (n39 = 0; n39 < node.variants.size(); ++n39) {
                            NpcProfile.Variant variant = node.variants.get(n39);
                            this.label("gui.settledlands.graph.variant", n2, n5);
                            this.numberBox(variant.minRelation, 0, 100, n2, n5 += 11, 36, 16, n -> {
                                variant.minRelation = n;
                            });
                            int n41 = n4 - 40;
                            int n42 = this.calcBoxHeight(this.calcTextLines(variant.text, n41), 16, 60);
                            this.multiLineTextBox(variant.text, 480, n2 + 40, n5, n41, 16, 60, string -> {
                                variant.text = string;
                            });
                            n5 += n42 + 4;
                        }
                        if (node.variants.size() < 5 || !node.variants.isEmpty()) {
                            n39 = (n4 - 4) / 2;
                            if (node.variants.size() < 5) {
                                this.button("gui.settledlands.graph.add_variant", n2, n5, node.variants.isEmpty() ? n4 : n39, 16, () -> {
                                    this.remember();
                                    node.variants.add(new NpcProfile.Variant(0, ""));
                                    this.changed();
                                    this.widgets();
                                });
                            }
                            if (!node.variants.isEmpty()) {
                                this.button("gui.settledlands.graph.del_variant", n2 + n39 + 4, n5, n4 - n39 - 4, 16, () -> {
                                    this.remember();
                                    node.variants.remove(node.variants.size() - 1);
                                    this.changed();
                                    this.widgets();
                                });
                            }
                            n5 += 20;
                        }
                    } else {
                        this.label("gui.settledlands.graph.relation", n2, n5);
                        this.numberBox(node.relation, -100, 100, n2, n5 += 11, n4, 16, n -> {
                            node.relation = n;
                        });
                        n39 = (n4 - 6) / 2;
                        this.label("gui.settledlands.graph.min_relation", n2, n5 += 20);
                        this.label("gui.settledlands.graph.max_relation", n2 + n39 + 6, n5);
                        this.numberBox(node.minRelation, 0, 100, n2, n5 += 11, n39, 16, n -> {
                            node.minRelation = n;
                        });
                        this.numberBox(node.maxRelation, 0, 100, n2 + n39 + 6, n5, n39, 16, n -> {
                            node.maxRelation = n;
                        });
                        this.label("gui.settledlands.graph.points", n2, n5 += 20);
                        this.textBox(node.pointsName, 32, n2, n5 += 11, n4, 16, string -> {
                            node.pointsName = string;
                        });
                        this.label("gui.settledlands.graph.min_points", n2, n5 += 20);
                        this.label("gui.settledlands.graph.max_points", n2 + n39 + 6, n5);
                        this.numberBox(node.minPoints, 0, 1000000, n2, n5 += 11, n39, 16, n -> {
                            node.minPoints = n;
                        });
                        this.numberBox(node.maxPoints, 0, 1000000, n2 + n39 + 6, n5, n39, 16, n -> {
                            node.maxPoints = n;
                        });
                        this.button(node.pointsShared ? "gui.settledlands.graph.shared_on" : "gui.settledlands.graph.shared_off", n2, n5 += 20, n4, 16, () -> {
                            this.remember();
                            node.pointsShared = !node.pointsShared;
                            this.changed();
                            this.widgets();
                        });
                        n5 += 20;
                    }
                    n5 = this.incomingIfSection(node, n2, n5, n4);
                    if (node.builtinTopic >= 0) {
                        this.label("gui.settledlands.graph.builtin", n2, n5);
                        n5 += 14;
                    }
                    n39 = (n4 - 4) / 2;
                    this.button("gui.settledlands.graph.unlink", n2, n5, n39, 16, () -> {
                        this.remember();
                        this.graph.disconnectOutputs(node.id);
                        this.changed();
                    });
                    this.button("gui.settledlands.graph.delete", n2 + n39 + 4, n5, n4 - n39 - 4, 16, () -> {
                        this.remember();
                        this.graph.remove(node.id);
                        this.selected = -1;
                        this.changed();
                        this.widgets();
                    });
                    n5 += 20;
                } else {
                    this.label("gui.settledlands.graph.escort_note", n2, n5);
                    n5 += 16;
                }
            }
        }
        this.sidebarHeight = n5 + this.sidebarScroll - (this.inspectorY + 24);
        for (AbstractWidget abstractWidget : this.inspectorWidgets) {
            abstractWidget.visible = abstractWidget.getY() >= this.inspectorY + 22 && abstractWidget.getY() + abstractWidget.getHeight() <= this.inspectorY + this.inspectorH - 4;
        }
        this.buildingInspector = false;
        this.suppress = false;
    }

    private int calcTextLines(String string, int n) {
        String string2 = string == null || string.isEmpty() ? " " : string;
        return Math.max(1, this.font.split(Component.literal(string2), Math.max(20, n - 14)).size());
    }

    private int calcBoxHeight(int n, int n2, int n3) {
        int n4 = 10 + n * 9;
        return Math.min(n3, Math.max(n2, n4));
    }

    private MultiLineEditBox multiLineTextBox(String string2, int n, int n2, int n3, int n4, int n5, int n6, Component component, Consumer<String> consumer) {
        int n7 = this.calcTextLines(string2, n4);
        int n8 = this.calcBoxHeight(n7, n5, n6);
        MultiLineEditBox multiLineEditBox = new MultiLineEditBox(this.font, n2, n3, Math.max(30, n4), n8, component == null ? Component.empty() : component, Component.empty());
        multiLineEditBox.setValue(string2 == null ? "" : string2);
        boolean[] blArray = new boolean[]{false};
        multiLineEditBox.setValueListener(string -> {
            if (blArray[0]) {
                return;
            }
            if (string.length() > n) {
                blArray[0] = true;
                string = string.substring(0, n);
                multiLineEditBox.setValue((String)string);
                blArray[0] = false;
            }
            String textNow = string;
            this.propertyChange(() -> consumer.accept(textNow));
            int linesNow = this.calcTextLines(textNow, n4);
            int heightNow = this.calcBoxHeight(linesNow, n5, n6);
            int prevHeight = multiLineEditBox.getHeight();
            if (heightNow != prevHeight) {
                int delta = heightNow - prevHeight;
                multiLineEditBox.setHeight(heightNow);
                for (Label object : this.labels) {
                    if (object.y <= multiLineEditBox.getY()) continue;
                    object.y += delta;
                }
                for (AbstractWidget abstractWidget : this.inspectorWidgets) {
                    if (abstractWidget == multiLineEditBox || abstractWidget.getY() < multiLineEditBox.getY() + prevHeight - 2) continue;
                    abstractWidget.setY(abstractWidget.getY() + delta);
                }
                this.sidebarHeight += delta;
                for (AbstractWidget abstractWidget : this.inspectorWidgets) {
                    abstractWidget.visible = abstractWidget.getY() >= this.inspectorY + 22 && abstractWidget.getY() + abstractWidget.getHeight() <= this.inspectorY + this.inspectorH - 4;
                }
            }
        });
        this.addRenderableWidget(multiLineEditBox);
        this.inspectorWidgets.add(multiLineEditBox);
        return multiLineEditBox;
    }

    private MultiLineEditBox multiLineTextBox(String string, int n, int n2, int n3, int n4, int n5, int n6, Consumer<String> consumer) {
        return this.multiLineTextBox(string, n, n2, n3, n4, n5, n6, Component.empty(), consumer);
    }

    private void label(String string, int n, int n2) {
        this.labels.add(new Label(string, n, n2));
    }

    private void label(String string, int n) {
        this.label(string, this.inspectorX + 8, n);
    }

    private EditBox textBox(String string2, int n, int n2, int n3, int n4, int n5, Consumer<String> consumer) {
        EditBox editBox = new EditBox(this.font, n2, n3, Math.max(30, n4), n5, Component.empty());
        editBox.setMaxLength(n);
        editBox.setValue(string2 == null ? "" : string2);
        editBox.setResponder(string -> this.propertyChange(() -> consumer.accept((String)string)));
        this.addRenderableWidget(editBox);
        this.inspectorWidgets.add(editBox);
        return editBox;
    }

    private EditBox textBox(String string, int n, int n2, int n3, Consumer<String> consumer) {
        return this.textBox(string, n, this.inspectorX + 8, n2, n3, 20, consumer);
    }

    private void numberBox(int n, int n2, int n3, int n4, int n5, int n6, int n7, Consumer<Integer> consumer) {
        EditBox editBox = this.textBox(Integer.toString(n), 10, n4, n5, n6, n7, string -> {
            try {
                int parsed = Integer.parseInt(string);
                if (parsed >= n2 && parsed <= n3) {
                    consumer.accept(parsed);
                }
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        });
        editBox.setFilter(string -> string.isEmpty() || string.equals("-") || string.matches("-?[0-9]{0,9}"));
    }

    private void numberBox(int n, int n2, int n3, int n4, int n5, Consumer<Integer> consumer) {
        this.numberBox(n, n2, n3, this.inspectorX + 8, n4, n5, 20, consumer);
    }

    private void doubleBox(double d, double d2, double d3, int n, int n2, int n3, int n4, Consumer<Double> consumer) {
        EditBox editBox = this.textBox(String.format(Locale.ROOT, "%.1f", d), 6, n, n2, n3, n4, string -> {
            try {
                double parsedD = Double.parseDouble(string);
                if (parsedD >= d2 && parsedD <= d3) {
                    consumer.accept(parsedD);
                }
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        });
        editBox.setFilter(string -> string.isEmpty() || string.matches("[0-9]*\\.?[0-9]*"));
    }

    private int incomingIfSection(NpcDialogueGraph.Node node, int n, int n2, int n3) {
        this.label("gui.settledlands.graph.incoming_if_condition", n, n2);
        n2 += 11;
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        for (NpcDialogueGraph.Node node2 : this.graph.nodes.values()) {
            if (node2.type != 3 || node2.next != node.id && node2.falseNext != node.id) continue;
            arrayList.add(node2.id);
        }
        if (!arrayList.isEmpty()) {
            Iterator<Integer> iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                int n4 = iterator.next();
                NpcDialogueGraph.Node node3 = this.graph.get(n4);
                boolean bl = node3 != null && node3.next == node.id;
                String string = bl ? "True \u2714" : "False \u2716";
                String string2 = node3 != null ? "#" + node3.id + " (" + string + ")" : "#" + n4;
                this.label(Component.translatable("gui.settledlands.graph.var_input_linked", n4).getString() + " " + string2, n, n2);
                n2 += 12;
            }
            this.button("gui.settledlands.graph.unlink_if", n, n2, n3, 16, () -> {
                this.remember();
                for (NpcDialogueGraph.Node node2 : this.graph.nodes.values()) {
                    if (node2.type != 3) continue;
                    if (node2.next == node.id) {
                        node2.next = -1;
                    }
                    if (node2.falseNext != node.id) continue;
                    node2.falseNext = -1;
                }
                this.changed();
                this.widgets();
            });
            n2 += 20;
        } else {
            this.label("gui.settledlands.graph.incoming_if_none", n, n2);
            n2 += 12;
        }
        return n2;
    }

    private boolean isInsideInspector(double d, double d2) {
        return this.selected >= 0 && d >= (double)this.inspectorX && d <= (double)(this.inspectorX + this.inspectorW) && d2 >= (double)this.inspectorY && d2 <= (double)(this.inspectorY + this.inspectorH);
    }

    private void add(int n) {
        this.addAt(n, this.canvas.worldX((double)(this.canvas.left + this.canvas.right) / 2.0), this.canvas.worldY((double)(this.canvas.top + this.canvas.bottom) / 2.0));
    }

    private NpcDialogueGraph.Node addAt(int n, double d, double d2) {
        if (!this.importError.isEmpty()) {
            return null;
        }
        if (this.graph.nodes.size() >= 2048) {
            this.status = this.tr("gui.settledlands.graph.limit");
            return null;
        }
        this.remember();
        NpcDialogueGraph.Node node = this.graph.add(n, 0, 0);
        if (node == null) {
            this.status = this.tr("gui.settledlands.graph.limit");
            return null;
        }
        this.canvas.move(node, d, d2);
        if (n == 0) {
            node.text = this.tr("gui.settledlands.graph.new_line");
        } else if (n == 1) {
            node.text = this.tr("gui.settledlands.graph.new_button");
        } else if (n == 13) {
            node.text = "";
            node.action = "";
            node.randomMin = 1;
            node.randomMax = 2;
            node.randomBranches.clear();
            node.randomBranches.add(-1);
            node.randomBranches.add(-1);
        } else {
            node.text = "";
            node.action = "";
        }
        this.selected = node.id;
        this.sidebarScroll = 0;
        this.changed();
        this.widgets();
        return node;
    }

    private NpcDialogueGraph.Node duplicateNode(NpcDialogueGraph.Node node, double d, double d2) {
        if (node == null || !this.importError.isEmpty()) {
            return null;
        }
        if (this.graph.nodes.size() >= 2048) {
            this.status = this.tr("gui.settledlands.graph.limit");
            return null;
        }
        this.remember();
        NpcDialogueGraph.Node node2 = this.graph.add(node.type, 0, 0);
        if (node2 == null) {
            this.status = this.tr("gui.settledlands.graph.limit");
            return null;
        }
        this.canvas.move(node2, d, d2);
        node2.text = node.text;
        node2.action = node.action;
        node2.special = node.special;
        node2.relation = node.relation;
        node2.minRelation = node.minRelation;
        node2.maxRelation = node.maxRelation;
        node2.pointsName = node.pointsName;
        node2.minPoints = node.minPoints;
        node2.maxPoints = node.maxPoints;
        node2.pointsShared = node.pointsShared;
        node2.varLocal = node.varLocal;
        node2.builtinTopic = node.builtinTopic;
        node2.varValue = node.varValue;
        node2.varCompare = node.varCompare;
        node2.varOp = node.varOp;
        node2.varInputNode = node.varInputNode;
        node2.checkTarget = node.checkTarget;
        node2.checkRadius = node.checkRadius;
        node2.radius = node.radius;
        node2.radiusTarget = node.radiusTarget;
        node2.checkCooldown = node.checkCooldown;
        node2.variants.clear();
        for (NpcProfile.Variant variant : node.variants) {
            node2.variants.add(new NpcProfile.Variant(variant.minRelation, variant.text));
        }
        this.selected = node2.id;
        this.sidebarScroll = 0;
        this.changed();
        this.widgets();
        this.status = this.tr("gui.settledlands.graph.copied");
        return node2;
    }

    private void history(boolean bl) {
        Deque<NpcDialogueGraph> deque;
        Deque<NpcDialogueGraph> deque2 = bl ? this.redo : this.undo;
        Deque<NpcDialogueGraph> deque3 = deque = bl ? this.undo : this.redo;
        if (deque2.isEmpty()) {
            return;
        }
        deque.addLast(this.graph.copy());
        this.graphs[this.tab] = this.graph = deque2.removeLast();
        this.summaries.clear();
        this.changed();
        this.widgets();
    }

    private void syncCamera() {
        this.graph.hasCamera = true;
        this.graph.panX = this.canvas.panX;
        this.graph.panY = this.canvas.panY;
        this.graph.zoom = this.canvas.zoom;
    }

    private boolean save() {
        this.syncCamera();
        if (!this.importError.isEmpty()) {
            this.status = this.tr("gui.settledlands.graph.import_failed");
            return false;
        }
        this.graphs[this.tab] = this.graph;
        NpcDialogueGraph npcDialogueGraph = this.graphs[0];
        if (npcDialogueGraph == null) {
            npcDialogueGraph = this.graph;
        }
        String string = npcDialogueGraph.error();
        CompoundTag compoundTag = new CompoundTag();
        compoundTag.putBoolean("GraphOnly", true);
        compoundTag.put("DialogueGraph", npcDialogueGraph.save());
        if (this.graphs[1] != null) {
            compoundTag.put("WalkGraph", this.graphs[1].save());
        }
        if (this.graphs[2] != null) {
            compoundTag.put("AnimGraph", this.graphs[2].save());
        }
        if (NpcDialogueGraph.encodedSize(compoundTag) > 1000000) {
            this.status = this.tr("gui.settledlands.graph.too_large");
            return false;
        }
        this.sentMain = true;
        this.sentWalk = this.graphs[1] != null;
        this.sentAnim = this.graphs[2] != null;
        this.lastSent = this.revision;
        NpcNet.sendToServer(new NpcNet.CfgSave(this.entityId, compoundTag));
        this.status = this.tr("gui.settledlands.graph.sending") + (String)(string.isEmpty() ? "" : " (" + string + ")");
        return true;
    }

    public void applySnapshot(NpcProfile npcProfile) {
        NpcProfile npcProfile2 = npcProfile.copy();
        if (!this.sentMain && this.graphs[0] != null) {
            npcProfile2.dialogueGraph = this.graphs[0].copy();
        }
        if (!this.sentWalk) {
            NpcDialogueGraph npcDialogueGraph = npcProfile2.walkGraph = this.graphs[1] == null ? null : this.graphs[1].copy();
        }
        if (!this.sentAnim) {
            npcProfile2.animGraph = this.graphs[2] == null ? null : this.graphs[2].copy();
        }
        this.profile = npcProfile2;
        Screen screen = this.parent;
        if (screen instanceof NpcConfigScreen) {
            NpcConfigScreen npcConfigScreen = (NpcConfigScreen)screen;
            npcConfigScreen.acceptGraphProfile(npcProfile2);
        }
        if (this.lastSent >= 0 && this.revision == this.lastSent) {
            if (this.sentMain && npcProfile.dialogueGraph != null) {
                this.graphs[0] = npcProfile.dialogueGraph.copy();
                if (this.tab == 0) {
                    this.graph = this.graphs[0];
                }
            }
            if (this.sentWalk) {
                NpcDialogueGraph npcDialogueGraph = this.graphs[1] = npcProfile.walkGraph == null ? null : npcProfile.walkGraph.copy();
                if (this.tab == 1 && this.graphs[1] != null) {
                    this.graph = this.graphs[1];
                }
            }
            if (this.sentAnim) {
                NpcDialogueGraph npcDialogueGraph = this.graphs[2] = npcProfile.animGraph == null ? null : npcProfile.animGraph.copy();
                if (this.tab == 2 && this.graphs[2] != null) {
                    this.graph = this.graphs[2];
                }
            }
            this.dirty = false;
            this.summaries.clear();
            this.status = this.tr(this.sentMain ? "gui.settledlands.graph.saved" : "gui.settledlands.graph.saved_partial");
            this.widgets();
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        long l;
        if (this.openDropdown != null) {
            this.openDropdown.closePopup();
            this.openDropdown = null;
        }
        this.syncCamera();
        Screen screen = this.parent;
        if (screen instanceof NpcConfigScreen) {
            NpcConfigScreen npcConfigScreen = (NpcConfigScreen)screen;
            this.graphs[this.tab] = this.graph;
            this.profile.dialogueGraph = this.graphs[0].copy();
            this.profile.walkGraph = this.graphs[1] == null ? null : this.graphs[1].copy();
            this.profile.animGraph = this.graphs[2] == null ? null : this.graphs[2].copy();
            npcConfigScreen.acceptGraphProfile(this.profile);
        }
        if (this.dirty && !this.save() && (l = System.currentTimeMillis()) - this.closeWarnAt > 8000L) {
            this.closeWarnAt = l;
            this.status = this.status + " " + this.tr("gui.settledlands.graph.exit_unsaved");
            return;
        }
        Minecraft.getInstance().setScreen(this.parent);
    }

    @Override
    public boolean mouseClicked(double d, double d2, int n) {
        int n2;
        if (this.openDropdown != null) {
            NpcUi.NpcDropdown npcDropdown = this.openDropdown;
            boolean bl = npcDropdown.popupClicked(d, d2);
            if (!npcDropdown.popupOpen()) {
                this.openDropdown = null;
            }
            return true;
        }
        if (this.contextMenu.open) {
            if (n == 0 && this.contextMenu.isScrollbar(d, d2)) {
                this.contextMenu.scrollbarDrag(d2);
                return true;
            }
            int n3 = this.contextMenu.rowAt(d, d2);
            boolean bl = this.contextMenu.contains(d, d2);
            double d3 = this.contextMenu.worldX;
            double d4 = this.contextMenu.worldY;
            n2 = this.contextMenu.pendingWireFrom;
            int n4 = this.contextMenu.pendingWirePort;
            int n5 = this.contextMenu.targetNodeId;
            this.contextMenu.close();
            if (n == 0 && n3 >= 0) {
                if (n5 >= 0) {
                    NpcDialogueGraph.Node node = this.graph.get(n5);
                    if (node != null) {
                        if (n3 == 0) {
                            if (this.multiSelected.contains(n5) && this.multiSelected.size() > 1) {
                                LinkedHashSet<Integer> linkedHashSet = new LinkedHashSet<Integer>();
                                double d5 = d3 + 24.0 - (double)node.x;
                                double d6 = d4 + 24.0 - (double)node.y;
                                for (int n6 : new ArrayList<Integer>(this.multiSelected)) {
                                    NpcDialogueGraph.Node node2;
                                    NpcDialogueGraph.Node node3 = this.graph.get(n6);
                                    if (node3 == null || (node2 = this.duplicateNode(node3, (double)node3.x + d5, (double)node3.y + d6)) == null) continue;
                                    linkedHashSet.add(node2.id);
                                }
                                this.multiSelected.clear();
                                this.multiSelected.addAll(linkedHashSet);
                                if (!linkedHashSet.isEmpty()) {
                                    this.selected = (Integer)linkedHashSet.iterator().next();
                                }
                                this.widgets();
                                return true;
                            }
                            this.duplicateNode(node, d3 + 24.0, d4 + 24.0);
                            return true;
                        }
                        if (n3 == 1) {
                            this.remember();
                            if (this.multiSelected.contains(n5) && this.multiSelected.size() > 1) {
                                for (int n7 : new ArrayList<Integer>(this.multiSelected)) {
                                    this.graph.remove(n7);
                                }
                                this.multiSelected.clear();
                                this.selected = -1;
                                this.changed();
                                this.widgets();
                                this.status = this.tr("gui.settledlands.graph.deleted");
                                return true;
                            }
                            if (this.graph.remove(n5)) {
                                this.multiSelected.remove(n5);
                                if (this.selected == n5) {
                                    this.selected = this.multiSelected.isEmpty() ? -1 : this.multiSelected.iterator().next();
                                }
                                this.changed();
                                this.widgets();
                                this.status = this.tr("gui.settledlands.graph.deleted");
                            }
                            return true;
                        }
                    }
                } else {
                    int n8 = switch (n3) {
                        case 0 -> 0;
                        case 1 -> 1;
                        case 2 -> 2;
                        case 3 -> 3;
                        case 4 -> 4;
                        case 5 -> 5;
                        case 6 -> 6;
                        case 7 -> 7;
                        case 8 -> 8;
                        case 9 -> 9;
                        case 10 -> 10;
                        case 11 -> 11;
                        case 12 -> 12;
                        case 13 -> 13;
                        case 14 -> 14;
                        case 15 -> 15;
                        default -> 0;
                    };
                    NpcDialogueGraph.Node node = this.addAt(n8, d3, d4);
                    if (node != null && n2 >= 0 && this.graph.connect(n2, node.id, n4)) {
                        this.changed();
                        this.status = this.tr("gui.settledlands.graph.connected");
                    }
                    return true;
                }
            }
            if (n == 0 || bl) {
                return true;
            }
        }
        if (CommandTabCompleter.mouseClicked(this, d, d2, n)) {
            return true;
        }
        if (!this.canvas.contains(d, d2)) {
            return super.mouseClicked(d, d2, n);
        }
        if (n == 0 && this.isShiftDownSafe()) {
            for (NpcDialogueGraph.Node node : this.graph.nodes.values()) {
                int n9;
                int n10 = n9 = node.next >= 0 && this.graph.get(node.next) != null && this.graph.get((int)node.next).type == 3 && node.type == 4 ? 1 : 0;
                if (node.next >= 0 && this.hitCable(node, 0, this.graph.get(node.next), n9, d, d2)) {
                    this.remember();
                    this.graph.disconnect(node.id, node.next);
                    this.changed();
                    return true;
                }
                if (node.type == 3 && node.falseNext >= 0 && this.hitCable(node, 1, this.graph.get(node.falseNext), 0, d, d2)) {
                    this.remember();
                    node.falseNext = -1;
                    this.changed();
                    return true;
                }
                if (node.type == 3 && node.varInputNode >= 0 && this.hitCable(this.graph.get(node.varInputNode), 0, node, 1, d, d2)) {
                    this.remember();
                    node.varInputNode = -1;
                    this.changed();
                    return true;
                }
                for (int n11 : new ArrayList<Integer>(node.choices)) {
                    if (!this.hitCable(node, 0, this.graph.get(n11), 0, d, d2)) continue;
                    this.remember();
                    this.graph.disconnect(node.id, n11);
                    this.changed();
                    return true;
                }
                for (int n12 : new ArrayList<Integer>(node.triggers)) {
                    if (!this.hitCable(node, 0, this.graph.get(n12), 0, d, d2)) continue;
                    this.remember();
                    this.graph.disconnect(node.id, n12);
                    this.changed();
                    return true;
                }
            }
        }
        this.setFocused(null);
        if (n == 2) {
            NpcDialogueGraph.Node node;
            boolean bl = false;
            for (NpcDialogueGraph.Node node4 : this.graph.nodes.values()) {
                int n13;
                int n14 = n13 = node4.next >= 0 && this.graph.get(node4.next) != null && this.graph.get((int)node4.next).type == 3 && node4.type == 4 ? 1 : 0;
                if (node4.next >= 0 && this.hitCable(node4, 0, this.graph.get(node4.next), n13, d, d2)) {
                    this.remember();
                    this.graph.disconnect(node4.id, node4.next);
                    this.changed();
                    this.status = this.tr("gui.settledlands.graph.disconnected");
                    bl = true;
                    break;
                }
                if (node4.type == 3 && node4.falseNext >= 0 && this.hitCable(node4, 1, this.graph.get(node4.falseNext), 0, d, d2)) {
                    this.remember();
                    node4.falseNext = -1;
                    this.changed();
                    this.status = this.tr("gui.settledlands.graph.disconnected");
                    bl = true;
                    break;
                }
                if (node4.type == 3 && node4.varInputNode >= 0 && this.hitCable(this.graph.get(node4.varInputNode), 0, node4, 1, d, d2)) {
                    this.remember();
                    node4.varInputNode = -1;
                    this.changed();
                    this.status = this.tr("gui.settledlands.graph.disconnected");
                    bl = true;
                    break;
                }
                for (int n15 : new ArrayList<Integer>(node4.choices)) {
                    if (!this.hitCable(node4, 0, this.graph.get(n15), 0, d, d2)) continue;
                    this.remember();
                    this.graph.disconnect(node4.id, n15);
                    this.changed();
                    this.status = this.tr("gui.settledlands.graph.disconnected");
                    bl = true;
                    break;
                }
                if (bl) break;
                for (int n15 : new ArrayList<Integer>(node4.triggers)) {
                    if (!this.hitCable(node4, 0, this.graph.get(n15), 0, d, d2)) continue;
                    this.remember();
                    this.graph.disconnect(node4.id, n15);
                    this.changed();
                    this.status = this.tr("gui.settledlands.graph.disconnected");
                    bl = true;
                    break;
                }
                if (bl) break;
                if (node4.type == 13) {
                    for (int i = 0; i < node4.randomBranches.size(); ++i) {
                        int n15;
                        n15 = node4.randomBranches.get(i);
                        if (n15 < 0 || !this.hitCable(node4, i, this.graph.get(n15), 0, d, d2)) continue;
                        this.remember();
                        node4.randomBranches.set(i, -1);
                        this.changed();
                        this.status = this.tr("gui.settledlands.graph.disconnected");
                        bl = true;
                        break;
                    }
                }
                if (!bl) continue;
                break;
            }
            if (bl) {
                return true;
            }
            int n16 = this.canvas.hitPort(this.graph, d, d2, true);
            if (n16 >= 0 && (node = this.graph.get(n16)) != null) {
                this.remember();
                if (node.type == 3) {
                    if (this.canvas.hitPortIndex == 1) {
                        node.falseNext = -1;
                    } else {
                        node.next = -1;
                    }
                } else if (node.type == 13) {
                    int n17 = this.canvas.hitPortIndex;
                    if (n17 >= 0 && n17 < node.randomBranches.size()) {
                        node.randomBranches.set(n17, -1);
                    }
                } else {
                    this.graph.disconnectOutputs(n16);
                }
                this.changed();
                this.status = this.tr("gui.settledlands.graph.disconnected");
                return true;
            }
            int n18 = this.canvas.hitPort(this.graph, d, d2, false);
            if (n18 >= 0) {
                this.remember();
                boolean bl2 = false;
                for (NpcDialogueGraph.Node node5 : this.graph.nodes.values()) {
                    if (node5.next == n18) {
                        node5.next = -1;
                        bl2 = true;
                    }
                    if (node5.falseNext == n18) {
                        node5.falseNext = -1;
                        bl2 = true;
                    }
                    if (node5.varInputNode == n18) {
                        node5.varInputNode = -1;
                        bl2 = true;
                    }
                    if (node5.choices.remove((Object)n18)) {
                        bl2 = true;
                    }
                    if (node5.triggers.remove((Object)n18)) {
                        bl2 = true;
                    }
                    if (node5.type != 13) continue;
                    for (n2 = 0; n2 < node5.randomBranches.size(); ++n2) {
                        if (node5.randomBranches.get(n2) != n18) continue;
                        node5.randomBranches.set(n2, -1);
                        bl2 = true;
                    }
                }
                if (bl2) {
                    this.changed();
                    this.status = this.tr("gui.settledlands.graph.disconnected");
                    return true;
                }
            }
            this.panning = true;
            this.panStartX = d;
            this.panStartY = d2;
            this.canvasPanMoved = false;
            return true;
        }
        if (n == 1) {
            int n19 = this.canvas.hit(this.graph, d, d2);
            this.contextMenu.press(d, d2);
            this.contextMenu.targetNodeId = n19;
            if (n19 >= 0) {
                if (!this.multiSelected.contains(n19)) {
                    this.multiSelected.clear();
                    this.multiSelected.add(n19);
                }
                this.selected = n19;
                this.sidebarScroll = 0;
                this.widgets();
            }
            return true;
        }
        if (n == 0) {
            if (this.isInsideInspector(d, d2)) {
                if (d >= (double)(this.inspectorX + this.inspectorW - 20) && d <= (double)(this.inspectorX + this.inspectorW - 4) && d2 >= (double)(this.inspectorY + 2) && d2 <= (double)(this.inspectorY + 18)) {
                    this.multiSelected.clear();
                    this.selected = -1;
                    this.sidebarScroll = 0;
                    this.widgets();
                    return true;
                }
                return super.mouseClicked(d, d2, n);
            }
            if (d2 >= 6.0 && d2 <= 32.0 && d >= 10.0 && d <= (double)this.topBarRight) {
                return super.mouseClicked(d, d2, n);
            }
            int n20 = this.canvas.hitPort(this.graph, d, d2, true);
            if (n20 >= 0) {
                this.linkFrom = n20;
                this.linkFromPort = this.canvas.hitPortIndex;
                this.selected = n20;
                this.multiSelected.clear();
                this.multiSelected.add(n20);
                this.sidebarScroll = 0;
                this.widgets();
                return true;
            }
            int n21 = this.canvas.hit(this.graph, d, d2);
            if (n21 >= 0) {
                if (!this.multiSelected.contains(n21)) {
                    if (!this.isShiftDownSafe() && !this.isControlDownSafe()) {
                        this.multiSelected.clear();
                    }
                    this.multiSelected.add(n21);
                }
                this.selected = n21;
                this.sidebarScroll = 0;
                this.widgets();
                this.remember();
                this.dragging = n21;
                this.dragMouseWorldX = this.canvas.worldX(d);
                this.dragMouseWorldY = this.canvas.worldY(d2);
                this.dragOrigins.clear();
                for (int n22 : this.multiSelected) {
                    NpcDialogueGraph.Node node = this.graph.get(n22);
                    if (node == null) continue;
                    this.dragOrigins.put(n22, new int[]{node.x, node.y});
                }
                return true;
            }
            if (this.isSpaceDown()) {
                this.panning = true;
                this.panStartX = d;
                this.panStartY = d2;
                this.canvasPanMoved = false;
                return true;
            }
            this.selectingBox = true;
            this.boxStartX = this.boxCurrentX = d;
            this.boxStartY = this.boxCurrentY = d2;
            if (!this.isShiftDownSafe() && !this.isControlDownSafe()) {
                this.multiSelected.clear();
                this.selected = -1;
                this.sidebarScroll = 0;
                this.widgets();
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double d, double d2, int n, double d3, double d4) {
        if (n == 1 && this.contextMenu.isPressed()) {
            if (this.contextMenu.drag(d, d2)) {
                this.canvas.pan(this.contextMenu.deltaX, this.contextMenu.deltaY);
                this.syncCamera();
            }
            return true;
        }
        if (n == 0 && this.contextMenu.open && this.contextMenu.isScrollbar(d, d2)) {
            this.contextMenu.scrollbarDrag(d2);
            return true;
        }
        if (CommandTabCompleter.mouseDragged(this, d, d2, n, d3, d4)) {
            return true;
        }
        if (this.isInsideInspector(d, d2)) {
            for (AbstractWidget abstractWidget : this.inspectorWidgets) {
                if (!abstractWidget.isMouseOver(d, d2) || !abstractWidget.mouseDragged(d, d2, n, d3, d4)) continue;
                return true;
            }
            return true;
        }
        if (this.panning) {
            if (Math.abs(d - this.panStartX) > 3.0 || Math.abs(d2 - this.panStartY) > 3.0) {
                this.canvasPanMoved = true;
            }
            this.canvas.pan(d3, d4);
            this.syncCamera();
            return true;
        }
        if (this.selectingBox) {
            this.boxCurrentX = d;
            this.boxCurrentY = d2;
            this.updateBoxSelection();
            return true;
        }
        if (this.linkFrom >= 0) {
            return true;
        }
        if (this.dragging >= 0) {
            double d5 = this.canvas.worldX(d);
            double d6 = this.canvas.worldY(d2);
            double d7 = d5 - this.dragMouseWorldX;
            double d8 = d6 - this.dragMouseWorldY;
            for (Map.Entry<Integer, int[]> entry : this.dragOrigins.entrySet()) {
                NpcDialogueGraph.Node node = this.graph.get(entry.getKey());
                if (node == null) continue;
                int[] nArray = entry.getValue();
                this.canvas.move(node, (double)nArray[0] + d7, (double)nArray[1] + d8);
            }
            this.changed();
            return true;
        }
        return super.mouseDragged(d, d2, n, d3, d4);
    }

    @Override
    public boolean mouseReleased(double d, double d2, int n) {
        if (n == 1 && this.contextMenu.isPressed()) {
            this.contextMenu.release(d, d2, this.canvas);
            return true;
        }
        CommandTabCompleter.mouseReleased(this, d, d2, n);
        if (this.linkFrom >= 0) {
            int n2 = this.canvas.hitPort(this.graph, d, d2, false);
            if (n2 < 0) {
                n2 = this.canvas.hit(this.graph, d, d2);
            }
            if (n2 >= 0) {
                this.remember();
                if (this.graph.connect(this.linkFrom, n2, this.linkFromPort)) {
                    this.changed();
                    this.status = this.tr("gui.settledlands.graph.connected");
                } else {
                    this.status = this.tr("gui.settledlands.graph.bad_link");
                }
            } else if (this.canvas.contains(d, d2)) {
                this.contextMenu.showForWire(d, d2, this.canvas, this.linkFrom, this.linkFromPort);
            }
            this.linkFrom = -1;
            return true;
        }
        if (this.panning && (n == 0 || n == 2)) {
            this.panning = false;
            return true;
        }
        if (this.selectingBox && n == 0) {
            this.selectingBox = false;
            this.sidebarScroll = 0;
            this.widgets();
            return true;
        }
        boolean bl = this.panning || this.selectingBox || this.dragging >= 0;
        this.panning = false;
        this.selectingBox = false;
        this.dragging = -1;
        this.dragOrigins.clear();
        return bl || super.mouseReleased(d, d2, n);
    }

    @Override
    public boolean mouseScrolled(double d, double d2, double d3, double d4) {
        if (this.openDropdown != null) {
            if (this.openDropdown.popupScrolled(d, d2, (int)d4)) {
                return true;
            }
            this.openDropdown.closePopup();
            this.openDropdown = null;
            return true;
        }
        if (this.contextMenu.open) {
            if (this.contextMenu.contains(d, d2)) {
                this.contextMenu.scroll(d4 > 0.0 ? -1 : 1);
                return true;
            }
            this.contextMenu.close();
            return true;
        }
        if (CommandTabCompleter.mouseScrolled(this, d, d2, d4)) {
            return true;
        }
        if (this.isInsideInspector(d, d2)) {
            for (AbstractWidget abstractWidget : this.inspectorWidgets) {
                MultiLineEditBox multiLineEditBox;
                if (!(abstractWidget instanceof MultiLineEditBox) || !(multiLineEditBox = (MultiLineEditBox)abstractWidget).isMouseOver(d, d2) || multiLineEditBox.getInnerHeight() <= multiLineEditBox.getHeight() || !multiLineEditBox.mouseScrolled(d, d2, d3, d4)) continue;
                return true;
            }
            this.sidebarScroll = Math.max(0, Math.min(Math.max(0, this.sidebarHeight), this.sidebarScroll - (int)(d4 * 18.0)));
            this.widgets();
            return true;
        }
        if (this.canvas.contains(d, d2)) {
            this.canvas.zoomAt(d4, d, d2);
            this.syncCamera();
            return true;
        }
        return super.mouseScrolled(d, d2, d3, d4);
    }

    @Override
    public boolean keyPressed(int n, int n2, int n3) {
        if (n == 32 && !(this.getFocused() instanceof EditBox) && !(this.getFocused() instanceof MultiLineEditBox)) {
            this.spaceDown = true;
        }
        if (this.openDropdown != null && n == 256) {
            this.openDropdown.closePopup();
            this.openDropdown = null;
            return true;
        }
        if (n == 256 && (this.contextMenu.open || this.contextMenu.isPressed())) {
            this.contextMenu.cancel();
            return true;
        }
        if (CommandTabCompleter.handleKey(this, n, n2, n3)) {
            return true;
        }
        if (this.isControlDownSafe() && n == 83) {
            this.save();
            return true;
        }
        if (!(this.getFocused() instanceof EditBox) && !(this.getFocused() instanceof MultiLineEditBox)) {
            if (this.isControlDownSafe() && n == 90) {
                this.history(this.isShiftDownSafe());
                return true;
            }
            if (this.isControlDownSafe() && n == 89) {
                this.history(true);
                return true;
            }
            if (!(n != 261 || this.multiSelected.isEmpty() && this.selected < 0)) {
                this.remember();
                boolean bl = false;
                if (!this.multiSelected.isEmpty()) {
                    for (int n4 : new ArrayList<Integer>(this.multiSelected)) {
                        if (!this.graph.remove(n4)) continue;
                        bl = true;
                    }
                    this.multiSelected.clear();
                    this.selected = -1;
                } else if (this.selected >= 0) {
                    bl = this.graph.remove(this.selected);
                    this.selected = -1;
                }
                if (bl) {
                    this.changed();
                    this.widgets();
                }
                return true;
            }
            if (n == 70) {
                this.canvas.frameAll(this.graph);
                return true;
            }
        }
        if (n == 256) {
            if (this.linkFrom >= 0 || this.dragging >= 0 || this.panning || this.selectingBox) {
                this.linkFrom = -1;
                this.dragging = -1;
                this.panning = false;
                this.selectingBox = false;
                return true;
            }
            if (this.getFocused() instanceof MultiLineEditBox || this.getFocused() instanceof EditBox) {
                this.setFocused(null);
                return true;
            }
            if (!this.multiSelected.isEmpty() || this.selected >= 0) {
                this.multiSelected.clear();
                this.selected = -1;
                this.sidebarScroll = 0;
                this.widgets();
                return true;
            }
        }
        return super.keyPressed(n, n2, n3);
    }

    @Override
    public boolean keyReleased(int n, int n2, int n3) {
        if (n == 32) {
            this.spaceDown = false;
        }
        return super.keyReleased(n, n2, n3);
    }

    @Override
    public void renderBackground(GuiGraphics guiGraphics, int n, int n2, float f) {
        int n3;
        guiGraphics.fill(0, 0, this.width, this.height, -15723235);
        guiGraphics.fill(this.canvas.left, this.canvas.top, this.canvas.right, this.canvas.bottom, -15196374);
        guiGraphics.enableScissor(this.canvas.left, this.canvas.top, this.canvas.right, this.canvas.bottom);
        this.grid(guiGraphics);
        this.wires(guiGraphics, n, n2);
        for (NpcDialogueGraph.Node node : this.graph.nodes.values()) {
            if (!this.canvas.visible(node)) continue;
            this.drawNode(guiGraphics, node);
        }
        if (this.selectingBox) {
            int n4 = (int)Math.min(this.boxStartX, this.boxCurrentX);
            int n5 = (int)Math.min(this.boxStartY, this.boxCurrentY);
            int n6 = (int)Math.max(this.boxStartX, this.boxCurrentX);
            n3 = (int)Math.max(this.boxStartY, this.boxCurrentY);
            guiGraphics.fill(n4, n5, n6, n3, 859356664);
            guiGraphics.fill(n4, n5, n6, n5 + 1, -13058568);
            guiGraphics.fill(n4, n3 - 1, n6, n3, -13058568);
            guiGraphics.fill(n4, n5, n4 + 1, n3, -13058568);
            guiGraphics.fill(n6 - 1, n5, n6, n3, -13058568);
        }
        guiGraphics.disableScissor();
        if (this.selected >= 0 && this.node() != null) {
            int n7;
            guiGraphics.fill(this.inspectorX, this.inspectorY, this.inspectorX + this.inspectorW, this.inspectorY + this.inspectorH, -300671960);
            guiGraphics.fill(this.inspectorX, this.inspectorY, this.inspectorX + this.inspectorW, this.inspectorY + 1, -12890522);
            guiGraphics.fill(this.inspectorX, this.inspectorY + this.inspectorH - 1, this.inspectorX + this.inspectorW, this.inspectorY + this.inspectorH, -12890522);
            guiGraphics.fill(this.inspectorX, this.inspectorY, this.inspectorX + 1, this.inspectorY + this.inspectorH, -12890522);
            guiGraphics.fill(this.inspectorX + this.inspectorW - 1, this.inspectorY, this.inspectorX + this.inspectorW, this.inspectorY + this.inspectorH, -12890522);
            guiGraphics.fill(this.inspectorX + 1, this.inspectorY + 1, this.inspectorX + this.inspectorW - 1, this.inspectorY + 20, -14668739);
            guiGraphics.fill(this.inspectorX + 1, this.inspectorY + 20, this.inspectorX + this.inspectorW - 1, this.inspectorY + 21, -12890522);
            NpcDialogueGraph.Node node = this.node();
            int n8 = node.type == 0 ? -7550482 : (node.type == 1 ? -1852043 : (node.type == 2 ? -2974723 : (node.type == 3 ? -13058568 : (node.type == 4 ? -290244 : (node.type == 5 ? -13315175 : -770210)))));
            String string = this.multiSelected.size() > 1 ? String.format(this.tr("gui.settledlands.graph.multiselected"), this.multiSelected.size()) : this.tr(node.type == 0 ? "gui.settledlands.graph.line" : (node.type == 1 ? "gui.settledlands.graph.button" : (node.type == 2 ? "gui.settledlands.graph.trigger" : (node.type == 3 ? "gui.settledlands.graph.if" : (node.type == 4 ? "gui.settledlands.graph.variable" : (node.type == 5 ? "gui.settledlands.graph.check" : "gui.settledlands.graph.damage")))))) + " #" + node.id;
            guiGraphics.drawString(this.font, this.clip(string, this.inspectorW - 34), this.inspectorX + 8, this.inspectorY + 6, n8, false);
            guiGraphics.drawString(this.font, "\u2715", this.inspectorX + this.inspectorW - 14, this.inspectorY + 6, -5588790, false);
            if (this.sidebarHeight > 0) {
                n3 = this.inspectorY + 22;
                int n9 = this.inspectorH - 26;
                int n10 = Math.max(16, (int)((float)n9 * (float)n9 / (float)(n9 + this.sidebarHeight)));
                int n11 = n9 - n10;
                int n12 = n3 + (int)((float)n11 * (float)this.sidebarScroll / (float)this.sidebarHeight);
                guiGraphics.fill(this.inspectorX + this.inspectorW - 4, n3, this.inspectorX + this.inspectorW - 1, n3 + n9, 0x33FFFFFF);
                guiGraphics.fill(this.inspectorX + this.inspectorW - 4, n12, this.inspectorX + this.inspectorW - 1, n12 + n10, -1996488705);
            }
        }
    }

    @Override
    public void render(GuiGraphics guiGraphics, int n, int n2, float f) {
        super.render(guiGraphics, n, n2, f);
        if (this.selected >= 0 && this.node() != null) {
            guiGraphics.enableScissor(this.inspectorX + 1, this.inspectorY + 21, this.inspectorX + this.inspectorW - 1, this.inspectorY + this.inspectorH - 1);
            for (Label label : this.labels) {
                if (label.y < this.inspectorY + 20 || label.y >= this.inspectorY + this.inspectorH - 8) continue;
                guiGraphics.drawString(this.font, this.clip(this.tr(label.key), this.inspectorW - 16), label.x, label.y, -5588790, false);
            }
            guiGraphics.disableScissor();
        }
        if (!(this.status.isEmpty() || this.status.equals(this.tr("gui.settledlands.graph.controls")) || this.status.equals(this.tr("gui.settledlands.graph.unsaved")))) {
            guiGraphics.drawString(this.font, this.status, 10, this.height - 16, -8070480, false);
        }
        guiGraphics.drawString(this.font, Math.round(this.canvas.zoom * 100.0) + "%", this.width - 36, this.height - 16, -2002077494, false);
        CommandTabCompleter.render(this, guiGraphics, n, n2);
        if (this.openDropdown != null) {
            guiGraphics.pose().pushPose();
            guiGraphics.pose().translate(0.0f, 0.0f, 500.0f);
            this.openDropdown.renderPopup(guiGraphics, n, n2);
            guiGraphics.pose().popPose();
        }
        if (this.contextMenu.open) {
            this.drawContextMenu(guiGraphics, n, n2);
        }
    }

    private void drawContextMenu(GuiGraphics guiGraphics, int n, int n2) {
        guiGraphics.pose().pushPose();
        guiGraphics.pose().translate(0.0f, 0.0f, 600.0f);
        int n3 = this.contextMenu.left;
        int n4 = this.contextMenu.top;
        int n5 = this.contextMenu.width;
        int n6 = this.contextMenu.height;
        guiGraphics.enableScissor(n3, n4, n3 + n5, n4 + n6);
        guiGraphics.fill(n3, n4, n3 + n5, n4 + n6, -15656669);
        guiGraphics.fill(n3, n4, n3 + n5, n4 + 1, -8415050);
        guiGraphics.fill(n3, n4 + n6 - 1, n3 + n5, n4 + n6, -8415050);
        guiGraphics.fill(n3, n4, n3 + 1, n4 + n6, -8415050);
        guiGraphics.fill(n3 + n5 - 1, n4, n3 + n5, n4 + n6, -8415050);
        if (this.contextMenu.targetNodeId >= 0) {
            NpcDialogueGraph.Node node = this.graph.get(this.contextMenu.targetNodeId);
            String string = node != null ? this.tr(node.type == 0 ? "gui.settledlands.graph.line" : (node.type == 1 ? "gui.settledlands.graph.button" : (node.type == 2 ? "gui.settledlands.graph.trigger" : (node.type == 3 ? "gui.settledlands.graph.if" : (node.type == 4 ? "gui.settledlands.graph.variable" : (node.type == 5 ? "gui.settledlands.graph.check" : (node.type == 6 ? "gui.settledlands.graph.damage" : (node.type == 7 ? "gui.settledlands.graph.time" : (node.type == 8 ? "gui.settledlands.graph.timer" : (node.type == 9 ? "gui.settledlands.graph.anim" : (node.type == 14 ? "gui.settledlands.graph.cutscene" : "gui.settledlands.graph.quest"))))))))))) + " #" + node.id : this.tr("gui.settledlands.graph.select");
            guiGraphics.drawString(this.font, this.clip(string, n5 - 16), n3 + 8, n4 + 6, -1852043, false);
            int n7 = this.contextMenu.rowAt(n, n2);
            for (int i = 0; i < 2; ++i) {
                int n8 = n4 + 20 + i * 22;
                if (i == n7) {
                    guiGraphics.fill(n3 + 2, n8, n3 + n5 - 2, n8 + 22, -13351331);
                }
                String string2 = i == 0 ? "gui.settledlands.graph.copy_node" : "gui.settledlands.graph.delete";
                int n9 = i == 0 ? -8070480 : -495247;
                guiGraphics.drawString(this.font, this.clip(this.tr(string2), n5 - 16), n3 + 8, n8 + 7, n9, false);
            }
        } else {
            int n10;
            int n11;
            int n12;
            int n13;
            guiGraphics.drawString(this.font, this.clip(this.tr("gui.settledlands.graph.create"), n5 - 24), n3 + 8, n4 + 6, -5588790, false);
            int n14 = this.contextMenu.rowAt(n, n2);
            int n15 = n3 + n5 - 6 - 4;
            for (n13 = 0; n13 < 5 && (n12 = this.contextMenu.scrollRow + n13) < 16; ++n13) {
                n11 = n4 + 20 + n13 * 22;
                if (n12 == n14) {
                    guiGraphics.fill(n3 + 2, n11, n15, n11 + 22, -13351331);
                }
                String string = switch (n12) {
                    case 0 -> "gui.settledlands.graph.add_line";
                    case 1 -> "gui.settledlands.graph.add_button";
                    case 2 -> "gui.settledlands.graph.add_trigger";
                    case 3 -> "gui.settledlands.graph.add_if";
                    case 4 -> "gui.settledlands.graph.add_variable";
                    case 5 -> "gui.settledlands.graph.add_check";
                    case 6 -> "gui.settledlands.graph.add_damage";
                    case 7 -> "gui.settledlands.graph.add_time";
                    case 8 -> "gui.settledlands.graph.add_timer";
                    case 9 -> "gui.settledlands.graph.add_anim";
                    case 10 -> "gui.settledlands.graph.add_quest";
                    case 11 -> "gui.settledlands.graph.add_move";
                    case 12 -> "gui.settledlands.graph.add_mobility";
                    case 13 -> "gui.settledlands.graph.add_random";
                    case 14 -> "gui.settledlands.graph.add_cutscene";
                    case 15 -> "gui.settledlands.graph.add_radius";
                    default -> "";
                };
                n10 = switch (n12) {
                    case 0 -> -7550482;
                    case 1 -> -1852043;
                    case 2 -> -2974723;
                    case 3 -> -13058568;
                    case 4 -> -290244;
                    case 5 -> -13315175;
                    case 6 -> -770210;
                    case 7 -> -278748;
                    case 8 -> -5796870;
                    case 9 -> -1292135;
                    case 10 -> -680437;
                    case 11 -> -8286984;
                    case 12 -> -13773633;
                    case 13 -> -5745161;
                    case 14 -> -1004548;
                    case 15 -> -8467457;
                    default -> -1;
                };
                guiGraphics.drawString(this.font, this.clip(this.tr(string), n15 - n3 - 12), n3 + 8, n11 + 7, n10, false);
            }
            n13 = n3 + n5 - 6 - 2;
            n12 = n4 + 20 + 2;
            n11 = n6 - 20 - 4;
            guiGraphics.fill(n13, n12, n13 + 6, n12 + n11, -14800581);
            int n16 = 11;
            n10 = Math.max(16, n11 * 5 / 16);
            int n17 = n12 + (n11 - n10) * this.contextMenu.scrollRow / Math.max(1, n16);
            boolean bl = n >= n13 && n <= n13 + 6 && n2 >= n17 && n2 <= n17 + n10;
            guiGraphics.fill(n13, n17, n13 + 6, n17 + n10, bl ? -7035976 : -10193781);
        }
        guiGraphics.disableScissor();
        guiGraphics.pose().popPose();
    }

    private String clip(String string, int n) {
        return this.font.plainSubstrByWidth(string == null ? "" : string, Math.max(1, n));
    }

    private void grid(GuiGraphics guiGraphics) {
        double d;
        double d2;
        for (d2 = 32.0 * this.canvas.zoom; d2 < 16.0; d2 *= 4.0) {
        }
        int n = (int)((double)this.canvas.left + (this.canvas.panX % d2 + d2) % d2);
        int n2 = (int)((double)this.canvas.top + (this.canvas.panY % d2 + d2) % d2);
        for (d = (double)n; d < (double)this.canvas.right; d += d2) {
            guiGraphics.vLine((int)d, this.canvas.top, this.canvas.bottom, -14406085);
        }
        for (d = (double)n2; d < (double)this.canvas.bottom; d += d2) {
            guiGraphics.hLine(this.canvas.left, this.canvas.right, (int)d, -14406085);
        }
    }

    private void drawNode(GuiGraphics guiGraphics, NpcDialogueGraph.Node node) {
        String var12_10;
        int n = node.special != 0 ? -11305096 : (node.type == 0 && node.cutsceneLine ? -34278 : (node.type == 0 ? -13145972 : (node.type == 1 ? -6654400 : (node.type == 2 ? -8704833 : (node.type == 3 ? -15829872 : (node.type == 4 ? -4046580 : (node.type == 5 ? -16484265 : (node.type == 6 ? -6352327 : (node.type == 7 ? -4959479 : (node.type == 8 ? -9623335 : (node.type == 9 ? -4319139 : (node.type == 14 ? -6153041 : (node.type == 10 ? -2525434 : (node.type == 11 ? -12371766 : (node.type == 12 ? -15763858 : (node.type == 15 ? -13668445 : -9756248))))))))))))))));
        double d = this.canvas.screenX(node.x);
        double d2 = this.canvas.screenY(node.y);
        guiGraphics.pose().pushPose();
        guiGraphics.pose().translate(d, d2, 0.0);
        guiGraphics.pose().scale((float)this.canvas.zoom, (float)this.canvas.zoom, 1.0f);
        int n3 = 220;
        int n4 = 100;
        boolean bl = node.id == this.selected || this.multiSelected.contains(node.id);
        guiGraphics.fill(-2, -2, n3 + 2, n4 + 2, bl ? -1458841 : -12167317);
        guiGraphics.fill(0, 0, n3, n4, -14274241);
        guiGraphics.fill(0, 0, n3, 22, n);
        String string = node.special == 1 ? this.tr("gui.settledlands.graph.travel") : (node.special == 2 ? this.tr("gui.settledlands.graph.arrival") : (node.type == 0 ? this.tr("gui.settledlands.graph.line") : (node.type == 1 ? this.tr("gui.settledlands.graph.button") : (node.type == 2 ? this.tr("gui.settledlands.graph.trigger") : (node.type == 3 ? this.tr("gui.settledlands.graph.if") : (node.type == 4 ? this.tr("gui.settledlands.graph.variable") : (node.type == 5 ? this.tr("gui.settledlands.graph.check") : (node.type == 6 ? this.tr("gui.settledlands.graph.damage") : (node.type == 7 ? this.tr("gui.settledlands.graph.time") : (node.type == 8 ? this.tr("gui.settledlands.graph.timer") : (node.type == 9 ? this.tr("gui.settledlands.graph.anim") : (node.type == 14 ? this.tr("gui.settledlands.graph.cutscene") : (node.type == 10 ? this.tr("gui.settledlands.graph.quest") : (node.type == 11 ? this.tr("gui.settledlands.graph.move") : (node.type == 12 ? this.tr("gui.settledlands.graph.mobility") : (node.type == 15 ? this.tr("gui.settledlands.graph.radius_title") : this.tr("gui.settledlands.graph.random")))))))))))))))));
        guiGraphics.drawString(this.font, this.clip(string + " #" + node.id, n3 - 16), 8, 7, -986121, false);
        if (node.id == this.graph.entry) {
            guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.start"), 8, 78, -8070480, false);
        }
        if (node.type == 2) {
            var12_10 = node.action.isBlank() ? this.tr("gui.settledlands.graph.no_command") : node.action;
            guiGraphics.drawString(this.font, this.clip("\u26a1 " + var12_10, n3 - 16), 8, 35, -2045697, false);
        } else if (node.type == 4) {
            var12_10 = node.pointsName.isBlank() ? this.tr("gui.settledlands.graph.no_var") : node.pointsName;
            guiGraphics.drawString(this.font, this.clip("\u26c1 " + var12_10 + (String)(node.pointsShared ? " (" + this.tr("gui.settledlands.graph.shared_on") + ")" : "") + (String)(node.varLocal ? " (" + this.tr("gui.settledlands.graph.local_flag") + ")" : ""), n3 - 16), 8, 35, -75862, false);
            String string2 = (node.varValue >= 0 ? "+" : "") + node.varValue;
            guiGraphics.drawString(this.font, this.clip(this.tr("gui.settledlands.graph.var_delta") + ": " + string2, n3 - 16), 8, 52, -75862, false);
            if (!node.action.isBlank()) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 70, -1852043, false);
            }
        } else if (node.type == 3) {
            var12_10 = node.varInputNode >= 0 ? (this.graph.get(node.varInputNode) != null && !this.graph.get((int)node.varInputNode).pointsName.isBlank() ? this.graph.get((int)node.varInputNode).pointsName : "#" + node.varInputNode) : (node.pointsName.isBlank() ? "?" : node.pointsName);
            String string3 = switch (node.varOp) {
                case 0 -> "==";
                case 1 -> "!=";
                case 2 -> ">=";
                case 3 -> ">";
                case 4 -> "<=";
                case 5 -> "<";
                default -> "==";
            };
            guiGraphics.drawString(this.font, this.clip("\u2753 " + var12_10 + " " + string3 + " " + node.varCompare, n3 - 16), 8, 35, -4528387, false);
            guiGraphics.drawString(this.font, "True \u2714", n3 - 46, (int)((double)n4 * 0.35 - 4.0), -11870592, false);
            guiGraphics.drawString(this.font, "False \u2716", n3 - 46, (int)((double)n4 * 0.7 - 4.0), -495247, false);
            if (!node.action.isBlank()) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 70, -1852043, false);
            }
        } else if (node.type == 5) {
            var12_10 = switch (node.checkTarget) {
                case 0 -> this.tr("gui.settledlands.graph.target_player");
                case 1 -> this.tr("gui.settledlands.graph.target_npc");
                case 2 -> this.tr("gui.settledlands.graph.target_monster");
                case 3 -> this.tr("gui.settledlands.graph.target_any");
                default -> this.tr("gui.settledlands.graph.target_player");
            };
            guiGraphics.drawString(this.font, this.clip("\ud83d\udc41 " + this.tr("gui.settledlands.graph.target") + ": " + var12_10, n3 - 16), 8, 35, -5770288, false);
            guiGraphics.drawString(this.font, this.clip("\u25ce " + this.tr("gui.settledlands.graph.check_radius") + ": " + node.checkRadius + " " + this.tr("gui.settledlands.graph.blocks"), n3 - 16), 8, 52, -5770288, false);
            guiGraphics.drawString(this.font, this.clip("\u23f1 " + this.tr("gui.settledlands.graph.check_cooldown") + ": " + node.checkCooldown + "s", n3 - 16), 8, 69, -9508937, false);
            if (!node.action.isBlank()) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 85, -1852043, false);
            }
        } else if (node.type == 15) {
            var12_10 = switch (node.radiusTarget) {
                case 0 -> this.tr("gui.settledlands.graph.target_player");
                case 1 -> this.tr("gui.settledlands.graph.target_npc");
                case 2 -> this.tr("gui.settledlands.graph.target_monster");
                case 3 -> this.tr("gui.settledlands.graph.target_any");
                case 4 -> this.tr("gui.settledlands.graph.target_passive");
                default -> this.tr("gui.settledlands.graph.target_player");
            };
            guiGraphics.drawString(this.font, this.clip("\u25ce " + this.tr("gui.settledlands.graph.radius") + ": " + node.radius + " " + this.tr("gui.settledlands.graph.blocks"), n3 - 16), 8, 52, -5777409, false);
            guiGraphics.drawString(this.font, this.clip("\ud83d\udc65 " + var12_10, n3 - 16), 8, 69, -5777409, false);
        } else if (node.type == 6) {
            var12_10 = switch (node.damageFilter) {
                case 0 -> this.tr("gui.settledlands.graph.damage_any");
                case 1 -> this.tr("gui.settledlands.graph.damage_player");
                case 2 -> this.tr("gui.settledlands.graph.damage_monster");
                case 3 -> this.tr("gui.settledlands.graph.damage_non_player");
                default -> this.tr("gui.settledlands.graph.damage_player");
            };
            guiGraphics.drawString(this.font, this.clip("\ud83d\udde1 " + this.tr("gui.settledlands.graph.damage_source") + ": " + var12_10, n3 - 16), 8, 35, -78381, false);
            guiGraphics.drawString(this.font, this.clip("\ud83d\udca5 " + this.tr("gui.settledlands.graph.min_damage") + ": " + node.minDamage, n3 - 16), 8, 52, -78381, false);
            guiGraphics.drawString(this.font, this.clip("\u23f1 " + this.tr("gui.settledlands.graph.check_cooldown") + ": " + node.damageCooldown + "s", n3 - 16), 8, 69, -154449, false);
            if (!node.action.isBlank()) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 85, -1852043, false);
            }
        } else if (node.type == 7) {
            var12_10 = switch (node.timeMode) {
                case 0 -> this.tr("gui.settledlands.graph.time_dawn");
                case 1 -> this.tr("gui.settledlands.graph.time_noon");
                case 2 -> this.tr("gui.settledlands.graph.time_sunset");
                case 3 -> this.tr("gui.settledlands.graph.time_midnight");
                case 4 -> this.tr("gui.settledlands.graph.time_custom") + " (" + node.timeTicks + ")";
                default -> this.tr("gui.settledlands.graph.time_custom") + " (" + node.timeTicks + ")";
            };
            guiGraphics.drawString(this.font, this.clip("\u2600 " + this.tr("gui.settledlands.graph.time_mode") + ": " + var12_10, n3 - 16), 8, 35, -137590, false);
            guiGraphics.drawString(this.font, this.clip("\u231b " + this.tr("gui.settledlands.graph.time_ticks") + ": " + node.timeTicks, n3 - 16), 8, 52, -137590, false);
            if (!node.action.isBlank()) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 70, -1852043, false);
            }
        } else if (node.type == 8) {
            guiGraphics.drawString(this.font, this.clip("\u23f1 " + this.tr("gui.settledlands.graph.timer_interval") + ": " + node.timerInterval + "s", n3 - 16), 8, 35, -2238722, false);
            var12_10 = node.timerRepeat ? this.tr("gui.settledlands.graph.timer_repeat_on") : this.tr("gui.settledlands.graph.timer_repeat_off");
            guiGraphics.drawString(this.font, this.clip("\ud83d\udd04 " + var12_10, n3 - 16), 8, 52, -2238722, false);
            if (!node.action.isBlank()) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 70, -1852043, false);
            }
        } else if (node.type == 9) {
            var12_10 = node.animName.isBlank() ? this.tr("gui.settledlands.graph.anim_none") : node.animName;
            guiGraphics.drawString(this.font, this.clip("\ud83c\udfac " + this.tr("gui.settledlands.graph.anim") + ": " + var12_10, n3 - 16), 8, 35, -274456, false);
            String string4 = node.animLoop ? this.tr("gui.settledlands.graph.anim_repeat_on") : this.tr("gui.settledlands.graph.anim_repeat_off");
            Object object = node.animBone.isBlank() ? this.tr("gui.settledlands.graph.anim_bone_all") : "\ud83e\uddb4 " + node.animBone;
            guiGraphics.drawString(this.font, this.clip("\ud83d\udd04 " + string4 + " | " + (String)object, n3 - 16), 8, 52, -274456, false);
            if (!node.action.isBlank()) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 70, -1852043, false);
            }
        } else if (node.type == 14) {
            var12_10 = node.cutsceneName.isBlank() ? this.tr("gui.settledlands.graph.cutscene_none") : node.cutsceneName;
            guiGraphics.drawString(this.font, this.clip("\ud83c\udfa5 " + this.tr("gui.settledlands.graph.cutscene") + ": " + var12_10, n3 - 16), 8, 35, -667394, false);
            if (!node.action.isBlank()) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 52, -1852043, false);
            }
        } else if (node.type == 10) {
            var12_10 = node.text.isBlank() ? this.tr("gui.settledlands.graph.quest_empty") : node.text;
            guiGraphics.drawString(this.font, this.clip("\ud83d\udcdc " + var12_10, n3 - 16), 8, 35, -137590, false);
            if (node.minRelation > 0) {
                guiGraphics.drawString(this.font, this.clip("\u2764 " + this.tr("gui.settledlands.graph.min_relation") + ": " + node.minRelation, n3 - 16), 8, 52, -137590, false);
            }
            int n5 = -1;
            boolean bl2 = true;
            for (NpcDialogueGraph.Node node2 : this.graph.nodes.values()) {
                if (node2.type != 3 || node2.next != node.id && node2.falseNext != node.id) continue;
                n5 = node2.id;
                bl2 = node2.next == node.id;
                break;
            }
            if (n5 >= 0) {
                guiGraphics.drawString(this.font, this.clip("\u2753 If #" + n5 + " (" + (bl2 ? "True" : "False") + ")", n3 - 16), 8, 69, -8530948, false);
                if (!node.action.isBlank()) {
                    guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 84, -1852043, false);
                }
            } else if (!node.action.isBlank()) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 70, -1852043, false);
            }
        } else if (node.type == 11) {
            var12_10 = node.moveCoords.isBlank() ? this.tr("gui.settledlands.graph.no_coords") : node.moveCoords;
            String string5 = node.moveEscort ? " | \ud83d\udee1 " + this.tr("gui.settledlands.graph.move_escort_badge") : "";
            guiGraphics.drawString(this.font, this.clip("\ud83d\udeb6 " + var12_10 + string5, n3 - 16), 8, 35, -3681538, false);
            String string6 = String.format(Locale.ROOT, "%.1fx", node.moveSpeed);
            String moveEscortSuffix = node.moveEscort ? " (" + this.tr("gui.settledlands.graph.move_escort") + ")" : "";
            guiGraphics.drawString(this.font, this.clip("\u26a1 " + this.tr("gui.settledlands.graph.move_speed") + ": " + string6 + moveEscortSuffix, n3 - 16), 8, 52, -3681538, false);
            int n6 = -1;
            boolean bl3 = true;
            for (NpcDialogueGraph.Node node3 : this.graph.nodes.values()) {
                if (node3.type != 3 || node3.next != node.id && node3.falseNext != node.id) continue;
                n6 = node3.id;
                bl3 = node3.next == node.id;
                break;
            }
            if (n6 >= 0) {
                guiGraphics.drawString(this.font, this.clip("\u2753 If #" + n6 + " (" + (bl3 ? "True" : "False") + ")", n3 - 16), 8, 69, -8530948, false);
                if (!node.action.isBlank()) {
                    guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 84, -1852043, false);
                }
            } else if (!node.action.isBlank()) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 70, -1852043, false);
            }
        } else if (node.type == 12) {
            var12_10 = node.mobilityGroupName.isBlank() ? (node.mobilityGroupId.isBlank() ? this.tr("gui.settledlands.graph.no_group") : node.mobilityGroupId) : node.mobilityGroupName;
            guiGraphics.drawString(this.font, this.clip("\ud83e\udded " + var12_10, n3 - 16), 8, 35, -10556716, false);
            guiGraphics.drawString(this.font, this.clip("\ud83d\udccd " + this.tr("gui.settledlands.graph.mobility_target_pt1"), n3 - 16), 8, 50, -6687004, false);
            int n7 = -1;
            boolean bl4 = true;
            for (NpcDialogueGraph.Node node2 : this.graph.nodes.values()) {
                if (node2.type != 3 || node2.next != node.id && node2.falseNext != node.id) continue;
                n7 = node2.id;
                bl4 = node2.next == node.id;
                break;
            }
            if (n7 >= 0) {
                guiGraphics.drawString(this.font, this.clip("\u2753 If #" + n7 + " (" + (bl4 ? "True" : "False") + ")", n3 - 16), 8, 69, -8530948, false);
                if (!node.action.isBlank()) {
                    guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 84, -1852043, false);
                }
            } else if (!node.action.isBlank()) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 70, -1852043, false);
            }
        } else if (node.type == 13) {
            guiGraphics.drawString(this.font, this.clip("\ud83c\udfb2 " + this.tr("gui.settledlands.graph.random_range") + ": [" + node.randomMin + " - " + node.randomMax + "]", n3 - 16), 8, 35, -1452545, false);
            guiGraphics.drawString(this.font, this.clip("\ud83d\udd00 " + this.tr("gui.settledlands.graph.random_outputs") + ": " + node.randomMax, n3 - 16), 8, 50, -4160260, false);
            if (!node.action.isBlank()) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 68, -1852043, false);
            }
        } else {
            var12_10 = this.summaries.computeIfAbsent(node.id, n2 -> this.clip(node.text.replace('\n', ' '), n3 - 16));
            guiGraphics.drawString(this.font, var12_10, 8, 35, -2760723, false);
            if (!node.action.isBlank()) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.trigger"), 8, 55, -1852043, false);
            }
            if (node.builtinTopic >= 0) {
                guiGraphics.drawString(this.font, this.tr("gui.settledlands.graph.builtin"), 8, 65, -5588790, false);
            }
        }
        if (node.special == 0) {
            if (node.type == 3) {
                guiGraphics.fill(-5, (int)((double)n4 * 0.35) - 5, 5, (int)((double)n4 * 0.35) + 5, -3876630);
                guiGraphics.fill(-5, (int)((double)n4 * 0.7) - 5, 5, (int)((double)n4 * 0.7) + 5, -290244);
                guiGraphics.fill(n3 - 5, (int)((double)n4 * 0.35) - 5, n3 + 5, (int)((double)n4 * 0.35) + 5, -11870592);
                guiGraphics.fill(n3 - 5, (int)((double)n4 * 0.7) - 5, n3 + 5, (int)((double)n4 * 0.7) + 5, -495247);
            } else if (node.type == 13) {
                guiGraphics.fill(-5, n4 / 2 - 5, 5, n4 / 2 + 5, -3876630);
                int n8 = Math.max(2, node.randomMax);
                for (int i = 0; i < n8; ++i) {
                    int n9 = (int)((double)n4 * (((double)i + 1.0) / ((double)n8 + 1.0)));
                    guiGraphics.fill(n3 - 5, n9 - 4, n3 + 5, n9 + 4, -5745161);
                    guiGraphics.drawString(this.font, String.valueOf(i + 1), n3 - 12, n9 - 4, -1452545, false);
                }
            } else {
                guiGraphics.fill(-5, n4 / 2 - 5, 5, n4 / 2 + 5, -3876630);
                int n10 = node.type == 0 ? -9389850 : (node.type == 1 ? -1852043 : (node.type == 2 ? -3703297 : (node.type == 4 ? -290244 : (node.type == 5 ? -13315175 : (node.type == 6 ? -770210 : (node.type == 7 ? -278748 : (node.type == 8 ? -5796870 : (node.type == 9 ? -1292135 : (node.type == 10 ? -680437 : (node.type == 11 ? -8286984 : -13773633))))))))));
                guiGraphics.fill(n3 - 5, n4 / 2 - 5, n3 + 5, n4 / 2 + 5, n10);
            }
        }
        guiGraphics.pose().popPose();
    }

    private void wires(GuiGraphics guiGraphics, int n, int n2) {
        int n32;
        NpcDialogueGraph.Node node2;
        guiGraphics.flush();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder bufferBuilder = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        Matrix4f matrix4f = guiGraphics.pose().last().pose();
        int n4 = 0;
        boolean bl = this.canvas.contains(n, n2) && !this.contextMenu.open && this.linkFrom < 0 && this.dragging < 0 && !this.panning && this.canvas.hit(this.graph, n, n2) < 0 && this.canvas.hitPort(this.graph, n, n2, true) < 0 && this.canvas.hitPort(this.graph, n, n2, false) < 0;
        int n5 = -1;
        int n6 = 0;
        int n7 = -1;
        int n8 = 0;
        int n9 = 0;
        if (bl) {
            block0: for (NpcDialogueGraph.Node nodeHit : this.graph.nodes.values()) {
                NpcDialogueGraph.Node node3;
                NpcDialogueGraph.Node nextNode;
                if (nodeHit.next >= 0 && (nextNode = this.graph.get(nodeHit.next)) != null) {
                    int n10 = n32 = (nextNode).type == 3 && nodeHit.type == 4 ? 1 : 0;
                    if (this.hitCable(nodeHit, 0, nextNode, n32, n, n2)) {
                        n5 = nodeHit.id;
                        n6 = 0;
                        n7 = (nextNode).id;
                        n8 = n32;
                        n9 = nodeHit.type == 3 ? -11870592 : (nodeHit.type == 4 ? -290244 : (nodeHit.type == 5 ? -13315175 : (nodeHit.type == 6 ? -770210 : (nodeHit.type == 7 ? -278748 : (nodeHit.type == 8 ? -5796870 : (nodeHit.type == 9 ? -1292135 : (nodeHit.type == 10 ? -680437 : (nodeHit.type == 11 ? -8286984 : (nodeHit.type == 12 ? -13773633 : (nodeHit.type == 0 ? -9389850 : (nodeHit.type == 1 ? -1852043 : -3703297)))))))))));
                        break;
                    }
                }
                if (nodeHit.type == 3 && nodeHit.falseNext >= 0 && (nextNode = this.graph.get(nodeHit.falseNext)) != null && this.hitCable(nodeHit, 1, nextNode, 0, n, n2)) {
                    n5 = nodeHit.id;
                    n6 = 1;
                    n7 = (nextNode).id;
                    n8 = 0;
                    n9 = -495247;
                    break;
                }
                if (nodeHit.type == 3 && nodeHit.varInputNode >= 0 && nodeHit.varInputNode != nodeHit.next && (nextNode = this.graph.get(nodeHit.varInputNode)) != null && this.hitCable(nextNode, 0, nodeHit, 1, n, n2)) {
                    n5 = (nextNode).id;
                    n6 = 0;
                    n7 = nodeHit.id;
                    n8 = 1;
                    n9 = -290244;
                    break;
                }
                Iterator<Integer> choiceIt = nodeHit.choices.iterator();
                while (choiceIt.hasNext()) {
                    n32 = choiceIt.next();
                    node3 = this.graph.get(n32);
                    if (node3 == null || !this.hitCable(nodeHit, 0, node3, 0, n, n2)) continue;
                    n5 = nodeHit.id;
                    n6 = 0;
                    n7 = node3.id;
                    n8 = 0;
                    n9 = -1852043;
                    break block0;
                }
                Iterator<Integer> triggerIt = nodeHit.triggers.iterator();
                while (triggerIt.hasNext()) {
                    n32 = triggerIt.next();
                    node3 = this.graph.get(n32);
                    if (node3 == null || !this.hitCable(nodeHit, 0, node3, 0, n, n2)) continue;
                    n5 = nodeHit.id;
                    n6 = 0;
                    n7 = node3.id;
                    n8 = 0;
                    n9 = -3703297;
                    break block0;
                }
                if (nodeHit.type != 13) continue;
                for (int i = 0; i < nodeHit.randomBranches.size(); ++i) {
                    n32 = nodeHit.randomBranches.get(i);
                    if (n32 < 0 || (node3 = this.graph.get(n32)) == null || !this.hitCable(nodeHit, i, node3, 0, n, n2)) continue;
                    n5 = nodeHit.id;
                    n6 = i;
                    n7 = node3.id;
                    n8 = 0;
                    n9 = -5745161;
                    break block0;
                }
            }
        }
        Iterator<NpcDialogueGraph.Node> nodeIt = this.graph.nodes.values().iterator();
        while (nodeIt.hasNext()) {
            NpcDialogueGraph.Node node4;
            NpcDialogueGraph.Node node5;
            NpcDialogueGraph.Node node6;
            node2 = nodeIt.next();
            if (node2.next >= 0 && (node6 = this.graph.get(node2.next)) != null) {
                int n11 = n32 = node6.type == 3 && node2.type == 4 ? 1 : 0;
                if (n5 != node2.id || n6 != 0 || n7 != node6.id || n8 != n32) {
                    int n12 = node2.type == 3 ? -11870592 : (node2.type == 4 ? -290244 : (node2.type == 5 ? -13315175 : (node2.type == 6 ? -770210 : (node2.type == 7 ? -278748 : (node2.type == 8 ? -5796870 : (node2.type == 9 ? -1292135 : (node2.type == 10 ? -680437 : (node2.type == 11 ? -8286984 : (node2.type == 12 ? -13773633 : (node2.type == 0 ? -9389850 : (node2.type == 1 ? -1852043 : -3703297)))))))))));
                    n4 += this.cable(bufferBuilder, matrix4f, node2, 0, node6, n32, n12, false);
                }
            }
            if (node2.type == 3 && node2.falseNext >= 0 && (node5 = this.graph.get(node2.falseNext)) != null && (n5 != node2.id || n6 != 1 || n7 != node5.id || n8 != 0)) {
                n4 += this.cable(bufferBuilder, matrix4f, node2, 1, node5, 0, -495247, false);
            }
            if (node2.type == 3 && node2.varInputNode >= 0 && node2.varInputNode != node2.next && (node4 = this.graph.get(node2.varInputNode)) != null && (n5 != node4.id || n6 != 0 || n7 != node2.id || n8 != 1)) {
                n4 += this.cable(bufferBuilder, matrix4f, node4, 0, node2, 1, -290244, false);
            }
            if (node2.type == 13) {
                for (int i = 0; i < node2.randomBranches.size(); ++i) {
                    NpcDialogueGraph.Node node7;
                    n32 = node2.randomBranches.get(i);
                    if (n32 < 0 || (node7 = this.graph.get(n32)) == null || n5 == node2.id && n6 == i && n7 == node7.id && n8 == 0) continue;
                    n4 += this.cable(bufferBuilder, matrix4f, node2, i, node7, 0, -5745161, false);
                }
            }
            for (int choiceId : node2.choices) {
                NpcDialogueGraph.Node node8 = this.graph.get(choiceId);
                if (node8 == null || n5 == node2.id && n6 == 0 && n7 == node8.id && n8 == 0) continue;
                n4 += this.cable(bufferBuilder, matrix4f, node2, 0, node8, 0, -1852043, false);
            }
            for (int triggerId : node2.triggers) {
                NpcDialogueGraph.Node node9 = this.graph.get(triggerId);
                if (node9 == null || n5 == node2.id && n6 == 0 && n7 == node9.id && n8 == 0) continue;
                n4 += this.cable(bufferBuilder, matrix4f, node2, 0, node9, 0, -3703297, false);
            }
        }
        if (n5 >= 0) {
            NpcDialogueGraph.Node hotA = this.graph.get(n5);
            NpcDialogueGraph.Node hotB = this.graph.get(n7);
            if (hotA != null && hotB != null) {
                n4 += this.cable(bufferBuilder, matrix4f, hotA, n6, hotB, n8, n9, true);
            }
        }
        NpcDialogueGraph.Node linkNode;
        if (this.linkFrom >= 0 && (linkNode = this.graph.get(this.linkFrom)) != null) {
            double d = this.canvas.portScreenX(linkNode, true);
            double d2 = this.canvas.portScreenY(linkNode, true, this.linkFromPort);
            n4 += this.curve(bufferBuilder, matrix4f, d, d2, n, n2, -1511948, false);
        }
        if (n4 > 0) {
            BufferUploader.drawWithShader(bufferBuilder.buildOrThrow());
        } else {
            bufferBuilder.build();
        }
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private boolean hitCable(NpcDialogueGraph.Node node, int n, NpcDialogueGraph.Node node2, int n2, double d, double d2) {
        return this.canvas.hitCable(node, n, node2, n2, d, d2);
    }

    private int cable(BufferBuilder bufferBuilder, Matrix4f matrix4f, NpcDialogueGraph.Node node, int n, NpcDialogueGraph.Node node2, int n2, int n3, boolean bl) {
        double d = this.canvas.portScreenX(node, true);
        double d2 = this.canvas.portScreenY(node, true, n);
        double d3 = this.canvas.portScreenX(node2, false);
        double d4 = this.canvas.portScreenY(node2, false, n2);
        double d5 = Math.max(25.0 * this.canvas.zoom, Math.abs(d3 - d) * 0.45);
        if (Math.max(d, d3) + d5 < (double)this.canvas.left || Math.min(d, d3) - d5 > (double)this.canvas.right || Math.max(d2, d4) < (double)this.canvas.top || Math.min(d2, d4) > (double)this.canvas.bottom) {
            return 0;
        }
        return this.curve(bufferBuilder, matrix4f, d, d2, d3, d4, n3, bl);
    }

    private int curve(BufferBuilder bufferBuilder, Matrix4f matrix4f, double d, double d2, double d3, double d4, int n, boolean bl) {
        double d5 = Math.max(25.0 * this.canvas.zoom, Math.abs(d3 - d) * 0.45);
        double d6 = d;
        double d7 = d2;
        double d8 = this.canvas.zoom < 0.3 ? Math.max(0.45, this.canvas.zoom / 0.3 * 0.85) : 1.0;
        int n2 = 0;
        if (bl) {
            double d9 = d8 + Math.max(1.2, 1.6 * Math.min(1.0, this.canvas.zoom));
            int n3 = 0x88000000 | n & 0xFFFFFF;
            d6 = d;
            d7 = d2;
            for (int i = 1; i <= 20; ++i) {
                double d10 = (double)i / 20.0;
                double d11 = 1.0 - d10;
                double d12 = d11 * d11 * d11 * d + 3.0 * d11 * d11 * d10 * (d + d5) + 3.0 * d11 * d10 * d10 * (d3 - d5) + d10 * d10 * d10 * d3;
                double d13 = d12 - d6;
                double d14 = d11 * d11 * d11 * d2 + 3.0 * d11 * d11 * d10 * d2 + 3.0 * d11 * d10 * d10 * d4 + d10 * d10 * d10 * d4;
                double d15 = d14 - d7;
                double d16 = Math.sqrt(d13 * d13 + d15 * d15);
                if (d16 > 0.001) {
                    double d17 = -d15 / d16 * d9;
                    double d18 = d13 / d16 * d9;
                    bufferBuilder.addVertex(matrix4f, (float)(d6 + d17), (float)(d7 + d18), 0.0f).setColor(n3);
                    bufferBuilder.addVertex(matrix4f, (float)(d6 - d17), (float)(d7 - d18), 0.0f).setColor(n3);
                    bufferBuilder.addVertex(matrix4f, (float)(d12 - d17), (float)(d14 - d18), 0.0f).setColor(n3);
                    bufferBuilder.addVertex(matrix4f, (float)(d12 + d17), (float)(d14 + d18), 0.0f).setColor(n3);
                }
                d6 = d12;
                d7 = d14;
            }
            n2 += 20;
            double d19 = d8 + 0.5;
            int n4 = n >> 16 & 0xFF;
            int n5 = n >> 8 & 0xFF;
            int n6 = n & 0xFF;
            int n7 = Math.min(255, n4 + (int)((float)(255 - n4) * 0.75f));
            int n8 = Math.min(255, n5 + (int)((float)(255 - n5) * 0.75f));
            int n9 = Math.min(255, n6 + (int)((float)(255 - n6) * 0.75f));
            int n10 = 0xFF000000 | n7 << 16 | n8 << 8 | n9;
            d6 = d;
            d7 = d2;
            for (int i = 1; i <= 20; ++i) {
                double d20 = (double)i / 20.0;
                double d21 = 1.0 - d20;
                double d22 = d21 * d21 * d21 * d + 3.0 * d21 * d21 * d20 * (d + d5) + 3.0 * d21 * d20 * d20 * (d3 - d5) + d20 * d20 * d20 * d3;
                double d23 = d22 - d6;
                double d24 = d21 * d21 * d21 * d2 + 3.0 * d21 * d21 * d20 * d2 + 3.0 * d21 * d20 * d20 * d4 + d20 * d20 * d20 * d4;
                double d25 = d24 - d7;
                double d26 = Math.sqrt(d23 * d23 + d25 * d25);
                if (d26 > 0.001) {
                    double d27 = -d25 / d26 * d19;
                    double d28 = d23 / d26 * d19;
                    bufferBuilder.addVertex(matrix4f, (float)(d6 + d27), (float)(d7 + d28), 0.0f).setColor(n10);
                    bufferBuilder.addVertex(matrix4f, (float)(d6 - d27), (float)(d7 - d28), 0.0f).setColor(n10);
                    bufferBuilder.addVertex(matrix4f, (float)(d22 - d27), (float)(d24 - d28), 0.0f).setColor(n10);
                    bufferBuilder.addVertex(matrix4f, (float)(d22 + d27), (float)(d24 + d28), 0.0f).setColor(n10);
                }
                d6 = d22;
                d7 = d24;
            }
            return n2 += 20;
        }
        d6 = d;
        d7 = d2;
        for (int i = 1; i <= 20; ++i) {
            double d29 = (double)i / 20.0;
            double d30 = 1.0 - d29;
            double d31 = d30 * d30 * d30 * d + 3.0 * d30 * d30 * d29 * (d + d5) + 3.0 * d30 * d29 * d29 * (d3 - d5) + d29 * d29 * d29 * d3;
            double d32 = d31 - d6;
            double d33 = d30 * d30 * d30 * d2 + 3.0 * d30 * d30 * d29 * d2 + 3.0 * d30 * d29 * d29 * d4 + d29 * d29 * d29 * d4;
            double d34 = d33 - d7;
            double d35 = Math.sqrt(d32 * d32 + d34 * d34);
            if (d35 > 0.001) {
                double d36 = -d34 / d35 * d8;
                double d37 = d32 / d35 * d8;
                bufferBuilder.addVertex(matrix4f, (float)(d6 + d36), (float)(d7 + d37), 0.0f).setColor(n);
                bufferBuilder.addVertex(matrix4f, (float)(d6 - d36), (float)(d7 - d37), 0.0f).setColor(n);
                bufferBuilder.addVertex(matrix4f, (float)(d31 - d36), (float)(d33 - d37), 0.0f).setColor(n);
                bufferBuilder.addVertex(matrix4f, (float)(d31 + d36), (float)(d33 + d37), 0.0f).setColor(n);
            }
            d6 = d31;
            d7 = d33;
        }
        return 20;
    }

    private /* synthetic */ void lambda$widgets$46(List list, NpcDialogueGraph.Node node, int n) {
        this.remember();
        if (n >= 0 && n < list.size()) {
            node.animBone = (String)list.get(n);
        }
        this.changed();
        this.widgets();
    }

    private static final class Label {
        final String key;
        final int x;
        int y;

        Label(String string, int n, int n2) {
            this.key = string;
            this.x = n;
            this.y = n2;
        }
    }
}

