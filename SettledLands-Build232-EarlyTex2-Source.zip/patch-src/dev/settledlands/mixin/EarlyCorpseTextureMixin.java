package dev.settledlands.mixin;

// ЭКВИВАЛЕНТ скомпилированного миксина build 231 (в jar лежит собранный байткод;
// сборка — tools/patch_earlytex_mixin.py, компилятора Java в песочнице нет).
// Класс-файл: major 65, без ветвлений (StackMapTable не требуется),
// Mixin пересчитывает фреймы сам (ClassWriter COMPUTE_FRAMES).

import java.util.Objects;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.settledlands.npc.GuideNpc;

@Mixin(GuideNpc.class)
public class EarlyCorpseTextureMixin {

    @Inject(method = "applyProfile()V", at = @At("HEAD"), require = 0)
    private void settledlands$earlyTexture(CallbackInfo ci) {
        // данные берём из public profile(); поля entityData и DATA_TEXTURE —
        // приватные, но после merge код находится ВНУТРИ GuideNpc, поэтому доступ легален.
        String t = Objects.toString(this.profile().texture, "");
        this.entityData.set(GuideNpc.DATA_TEXTURE, t);
        System.out.print("[SettledLands] corpse texture pre-set: ");
        System.out.println(t);
    }
}
