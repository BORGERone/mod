# AI-GUIDE — актуальное состояние build 263 (cutscene fade)

Сначала `START-HERE-RU.md` → `HANDOFF-NEXT-SESSION-RU.md` → этот файл; затем обновлять `SESSION-STATE.md`. Отвечать по-русски. Видео не просить.

## Build 263 — текущий релизный кандидат

Baseline Build 262 SHA `21fc8fa7c861c3652f020ce9bb10bac133ac253675084982e65f16cc734f2531`. В инспекторе CUTSCENE-ноды две независимые галки. Строгая последовательность: затемнение до полного чёрного, затем запуск камеры/playing, и только после сигнала playing — проявление. Фаза 500 мс. Fade-out-only мгновенно открывается при старте; fade-in-only ждёт старта на чёрном; timeout не даёт потерянному сигналу навсегда оставить чёрный. `animLoop`/`moveEscort` не используются; Node.copy и NBT сохраняют два отдельных флага.

Build263 UI-regression remains open. Build262 works for the user. Original Build263 candidate `03e3d9c9152adaf7b8afeb3c6a7693787987221a825944aad445f03a1830c716` showed a blank inspector body/mismatched header. Candidate `293a22505849b92cec191d66fafe189cd401dc66b7a7f17904d79d057af03bc0` included `@Shadow node()` and the user then reported the right panel disappeared. Candidate c80 `c80fa6948ef3817b04922542a0de70c03bb0ce06d95f928bd033d771e5aed13b` restored the panel but the user now reports its selected Reply #0 body is blank (screenshot `image-5.png`). Do not ask for JAR SHA again; user explicitly refuses. `latest-4.log` is from earlier `(3).jar`, confirms Build263 version but is not the log from c80 screenshot. No root cause is established. Next AI should inspect screen widgets/render/selection lifecycle and mixin transformation versus exact Build262; no speculative patch. Preserve independent fade toggles, 500ms phase, camera after full black, fade-in after playing signal. Technical gates cannot prove UI. No video.

`tools/jvm_verify.py` поддерживает primitive, reference и array parameter types, включая multidimensional arrays. `tools/smt.py` при вставках StackMapTable сдвигает frame PCs и offsets `Uninitialized_variable_info`. Не обходить `classedit.py`.

## Build 262 — историческая база

Baseline Build 261 SHA `979d64831b47336a84a72ec0d803da4f19d5ee6e1fdb85e542e7e08b03647df6`. `runMobilityAndAutoAi` сохраняет yaw корпуса/entity по горизонтальному вектору шага до idle tick. После остановки голова плавно сканирует случайные цели; корпус и entity yaw медленно следуют за ними. Это убирает мгновенный обратный разворот и даёт поворот торса. Диалог, бой, active navigation/movement и player-look сохраняют приоритет. Renderer Build 261 побайтово сохранён; его transient movement-facing override восстанавливает состояние как прежде.

Build 262 JAR `settledlands-0.8.0-build262-smooth-npc-turning.jar`, 2 260 085 байт, SHA-256 `21fc8fa7c861c3652f020ce9bb10bac133ac253675084982e65f16cc734f2531`. `tests/gate_build262.py` и independent backup gate PASS; Java 21 runtime покрывает stop transition, первый небольшой torso step, случайные ranges головы/корпуса, dialogue priority и inherited AI/combo, плюс Build 261 render/first-person regression. Minecraft/NeoForge/modpack НЕ запускались — нужен пользовательский тест по `CHECKLIST-TEST-BUILD262-RU.md`, видео не просить.

## Build 261 — исторический релизный кандидат

Точный baseline Build 260 (`8d47171845652c1a3499643ca1936a7d6b742d9e88811751d94d84bef47d2ebc`). `NpcAutoAiEngine255.tickIdleLookAround` медленно/случайно меняет только yaw головы, когда NPC действительно idle; игрок, диалог, бой, маршрут и движение имеют приоритет. Для Ivy при доступном EMF/ETF один Fresh Animations/TnM bridge остаётся активным также в разговоре и при full-body Blockbench-клипе. Клип накладывается поверх FA/TnM, а обе ноги при реальном перемещении сохраняют базовую gait-позу. При отказе optional animation stack остаётся BBModel actor fallback.

First-person compatibility: добавлен client mixin на `ItemInHandRenderer.renderHandsWithItems` и possession-context для прямого `PlayerModel` рендера; так руки/texture NPC могут заменить Steve, даже когда first-person мод не идёт через `RenderArmEvent` или PAL marker. Код не зависит от классов Punchy и имеет `require=0`. Версия Punchy пользователя неизвестна, сам Punchy и игра не запускались: не выдавать тестовое покрытие за подтверждение конкретного mod build; обязательно отправить чеклист.

`tests/gate_build261.py` PASS: reproducible JAR, точный seven-changed + one-added diff, структуру JAR/TOML/mixins, текущий 1.21.1 boolean ABI, idle-angle/body invariant, hurt→dialogue/full-body custom clip + locomotion fixture, first-person NPC texture/animated arm fixture и inherited AI checks. Real Minecraft/NeoForge/full modpack не запускались.

## Build 260 — историческая база и сохранённые требования

User reports и исправления: у обычного `GuideNpc` default ambient/hurt/death фактически были Skeleton sounds; заменены на Villager events. Тумблер «смотрит на игрока» раньше делал `LookControl.setLookAt`, тем самым поворачивая всё тело при walking; заменено на `lookHeadAtPlayer`. `shouldLookAtPlayer` принимает toggle OR `npc.isTalking()`, а оба рендер-режима пропускают head-yaw suppression во время диалога. Во время горизонтальной наземной ходьбы `NpcMotionBridge256` временно выравнивает корпус по `getDeltaMovement()` независимо от toggle, затем восстанавливает все body yaw значения.

`settledlands-0.8.0-build260-npc-facing-sounds.jar`: 2 257 565 байт, SHA-256 `8d47171845652c1a3499643ca1936a7d6b742d9e88811751d94d84bef47d2ebc`; source ZIP: 9 549 285 байт, SHA-256 `44ff3e8bb1f5a4c0c3e58c5bce9ddcede205085168b063ca9cd30dfc3e619c5a`. Build260 строится от build259 `ab44f422a423a428f198ae4393e55ad8409857e10e85674d1ccfa093790f5da7`. Exact five-entry diff: Engine, GuideNpc, renderer bridge, TOML, patch-info; 418 entries unchanged. Build258 `removeModifier(ResourceLocation)Z`, build259 Ivy multi-hit combos, +10% calm speed, Stats/Auto-AI/wander/return остаются.

`tests/gate_build260.py` основной и распакованный gates PASS; Java21 verifier, sound refs, profile/dialogue/toggle/head-only runtime fixtures, exact diff/rebuild, 5 negative controls. Настоящий Minecraft/NeoForge/modpack НЕ запускался: обязательно просить user проверить ambient/hurt/death, torso path facing при toggle ON/OFF и dialogue look при OFF на копии мира по чеклисту. Видео не просить.

Source zip `SettledLands-Build260-NpcFacingSounds-Source.zip`, manifest обязателен. Только branch `arena/24676dbe-mod`; перед ответом сверить hashes/sizes. JAR download link первой, ZIP следующей, открыть JAR последним.

---

## История инцидента:---

## История инцидента: Build 257 ABI mismatch / Build 258 hotfix

Пользователь сообщил «вылет» на build 257. В Minecraft 1.21.1 / NeoForge 21.1.253 / Java 21.0.7 fatal был `NoSuchMethodError: void AttributeInstance.removeModifier(ResourceLocation)` на первом NPC server AI tick. Реальная сигнатура `removeModifier(ResourceLocation)` возвращает `boolean`; build257 synthetic API stub ошибочно объявил `void`, из-за чего предыдущие тесты воспроизвели ошибку стенда. Признавать это как свою ошибку тестового контракта, не обвинять пользователя/модпак. Build257 отозван, SHA `93013d8380263c3fdc4f5245a6ce4178f30bcda61478081bd9d10c93e42c45b1`.

Build258 исправил точный boolean ABI и прошёл основной/backup gate. Build259 основан на этом исправлении и сохраняет call descriptor `(ResourceLocation)Z`; не откатывать и не менять ABI stub обратно. Crashlog не включать в Git/backup; его SHA сохранён в истории.

---

## История build 252–254 (253 подтверждена в игре; 254 — UI/нода характеристик и дефолт ivy_oleander)

Пользователь подтвердил в игре исправления **build 251** (3-е лицо Иви, ползание под люком, сохранение вселённой модели после перезахода) и запросил исправление **ударов мечом от первого лица** с HnS (`2.0-beta2.5`) + Touch’n Motion (`1.0.4`), где меч бил вниз под себя и `BladeTracker` не дотягивался до моба спереди. Собрана детерминированная от точной 251 сборка **`settledlands-0.8.0-build252-fp-hns.jar`**: 1 627 973 байт, SHA-256 `29a0e6e6245d9a906865a4020cf0f2c4532e3a488914260bf9d80df4e57dbc3d`. Ничего не выдавать без полного `tests/gate_build252.py` (включая 251–237/§8) и независимого повтора из распакованного `SettledLands-Build252-FirstPersonHnS-Source.zip`, проверки `BACKUP-MANIFEST.sha256` и итоговых внешних логов `GATE-RESULT-252.txt` / `GATE-BACKUP-RESULT-252.txt`.

Код 252: `src/build252/dev/settledlands/model/{FirstPersonSwordBridge252,FirstPersonPalEmfAccess252}.java`, `tools/gen_api252.py`, `tools/patch_fp_hns252.py`, стенд `tests/java252-fp/` + `tests/jvm_fp_sword252.py` и мутанты `tests/mutants_fp252.py`. В `PlayerBodyRenderer.onRenderPlayerPre` изменён только вход на смещении `0` (до `isSpectator`/`isInvisible`/`modelKey`/`isFirstPerson`), без прямых байткодных ссылок на `ModList`/`EMF`/`PAL`; методы `ModContainer`/`IModInfo` берутся строго с публичных интерфейсов (JPMS Java 21). В проходе 1-го лица `FirstPersonMode.THIRD_PERSON_MODEL` для 5 слоёв HnS `PRE_HOOK` на индексе `0` (до `EMFCompatAnimationHook`) снимает позу PAL 12 ванильных частей + `root`, а `POST_HOOK` на индексе `size - 1` (после `TouchNMotionHook` и любых поздних хуков) восстанавливает их и сбрасывает кастомные JEM-подчасти через `resetPose()` + `isSetByAnimation = false` (исключая перенос сгибов из `F5`). Все классы 251 (`BbModel`, `PlayerMotionBridge`, `HackSlashAccess`, `FreshEmfAccess`, `PossessionSystem`, `PossessionLoginSync251`, `GuideRenderer`) и механики 247–243 сохранены байт-в-байт. Touch’n Motion для самих NPC (`GuideNpc`) не реализован; реальный клиент Minecraft/NeoForge не запускался. Детали — `API-COMPAT-252-RU.md`, команды — `BACKUP-252-RU.txt`, чеклист — `CHECKLIST-TEST-BUILD252-RU.md`. Сторонние JAR, HnS/ресурсы, лог пользователя и исходники Gson не включать в Git/backup. Работать и пушить только в закреплённую ветку `arena/24676dbe-mod`; в ответе по-русски краткий чейнджлог перед JAR, затем backup с размерами и SHA, основной JAR показать последним через `present_file`.

---

## История build 251 (подтверждены 3-е лицо, ползание и перезаход; 1-е лицо исправлено в 252)

Цель 251: исправление ползания, в том числе под люком, поддержка ударов установленного Hack and Slasher от 3-го лица и исчезновения вселённой модели при перезаходе, сохраняя FA Player Extension + TnM, внешность NPC и механики. `settledlands-0.8.0-build251-crawl-hns.jar`: 1 616 133 байт, SHA-256 `a3be663ea42de11e815b67b710e589bb92dd2752eb6fbd0d5408fdba3c9d256a`.

Код: `src/build251/dev/settledlands/model/{PlayerMotionBridge,HackSlashAccess}.java`, `src/build251/dev/settledlands/npc/PossessionLoginSync251.java`, `tools/gen_api251.py`, `tools/patch_player_motion251.py`; базовый `FreshEmfAccess` не изменён. Login передаёт реальные server-authoritative model/name/UUID, пустую запись при отсутствии вселения, и не изменяет состояние тела. Vanilla swim root восстанавливается после yaw, PAL-части после FA→TnM до retarget Ivy, PAL item-позиции/вращения/масштаб в охраняемом item renderer. PAL только HnS `2.0-beta2.5`/PAL `1.1.6+mc.1.21.1`, при активном слое и без HnS-дополнения EMF Compat; применяется весь активный PAL stack. Подробные обоснование, exact ZIP diff, порядок, guards, классы и пределы тестов: `API-COMPAT-251-RU.md`.

Команды входов, сборки, полного `tests/gate_build251.py`, отдельного `tests/jvm_hns_modifiers251.py`, manifest и повтора — `BACKUP-251-RU.txt`. Весь gate включает старую цепочку 250→237/§8, бинарный validator, точный diff и negative controls, JVM 251/реальные EMF/TnM/PAL и 39 пользовательских HnS JSON, 37 новых и 21 FA-мутантов, настоящий login/codec/client handler/renderer и 9 мутантов синхронизации. Отдельный тест загружает четыре подлинных HnS modifiers + 4 отрицательных контроля, но только в частичном сценарии с искусственным боевым состоянием. Реальные MC/NeoForge, полный HnS-controller и визуал не проверены. Все сторонние JAR, HnS JSON/ресурсы, пользовательский лог и исходники Gson — внешние входы, не включать в Git/backup.

Сохранить 247/246/245/244: ограничение урона и молока, характеристики, гравитацию, mob-ignore, возвраты в своё тело за 9 изумрудов без очереди, −4/−8/−16 от максимума HP и обычный дроп на четвёртой смерти, предметы/поводок. Труп не нежить и неуязвим; труп не появляется после смерти невселённого игрока. Причина старого отказа при `культ=1` не установлена; probe только читает данные. NPC/TnM и первое лицо остаются незавершёнными, UV-причина не доказана.

Ориентироваться на `README-Build251-CrawlHnS-RU.txt` и чеклист для пользователя. В игре оставить **один** SettledLands JAR; старые 245 и 250 ранее лежали вместе. Никаких видео не требовать. Статус визуала отмечать честно. Ответы короткие по-русски, перед ссылкой на новый JAR — краткий чейнджлог; затем backup с размером и SHA. JAR открыть через `present_file` последним. Работать/пушить только ветку текущей сессии.

---

# История и постоянные технические правила (сборки 250 и ранее)

Нижеследующие просьбы/статусы относятся к указанной старой сборке, в том числе старые просьбы о видео или ресурсах; их нельзя считать текущими инструкциями.

**Build 250 — эксперимент, оба полных gate PASS:** `settledlands-0.8.0-build250-fresh-motion.jar`, 1 608 517 байт, SHA-256 `2187bd12cbbd252570280c850c665945d6ad87b929fd80a4f400217e4c11082d`; backup `SettledLands-Build250-FreshMotion-Source.zip`, 35 372 945 байт, SHA-256 `72acc37e6275f6a706852f405532ed8f2d99652759f816fec43cd2916691a4de`. Основной gate 250 PASS (`GATE-RESULT-250.txt`, включает проверенный полный 249 gate), дополнительно свежий 249–237/§8 PASS (`GATE-BASE-RESULT-250.txt`). Из независимо распакованного backup полный gate 250–237/§8 завершён PASS (`GATE-BACKUP-RESULT-250.txt`), manifest 380/380 и побайтное воспроизведение ZIP PASS. Снимок архива создан до окончания gate, окончательные логи снаружи. JAR и ZIP перед выдачей сверить по SHA и в удалённой ветке; JAR в ответе до backup и открыть последним.

Пользователь выбрал установленный Fresh Animations: Player Extension + Touch'n Motion, а не ванильную основу 249. Реализован изолированный EMF-риг игрока, TnM вызывается собственным хуком EMF однократно; при успехе зашитые player-clips пропускаются. При нераспознанном/отключённом FA и обнаруженном совместимом TnM используется нейтральная поза; при отсутствии/несовместимости TnM или аварийном отключении сохраняется старый рендер. Сигнатура проверена на стороннем зеркале FA 1.0; источник не доказан. Marker содержится в a_player_variables.jpm, а не в основном player.jem как animKey. Пак пользователя, настоящий EMF 3.3.9, Minecraft/NeoForge и визуальный результат НЕ проверены; EMF 3.3.12 root с идентичными upstream исходниками и настоящий TnM 1.0.4 hook проверены только с синтетическими API. NPC и первое лицо TnM не поддерживают, UV не исправлена/не проверена. Прочитать README/API-COMPAT/CHECKLIST 250. Попросить игровую проверку, свежий latest.log и при проблеме ресурс-пак/скриншоты; не выдавать синтетическую анимацию за подтверждённый FA.




Читать после `START-HERE-RU.md` и `HANDOFF-NEXT-SESSION-RU.md`, затем `SESSION-STATE.md`. Язык ответов — русский. В текущей сессии артефакты и push только в закреплённую `arena/24676dbe-mod`; в следующей сессии использовать её системно заданную ветку.

**Эксперимент 249:** `settledlands-0.8.0-build249-player-motion.jar` SHA `904ea1cb82c43735ec6f18dce60382c0ccafe7654045556fe1dccee10187b272`; полный gate и независимый повтор прошли (`GATE-RESULT-249.txt`, `GATE-BACKUP-RESULT-249.txt`); backup 33 734 991 байт, SHA `d03b618f09154267d22c2d7374bc965aa1d85dc344c3ab9ab986285c4ba8cef9`, manifest 325/325 и воспроизведение ZIP проверены. По выбору пользователя оригинальные клипы игрока при активном мосте пропускаются, ванильная модель даёт базу TnM 1.0.4, дельта переносится с ванильных pivot на вложенные Ivy-кости. Не заявлять, что UV исправлена: ресурсы/PNG совпадают с 247, визуальную причину не установили и игру не запускали. NPC и первое лицо не поддержаны. Проверки и ограничения — README/API-аудит/чеклист 249; каждый release требует полных gate/backup, без обмана игровыми стендами.

**Эксперимент 248, игрок-only:** `settledlands-0.8.0-build248-touchmotion-player.jar` SHA-256 `a07262fb01223f5418e124bd4ad4715d4b8d23bdc318d9ec324c46970e5ed782`; `src/build248/`, `tools/patch_touchmotion248.py`, `tests/gate_build248.py`. Пользователь хотел и NPC, но они НЕ реализованы; руки от первого лица тоже. Реальные Minecraft/NeoForge и игра не запускались. В JAR не включать JOML, TnM, игровые API-стенды; JOML MIT-исходники и тестовая лицензия доступны отдельно. Внешний TnM GPL 1.0.4 нужен отдельно для полного теста и не включён в backup. Виртуальные кости, математика JOML, 24 сценария, 1200 поз, 23 мутанта и реальные TnM FootGrounding/TorsoLean со стендами не заменяют реальную игровую проверку. Основной и независимый gate завершились PASS, manifest 247/247 и воспроизведение ZIP прошли; логи `GATE-RESULT-248.txt` и `GATE-BACKUP-RESULT-248.txt`. Детали — README/API-аудит/чеклист 248. В ответе — JAR перед backup и честное ограничение NPC.

**История 247:** JAR SHA-256 `c3130e136018342d133b710812e6c86fc0fcf5f181146c6973f055abba3798f1`; исходник `src/build247/`, патчер `tools/patch_bodiless247.py`, test-only API `tools/gen_api247.py`. В Верхнем мире отменяются удары и урон с узнаваемым бестелесным виновником, от него не применяются яд/иссушение/голод; в чистилище бой разрешён. Только удаление бестелесности молоком блокируется через NeoForge `MobEffectEvent.Remove`, не запрещать обычное удаление или вселение. Огонь, лава, падение и чужой код без виновника не гарантируются. Унаследованный код 246 не менялся. Прочитать README 247, API-аудит и начало HANDOFF; полный gate 246–237/§8 и независимый повтор из backup прошли, логи — `GATE-RESULT-247.txt` и `GATE-BACKUP-RESULT-247.txt`. Новая функциональная JVM-fixture + 17 негативных мутантов используют synthetic API, не настоящий Minecraft/NeoForge; фактический игровой bus и mixin не проверены.

**История 246:** JAR SHA-256 `fe62c48b5bfbb0607cf1fa1e9996649bcd90a144de57ca991dfb737ff78cc819`; новые исходники находятся в `src/build246/`, байткодный патчер — `tools/patch_npc_stats246.py`, компиляция нового кода использует лицензированный `tools/vendor/ecj-3.46.100.jar` и `tools/gen_api246.py`. Последний создаёт только силуэты API: они НЕ должны попасть в JAR. Старые указания ниже про отсутствие компилятора относятся к прежним сборкам. Механики и тесты 246, ограничения и команда полного воспроизведения — в начале HANDOFF и README 246. Полный gate 246/245–237/§8 прошёл на Java 21, включая 32 новых и 18 наследованных мутантов; полный повтор из независимого backup также PASS. Настоящие Minecraft/NeoForge и применение mixin не запускались. Только пользовательские игровые испытания подтверждают поведение в конкретной сборке модов.

**История после 245:** пользователь подтвердил работу 244. Build 245 добавляет общий штраф максимального HP −4/−8/−16 после 1/2/3 успешных платных возвратов в то же тело; четвёртая смерть без трупа с обычными правилами вещей и `keepInventory`. Самостоятельный выход не увеличивает износ, новый NPC сбрасывает. `BodyWear` использует namespaced modifier, сохраняет стандартные сторонние modifiers и пересчитывает максимум при dirty-событии; отменяет только старые fallback watches/PENDING/STOCK нужного владельца. Полный gate 245, вложенный 244–237/§8, Java 21 и 18 новых негативных мутантов прошли; синтетический API — не игра. Minecraft, NeoForge, реальное применение mixin и проверка конкретных модов здоровья не запускались. Актуальны README и чеклист 245 и начало HANDOFF.

Пользователь отменил FIFO. Алтарь возрождает любого доступного живого онлайн-владельца загруженного собственного тела текущей смерти у алтаря за 9 изумрудов, по одному за проверку; офлайн не блокирует, нет тела — нет алтарного возрождения. Привязка означает принадлежность, поводок необязателен. Обычная смерть не создаёт тело и не меняет обычный дроп; повторные смерти в чистилище не заменяют UUID исходного тела. Сохранять выдачу вещей, поводок, неуязвимость и отдельную NPC-механику. Причина отказа вселения при подтверждённом узле `культ=1` по-прежнему неизвестна; фактические NBT/effect/цель неизвестны, probe read-only, мост личных/общих очков не восстанавливать.

Не угадывать потерянный UUID старого тела. Известное исключение прежнего кода: после неудачного штатного спавна поздний fallback может создать тело без UUID текущей смерти; алтарь/передача pending могут не принять его. Этот путь не исправлен. Сделать копию мира, проверять новую смерть и ограничения README 245. Актуальные команды и статус — начало HANDOFF и §8; записи ниже являются историей.

**Уроки 244:** `EntityInteractSpecific` на клиенте отправляется на сервер до локального hook; PASS не доказывает, что сервер не получил пакет. Состояние гроба/поводка на клиенте может отставать. Для 244 specific возвращает PASS, а общий event потребляется после отправки; оба серверных пути и обе руки тестируются отдельно. Нельзя выдавать два конфликтующих списка или удалять тело раньше проверки происхождения pending. Диалог может запускаться из настоящего superclass `GuideNpc.mobInteract` через инструменты; отсекать только труп и проверять живого NPC. Поведенческие тесты с явными стендами и мутантами не заменяют настоящий NeoForge.

## 0. Главное правило (после инцидентов 230 / 231 / 233 / 234 / 236)
**Нерабочий jar дороже, чем отсутствие jar.** Любая сборка проходит шлюз проверок
(§2) ДО выдачи. Если проверку провести нечем — сначала сделать инструмент, потом сборку.
Никаких «должно работать»: только «проверено вот этим скриптом, вот этот вывод».

## 1. Что нельзя проверить в песочнице и как это компенсировать
Нет `javac`, нет классов Minecraft/NeoForge, нет запуска игры. Значит:
* нельзя вручную вставлять байты в `Code` существующих классов (сдвиги → невалидный класс); допустим только проверенный пересчёт `classedit.py`/`smt.py` и JVM-шлюз;
* нельзя писать код «на глаз» без структурной валидации;
* Mixin/ASM-этап эмулируется только нашими парсерами → они должны быть строгими (§2).

## 2. ШЛЮЗ ПЕРЕД ВЫДАЧЕЙ (обязательно, каждый билд)
1. **Калибровка**: `python3 tools/validate_jar.py <прошлый рабочий jar>` → должно быть
   «ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ». Если валидатор ругается на рабочий билд — сначала починить
   валидатор (ложные срабатывания так и ловятся).
2. `python3 tools/validate_jar.py <новый jar> --base <прошлый jar>` → «ПРОЙДЕНЫ» + дифф
   ровно тот, что задуман (лишних изменённых записей быть не должно).
3. `python3 tools/jvm_verify.py <jar> '<Class>#<method>' …` → «ИТОГ: OK» для КАЖДОГО
   изменённого класса. Это верификация настоящей JVM на синтетических заглушках
   (см. §11). Без неё правка `Code` не считается проверенной.
4. `python3 tools/selftest_probe.py` → допускается только «JVM-САМОТЕСТ: OK».
   Скрипт собирает **тот же** генератор, что идёт в jar, и грузит класс реальной JVM
   (`tools/jdkpkg/jdk4py/java-runtime/bin/java -Xshare:off`). Валидатора недостаточно:
   он проверяет структуру, но не верификацию JVM. Самотест обязан исполнять свой `main`
   и печатать ожидаемые маркеры (`selftest = A/B`, `obj = NULL`).
   Обязательно сверять, что байткод в jar == байткод, прогнанный самотестом
   (`build_probe_class(with_main=False)` vs `True` — должны совпадать кроме `main`).
5. `python3 tools/check_mixin_class.py <каждый новый самописный class>` → OK.
6. `tools/verify_jar.py <jar> --base ...` → zip/toml/lang/mixins/маркеры.
7. Только после этого — `present_file` (jar → zip → jar, чтобы основным остался jar) + sha256/размер + ссылка.
8. Отдельно: регресс-тест валидатора на заведомо сломанном jar, если он есть в репо
   (например `settledlands-0.8.0-build233-probe.jar` обязан валиться).
   Валидатор, который не ловит известный дефект, бесполезен.

Что именно проверяет `validate_jar.py` (весь jar, все классы):
структура до последнего байта; все индексы пула (this/super/interfaces/поля/методы/
атрибуты/операнды); операнды байткода по тегам; exception_table в границах кода; цели всех переходов (`if*`, `goto`, `tableswitch`,
`lookupswitch`) и `exception handler` — на границах инструкций;
полный разбор `Code`, `LineNumberTable`, `StackMapTable`, аннотаций, `SourceFile`,
`Signature`, `Nest*`, `InnerClasses`, `BootstrapMethods` и др.; версия 49..65;
миксины из JSON существуют; `@Mixin.value/targets` — массив.

## 3. Уроки по байткоду (дорого стоили)
* **Порядок сборки пула**: все `cp.utf8(...)` должны быть добавлены ДО `cp.dump()`.
  Инцидент 233: `SourceFile.sourcefile_index=79` при пуле 79 →
  `ClassReader.readUtf AIOOBE: Index 79 out of bounds for length 79` на скане NeoForge
  (игра падает ДО загрузки модов). Симптом в логе: `An error occurred scanning file Mod file: ...`.
* **Аннотации**: `@Mixin(value = X.class)` — это `Class<?>[]`, кодировать МАССИВОМ:
  `5b 0001 63 <utf8-дескриптор>`. Одиночный `63` → `ClassCastException: asm.Type -> Iterable`
  на `MixinInfo.readTargets` (инцидент 231). Форма `targets = {"..."}` — `5b 0001 73 <utf8>`.
  `method` (тег `s`) и `at` (тег `@`) одиночными работают — проверено на `GuideCorpseNameTagMixin`.
* **Не вставлять байты в `Code` вручную** (инцидент 230: AIOOBE на 11 миксинах).
  Допустимы правки равной длины и вставки только через `classedit.py`/`smt.py` с проверкой
  структуры, калибровкой и настоящей JVM, либо новый класс/миксин.
* Свой класс без ветвлений → `StackMapTable` не нужен (major ≥ 50).
  Свой класс С ветвлениями → либо major 49 (старый inference-верификатор), либо честные фреймы.
* `ldc` требует индекс ≤ 255 — следить, чтобы нужные записи пула не оказались дальше.
* `Component` в Minecraft 1.21 — интерфейс. Вызов его статического метода через `CONSTANT_Methodref` ведёт к `IncompatibleClassChangeError`; `invokestatic` на interface требует правильного InterfaceMethodref и версии класса ≥ 52. В major 49 build 238 уведомление создаётся через `new TranslatableContents(...)` + статический метод класса `MutableComponent.create`, как это делает vanilla `Component.translatable`. Проверять реальным исполнением, а не только верификацией.
* `Inventory.add(stack)` может при creative и заполненном инвентаре обнулить непоместившийся остаток, а boolean не доказывает полный перенос. Build 238 вставляет ограниченные порции в заведомо подходящий слот и сразу обновляет NBT `count`; сохраняет компоненты. `ItemStack.parse` использует `resultOrPartial` и может потерять частично разобранные модовые компоненты — при возврате использовать только полный `CODEC`/`DataResult.result()` и сохранять повреждённые записи.
* Vanilla `Entity.discard()` не делает смерть и сам по себе не возвращает привязанный поводок; 239 перед удалением использует тот же `GuideCorpseNpc.dropLeash(true, true)`, что и существующий `mobInteract`. Если список пуст на входе, это не успешный возврат: обычное тело не удалять. Для обнаружения преждевременного удаления нужны JVM-мутанты с неполным инвентарём, пустым телом и отключённым снятием поводка.
* UUID владельца + единственное тело поблизости не устанавливают, к какой смерти оно относится: рядом может быть старое тело. Build 241 записывает фактический UUID нового тела только после успешного спавна и копирует при клоне; старые/незагруженные тела не угадывает. Обычный алтарь при fallback всё равно расходует 9 по старому коду. Список ожидающих вещей имеет отдельную привязку к смерти: иначе старый список можно случайно выдать через новый труп. При конфликте двух списков сохранять оба, не объединять предполагаемые копии.
* Проверка `cult(npc) >= 1` сама по себе не защищала от вселения в неотмеченного NPC: раньше событие с HIGHEST-приоритетом копировало очки игрока в NPC до HIGH-проверки. Диагностировать весь путь и приоритеты событий; проверять отсутствие побочных записей по двум разным NPC и при положительных личных/общих очках. Build 240 отключает только handler моста; сохранённые ранее значения не мигрирует. JVM-fixture выполняет реальные методы на стендах, но не проверяет NeoForge event bus и игру.

## 4. Диагностика: сначала измерение, потом правка
* Сначала смотрим `latest.log` юзера (правило: сразу после «залил лог» — `git fetch origin`,
  `git checkout origin/main -- latest.log`, сверить версию мода в логе с тем, что выдавали).
* Если причина не доказана — собираем ЗОНД (только чтение), а не «ещё один фикс».
  Данные должны идентифицировать сущность и не спамить при чередовании разных сущностей. Глобальная дедупликация старого `TexProbe` этого не обеспечивает.
* Диагноз фиксируем в `SESSION-STATE.md` фактами из байткода/лога, а не гипотезами.

## 5. Оптимизация (требование юзера)
* Ноль лишней работы в per-frame/per-tick путях; при необходимости диагностика должна быть адресной и ограниченной. Старый `TexProbe` глобально смешивал сущности и заспамливал лог, поэтому его клиентский миксин отключён.
* Никаких `AABB` больше ~1e5 в этом модпаке (Sable `SubLevelInclusiveLevelGetter` отменяет
  такие запросы). Всемирный поиск — через `level.getAllEntities()`.
* Не плодить классы и лишние вызовы; не тащить `System.out` в горячие пути.
* Не «улучшать» попутно ничего, о чём не просили (правило PROPOSE-ONLY).

## 6. Дисциплина сборки
* Версия в `neoforge.mods.toml` — только после `tomllib`-валидации (урок 223).
* `settledlands.mixins.json`: общий список vs `client` — клиентские миксины (рендер,
  `GuideRenderer`) только в `client`.
* sha256 + размер каждого билда; `present_file` jar → zip → jar; в ответе прямая ссылка на jar перед backup.
* Отозванные билды оставлять в репо для истории и явно помечать «не выдавать».
* Дифф всегда озвучивать: сколько записей изменено и какие именно.

## 7. Что уже проверено опытом (не переисследовать)
* `GuideRenderer.renderCorpse` берёт модель из `GuideNpc.texturePath()` → `entityData(DATA_TEXTURE)`,
  NBT не читается (`/data merge ... Texture` бесполезен).
* `GuideNpc.applyProfile()` в 236/237 пишет `DATA_TEXTURE` в начале и ещё раз ближе к концу; вызывается из `setProfile()` (сам!), `readAdditionalSaveData()` и `PlayerCorpsePossession.dressBodyCorpse()`. В 237 добавленный предварительный вызов также меняет имя/видимость, масштаб/позу и делает `refreshDimensions`; нормальный и исключительные пути проверены на JVM со стендами, не в игре.
* `GuideCorpseFreezeMixin` (client, HEAD `renderCorpse`) для негроба при пустом или не содержащем `die` `anim` отменяет рендер и ничего не рисует. При `die` сам рисует модель, но если `getModel(...) == null`, тоже ничего не рисует. Гроб проходит без этой отмены.
* `BbModelStorage.findModelFile(name)`: `FMLPaths.GAMEDIR/settledlands/models`,
  сначала точное имя, иначе `name + ".bbmodel"` (если имя не оканчивается на `.bbmodel`).
* `GuideNpc.<init>` всегда создаёт profile (не null); `GuideCorpseNpc.defineSynchedData` зовёт super
  (DATA_TEXTURE у трупа зарегистрирован).
* Зонд build 232 подтвердил: на сервере `DATA_TEXTURE` = `provodnik.bbmodel` / `ivy_oleander.bbmodel`.

## 8. Журнал инцидентов
| Билд | Что случилось | Причина | Вывод |
|---|---|---|---|
| 230 | «Mod loading has failed», AIOOBE в 11 миксинах | вставка 14 байт в `Code` GuideNpc | не править `Code` существующих классов |
| 231 | FATAL на mixin prepare | `@Mixin.value` одиночным `c` | массивы в аннотациях |
| 233 | падение на скане мода (`ClassReader.readUtf`) | имя `SourceFile` добавлено в пул после `cp.dump()` | шлюз §2 + строгий валидатор |
| 236α | `VerifyError: Inconsistent args count operand` в самописной вставке | `invokeinterface`: count = objectref + слоты аргументов (для `info(String,Object,Object)` = 4, я поставил 3) | валидатор теперь сверяет count с дескриптором |
| 236β | код разъехался после вставки | `tableswitch` выравнивается по 4 байта от АБСОЛЮТНОГО адреса; вставка длиной 19 сдвинула padding | длина вставки всегда кратна 4 (добивается `nop`) |
| 234 | `VerifyError: Illegal target of jump or branch` в самописном `TexProbe.logObj`, краш при первом рендере трупа | смещение перехода считалось от операнда, а не от адреса опкода → прыжок в середину инструкции. Валидатор такое пропускал | считать `rel = label - opcode_pc`; валидатор обязан проверять, что цель перехода/`exception handler` лежит на границе инструкции; **JVM-самотест** (§2.3) для любого класса с ветвлениями |

## 9. Тон общения
Коротко, по делу, без оправданий и «простыней»: что случилось → почему → что сделано →
что проверить юзеру → ссылка на jar. Ошибку признавать сразу и конкретно.

## 10. Раздача билда: ссылки — обязательная часть ответа
Правило: **в каждом ответе, где упоминается собранный jar, ссылка присутствует.** Без
исключений («уже давал выше» не считается). Если юзер спрашивает «где ссылки?» — это
провал ответа, а не проблема юзера.

Для текущей сессии ветка `arena/24676dbe-mod`: ссылки на `raw.githubusercontent.com/BORGERone/mod/<ветка>/<файл>`, резерв `github.com/BORGERone/mod/raw/<ветка>/<файл>`. В следующей сессии подставлять закреплённую системную ветку. GitHub Contents API при размере >1 MiB возвращает пустой `content`, поэтому не является резервом скачивания.

Порядок: jar первым, zip вторым. GitHub Releases не использовать.
Всегда рядом: размер + sha256 + `certutil -hashfile <ФАЙЛ> SHA256` + напоминание
«Сохранить ссылку как…» (PowerShell/браузер иначе переименовывает `.jar`).
Проверять существование файла в ветке через `gh api ... --jq .size` ДО выдачи ссылки.
Ссылки оформлять **markdown-ссылками**, кликабельными: `[settledlands-...jar](https://raw...)`.
Не вставлять URL в блок кода и не давать «голым текстом» — юзер качает в один клик.
Ссылки — отдельным блоком в конце ответа, чтобы их было видно без прокрутки текста.

## 11. JVM-верификация на заглушках (главный инструмент)
`tools/jvm_verify.py <jar> 'dev/…/Class#method' ['…']`

Что делает: генерирует классы-заглушки для всех внешних типов (net/minecraft,
org/slf4j, …), подсовывает их JVM вместе с настоящим jar и вызывает метод через
рефлексию. Класс загружается без инициализации, метод разрешается по точной сигнатуре; `DECLARED` обязателен для каждой цели. `VerifyError`/`ClassFormatError` = провал, ошибка ДО `DECLARED` = непроверено. Ошибки вызова на синтетических заглушках после `DECLARED` не являются игровым тестом.

Калибровка (обязательно повторять после правок инструмента):

| jar | ожидание | факт |
|---|---|---|
| 230, `GuideNpc#applyProfile` | VerifyError | `Bad instruction` (неинициализированная локаль) |
| 234, `TexProbe#logObj(java.lang.String,java.lang.Object)` | VerifyError | `Illegal target of jump or branch` |
| 232/236, `GuideNpc#applyProfile` | OK | OK |
| 235, `TexProbe#logObj(java.lang.String,java.lang.Object)` | OK | OK |

Правила работы с `Code` (дополнение к §3):
* вставка обязана быть **кратна 4** (switch-и выравниваются от абсолютного адреса);
* `invokeinterface`: count = objectref + слоты аргументов;
* после вставки пересчитываются: переходы, `exception_table`, `LineNumberTable`,
  `StackMapTable` — `tools/classedit.py` + `tools/smt.py` (фреймы пересобираются
  с сохранением типов, меняется только delta);
* пересборка пула проверяется байт-в-байт (`patch_pool`) — если не совпала, сборка
  останавливается.

## 12. «Вылет» после раздачи: сперва проверить САМ ФАЙЛ
Порядок разбора (инцидент 27.10.2026, build 236):
1. `git fetch origin` → забрать новый `latest.log`.
2. Искать `is not a jar file`, `zip END header not found`, `UnionFileSystem`.
   Это **не баг мода**, это недокачанный файл. Не пересобирать, а дать
   PowerShell-команду `Invoke-WebRequest -OutFile` + сверку `Length` и `sha256`.
3. Только если jar на месте и валиден — смотреть дальше (VerifyError, FATAL).
Своя сторона тоже проверяется: `python3 -c "import zipfile;zipfile.ZipFile(p).testzip()"`,
наличие `PK\x05\x06`, размер = размер на GitHub (`gh api ... --jq .size`).
Битый скачанный файл лечится удалением из `mods` и повторной закачкой — не правкой кода.
