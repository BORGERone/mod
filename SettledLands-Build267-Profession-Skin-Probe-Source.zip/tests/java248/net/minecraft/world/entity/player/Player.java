package net.minecraft.world.entity.player; public class Player extends net.minecraft.world.entity.LivingEntity implements traben.entity_model_features.utils.EMFEntity {}
