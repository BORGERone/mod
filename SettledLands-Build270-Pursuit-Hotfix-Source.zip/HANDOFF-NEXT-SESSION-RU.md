# ПЕРЕДАЧА СМЕНЫ: SettledLands — Build270 Pursuit hotfix, нужен реальный запуск

## Инцидент Build269 и исправление

Пользовательский `latest-9.log` показал точную причину вылета Build269: `ScreenAccessorPursuit269` был Mixin-интерфейсом, направленным на класс `net.minecraft.client.gui.screens.Screen`; Mixin 0.8.7 завершил подготовку с `InvalidMixinException: @Mixin target type mismatch`. Build269 `settledlands-0.8.0-build269-pursuit.jar` отозван, не рекомендовать к установке. Причина в нашем коде, не в сторонних предупреждениях.

Build270 hotfix строится от опубликованного Build269 (SHA `5fdd2044dc9e52a7df1cc768b1489b72960f5c4c4263c66f8c249fc665028189`). `ScreenAccessorPursuit269` теперь abstract class-mixin на `Screen`; UI-mixin вызывает public invoker через reflection без interface-cast. Build269-функциональность преследования и Build268 база сохранены; Build263 fade исключён. В Build270 diff к Build269 ровно четыре записи: два class-файла, TOML и patch-info.

`tests/gate_pursuit270.py` PASS: чистая детерминированная пересборка, exact diff, проверка class-флага и target строки accessor, наличие `@Invoker`, JVM links и fixture рядов. Это не запускает Mixin/NeoForge/Minecraft. Требуется реальный запуск Build270 и проверка UI на копии мира по `CHECKLIST-TEST-BUILD270-RU.md`; до ответа пользователя считать hotfix кандидатом, не подтверждённым.

Выпускать только после проверки manifest, локального JAR/ZIP, push и удалённых размеров GitHub через `gh api`, а также Drive upload и удалённых размеров. JAR первым, ZIP вторым; SHA и `certutil -hashfile <file> SHA256`; ссылка «Сохранить ссылку как…» согласно §10. Работать только в `arena/24676dbe-mod`. Не менять Build269 артефакты; они остаются исторически отозванными.

---

# ПЕРЕДАЧА СМЕНЫ: SettledLands 0.8.0 — Build268, нужен игровой тест

## Build268: исправлен runtime visibility Mixin-аннотаций

Пользователь подтвердил штатное сообщение о сохранении графа. Байткод Build267: `GuideNpc.applyConfig` (GraphOnly) вызывает `setProfile`, который вызывает `applyProfile`; значит сохранение проходило.

Причина отсутствующих `[SL-PROFESSION-267]` установлена. Лог показывает SpongePowered Mixin 0.8.7. В helper API `tools/api264` аннотации `@Inject`, `@At`, `@Shadow`, `@Final` ошибочно имели retention `CLASS`; поэтому ECJ создал `RuntimeInvisibleAnnotations`. Mixin 0.8.7 обнаруживает injector через `InjectionInfo.getInjectorAnnotation` → `Annotations.getSingleVisible`, поэтому compiled handlers пропускались без ожидаемых callback-логов. Исходник для точного Mixin tag `releases/0.8.7` сверён, commit `4053421aa10aaac6127d969028a29c94fe3054f6`: эти аннотации имеют `RUNTIME`, а `@Mixin` правильно остаётся `CLASS`. Старый Build266 handwritten HEAD callback имел `RuntimeVisibleAnnotations` и срабатывал — это согласуется с диагнозом.

Build268 использует отдельные исправленные stubs `tools/api268`, сохраняет точную базу Build262 SHA `21fc8fa7c861c3652f020ce9bb10bac133ac253675084982e65f16cc734f2531`, Build263 CUTSCENE fade исключён. Три `@Inject` handler и shadow-field annotations в JAR проверены как RuntimeVisible. Основной gate и полный gate из clean source ZIP: PASS. JAR 3 079 012 байт, SHA-256 `bc4f01b8461ef36ab4d6a8cda35aaf10967c9becdc07c8f6ccba127aa39f1ea5`. Размеры/SHA обоих файлов — в `SHA256SUMS-build268.txt`. Minecraft/NeoForge не запускались и скин визуально не подтверждён.

Дальше выдать пользователю Build268 на тест копии мира по `CHECKLIST-TEST-BUILD268-RU.md`; свежий лог должен показать `[SL-PROFESSION-268] early/apply`, затем `resolve ... exists=true`. Только после этого считать, что callback теперь работает; отдельное визуальное подтверждение всё равно обязательно. Пользовательские логи не включать в backup.

## Build267: установленный диагностический пакет, не skin fix

`latest-8.log` подтверждает загрузку Build267, рендер `GuideNpc`, сохранение графа и отсутствие всех `[SL-PROFESSION-267]` меток. Причину объясняет visibility-ошибка выше. Build267 не выдавать как исправление.

## Build266: диагностический predecessor, skin не подтвердил

В пользовательском `latest-7.log` Build266 запущен, но отсутствуют его все probe-маркеры. Build266 не выдавать за исправление. Пользовательские логи не включать в source bundle.

## Build265: предыдущий dropdown/skin candidate — проблема сохраняется

Пользователь подтвердил: с Build265 внешний вид NPC не меняется. Build265 не выдавать за фикс; его source, gate и hash сохранены в release-файлах.

## Архив Build 264: первоначальная профессия/скины

Build264 сохраняется для истории; его UI был стрелочной прокруткой, а поведение скина по сообщению пользователя не работало. `latest-5.log` отдельно показал локально недокачанный Build264 (`ZipException: zip END header not found`); опубликованный JAR при проверке был корректным. Не выдавать Build264 вместо Build265.

## Архив Build 263: затухание и проявление в начале катсцены

Пользователь попросил в инспекторе CUTSCENE-ноды два независимых переключателя: плавное затемнение до показа сцены и плавное проявление после фактического старта камеры. Обе галки дают переход через чёрный. Фаза фиксирована на 500 мс; длительность отдельно не уточнялась.

После позднего ревью исправлен порядок: клиент удерживает payload камеры и `handlePlaying(true)` до полного чёрного, затем воспроизводит их на client thread; fade-in стартует только в callback после реального `handlePlaying(true)`. Fade-out-only открывается мгновенно при старте камеры, fade-in-only ждёт сигнал на чёрном. Есть timeout на случай потерянного start packet. Точный diff от Build 262: 7 изменённых entries и 11 новых class entries. Два флага — собственные Node mixin fields; `Node.copy()`/NBT сохраняют их; `animLoop`/`moveEscort` не используются. Chained scenes получают параметры отдельно.

Пользователь отказался присылать SHA; не запрашивать повторно. После выдачи candidate c80 (`c80fa6948ef3817b04922542a0de70c03bb0ce06d95f928bd033d771e5aed13b`) пользователь сообщил, что правая панель появилась снова, но выбранная нода опять пустая; новый screenshot `image-5.png` показывает заголовок «Реплика #0» и пустое тело. Build262 в той же среде работает. Текущий source candidate c80 использует graph/selected, напрямую добавляет два fade-контрола в inspectorWidgets и не трогает shared buildingInspector; этот вариант не устранил пустое содержимое, так что не считать регрессию закрытой. Известный предыдущий candidate `293a22505849b92cec191d66fafe189cd401dc66b7a7f17904d79d057af03bc0` с `@Shadow node()` по сообщению пользователя убирал правую панель целиком. `latest-4.log` показывает только более ранний filename `(3).jar` и version Build263, не является логом текущего screenshot; SHA снова не просить. Следующий AI: читать Build263 `widgets()`/render/mouse-selection bytecode и mixin composition в сравнении с Build262; причина пустого inspector body пока не найдена. Не делать очередной blind patch и не утверждать исправление. No video.

Файлы: `README-Build263-Cutscene-Fade-RU.txt`, `API-COMPAT-263-RU.md`, `CHECKLIST-TEST-BUILD263-RU.md`, `BACKUP-263-RU.txt`, `GATE-RESULT-263.txt`, `GATE-BACKUP-RESULT-263.txt`, `SHA256SUMS-build263.txt`, `SettledLands-Build263-Cutscene-Fade-Source.zip`.

## Build 262: плавный переход ходьба → остановка → idle и поворот торса

От точного Build 261 (`settledlands-0.8.0-build261-idle-look-punchy-animation.jar`, SHA `979d64831b47336a84a72ec0d803da4f19d5ee6e1fdb85e542e7e08b03647df6`) собран `settledlands-0.8.0-build262-smooth-npc-turning.jar`, 2 260 085 байт, SHA-256 `21fc8fa7c861c3652f020ce9bb10bac133ac253675084982e65f16cc734f2531`. JAR отличается ровно тремя entries: Auto-AI engine, TOML и patch-info; renderer Build 261 остался побайтово без изменений.

- При горизонтальном движении yaw корпуса и сущности выставляется по вектору движения и сохраняет направление после остановки.
- Следующая случайная idle-цель не выполняет мгновенный разворот: корпус/entity yaw плавно следуют с коэффициентом `0.035F`, голова — быстрее (`0.12F`). Диалог, бой, активный маршрут/движение и взгляд на ближайшего игрока сохраняют приоритет.
- `tests/gate_build262.py` PASS: deterministic rebuild, точный diff/ABI/JAR checks, Java 21 «walk → stop → first torso step → randomized head/body scan», диалог, inherited AI/combo, Build 261 animation/first-person regressions; verifier-valid no-op torso mutant убит. `tests/gate_backup262.py` PASS: manifest и побайтовое воспроизведение ZIP, полный gate из чистой распаковки.
- Minecraft/NeoForge/modpack не запускались. Обязателен тест на копии мира по `CHECKLIST-TEST-BUILD262-RU.md`; видео не просить.

Файлы: `README-Build262-Smooth-Npc-Turning-RU.txt`, `API-COMPAT-262-RU.md`, `CHECKLIST-TEST-BUILD262-RU.md`, `BACKUP-262-RU.txt`, `GATE-RESULT-262.txt`, `GATE-BACKUP-RESULT-262.txt`, `SHA256SUMS-build262.txt`. Source ZIP: `SettledLands-Build262-Smooth-Npc-Turning-Source.zip`.

## Build 261 (предыдущая сборка): idle-взгляд, согласование анимаций, руки NPC в Punchy-style first person

От точного Build 260 собран кандидат `settledlands-0.8.0-build261-idle-look-punchy-animation.jar`, 2 259 841 байт, SHA-256 `979d64831b47336a84a72ec0d803da4f19d5ee6e1fdb85e542e7e08b03647df6`. Source ZIP: `SettledLands-Build261-IdleLook-Punchy-Animation-Source.zip`; финальный размер/hash лежит в `SHA256SUMS-build261.txt`.

Новые правки:
- `NpcAutoAiEngine255.tickIdleLookAround` реализует ванильный по стилю idle head scan: случайные направления и мягкая интерполяция головы; body yaw/navigation не меняются. Игрок, бой, movement, активный маршрут и dialogue приоритетны.
- `NpcMotionBridge256` на Ivy EMF/ETF не уходит на отдельный raw-Blockbench renderer во время `isTalking` или active full-body clip. FA/TnM база остаётся, разговорный/custom clip накладывается сверху. При движении точные базовые poses обеих ног сохраняются поверх full-body клипа.
- `FirstPersonPossession256` и новый `PunchyFirstPersonContextMixin261` добавляют контекст на pass `ItemInHandRenderer.renderHandsWithItems`, чтобы прямой PlayerModel first-person hand render получил NPC arms/texture, даже без `RenderArmEvent`/PAL mark. Внешняя Punchy binary/version неизвестна; только общий PlayerModel fixture проверен.

`tests/gate_build261.py` PASS: deterministic build, JAR validators, exact Build260 diff, runtime idle/body/dialogue, inherited AI, full-body/layer/leg, hurt→dialogue and first-person NPC arm/skin scenarios; два verifier-valid мутанта убиты. Настоящий Minecraft/NeoForge/modpack и Punchy не запускались. Нужен пользовательский тест на копии мира по `CHECKLIST-TEST-BUILD261-RU.md`; видео не просить.

Файлы: `API-COMPAT-261-RU.md`, `README-Build261-IdleLook-Punchy-Animation-RU.txt`, `CHECKLIST-TEST-BUILD261-RU.md`, `BACKUP-261-RU.txt`, `GATE-RESULT-261.txt`, `GATE-BACKUP-RESULT-261.txt`, `SHA256SUMS-build261.txt`. История ниже — build 260 и ранее; вся прежняя функциональность сохранена.

## Build 260: звуки, корпус при ходьбе, взгляд в диалоге

Пользователь сообщил, что NPC звучат как скелеты; поворачиваются корпусом к игроку при включённом «смотрит на игрока»; при выключенном тумблере ходят боком; и попросил, чтобы во время диалога NPC смотрел на игрока даже при выключенном тумблере.

**Build 260**: `settledlands-0.8.0-build260-npc-facing-sounds.jar`, 2 257 565 байт, SHA-256 `8d47171845652c1a3499643ca1936a7d6b742d9e88811751d94d84bef47d2ebc`; точная база build 259 `settledlands-0.8.0-build259-npc-combo-tuning.jar`, SHA `ab44f422a423a428f198ae4393e55ad8409857e10e85674d1ccfa093790f5da7`. Source ZIP `SettledLands-Build260-NpcFacingSounds-Source.zip`: 9 549 285 байт, SHA-256 `44ff3e8bb1f5a4c0c3e58c5bce9ddcede205085168b063ca9cd30dfc3e619c5a`. В `GuideNpc` непосредственно подтверждены Skeleton constants в `getAmbientSound`, `getHurtSound`, `getDeathSound`; заменены на `VILLAGER_AMBIENT/HURT/DEATH`. Не смешивать это с остающимися combat sound cues Warden/Wolf: исходные три skeleton voices исправлены.

В `GuideNpc.customServerAiStep` ветка player-look больше не вызывает `LookControl.setLookAt`, потому что он разворачивает torso. Условие заменено на `NpcAutoAiEngine255.shouldLookAtPlayer`: profile toggle OR active dialogue. Ближайшая цель обрабатывается как раньше, но `lookHeadAtPlayer` изменяет лишь `yHeadRot`. Рендерер больше не прячет yaw головы во время `isTalking`, даже если toggle off. `NpcMotionBridge256` при наземном горизонтальном движении временно выставляет `yBodyRotO/yBodyRot` по вектору движения для полного, Ivy/EMF и fallback render paths, затем всегда восстанавливает state в `finally`; применяется независимо от profile flag и без permanent entity mutation. Это закрывает отчёт «при выключенном всё равно идёт боком».

Build 260 сохраняет 259 Ivy-combos/follow-up hits, +10% calm speed, Auto-AI, Stats, wander/return и boolean ABI hotfix 258. В JAR меняются ровно пять entries: `NpcAutoAiEngine255.class`, `GuideNpc.class`, `NpcMotionBridge256.class`, TOML, patch-info; остальные 418 идентичны базе.

`tests/gate_build260.py`: основной gate PASS и independent source ZIP gate PASS. Проверены deterministic rebuild, exact diff, звуковые field refs, отсутствие `LookControl.setLookAt` в patched branch, JVM linkage, runtime toggle/dialogue/head-only scenarios, наследуемые Stats/Auto-AI/combo tests и 5 verifier-valid mutants. Не заявлять реальную игру: Minecraft/NeoForge/full modpack не запускались.

Source ZIP: `SettledLands-Build260-NpcFacingSounds-Source.zip`; включает baseline259/new260 JAR, code, tools, tests, manifest. Сверить `BACKUP-MANIFEST.sha256`, reproduce source ZIP и independent gate. Документы: `API-COMPAT-260-RU.md`, `README-Build260-NpcFacingSounds-RU.txt`, `CHECKLIST-TEST-BUILD260-RU.md`, `BACKUP-260-RU.txt`.

Следующий шаг: user test build260 на копии мира, без остальных JAR SettledLands: проверить ambient/hurt/death sound, orientation при walking с toggle on/off, head-only look и диалог при toggle off, а также regressions из чеклиста. Видео не просить. Ветка только `arena/24676dbe-mod`; jar link первой, ZIP второй, SHA+размер, открыть JAR последним.

## История build 259 и сохранённые требования

Build259 сначала убрал look-at на combat target в Auto-AI path, но user подтвердил, что profile toggle в `GuideNpc.customServerAiStep` всё ещё разворачивает корпус, а выключенный toggle оставляет walking torso боком. Не считать build259 исправлением этих замечаний; build260 добавляет отдельные fixes выше. Build259 intent/combos сохранены: calm pace +10%, multi-hit jab-cross/jab-jab-hook в обычных и lunge attacks.

Все прежние settled features 237–258 сохранять, особенно Stats/Auto-AI hostile targets, wander/return, melee clips и build258 boolean ABI fix. Видео не просить.

## История build 254

По итогам игровой проверки **build 253** пользователь подтвердил, что сборка работает («Все хорошо»), и поставил 5 задач для **build 254**: (1) дефолтная позиция ноды характеристик слева от начальной реплики, а не справа от «прибытие 2»; (2) исправить отрисовку символов слайдера поверх других окон в редакторе графа; (3) исправить выпадающий список выбора модельки, чтобы он рисовался поверх всех элементов; (4) сделать `ivy_oleander.bbmodel` моделью НПС по умолчанию; (5) добавить вниз ноды характеристик кнопку «рандомизировать» с изменением каждого параметра в радиусе от `-2` до `+2` (включая `0` без изменения параметра). Видео у пользователя не запрашивать.

Кандидат **build 254** `settledlands-0.8.0-build254-ui-ivy.jar`: 2 181 852 байта, SHA-256 `19634ba583fd6f196973416d9420b0b20b58a4508dd5c65a7a061094cdd11f5c` (собран детерминированно от точной подтверждённой пользователем build 253 `a5ac75dfbf24ad4fd0e06fcdcc3c4da51b2ab64bdea24440f43903259d01814e` через `tools/patch_ui_ivy254.py`). В `NpcStatsGraph.ensure` нода `TYPE = 16` размещается слева от `g.get(g.entry)` на `(-360, 0)`. В `NpcStatsGraphUi.draw` все `drawCenteredString` (`SHADOW_OFFSET = +0.03f` по Z) заменены на `drawString(..., false)` с ручным центрированием, высота ноды увеличена до `170` px и добавлена нижняя кнопка «Рандомизировать» (`[-2..+2]` с `0` и `Ctrl+Z`). В `NpcConfigScreen.render` (`pc=752`) и `NpcBranchScreen.render` (`pc=605`) вызов `renderPopup` заменён на `NpcDropdownTop254.renderPopupTop` (`Z = +500.0f` с `flush()`). Модель `ivy_oleander.bbmodel` встроена в `/assets/settledlands/dragon_default/ivy_oleander.bbmodel`, извлекается в `<gameDir>/settledlands/models/ivy_oleander.bbmodel` при инициализации `NpcClient` и назначена дефолтом в `NpcProfile` и `GuideNpc` через server-safe `NpcDefaultModel254` (исключая `GuideTriggerNpc`/`GuideCorpseNpc` и сохраняя явный `Texture: ""`). Все классы анимаций, HnS, FA, TnM, щита и копирования НПС (`BbModel`, `PlayerBodyRenderer`, `FirstPersonSwordBridge252`, `FirstPersonPalEmfAccess252`, `PlayerMotionBridge`, `HackSlashAccess`, `FreshEmfAccess`, `PossessionSystem`, `PossessionLoginSync251`, `NpcCopyPickPayload`, `NpcCopyEggFix253`, `GuideTriggerNpc`, `GuideCorpseNpc`, `GuideRenderer`) сохранены байт-в-байт. Touch’n Motion для самих NPC (`GuideNpc`) не реализован; реальный клиент Minecraft/NeoForge не запускался. Детали — `API-COMPAT-254-RU.md`, внешние входы и команды повтора — `BACKUP-254-RU.txt`, чеклист — `CHECKLIST-TEST-BUILD254-RU.md`.

ПЕРЕД раздачей обязателен полный `tests/gate_build254.py` (включающий регрессии 253–237 / HANDOFF §8, воспроизведение багов 253, сценарии `tests/jvm_ui_ivy254.py` и 17/17 мутантов `tests/mutants254.py`) и полный повтор того же шлюза из независимой распаковки `SettledLands-Build254-UiIvy-Source.zip`, проверка `BACKUP-MANIFEST.sha256` и побайтное воспроизведение ZIP. Итоговые логи `GATE-RESULT-254.txt`, `GATE-BACKUP-RESULT-254.txt` и `SHA256SUMS-build254.txt` хранить вне ZIP. Личные HnS JAR/лог пользователя, сторонние JAR и исходники Gson не распространять. В ответе по-русски: краткий чейнджлог перед ссылкой на JAR, далее ссылка на backup с размерами и SHA; основной JAR открыть через `present_file` последним.

## История build 253

Подтверждённая пользователем в игре **build 253**: `settledlands-0.8.0-build253-shield-copy.jar` (1 629 114 байт, SHA-256 `a5ac75dfbf24ad4fd0e06fcdcc3c4da51b2ab64bdea24440f43903259d01814e`, backup `SettledLands-Build253-ShieldCopy-Source.zip` SHA-256 `56ea74a6b607fe4d4fe6b77c2e71faca440f5ff062ccabf1afd71fc73599a83f`). Удалён старый поворот щита `+40°` при блоке в `BbModel.renderActorHeldItem` и исправлено отсутствие поля `"id"` в `DataComponents.ENTITY_DATA` при копировании НПС (`NpcCopyPickPayload.buildCopyEgg` + `NpcCopyEggFix253`).

## История build 252

Подтверждённая пользователем в игре **build 252**: `settledlands-0.8.0-build252-fp-hns.jar` (1 627 973 байт, SHA-256 `29a0e6e6245d9a906865a4020cf0f2c4532e3a488914260bf9d80df4e57dbc3d`, backup `SettledLands-Build252-FirstPersonHnS-Source.zip` SHA-256 `aaf0c8e5c935175c81479e9fa97fd0c88152ac396727ccdd7a24345793286f42`). Исправлены взмахи и хитбокс меча HnS от первого лица поверх EMF/FA/Core/TnM (`FirstPersonSwordBridge252`, `FirstPersonPalEmfAccess252`).

## История build 251

Экспериментальная **build 251** `settledlands-0.8.0-build251-crawl-hns.jar`: 1 616 133 байт, SHA-256 `a3be663ea42de11e815b67b710e589bb92dd2752eb6fbd0d5408fdba3c9d256a`; backup `SettledLands-Build251-CrawlHnS-Source.zip`: 37 054 657 байт, SHA-256 `6b5a7acf69bd7276ebc34c78aaa961cb43a1dd75139642c9aa97c6983eaf517f`. Третий вид игрока с моделью Иви: восстановление vanilla swim root и активного PAL attack stack HnS 2.0-beta2.5/PAL 1.1.6 поверх FA/TnM; при входе синхронизируется серверная внешность себе и другим игрокам. Пользователь подтвердил в игре исправление 3-го лица, ползания и перезахода, отметив оставшийся баг ударов от 1-го лица (исправлен в 252).

Стойкие условия 244–247: вещи и поводок, труп/гроб не нежить и неуязвимы; труп после обычной смерти не создаётся; очередь отключена — своё тело/гроб рядом и 9 изумрудов; −4/−8/−16 максимального HP после платных возвратов, четвёртая смерть — обычный дроп; характеристики NPC, экран вселения, половинная гравитация и игнорирование мобами; бестелесный не наносит атрибутированный урон в Верхнем мире и может в чистилище, молоко не снимает эффект. См. README и ограничения 247/246/245; причина старого отказа при `культ=1` неизвестна.

## История build 250 и ранее

Нижеследующие статусы, выборы и запросы относятся к указанным старым сборкам и не отменяют актуальные указания выше.

**Build 250 — эксперимент, оба полных gate PASS:** `settledlands-0.8.0-build250-fresh-motion.jar`, 1 608 517 байт, SHA-256 `2187bd12cbbd252570280c850c665945d6ad87b929fd80a4f400217e4c11082d`; backup `SettledLands-Build250-FreshMotion-Source.zip`, 35 372 945 байт, SHA-256 `72acc37e6275f6a706852f405532ed8f2d99652759f816fec43cd2916691a4de`. Основной gate 250 PASS (`GATE-RESULT-250.txt`, включает проверенный полный 249 gate), дополнительно свежий 249–237/§8 PASS (`GATE-BASE-RESULT-250.txt`). Из независимо распакованного backup полный gate 250–237/§8 завершён PASS (`GATE-BACKUP-RESULT-250.txt`), manifest 380/380 и побайтное воспроизведение ZIP PASS. Снимок архива создан до окончания gate, окончательные логи снаружи. JAR и ZIP перед выдачей сверить по SHA и в удалённой ветке; JAR в ответе до backup и открыть последним.

Пользователь выбрал установленный Fresh Animations: Player Extension + Touch'n Motion, а не ванильную основу 249. Реализован изолированный EMF-риг игрока, TnM вызывается собственным хуком EMF однократно; при успехе зашитые player-clips пропускаются. При нераспознанном/отключённом FA и обнаруженном совместимом TnM используется нейтральная поза; при отсутствии/несовместимости TnM или аварийном отключении сохраняется старый рендер. Сигнатура проверена на стороннем зеркале FA 1.0; источник не доказан. Marker содержится в a_player_variables.jpm, а не в основном player.jem как animKey. Пак пользователя, настоящий EMF 3.3.9, Minecraft/NeoForge и визуальный результат НЕ проверены; EMF 3.3.12 root с идентичными upstream исходниками и настоящий TnM 1.0.4 hook проверены только с синтетическими API. NPC и первое лицо TnM не поддерживают, UV не исправлена/не проверена. Прочитать README/API-COMPAT/CHECKLIST 250. Попросить игровую проверку, свежий latest.log и при проблеме ресурс-пак/скриншоты; не выдавать синтетическую анимацию за подтверждённый FA.




## Эксперимент build 249 — ванильная основа + TnM у игрока

Пользователь сообщил, что после 248 игрок с моделью Иви выглядит и движется плохо, тогда как NPC в порядке; до 248 внешний вид игрока был нормальным. Он выбрал убрать встроенные клипы игрока и оставить ванильную походку + добавления TnM. От точной 247 собран эксперимент `settledlands-0.8.0-build249-player-motion.jar`, 1 602 595 байт, SHA `904ea1cb82c43735ec6f18dce60382c0ccafe7654045556fe1dccee10187b272`. Статический анализ показывает, что ресурсы/UV/PNG и выбор texture у игрока/NPC не менялись: причина визуального сбоя не доказана. Новая схема ретаргетинга использует ванильные шарниры и `V × Vrest⁻¹ × Ivyrest`, исходные встроенные клипы игрока при активном мосте не вызываются, NPC не изменён. Fallback вызывает прежний setup; первое лицо и TnM для NPC не реализованы. Подробности `README-Build249-PlayerMotion-RU.txt`, `API-COMPAT-249-RU.md`, `CHECKLIST-TEST-BUILD249-RU.md`.

Новый `tests/gate_build249.py` включает gate 248–237/§8, настоящий BbModel/BbAnimation/renderActor со стендами, 28 сценариев и 1200 поз, 32 мутанта, настоящий TnM hook и foot/torso со стендами. Minecraft/NeoForge, реальные UV-буферы и игру НЕ запускали. Оба полных gate завершились PASS: `GATE-RESULT-249.txt` и `GATE-BACKUP-RESULT-249.txt`. Backup `SettledLands-Build249-PlayerMotion-Source.zip`, 33 734 991 байт, SHA-256 `d03b618f09154267d22c2d7374bc965aa1d85dc344c3ab9ab986285c4ba8cef9`: manifest 325/325, побайтное воспроизведение и полный gate из независимой распаковки прошли. Снимок архива создан до окончания gate; итоговые логи хранятся вне ZIP. TnM 1.0.4 GPL нужен отдельно и в backup не входит. Ссылка на JAR должна предшествовать ссылке на backup, оба с размером и SHA, JAR открыть последним.

## Эксперимент build 248 — игрок с моделью Иви, не полное выполнение запроса

`settledlands-0.8.0-build248-touchmotion-player.jar`, 1 599 840 байт, SHA-256 `a07262fb01223f5418e124bd4ad4715d4b8d23bdc318d9ec324c46970e5ed782`, детерминированно создан от точного 247 через `tools/patch_touchmotion248.py`. Экспериментальный мост вызывает реально установленный Touch'n Motion 1.0.4 для `AbstractClientPlayer` с моделью `ivy`/`ivy_oleander` в третьем лице, через его закрытый API с проверкой версии/контекста и fail-closed откатом. NPC Иви и первое лицо НЕ поддержаны. Игру, NeoForge и визуальный результат не запускали, не обещать конкретные движения. Пользователь также просил NPC, поэтому дальнейшая работа нужна; синтетического/фальшивого игрока не выдавать за полноценную NPC-интеграцию.

Изменён только BbModel renderActor (wrapper и два hook), добавлены четыре класса моста и обновлены TOML/patch-info; старые механики 247–237 не переписаны. Модель Иви вложенная, её кости переводятся в плоское пространство, затем обратно parent-first. Некорректный/непредставимый риг и исключения откатывают дополнительный PoseStack. Для отражения порядка vanilla 1.21.1 используется quaternion `rotationZYX`, а не `Matrix4f.rotateZYX`; у JOML 1.10.5 также есть проблемное quaternion Euler-извлечение, применено устойчивое извлечение с gimbal lock. Есть 24 сценария, 1200 детерминированных real-JOML поз и 23 откалиброванных мутанта; исполнялись также настоящие методы TnM 1.0.4 `ModelSpace`, `applyAll`, `FootGrounding`, `FootStep`, `TorsoLean` и `PelvisFollow` при искусственных состояниях и заглушках окружающих систем. Это не игровой тест.

Полный `tests/gate_build248.py` включает весь gate 247–237/§8, проверку реальных API-сигнатур, JVM и негативные контроли. Основной и повторный gate из независимой распаковки прошли (`GATE-RESULT-248.txt`, `GATE-BACKUP-RESULT-248.txt`), manifest 247/247 OK, ZIP побайтно воспроизведён из распаковки. Backup `SettledLands-Build248-TouchMotionPlayer-Source.zip`: 32 100 201 байт, SHA-256 `c4cf4c4e41f6656d8c3664918a7dfa25abe8f1f81c919ac3fc01e3f8af60e546`. Сборка и описание — `README-Build248-TouchMotionPlayer-RU.txt`, `BACKUP-248-RU.txt`; сверить SHA и манифест. Точный внешний TnM 1.0.4, необходимый для полного gate, GPL и не входит в ZIP. Проверялся публичный JAR SHA `3754909bf0d12445b18a60de315619734c1229bcc621f88f315ccf076701ab56`; побайтной проверки JAR пользователя нет. Сохранить мир и использовать `CHECKLIST-TEST-BUILD248-RU.md`. В ответе краткий чейнджлог, ссылка на JAR до backup, размеры/SHA; JAR открыть последним.

## История: build 247 — читать после 248

`settledlands-0.8.0-build247-bodiless-protection.jar`, 1 589 582 байта, SHA-256 `c3130e136018342d133b710812e6c86fc0fcf5f181146c6973f055abba3798f1`; воспроизводимо от точной 246 через `tools/patch_bodiless247.py`. Добавлен один новый класс и изменены только TOML/patch-info, все классы 246 сохранены. `BodilessProtection` обычными событиями NeoForge отменяет прямые атаки и урон с узнаваемым бестелесным источником в `minecraft:overworld`, а также применение от такого источника яда, иссушения и голода. В `settledlands:purgatory` бой разрешён; молоко не снимает эффект, но нормальное снятие и другие эффекты молока не менялись. Огонь/лава/падение и другое без установленного виновника могут обходить запрет, как и нестандартные чужие механизмы. Реальный Minecraft/NeoForge, регистрация bus и mixin не запускались. Подробнее — README, игровой чеклист и `API-COMPAT-247-RU.md`.

Полный gate и повторный gate из независимой распаковки прошли; логи — `GATE-RESULT-247.txt` и `GATE-BACKUP-RESULT-247.txt`. Backup `SettledLands-Build247-BodilessProtection-Source.zip`, 29 760 065 байт, SHA `dd0e369edb0315dfdc9444a0c7ea73037e6c6a432aa96baaf088b798afa7aa9a`: manifest 199/199 OK, AI-GUIDE внутри, ZIP воспроизводится побайтно из собственных файлов. Из распакованного backup, Python 3.11+ / Java 21:

```bash
sha256sum -c BACKUP-MANIFEST.sha256
python3 tests/gate_build247.py --inputs test-inputs --base245 settledlands-0.8.0-build245-body-wear.jar --base246 settledlands-0.8.0-build246-npc-characteristics.jar --java /path/to/java21 --jar settledlands-0.8.0-build247-bodiless-protection.jar
```

Ожидается `BUILD 247 GATE: PASS`: полный gate 246–237/§8 плюс те же регрессии на JAR 247, actual 247/246 bytecode со стендами, 17 новых и 50 наследованных мутантов. Стенды не заменяют игру. Каждый будущий билд снова требует полный gate и независимый backup с AI-GUIDE и повторной проверкой из распаковки; работать только на ветке текущей сессии.

## История: build 246 — читать после 247

`settledlands-0.8.0-build246-npc-characteristics.jar`, 1 587 651 байт, SHA-256 `fe62c48b5bfbb0607cf1fa1e9996649bcd90a144de57ca991dfb737ff78cc819`, детерминированно создан от точной базы 245 через `tools/patch_npc_stats246.py` и ECJ `tools/vendor/` (EPL-2.0). Копия мира обязательна; игровой чеклист — `CHECKLIST-TEST-BUILD246-RU.md`. Пользователь подтвердил в игре 244; 245 и 246 в игре не проверены.

Бестелесный получает 50% гравитации независимо от уровня эффекта; стандартные мобы не выбирают его и забывают текущую цель, другие игроки видят. Основной граф каждого NPC получает уникальную ноду с независимыми здоровьем/уроном/скоростью (дефолт 10, диапазон 1–100); 10 здоровья = 20 HP/10 сердец, каждый пункт ±2 HP, урон и скорость ±10% итогового значения за пункт. ПКМ бестелесным по живому NPC открывает характеристики и кнопку «Вселиться»: сервер проверяет одноразовый nonce, цель/мир/дистанцию/живость, срок, инструмент/эффект, неизменные значения и локальный `культ≥1`. Инструменты и трупы исключены. Сохранены износ, обычный дроп/keepInventory, отсутствие очереди, своё тело и 9 изумрудов, возврат предметов/поводок.

Полный `tests/gate_build246.py` на Java 21 прошёл, включая полный gate 245–237/§8, новый функциональный тест графа/NBT, UI/undo, nonce/культа/AI, stats/wear, реального моста вселения, экрана, гравитации, а также 32 новых и 18 наследованных калиброванных мутантов. Есть проверка дескрипторов по открытым исходникам (`API-COMPAT-246-RU.md`), но фикстуры — синтетические API, не игра. Сам Minecraft/NeoForge, сетевой обмен, сохранение мира, применение mixin, совместимость конкретных сторонних модов НЕ запускались. Нестандартный AI и порядок сторонних обработчиков урона не гарантированы. Причина старого отказа при `культ=1` не установлена; probe read-only; старый fallback без UUID остаётся ограничением.

Независимый backup `SettledLands-Build246-NpcStats-Source.zip`: 28 178 718 байт, SHA-256 `55885e96fcc916a260bc539b60b09bb2bc6ec92f91f694b579c383862b75bb8f`. В нём AI-GUIDE, архив исходного графа 228, ECJ и входы 230/232–244. Проверены manifest (180 файлов) и повторный полный gate из распаковки — PASS. Для воспроизведения после распаковки:

```bash
sha256sum -c BACKUP-MANIFEST.sha256
python3 tests/gate_build246.py --inputs test-inputs --base245 settledlands-0.8.0-build245-body-wear.jar --java /path/to/java21 --jar settledlands-0.8.0-build246-npc-characteristics.jar
```

Дальнейшие изменения делать только на ветке текущей сессии; полный gate и независимый backup повторять для каждой раздачи. Ниже — история; инструкции 245 не описывают новые характеристики.

## История: build 245 — читать после build 246

Пользователь подтвердил работу 244 и запросил износ: после 1/2/3 успешных возвратов в то же тело за 9 изумрудов общий штраф максимального HP −4/−8/−16 (при 20: 16 → 12 → 4). Выход без оплаты не увеличивает счётчик, новый живой NPC сбрасывает счётчик. Четвёртая смерть не создаёт труп; вещи подчиняются обычным правилам мира и `keepInventory`. В чистилище можно выйти самостоятельно; маяк без тела не возрождает. Сохранить независимые модификаторы максимального здоровья и правила 244.

`settledlands-0.8.0-build245-body-wear.jar`: 1 563 087 байт, SHA-256 `b6825213caa98096881f02659f81f719cb5f86588c22c2899ccca09f139aca86`. `tools/patch_body_wear245.py` принимает только точную базу 244. `BodyWear` записывает оплаченный UUID после фактической транзакции и учитывает его только при восстановлении вселения; защищён от повторов и другого UUID. Для здоровья использует собственный `settledlands:body_wear` modifier и пересчёт при dirty `MAX_HEALTH`, сохраняя чужие модификаторы и ограничение атрибута. В clone различает смерть и non-death, на login согласует сохранённые данные, при новом NPC сбрасывает, при выходе деактивирует. При оплате и исчерпании тела отменяются только отложенные fallback watches/PENDING/STOCK данного владельца — не остальных.

Полный `tests/gate_build245.py` прошёл на Java 21, включает gate 244–237 и HANDOFF §8, точный diff и аннотации, исходные байткоды смерти/дропа/clone/платежа/вселения/выхода/login, сторонние health modifiers, минимум/cap, мультиплеер, pending и 18 негативных мутантов. `jvm_body_wear245.py`, `jvm_new_body245.py`, `jvm_wear_login245.py` используют синтетические игровые API; dirty-callback вызывается стендом. Настоящий Minecraft/NeoForge, применение mixin, реальный keepInventory и совместимость с конкретными сторонними модами НЕ запускались. Пользователю нужен игровой чеклист `CHECKLIST-TEST-BUILD245-RU.md`, сначала копия мира.

Полный повторяемый шлюз из распакованного backup (Python 3.11+, Java 21, без javac):

```bash
python3 tests/gate_build245.py --inputs test-inputs \
  --base237 test-inputs/settledlands-0.8.0-build237-corpse-pose.jar \
  --base238 test-inputs/settledlands-0.8.0-build238-corpse-recovery.jar \
  --base239 test-inputs/settledlands-0.8.0-build239-empty-corpse-cleanup.jar \
  --base240 test-inputs/settledlands-0.8.0-build240-npc-local-cult.jar \
  --base241 test-inputs/settledlands-0.8.0-build241-altar-body-respawn.jar \
  --base242 test-inputs/settledlands-0.8.0-build242-body-required.jar \
  --base243 test-inputs/settledlands-0.8.0-build243-body-without-queue.jar \
  --base244 test-inputs/settledlands-0.8.0-build244-corpse-click.jar \
  --java /path/to/java21 --jar settledlands-0.8.0-build245-body-wear.jar
```

Ожидается `BUILD 245 GATE: PASS`; это НЕ игровой тест. См. README 245 для прежнего ограничения failed-spawn fallback без UUID и неизвестной причины отказа вселения при `культ=1`.

## История: build 244 — пользователь подтвердил работу

После игрового отчёта по 243: самостоятельный выход из чистилища → владелец не забирает вещи ПКМ из тела и гроба; обычный труп позволяет диалог, гроб — нет. Лога этого нового запуска нет. Зафиксированный на JVM дефект — список может оставаться на игроке, тогда как `tryClaim` 243 читает только список тела. Реальный `GuideNpc.mobInteract` может открыть разговор при обходе событий инструментом. Это проверенные возможные пути, но без свежего лога не утверждать окончательную причину игрового отказа.

`settledlands-0.8.0-build244-corpse-click.jar`: 1 559 202 байта, SHA-256 `d9e558d17ba4ff123e6588d7048a5b0cdfbf359eac092101553da54b1eaae2c8`. `tools/patch_corpse_click244.py` принимает точную базу 243. Прежние реализации сохранены байт-в-байт как alias. Небезопасная legacy-выдача pending заблокирована при наличии списка. Живой владелец вне чистилища по ПКМ может перенести список только при совпадении current-death UUID и UUID происхождения; неизвестные/конфликтующие списки сохраняются с сообщением. Частичные остатки, ошибки разбора и поводок сохраняются; после полной выдачи тело исчезает, повтор удалённой сущности защищён. Для другого подтверждённого тела отдельный ожидающий список не мешает. Обычный диалог отсекается только для `GuideCorpseNpc`; живой NPC делегируется прежней логике. Редактирование, предмет гроба, поводок и приоритет второй руки сохранены.

`IvyDeathScene` остаётся `@EventBusSubscriber`, оба метода сохраняют `@SubscribeEvent`. Клиентский specific-event возвращает PASS, чтобы ушёл general packet при отстающем синхронизированном состоянии гроба/поводка; general-event потребляется после отправки. Оба серверных пути и запасной entity-метод отдельно проверены и идемпотентны. Клиент отправляет specific packet до своего hook — PASS не является доказанной причиной прежнего отказа. Старые UUID и происхождение не угадывать; прежний редкий fallback без UUID остаётся неисправленным.

Полный `tests/gate_build244.py` прошёл с вложенным gate 243–237 и §8, Java 21, проверкой аннотаций/точного diff, 19 отрицательными JVM-мутантами и регрессиями. `jvm_self_escape244.py` исполняет реальные смерть → drop → clone → выход из чистилища → ПКМ, в том числе искусственно задержанный перенос подтверждённого списка. `jvm_real_corpse_dialogue244.py` исполняет настоящий `GuideNpc.mobInteract`, а эффекты диалога — стенды. `jvm_corpse_click244.py` проверяет конфликт, неизвестное происхождение, обе руки/события, отдельный fallback, неполные/битые вещи, инструменты и поводок. Minecraft/NeoForge, реальные события/mixin и игра не запускались. Причина отказа вселения по-прежнему неизвестна, read-only probe оставлен без изменения. См. `README-Build244-CorpseClick-RU.txt` и `CHECK-JAR-244-RU.txt`.

Полный шлюз из распакованного backup (Python 3.11+, Java 21; javac не нужен):

```bash
python3 tests/gate_build244.py --inputs test-inputs \
  --base237 test-inputs/settledlands-0.8.0-build237-corpse-pose.jar \
  --base238 test-inputs/settledlands-0.8.0-build238-corpse-recovery.jar \
  --base239 test-inputs/settledlands-0.8.0-build239-empty-corpse-cleanup.jar \
  --base240 test-inputs/settledlands-0.8.0-build240-npc-local-cult.jar \
  --base241 test-inputs/settledlands-0.8.0-build241-altar-body-respawn.jar \
  --base242 test-inputs/settledlands-0.8.0-build242-body-required.jar \
  --base243 test-inputs/settledlands-0.8.0-build243-body-without-queue.jar \
  --java /path/to/java21 --jar settledlands-0.8.0-build244-corpse-click.jar
```

Ожидается `BUILD 244 GATE: PASS`; это НЕ игровой тест. Backup содержит AI-GUIDE, патч, тесты и точные входные JAR. На копии мира проверить новую смерть во вселённом NPC, самостоятельный выход, пустые руки, ПКМ по телу и по гробу, частичный инвентарь, поводок и живого NPC; при проблеме запросить свежий `latest.log`, время и сообщение. На уровне пользователя очередь и требования к алтарю 243 не изменялись.

## История: build 243 — читать, только если не противоречит 244

После игрового отчёта по 242 пользователь отменил FIFO: алтарь берёт ровно 9 изумрудов и возрождает любого доступного живого онлайн-владельца его загруженного собственного тела текущей смерти у алтаря, по одному за проверку. «Привязан» означает принадлежность, поводок не обязателен. Офлайн другие тела не блокирует. Нет тела — нет алтарного возрождения, в том числе после обычной смерти. Обычный дроп не перехватывать. В чистилище новые смерти не должны создавать тело или менять UUID исходного; тело создаётся для смерти во вселённом NPC вне чистилища.

`settledlands-0.8.0-build243-body-without-queue.jar`: 1 555 767 байт, SHA-256 `a78c2943ec481aab0ed9b9fa67b6aa09a905d019b46b9866a5e6feab91cc584c`. Полный `tests/gate_build243.py` прошёл, включая gate 242/241/240/239/238/237, §8, Java 21, проверку точного diff и 15 отрицательных мутантов. Minecraft/NeoForge и реальный mixin не запускались, этот билд требует игровой проверки. Для скачанного файла использовать `CHECK-JAR-243-RU.txt`, до проверки сделать копию мира.

`tools/patch_noqueue243.py` работает только от SHA build 242, применяет ограничители смерти, выключает API очереди (старые данные на диске не удаляются), выбирает по текущему UUID, сохраняет прежний предикат владельца/расстояния и транзакцию оплаты. `tests/jvm_noqueue243.py` исполняет реальный death → синхронный join до записи UUID → clone/respawn → повторные смерти → drop → алтарь/вещи; `tests/jvm_server_tick243.py` исполняет реальный server tick и уровень алтарей, `tests/jvm_noqueue_altar243.py` — несколько владельцев и откаты, `tests/jvm_queue_disabled243.py` — настоящие методы старой очереди, `tests/jvm_login243.py` — old pending/login. Игровые API и часть телепорта/визуала в этих тестах являются стендами. Сохранившийся обычный NPC-ритуал и настоящий приоритет mixin требуют отдельной игровой проверки.

Старые смерти: затёртый в 242 UUID тела невозможно надёжно восстановить по близости/совпадению владельца. Неподтверждённый старый pending отклоняется. В существующем аварийном fallback при неудаче штатного спавна тело может не получить UUID текущей смерти и алтарь его не примет; происхождение отложенных вещей также может быть неопределённым. Это известное ограничение НЕ исправлено; не угадывать и не править живой мир без копии. Подробности — `README-Build243-BodyWithoutQueue-RU.txt`.

Причина отказа вселения не установлена. Пользователь подтвердил выполнение узла графа, но старый лог не показывает фактическое локальное NBT, эффект, руку и выбранную цель. `CultAttemptProbe` только читает их в серверном EntityInteractSpecific, логирует не чаще раза за 500 мс на игрока, не пишет переменные и не изменяет gate. Старый мост player/global очков остаётся выключен. Запросить свежий `latest.log` после повторной попытки и сообщение игрока; отсутствие строки может означать перехват события. JVM-стенд проверяет диагностику, но не настоящий игровой dispatch.

Полный шлюз после распаковки backup (Python 3.11+, Java 21; javac не нужен):

```bash
python3 tests/gate_build243.py --inputs test-inputs \
  --base237 test-inputs/settledlands-0.8.0-build237-corpse-pose.jar \
  --base238 test-inputs/settledlands-0.8.0-build238-corpse-recovery.jar \
  --base239 test-inputs/settledlands-0.8.0-build239-empty-corpse-cleanup.jar \
  --base240 test-inputs/settledlands-0.8.0-build240-npc-local-cult.jar \
  --base241 test-inputs/settledlands-0.8.0-build241-altar-body-respawn.jar \
  --base242 test-inputs/settledlands-0.8.0-build242-body-required.jar \
  --java /path/to/java21 --jar settledlands-0.8.0-build243-body-without-queue.jar
```

Ожидается `BUILD 243 GATE: PASS`. Для JVM-верификатора добавлена поддержка наследников, встречающихся только в дескрипторах; калибровки старых 230/234 входят в повторённый полный шлюз. Старые изолированные тесты рендера/вещей используют явный pass-through нового death guard; его реальный байткод исполняется отдельно в тестах 243.

## История: build 242 — читать, только если не противоречит 243

Новый запрос пользователя меняет условия 241: возрождение на маяке только за **9 изумрудов** и только при собственном трупе/гробе **текущей смерти рядом с маяком**. Кандидат `settledlands-0.8.0-build242-body-required.jar`, 1 551 583 байта, SHA-256 `375e8faed7ea19e7bc1c343a043f833f82112a10b0ff17c1f6982bc18c2afe6d`. Полный gate 242, включая §8 и gate 241/240/239/238/237, Java 21 и отрицательные мутанты, прошёл. Minecraft/NeoForge не запускались; пользователь подтвердил в игре только 237, а 238–242 пока нет. Перед испытанием сделать копию мира и оставить в mods только 242. Полные ограничения и сценарий — `README-Build242-BodyRequired-RU.txt`.

`tools/patch_altar_corpse242.py` принимает только SHA базы 241. Новый `CorpseRitualGate` ищет точный UUID тела текущей смерти, проверяет владельца, загруженный мир и прежнюю для прямого гроба границу `BlockPos.distSqr <= 16.5`. Требуется живой онлайн-владелец во главе FIFO. Ровно 9 изумрудов резервируются со snapshot полных ItemStack, затем первый удаляется до телепорта, поскольку синхронный `onDimensionChange` тоже удаляет этого игрока. При отказе `teleportTo=false` или исключении до прибытия восстанавливаются стек и начало очереди; при исключении после прибытия нельзя вернуть деньги за уже совершённое перемещение — удерживаются 9, выполняется безопасная выдача и исключение повторно выбрасывается. Инфраструктура событий в fixture синтетическая; нет гарантии любых возможных сторонних необратимых изменений при произвольных исключениях.

Общий путь не переходит на маяк без нужного тела, а прямой путь помеченного/непомеченного гроба проходит тот же платный player-only ритуал, минуя NPC-first mixin. `GuideCorpseNpc.reviveOwner` и redirect защищены независимо. Без UUID даже прямое старое тело не принимается: оно может относиться к прошлой смерти. Если первый офлайн или недопущен, FIFO ждёт; тело в незагруженном чанке не ищется насильно. Старый pending не доказывает ни оплату, ни тело: игрок возвращается в очередь и чистилище; ранее платившему может потребоваться повторная оплата. Лучше обновляться при живых игроках без pending; старые смерти без UUID иначе могут не иметь штатного выхода из чистилища. Дроп обычных смертей не менялся. Вещи, ошибочный NBT и поводок обрабатываются как в 241/239/238; неопределённые списки не объединяются. `RevivalNpcHelper` и `AltarNpcReviveMixin` не менялись, NPC могут иметь приоритет на общем входе.

Отдельный риск: `onCorpseJoin` может произойти синхронно внутри `addFreshEntity` до записи UUID; в этом случае `movePendingSafely` не переносит данные при самом join. Это не заменено утверждением об игровой проверке: дальше возможен захват дропов/отложенный перенос, но реальное событие NeoForge следует проверить в игре. Login со старым pending и синхронная смена измерения проверены на synthetic API; реальные respawn/server tick и mixin/NeoForge не запускались.

Полный шлюз из распакованного backup (Python 3.11+, Java 21, javac не нужен):

```bash
python3 tests/gate_build242.py --inputs test-inputs \
  --base237 test-inputs/settledlands-0.8.0-build237-corpse-pose.jar \
  --base238 test-inputs/settledlands-0.8.0-build238-corpse-recovery.jar \
  --base239 test-inputs/settledlands-0.8.0-build239-empty-corpse-cleanup.jar \
  --base240 test-inputs/settledlands-0.8.0-build240-npc-local-cult.jar \
  --base241 test-inputs/settledlands-0.8.0-build241-altar-body-respawn.jar \
  --java /path/to/java21 --jar settledlands-0.8.0-build242-body-required.jar
```

Ожидается `BUILD 242 GATE: PASS`. `tests/jvm_altar242.py` исполняет реальные байткоды на тестовых игровых API и отдельно выявляет прежние бесплатные/неподтверждённые обходы; `tests/jvm_queue242.py` отдельно исполняет настоящие FIFO-методы с synthetic SavedData. 13 JVM-мутантов проверяют границу, владельца, запрет старой прямой привязки, цену и откаты. Это не игровое испытание. Backup включает AI-GUIDE, тесты, инструменты и все jar-входы; 230/233/234 сломаны и нужны только как отрицательные тесты.

## История: build 241 — только если не противоречит 242

Пользователь попросил **не менять запуск возрождения на маяке за 9 изумрудов и очередь**, а переместить возрождённого к трупу/гробу-инициатору, сразу вернуть его вещи и удалить пустое тело. Непоместившиеся/битые вещи остаются, поводок возвращается; чужие вещи и обычный дроп не трогать. В игре пользователь подтвердил только 237; 238–241 ещё не подтверждены.

Кандидат `settledlands-0.8.0-build241-altar-body-respawn.jar` — 1 548 387 байт, SHA-256 `ded3b5b10db1edfeeea6f90ee753d420d1f7f17da92cf136d8db3012346f5b27`. Полный gate §8 с Java 21 прошёл, но Minecraft/NeoForge не запускались. Сохраните мир и установите только этот jar. Полный сценарий и ограничения — `README-Build241-AltarBodyRespawn-RU.txt`.

Два пути: прямой `GuideCorpseNpc.reviveOwner` имеет конкретную сущность; общий `PurgatoryManager.tryReviveAtAltar` передаёт лишь UUID игрока, поэтому при НОВОЙ смерти `CorpseLifecycle` после успешного спавна записывает UUID именно нового тела в persistent NBT игрока, `onPlayerClone` его переносит, а общий путь ищет загруженную сущность по UUID и проверяет владельца. Не угадывать по единственности/близости: старое единственное тело тоже может оказаться неправильным. Нет UUID для смерти до установки 241, при неудачном спавне или тело не загружено в измерении маяка → прежняя точка на маяке, без выбора вещей; уже запущенный обряд не отменяется и обычная цена расходуется. Прямой известный гроб старого сохранения остаётся допустимым, но при наличии нового UUID несовпадающий гроб не подменяет текущий.

`PlayerCorpsePossession.onPlayerDrops` раньше мог записать новый дроп в ПЕРВОЕ близкое тело владельца и даже перезаписать старые вещи. Патч привязывает новый захват к конкретному UUID и отдельной метке происхождения списка, не перезаписывает существующий список и не принимает старые ожидающие вещи за новые. При конфликтующих старых списках на игроке и теле оба сохраняются, автоматическая выдача и прежний небезопасный `restoreBodyItems` блокируются. Новый список не затирает старый: в таком исключительном случае новый дроп остаётся в мире. Прямой/общий пути используют существующий строгий `CorpseRecovery.tryClaim`; частичные/некорректные списки не удаляются, `dropLeash(true,true)` вызывается только при полном удалении.

Обнаружено прежнее исключение 240: redirect для **непомеченного** гроба не проверяет 9 изумрудов; 241 оставляет его условия как есть из-за явного запрета менять запуск. Основной путь маяка и помеченный гроб по-прежнему проверяют девять. Не утверждать, что все исторические пути требуют оплату.

Шлюз после распаковки backup (Python 3.11+, Java 21; javac не нужен):

```bash
python3 tests/gate_build241.py --inputs test-inputs \
  --base237 test-inputs/settledlands-0.8.0-build237-corpse-pose.jar \
  --base238 test-inputs/settledlands-0.8.0-build238-corpse-recovery.jar \
  --base239 test-inputs/settledlands-0.8.0-build239-empty-corpse-cleanup.jar \
  --base240 test-inputs/settledlands-0.8.0-build240-npc-local-cult.jar \
  --java /path/to/java21 --jar settledlands-0.8.0-build241-altar-body-respawn.jar
```

Ожидается `BUILD 241 GATE: PASS`. Включает старые gate/калибровки, точный diff и проверку неизменности кода очереди/оплаты, настоящую JVM и `tests/jvm_altar241.py`: исполняемые реальные байткоды смерти, клона, захвата, обоих путей, очереди и строгого возврата, стенды игровых API, offline, 8/9/12 изумрудов, несколько тел/владельцев, ошибки и остаток, клонирование, поводок, повтор и 10 отрицательных мутантов. В старых изолированных fixture рендера/возврата 241-хук заменён pass-through адаптером только для тестируемого компонента; реальный хук отдельно исполняется в `jvm_altar241.py`. Это не игровая проверка.

## История: build 240 — читать после раздела 241

Пользователь попросил вселяться **только в NPC с его собственной локальной целочисленной переменной `культ` ≥ 1**. Без неё, при 0 или отрицательном значении — отказ. Личные/общие очки игрока не должны разрешать вселение или записывать переменную NPC. Другое поведение, обычную смерть и алтарь не менять. Пользователь подтвердил в игре 237; 238–240 в игре ещё не подтверждены.

Кандидат `settledlands-0.8.0-build240-npc-local-cult.jar`: **1 544 935 байт**, SHA-256 `2e4a29f6f147d6d081234ea5b7d3839b9a5ba297e984b3962b6f3113e47d76b5`. Сделать копию мира, установить только этот jar, ZIP в `mods` не класть.

В 239 серверный `PossessionSystem.onEntityInteractSpecific` уже проверял `cult(npc) >= 1`, но более ранний `PossessionCultBridge.onInteractSpecific` с приоритетом HIGHEST вызывал `mirror`: положительные личные/общие очки игрока записывали `культ=1` в выбранного NPC и тем самым обходили проверку. `tools/patch_npc_local_cult240.py` воспроизводимо заменяет **только исполняемое тело** обработчика моста на `nop` + `return`, той же длины; аннотации, остальные методы, старый настоящий gate и сценарный writer не меняются. Дифф относительно 239: класс моста, ru/en текст отказа, TOML, patch-info — ровно пять записей. Локальный `культ` регистрозависим и читается из persistent NBT `settledlands_local_vars` именно выбранного NPC. Остальные ограничения вселения сохранены. Возврат владельца к своему телу у алтаря не менялся.

**Старые сохранения:** значения, которые мост ранее записал NPC, остаются — байткод не различает их и значения, выставленные специально. Автоматического удаления/миграции нет. Для проверки запрета брать NPC, у которого локального `культ` точно нет/он 0; личные/общие очки игрока могут быть положительными.

Полный `tests/gate_build240.py` (см. §8) прошёл: вложенные шлюзы 239/238/237, негативные калибровки валидатора и JVM, точный diff, воспроизводимость, Java 21 и реальные байткоды моста, gate, переноса инвентаря и graph-variable writer с исполняемыми synthetic-зависимостями. Build 239 подтверждает старый обход; мутанты восстановленного моста, постоянно разрешающего `cult` и порога `>1` обнаружены. Проверены два NPC, 0/отрицательное/1/больше, отсутствие, точный регистр, строковое значение, очки игрока и исключения инструментов/трупов; ниже написан план игрового прогона. **Это не Minecraft/NeoForge: игра не запускалась.**

Backup `SettledLands-Build240-NpcLocalCult-Source.zip` содержит AI-GUIDE, инструменты/тесты и точные jar-входы 230/232–239. 230/233/234 заведомо сломаны и предназначены только для негативных проверок.

## Историческое состояние: build 239

Пользователь дополнительно попросил: после полного получения вещей из собственного трупа **или гроба** сущность исчезает. При любом остатке, ошибке разбора и недопуске остаётся. Обычную смерть не менять. Пользователь подтвердил в игре 237, но **не подтвердил проверку 238 или 239**.

Кандидат `settledlands-0.8.0-build239-empty-corpse-cleanup.jar`: **1 544 746 байт**, SHA-256 `b68fd79357da507fff35939964816c2a301101ac3afb31298bf4ea31ab7a4290`. Перед испытанием сохранить копию мира, оставить только этот jar в `mods` (ZIP туда не класть).

`tools/patch_corpse_cleanup239.py` воспроизводимо патчит точную базу 238. В `CorpseRecovery.tryClaim` только после выдачи всех вещей из изначально непустого списка и удаления ключа `settledlands_corpse_items`: `corpse.dropLeash(true,true)` (прежняя ванильная механика возвращает прикреплённый поводок) и `corpse.discard()`. Пустое тело без вещей не удаляется. При неполной выдаче труп и привязанный поводок остаются. Нет нового tick/per-frame кода; обычная смерть, алтарь, render, здоровье и события 238 не изменены. Ровно три записи изменены относительно 238: `CorpseRecovery.class`, TOML и patch-info; прочие методы helper и все остальные классы побайтно сохранены.

Полный `tests/gate_build239.py` проходит: включает весь gate 238/237 и §8, точный diff и воспроизводимость, реальные байткоды на Java 21, 238 как негативный контроль, проверки полного/частичного/пустого инвентаря, невалидного CODEC, повторных событий, владельца/очереди/измерения/мёртвого игрока, двух тел, имитации загрузки и поводка. Мутанты отсутствия удаления/возврата поводка, преждевременного удаления, обхода UUID/очереди детектируются. Фактический Minecraft/NeoForge не запущен; стенды не равны игре.

Backup 239 содержит AI-GUIDE, документацию, инструменты, тесты, jar 239 и входные jar 230/232–238 в `test-inputs/`. 230/233/234 заведомо сломаны и нужны только для негативных тестов. Команда повторного шлюза из backup — в §8 ниже. При игровом сбое нужны свежий `latest.log` этого запуска, время, кто нажал, состояние инвентаря/трупа и наличие поводка.

## Историческое состояние: build 238

Пользователь подтвердил: **build 237 прекрасно работает в игре**. Затем попросил возврат вещей из своего трупа по ПКМ после самостоятельного выхода из чистилища и здоровье трупа 1 HP, гроба 60 HP. Уточнение через `ask_user`: новая выдача только для смерти **во вселённом теле**, обычные смерти не менять.

Кандидат `settledlands-0.8.0-build238-corpse-recovery.jar`: 1 544 550 байт, SHA-256 `632a64b9a94c31165f351152e260ece774c62870570a4ac6101c06ca634a84c2`. В игре/NeoForge он **ещё не проверен**. Перед игровыми испытаниями сохранить копию мира, убрать другие jar SettledLands из `mods`; backup ZIP в `mods` не класть.

Кодовый путь (байткод, без javac): `IvyDeathScene` вызывает новый `CorpseRecovery.tryClaim` перед существующей отменой обычных `EntityInteract` и `EntityInteractSpecific`. Предмет гроба, поводок и инструменты редактирования идут по прежнему пути. Допуск: живой `ServerPlayer`, UUID совпадает с `GuideCorpseNpc.ownerUuid`, игрок не в `PurgatoryData.deadQueue` и не в измерении чистилища. Содержимое считывается из `settledlands_corpse_items` только выбранного трупа; обычный дроп и код алтаря не изменены.

Инвентарь наполняется по слотам ограниченными порциями. После каждой порции изменяется только исходный NBT `count`; при заполнении остаток остаётся в трупе, при повторном ПКМ дубликатов нет. Это необходимо и в creative: ванильный `Inventory.add(stack)` может обнулить непоместившийся остаток. `ItemStack.CODEC` + `DataResult.result()` не принимает частичный разбор, а исключения парсинга не удаляют NBT. Серверное `syncHealth` при конструкторе и `setCoffin` (включая загрузку) задаёт максимум/текущее здоровье 1/1 или 60/60. `hurt`, исключение `/kill`, поводок, алтарь, нежить, рендер 237 и дроп обычной смерти не менялись.

Шлюз `tests/gate_build238.py` полностью прошёл: полный шлюз 237 и его калибровки, точный diff с 237 (+1 класс, 6 изменённых записей), TOML/языки/mixins/CRC, Java 21, 5 поведенческих fixture, негативные мутанты UUID и очереди. JVM-fixture действительно исполняет байткод мода, но использует стенды Minecraft/NeoForge/DFU и **не является игровым тестом**. Проверить в игре возврат из тела, чужого владельца, полный/частичный инвентарь и повторный ПКМ, сохранение/загрузку, 1/1 и 60/60, гроб/поводок, обычную смерть и алтарь. При проблеме запросить свежий `latest.log`, состояние вещей и время.

Инструмент сборки — `tools/patch_corpse_reclaim238.py`. Backup 238 содержит оба jar, входы 230/232–236 в `test-inputs/`, инструменты/тесты, инструкции и AI-GUIDE. Билды 230/233/234 заведомо сломаны: только негативные тесты, не устанавливать. Работать только в закреплённой сессионной ветке `arena/24676dbe-mod`.

## Историческое состояние после сборки build 237

Пользователь проверил build 236: труп всё ещё не виден. Более новый приложенный лог (1 285 346 байт, SHA-256 `f6c87a4cf8668a0ba5697111356ea99d29cf35378ad2d0e12839f17f0b431062`) подтверждает загрузку 236; старый `origin/main:latest.log` ниже про битую загрузку — **не этот запуск**. В свежем логе probe показывает негроб с пустой анимацией, а также `ivy_oleander.bbmodel → BbModel` и пустую текстуру, но не пишет ID. Значения могли относиться к разным сущностям; независимых маркеров смерти нет. Не утверждать, что найдена причина именно искомого трупа.

По байткоду подтверждён дефект сохранённых трупов: `readAdditionalSaveData` 236 не восстанавливает анимацию; `GuideCorpseFreezeMixin` отменяет рендер негроба без имени, содержащего `die`. Build 237 восстанавливает `die` при загрузке только если анимация `null`/пустая и это не гроб, а при стандартном спавне задаёт её до добавления сущности. Непустые анимации не переписываются. Дополнительно переделан неверный фрагмент 236 в `dressBodyCorpse`: старая вставка обходилась на успехе и на исключении могла вызвать `IllegalAccessError`; вместо неё текстура готовится через публичный профиль, логируется один раз при успешной подготовке. Сохранены здоровье/неуязвимость, старая логика имён и гробов. Клиентский `CorpseRenderProbeMixin` выключен в конфигурации, поскольку его глобальные значения смешивают сущности и спамят на кадрах.

**База 237:** `settledlands-0.8.0-build237-corpse-pose.jar`, 1 541 606 B, SHA-256 `9abf34da8a566d882e4bb7a4561a93e019aa4c5a58461ec1e54fc51039e58c45`. Структурный и полный JVM-шлюз §8 прошли. Настоящие байткоды чтения, спавна и подготовки трупа исполнены на JVM 21 со стендами и отрицательным контролем 236; дополнительная fixture исполняет настоящие `GuideNpc.applyProfile/setProfile`. После выпуска **пользователь подтвердил работу 237 в игре**. Minecraft/NeoForge в песочнице не запускались. При пустом имени модели и при непустой анимации без `die` исправление 237 имя не угадывает.

В текущей сессии работать и пушить только в закреплённую ветку `arena/24676dbe-mod`. Указания ниже про историческую `arena/829e0ad0-mod` не дают права переключаться на неё; в будущей сессии приоритет у системного имени ветки. Входные jar для полного воспроизведения лежат в backup ZIP в `test-inputs/`; 230/233/234 заведомо сломаны и не должны устанавливаться.

Ниже сохранена историческая передача 236; при противоречии приоритет у актуального состояния выше, §8 и `SESSION-STATE.md`.

Файл для новой сессии. Читать целиком до первой сборки. Всё, что ниже, проверено
по байткоду/логам, а не «по памяти». Дата: 27.10.2026.

---

## 0. Задача в одну строку

Труп игрока (`dev.settledlands.npc.GuideCorpseNpc`) **не рисуется моделью** —
либо ничего не видно («прозрачный»), либо встроенная заглушка. Живые NPC при этом
рисуются нормально. Нужно найти, почему у трупа не разрешается имя модели, и
починить. Собирать jar агент обязан сам (компилятора нет — только правка байткода
и новые классы).

Исторический кандидат был build 236 (см. §4): пользователь проверил его в игре, проблема осталась. Позднее пользователь подтвердил, что build 237 работает. Текущий кандидат 240 и новые задачи описаны в начале.

---

## 1. Первые действия новой сессии (5 минут, ничего не собирать)

```bash
cd /home/user/mod
git fetch origin && git log --oneline -3 origin/main -- latest.log
git checkout origin/main -- latest.log && wc -l latest.log
```
Сравнивать дату, версию и SHA файла с приложенными отдельно логами. Отсутствие нового файла в `main` **не доказывает**, что игру не запускали: после 236 пользователь приложил свежий лог отдельно. После проверки 237 нужен именно лог этого нового запуска.

Дальше — только чтение, без сборки:
```bash
python3 tools/disasm.py settledlands-0.8.0-build236-corpse-tex.jar \
    --class dev/settledlands/npc/GuideNpc.class --method applyProfile
python3 tools/disasm.py settledlands-0.8.0-build236-corpse-tex.jar \
    --class dev/settledlands/npc/GuideCorpseNpc.class
```

---

## 2. Как устроен путь рендера (проверено по байткоду)

```
GuideRenderer.renderCorpse(...)                 (клиент)
  ├─ GuideCorpseFreezeMixin (@Inject HEAD)      dev/settledlands/mixin/GuideCorpseFreezeMixin
  │    if (!anim.contains("die")) → ci.cancel()          // живой рендер не наш случай
  │    m = BbModelManager.getModel(npc.texturePath())
  │    if (m == null) → ci.cancel()  → НЕ РИСУЕТСЯ НИЧЕГО  ← «прозрачный труп»
  │    else → ci.cancel(); m.render(...)
  └─ иначе ванильный MobRenderer с GuideModel + guide_npc.png  ← «заглушка»
```

`GuideNpc.texturePath()` — 14 байт: `entityData.get(DATA_TEXTURE)` (никогда не
переопределён в `GuideCorpseNpc`).

`BbModelManager.getModel(String name)`:
* `null`, пустая/пробельная строка, `"default"` (без учёта регистра) → `null`;
* иначе `BbModelStorage.findModelFile(name)`; если файла нет → `null`;
* исключение парсера → печать в `System.err` и `null`.

`BbModelStorage.findModelFile(name)`:
* `modelsDir.resolve(name)` и `isRegularFile` → файл;
* иначе, если имя не оканчивается на `.bbmodel` → `modelsDir.resolve(name + ".bbmodel")`;
* иначе `null`.
`modelsDir` = `FMLPaths.GAMEDIR / "settledlands/models"` (у юзера:
`.minecraft/settledlands/models/`, там лежат `ivy_oleander.bbmodel`, `red_coffin.bbmodel`).
Путь **не зависит от регистра только на Windows-ФС**, сам код регистро-зависим.

`DATA_TEXTURE` (тип `EntityDataAccessor`, синхронизируемое поле) выставляется:
1. в `GuideNpc.applyProfile()` — **последними** инструкциями (offset 183..209 из 236);
2. в `GuideNpc.setProfile()` — косвенно, он вызывает `applyProfile()` в конце,
   но `putfield profile` происходит **после** `mobilitySettingsChanged()`/`resetMobility()`.

Вызовы у трупа:
```java
// PlayerCorpsePossession.dressBodyCorpse(npc, pending)
try { npc.setYRot(...); npc.setYBodyRot(...); npc.setYHeadRot(...); } catch (Throwable ignored) {}
try { if (!pending.model().isEmpty()) { prof = new NpcProfile(); ... npc.setProfile(prof); npc.applyProfile(); } } catch (Throwable ignored) {}
try { имя } catch (Throwable ignored) {}
try { playCustomAnimation("die", false) } catch (Throwable ignored) {}
try { setHealth(1f); setInvulnerable(true) } catch (Throwable ignored) {}
```
Важно: `setProfile()` уже вызывает `applyProfile()`, а строка `npc.applyProfile()`
идёт второй раз и работает с **тем** профилем, который успел записаться в поле.

Имя модели у трупа берётся при смерти игрока:
```
LivingDeathEvent → PlayerCorpsePossession.onPlayerDeath
    model = PossessionSystem.isPossessed(p) ? safe(PossessionSystem.possessModelKey(p)) : ""
    → DeadWatch(model, ...)
    → onServerTick → спавн GuideCorpseNpc → dressBodyCorpse(new PendingBody(model, name, ...))
```
а `possessModelKey(p)` — это NBT игрока `settledlands_possess_model`, куда при
вселении писалось `npc.texturePath()` (`PossessionSystem.possess`).

---

## 3. Что уже сделано и чем это закончилось

| билд | что делал | итог |
|---|---|---|
| 229 | sable-AABB | рабочая база |
| 230 | вставка 14 байт в начало `applyProfile` | ❌ AIOOBE при загрузке миксинов (вставка была неверной: `aload_1` до `astore_1`, сломанное смещение `Code`) |
| 231 | новый миксин `EarlyCorpseTextureMixin` | ❌ падение на скане (`@Mixin.value` одиночным `c`) |
| 232 | тот же миксин, аннотации массивами | ⚠️ грузится, но модели нет. Маркер `corpse texture pre-set` в логе был **неверной трактовкой** |
| 233 | зонд-класс `TexProbe` + `CorpseRenderProbeMixin` | ❌ скан: `SourceFile` добавлен в пул после `dump()` |
| 234 | те же зонды, исправлен пул | ❌ `VerifyError: Illegal target of jump or branch` (смещение считалось от операнда) |
| 235 | то же + исправлены смещения + JVM-самотест | ✅ грузится (это уже не проверялось в игре отдельно) |
| 236 | `DATA_TEXTURE` в начале `applyProfile`; попытка подготовки/лога в `dressBodyCorpse` | загружен в свежем логе, труп всё ещё невидим; вставка в `dressBodyCorpse` ошибочна |
| 237 | восстановление `die`, безопасная подготовка через профиль, выключение спамящего probe | пользователь подтвердил, что в игре работает |
| 238 | возврат вещей владельцу после выхода из чистилища; 1/1 и 60/60 | JVM-шлюз пройден, игровая проверка ещё нужна |
| 239 | удаление трупа/гроба после полной выдачи и возврат прикреплённого поводка | JVM-шлюз пройден, игровая проверка ещё нужна |

---

## 4. Билды, их sha256 и статус

Старые билды доступны в исторической ветке `arena/829e0ad0-mod`; необходимые входы также упакованы в backup 237. В текущей сессии не переключаться на историческую ветку.

| файл | байт | sha256 | статус |
|---|---|---|---|
| `settledlands-0.8.0-build229-sablesweep.jar` | — | — | рабочая база (до фиксов) |
| `settledlands-0.8.0-build230-modelfix.jar` | 1536982 | `b41dc40574e3c2d8…` | отозван |
| `settledlands-0.8.0-build231-earlytex.jar` | 1538081 | `c1ca5ebf9d642bbd…` | отозван |
| `settledlands-0.8.0-build232-earlytex2.jar` | 1538344 | `a75d8a8f724f5e74…` | рабочая база для диффов, модели нет |
| `settledlands-0.8.0-build233-probe.jar` | 1540690 | `0592d61c4ffe5888…` | отозван (регресс-кейс валидатора) |
| `settledlands-0.8.0-build234-probe.jar` | 1540699 | `f83b8c69178176ec…` | отозван (регресс-кейс JVM-верификатора) |
| `settledlands-0.8.0-build235-probe.jar` | 1540699 | `cfddca97baf6a98b…` | зонд, грузится |
| `settledlands-0.8.0-build236-corpse-tex.jar` | 1541160 | `4d640528b565e788…` | загружен в игре, проблема осталась |
| `settledlands-0.8.0-build237-corpse-pose.jar` | 1541606 | `9abf34da8a566d88…` | пользователь подтвердил в игре |
| `settledlands-0.8.0-build238-corpse-recovery.jar` | 1544550 | `632a64b9a94c3116…` | предшествующий кандидат; игра не подтверждена |
| **`settledlands-0.8.0-build239-empty-corpse-cleanup.jar`** | **1544746** | **`b68fd79357da507f…`** | **текущий кандидат: полный JVM-шлюз пройден, игровая проверка ожидается** |

Полные хеши — в `git log` / `SESSION-STATE.md`.

---

## 5. Исторический старый лог (origin/main `10b423f`, 1170 строк) — НЕ свежий лог после 236

```
[Render thread/FATAL] Error during pre-loading phase:
  File mods\settledlands-0.8.0-build236-corpse-tex.jar is not a jar file
Caused by: java.util.zip.ZipException: zip END header not found
...
java.lang.ExceptionInInitializerError
Caused by: java.lang.IllegalStateException: zetafix: could not resolve mod container for quark
```
Это **недокачанный jar** (обрезанный файл), мод вообще не загрузился, остальное —
каскад. Сам артефакт целый: 355 записей, EOCD на 1 541 138, `zipfile.testzip()` → `None`.

Для текущего билда инструкция — `CHECK-JAR-237-RU.txt` (PowerShell `Invoke-WebRequest -OutFile` и сверка размера/хеша). GitHub Contents API не возвращает base64 для файлов >1 MiB, поэтому не использовать его как резерв скачивания.
**Правило: при «вылете» сначала сверять размер/хеш скачанного файла, потом код.**

---

## 6. Маркеры, которые надо искать в НОВОМ логе

С build 237 клиентский `CorpseRenderProbeMixin` отключён, поэтому строки `client.corpse.*` ожидаемо отсутствуют. Серверный `[corpse]` пишет один раз на успешном пути подготовки possessed-тела, но не содержит ID и не заменяет подтверждение создания конкретной сущности. Не выводить связь между значениями разных сущностей без адресной диагностики.

```
[SettledLands][corpse] model=<...> tex=<...>          ← 236, сервер: что записали трупу
[SettledLands][probe] client.corpse.coffin
[SettledLands][probe] client.corpse.anim
[SettledLands][probe] client.corpse.tex               ← что видит клиент
[SettledLands][probe] client.corpse.model             ← разрешилась ли модель
[SettledLands][probe] client.modelsDir
[SettledLands][probe] client.models                    ← какие файлы клиент видит
[SettledLands] player death at (...) possessed=... — corpse watch scheduled   ← уже было в 229
```
Исторический `TexProbe` дедуплицирует каждую метку глобально, не по ID: чередование сущностей всё равно вызывает per-frame спам. В 237 его клиентский вызов отключён.

---

## 7. Дерево решений по новому логу

### A. `model=` пустое (сервер не получил имя модели)
Значит `possessModelKey(player)` пуст → при вселении `npc.texturePath()` был `""` либо
`setPossessed` не выполнился. Смотреть `PossessionSystem.possess` (184 Б) — он пишет
`settledlands_possess_model = npc.texturePath()` перед `npc.discard()`.
Возможная диагностика в будущем билде (не считать доказанным исправлением 237): в `possess` логировать `texturePath()` и `profile.texture`,
при пустом `texturePath()` брать `this.profile.texture` (поле
`dev/settledlands/npc/NpcProfile.texture`, `getfield`) и писать через
`Objects.toString(x, "")`. Инструменты: `tools/classedit.py` (`insert`), `tools/smt.py`.

### B. `model=` есть, `client.corpse.tex` пустая на клиенте
Синхронизация `SynchedEntityData`: значение записали после `addFreshEntity`, и dirty-бит
не ушёл / записали до добавления. Фикс: писать `DATA_TEXTURE` **до** спавна в
`DeadWatch`-пути (там есть готовый `model`), либо в `GuideCorpseNpc.tick()` на сервере
(дешёвая самопроверка «поле пустое, а профиль есть → записать»).

### C. `client.corpse.tex` есть, `client.corpse.model` = `null`
Не находится файл модели. Сверить `client.corpse.tex` с `client.models`:
* имя с расширением/без (`.bbmodel` добавляется автоматически, если его нет);
* регистр (`Ivy_Oleander.bbmodel` vs `ivy_oleander.bbmodel`) — код регистро-зависим;
* имя с каталогом/пробелами;
* ошибку парсера искать в `System.err` этого же лога (там печатается имя файла и стек).
Фикс — правка `BbModelStorage.findModelFile` или `BbModelManager.getModel`
(небольшие методы, вставка в `Code` через `tools/classedit.py`).

### D. Всё непустое и `client.corpse.model` не null, но труп не виден
Тогда проблема в самом `BbModel.render(...)` (поза/анимация `die`/масштаб) —
начинать с `CorpseRenderProbeMixin`: добавить в лог аргументы `render` (свет, overlay,
частичный тик) и результат `BbAnimation`.

---

## 8. Инструменты и обязательный шлюз перед раздачей

**Актуально для 251:** полная команда и фиксированные внешние входы — в `BACKUP-251-RU.txt`. Сначала проверить полный `gate_build251.py` и отдельный `jvm_hns_modifiers251.py` на основном JAR, затем повторить оба из чистой распаковки backup и проверить manifest/побайтную воспроизводимость архива. Вложенный gate 250 запускает 249→237 и все перечисленные ниже калибровки. Результаты должны быть записаны вне архива. Java 21 запускает реальный байткод на стендах, но не заменяет игру.

- `tools/classedit.py`, `tools/smt.py`: точечные вставки с пересчётом переходов, таблиц и фреймов; не править байткод вручную.
- `tools/patch_corpse_pose237.py`: воспроизводимый патч с контролем SHA входов 235/236 и точного диффа.
- `tools/validate_jar.py`: структура каждого класса, TOML, mixin JSON, пулы, инструкции, атрибуты и границы переходов.
- `tools/jvm_verify.py`: настоящая JVM, реальные классы, синтетические зависимости; цель с аргументами задаётся полностью. JVM должна выдать `DECLARED` для каждой цели; ошибку до этого нельзя считать успехом.
- `tools/selftest_probe.py`, `tools/check_mixin_class.py`, `tools/verify_jar.py`: отдельные JVM/аннотации/zip/lang/mixins/TOML и строгий allowlist диффа.
- `tests/jvm_corpse_load.py`, `jvm_corpse_spawn.py`, `jvm_corpse_dress.py`, `jvm_corpse_realprofile.py`: реальные байткоды и исполняемые заглушки, отрицательный контроль build 236, границы поведения. Последний тест запускает реальные `GuideNpc.applyProfile/setProfile`; при нормальном пути дополнительный вызов повышает число пересчётов размеров с двух до трёх — это не игровой тест.

### Исторический полный повторяемый шлюз build 245

Историческая команда — в разделе build 245 ниже. Она включает весь шлюз 244–237 и §8, настоящую JVM 21, последовательность 3 платных возвратов/четвёртой смерти, drop/clone/самостоятельный выход/новый NPC/login, сторонние modifiers, отложенные watches, владельцев и 18 отрицательных мутантов. Стенды не являются Minecraft/NeoForge; игровое испытание и проверка mixin обязательны отдельно.

### Исторический шлюз build 244

Команда — в историческом разделе 244 выше. Она включает полный шлюз 243 и историю, настоящую JVM, смерть → дроп → clone → самостоятельный выход → ПКМ, настоящую ветку диалога NPC на стендах, обе руки и 19 отрицательных мутантов. Пользователь подтвердил работу 244.

### Исторический шлюз build 243

Команда — в разделе истории build 243 выше. Она включает полный шлюз 242 и историю, настоящую JVM, жизненный цикл, алтарь, старые данные очереди, login, диагностический зонд и 15 отрицательных мутантов.

### Исторический шлюз build 242

Команда — в историческом разделе build 242 выше. Она включает полный шлюз 241/240/239/238/237 и 13 отрицательных JVM-мутантов.

### Исторический полный повторяемый шлюз build 241

Команда — в разделе истории build 241 выше. Она включает полный шлюз 240/239/238/237 и 10 отрицательных мутантов. Исполняемый стенд не является работающей игрой.

### Исторический полный повторяемый шлюз build 240

Из распакованного backup 240 (Python 3.11+ и Java 21; `javac` не нужен). При отсутствии JVM можно установить её вне репозитория: `python3 -m pip install --no-cache-dir --target /tmp/jdkpkg 'jdk4py==21.0.8.2'`.

```bash
python3 tests/gate_build240.py --inputs test-inputs \
  --base237 test-inputs/settledlands-0.8.0-build237-corpse-pose.jar \
  --base238 test-inputs/settledlands-0.8.0-build238-corpse-recovery.jar \
  --base239 test-inputs/settledlands-0.8.0-build239-empty-corpse-cleanup.jar \
  --java /path/to/java21 --jar settledlands-0.8.0-build240-npc-local-cult.jar
```

Ожидается `BUILD 240 GATE: PASS`. Включает gate 239/238/237 и все калибровки §8. `tools/patch_npc_local_cult240.py` принимает только точный SHA базы 239; `tools/make_backup240.py` собирает воспроизводимый ZIP с проверочным манифестом. Проверяются реальное исполнение байткода и три негативных мутанта, но вместо игровых API — стенды. После изменения `tools/jvm_verify.py` обязательно перепроверять положительные и отрицательные калибровки, уже включённые в gate.

### Исторический полный повторяемый шлюз build 239

Из распакованного backup 239 (нужны Python 3.11+ и Java 21; без javac):

```bash
python3 tests/gate_build239.py --inputs test-inputs \
  --base237 test-inputs/settledlands-0.8.0-build237-corpse-pose.jar \
  --base238 test-inputs/settledlands-0.8.0-build238-corpse-recovery.jar \
  --java /path/to/java21 --jar settledlands-0.8.0-build239-empty-corpse-cleanup.jar
```

Ожидается `BUILD 239 GATE: PASS`. Включены оба исторических шлюза и реальные JVM-тесты на синтетических API; отдельно нужен игровой тест. `tools/patch_corpse_cleanup239.py` требует точный SHA базы 238. Backup детерминированно создаётся `tools/make_backup239.py`; Manifest проверяет все содержимые файлы.

### Исторический полный повторяемый шлюз build 238

Из распакованного backup 238 (Java 21 можно временно поставить `python3 -m pip install --no-cache-dir --target /tmp/jdkpkg 'jdk4py==21.0.8.2'`):

```bash
python3 tests/gate_build238.py --inputs test-inputs \
  --base237 test-inputs/settledlands-0.8.0-build237-corpse-pose.jar \
  --java /path/to/java21 --jar settledlands-0.8.0-build238-corpse-recovery.jar
```

Ожидается `BUILD 238 GATE: PASS`. Запускает весь шлюз 237 ниже, проверяет все изменённые классы 238 и точный diff, старые 4 fixture также на 238, новую `tests/jvm_recovery238.py` и отрицательные мутанты обхода владельца/очереди. В fixture код мода настоящий, но игровые зависимости — стенды; игра ещё не проверена. После изменений `jvm_verify` калибровки старых сломанных билдов обязательны.

### Исторический полный повторяемый шлюз build 237

Backup содержит входные jar в `test-inputs/`; 230/233/234 использовать только как отрицательные тесты. Нужны Python 3.11+ и **JVM 21**, не `javac`. При её отсутствии агент может временно установить `jdk4py==21.0.8.2` через pip вне репозитория.

```bash
python3 tests/gate_build237.py --inputs /path/to/test-inputs \
  --java /path/to/java21 \
  --jar settledlands-0.8.0-build237-corpse-pose.jar
```

Ожидается `BUILD 237 GATE: PASS`. Скрипт проверяет воспроизводимую сборку, валидатор на 232 и 237, отрицательные 233/234, точный allowlist относительно 232 и 236, TOML, языки и mixin-классы, побайтное соответствие `TexProbe` генератору и его JVM-самотест. Дополнительно проверяются CRC, отсутствие/невалидность языка, несовпадение ключей, отсутствующий mixin, ошибочный allowlist и невозможная цель JVM-проверки: каждый негативный тест обязан падать.

`jvm_verify.py` после любой правки требует повторной калибровки: build 230 `GuideNpc#applyProfile` → `VerifyError: Bad instruction`; build 234 `TexProbe#logObj(java.lang.String,java.lang.Object)` → `VerifyError: Illegal target of jump`; build 232/236 `GuideNpc#applyProfile` и build 235 `TexProbe#logObj(...)` → OK. Для 237 отдельно проверять `GuideNpc#applyProfile`, `GuideCorpseNpc#readAdditionalSaveData(net.minecraft.nbt.CompoundTag)`, `CorpseLifecycle#onPlayerDeath(net.neoforged.neoforge.event.entity.living.LivingDeathEvent)` и `PlayerCorpsePossession#dressBodyCorpse(dev.settledlands.npc.GuideCorpseNpc,dev.settledlands.npc.PlayerCorpsePossession$PendingBody)`. Текущий скрипт всё это делает.

Обязательно выполняются четыре поведенческие fixture с отрицательными контролями на 236. Реальная JVM с тестовыми заглушками **не** подтверждает работу NeoForge/рендера в игре; после каждого билда нужен отдельный пользовательский игровой прогон.

---

## 9. Грабли байткода (стоили шести отозванных сборок)

1. **Не вставлять байты «на глаз»** — только `tools/classedit.py`.
2. `rel = target_addr − opcode_addr` (не операнда!) — инцидент 234.
3. `invokeinterface`: `count = objectref + слоты аргументов` (для
   `info(String,Object,Object)` = **4**), последний байт `0` — инцидент 236α.
4. `tableswitch`/`lookupswitch` выравниваются по 4 байта от **абсолютного** адреса:
   длина вставки обязана быть кратна 4 (добивается `nop`) — инцидент 236β.
5. Порядок сборки пула: все `cp.utf8(...)` **до** `dump()` (инцидент 233).
6. `@Mixin.value` и `targets` — **массивы** (`5b 00 01 63 …`), иначе ClassCastException.
7. Свой класс без ветвлений → фреймы не нужны; с ветвлениями → либо major 49,
   либо честные `StackMapTable` (и только `jvm_verify.py` это подтверждает).
8. `ldc` — индекс ≤ 255, иначе `ldc_w`.

---

## 10. Правила, которые юзер требует соблюдать (нарушать нельзя)

* Ответы **короткие**, без «простыней» и оправданий. Схема: что случилось → почему →
  что сделано → что проверить → ссылка.
* В каждом ответе, где есть собранный jar, — **кликабельная markdown-ссылка**
  `[имя](https://raw.githubusercontent.com/BORGERone/mod/arena/24676dbe-mod/<файл>)`,
  резерв `https://github.com/BORGERone/mod/raw/arena/24676dbe-mod/<файл>`. В новой сессии подставить её закреплённую ветку.
  Не вставлять URL в блок кода, не давать «голым текстом». Jar первым, zip вторым.
* Всегда рядом: размер, `sha256`, `certutil -hashfile <файл> SHA256`, и напоминание
  «Сохранить ссылку как…». GitHub Releases для раздачи **не** использовать.
* Перед выдачей ссылки проверять файл в текущей ветке: `gh api repos/BORGERone/mod/contents/<файл>?ref=arena/24676dbe-mod --jq .size`. Contents API для файлов >1 MiB не даёт base64 в `content` и не подходит как запасная скачка.
* Историческая ситуация: лог лежал в origin/main. Сейчас пользователь загружает его через Google Drive; читать реальный новый файл, не перезаписывать изменения из main.
* jar собирает **агент**, вариант «поставь javac/собери сам» отклонён.
* Каждый билд: backup + sha256, `present_file` jar → zip → jar (jar остаётся последним в просмотре), AI-GUIDE внутрь zip,
  toml проверять `tomllib`.
* Самодеятельные фиксы вне списка задачи — только **предлагать** (PROPOSE-ONLY).
* Не пересобирать `GuideNpc`/`NpcContent`/`GuideRenderer` из `patch-src-229`
  (там лежит только `PlayerCorpsePossession.java`, он НЕ компилируется) — только
  байтпатч/миксин/новый класс.
* Труп и гроб не должны быть нежитью (откат 205): 1/1 и 60/60 HP, прежняя неуязвимость (включая существующее исключение `/kill`),
  привязка поводком к гробу. Отклонены: микро-хитбокс, keyAttack-гейт, снятие
  land-гейта, щит +40°, crossfade 0.2s, HnS-переопределения, «бонусные» фичи.

---

## 11. Как проверить build 240 в игре

1. Сохранить копию мира. В `mods` оставить только `settledlands-0.8.0-build240-npc-local-cult.jar`; ZIP туда не класть. Сверить размер и SHA из начала файла.
2. Бестелесным игроком попытаться вселиться в **нового или проверенно не отмеченного** NPC: отсутствие `культ`, 0 и отрицательное значение должны запрещать вселение, даже если у игрока положительные личные или общие очки `культ`. Переменная NPC не должна при этом создаваться или изменяться.
3. Через прежний сценарий/редактор локальных переменных NPC выставить именно локальное `культ` и выполнить действие графа; с 1 и больше вселение должно работать по прежним правилам, с 0 — нет. Проверить, что локальное значение одного NPC не даёт допуск другому; имя `культ` писать точно, с тем же регистром.
4. Старые NPC могли получить `культ=1` от прежнего моста; обновление не удаляет такие значения. Проверить сохранение/повторный вход, а также старую механику смерти во вселённом теле, возврат вещей, тело/гроб и поводок. Обычная смерть и алтарь должны работать как прежде.
5. Если сбой — приложить свежий `latest.log` этого запуска, время, точные значения переменных игрока и выбранного NPC и описать способ проверки. Игровой результат не заявлять без подтверждения пользователя.

### Исторический план проверки build 239

1. Сохранить копию мира, убрать предыдущий jar из `mods`, поставить только build 239; сверить 1 544 746 байт и SHA-256 из актуального состояния. Backup ZIP не класть в `mods`.
2. Войти в NPC, умереть, самостоятельно выйти из чистилища, найти именно свой труп и нажать ПКМ пустой рукой. После полного возврата труп исчезает; отдельно проверить гроб и прикреплённый поводок (отсоединяется и выпадает).
3. При полном/частичном инвентаре труп или гроб должен остаться, как и оставшиеся вещи; освободить место и повторить. Проверить чужого игрока, повторный ПКМ и сохранение/загрузку. Пустой обычный труп по ПКМ не пропадает.
4. Проверить здоровье тела 1/1 и гроба 60/60, неуязвимость, механику поводка и алтарь; обычная смерть должна работать как раньше. Если обнаружен сбой — приложить свежий `latest.log` этого прогона, указать время и состояние вещей.

### Исторический план проверки 237 (уже пройден пользователем)

1. Удалить build 236 из папки `mods`, поставить только build 237; сверить 1 541 606 байт и SHA-256 из актуального состояния. Backup ZIP не класть в `mods`.
2. Войти в мир, проверить уже существовавший сохранённый труп; затем вселиться в NPC и умереть, дождаться **нового** трупа. Отдельно убедиться, что гроб работает как раньше.
3. Если труп всё ещё не виден — выйти из мира, приложить свежий `latest.log` этого запуска и сообщить приблизительное время смерти/тип трупа. Искать `[SettledLands][corpse] model=… tex=…`, маркеры смерти, ошибки. Отсутствие `[probe]` в build 237 ожидаемо.
4. Не угадывать имя модели при пустом `model`/`tex`; не считать глобальные значения в логах 236 доказательством, что они от одной сущности. Если одного серверного лога недостаточно, сначала разработать адресный одноразовый зонд без per-frame спама.

---

## 12. Где что лежит

```
/home/user/mod/
  AI-GUIDE-SettledLands.md      правила, §11 JVM-верификация, §12 битая закачка
  SESSION-STATE.md              журнал решений по билдам (28 пунктов)
  HANDOFF-NEXT-SESSION-RU.md    этот файл
  CHECK-JAR-239-RU.txt          PowerShell-проверка скачанного jar
  README-Build239-EmptyCorpseCleanup-RU.txt  сведения и игровые шаги
  latest.log                    старый origin/main лог (не более новый attachment после 236)
  tools/                        сборщики 238/239, байтредактор, валидаторы
  tests/                        полный шлюз и JVM-fixture
  settledlands-0.8.0-build237-corpse-pose.jar   подтверждённая база
  settledlands-0.8.0-build238-corpse-recovery.jar
  settledlands-0.8.0-build239-empty-corpse-cleanup.jar
  SettledLands-Build239-EmptyCorpseCleanup-Source.zip  все тестовые входы, инструменты, AI-GUIDE и jar
```

Полезные дескрипторы/поля, которые точно понадобятся:
```
dev/settledlands/npc/GuideNpc            entityData:Lnet/minecraft/network/syncher/SynchedEntityData;
                                         DATA_TEXTURE:Lnet/minecraft/network/syncher/EntityDataAccessor;
                                         profile:Ldev/settledlands/npc/NpcProfile;
                                         setProfile(Ldev/settledlands/npc/NpcProfile;)V
                                         applyProfile()V   texturePath()Ljava/lang/String;
dev/settledlands/npc/NpcProfile          texture:Ljava/lang/String;
dev/settledlands/npc/PlayerCorpsePossession   LOGGER:Lorg/slf4j/Logger;
                                         dressBodyCorpse(Ldev/settledlands/npc/GuideCorpseNpc;Ldev/settledlands/npc/PlayerCorpsePossession$PendingBody;)V
                                         onPlayerDeath(Lnet/neoforged/neoforge/event/entity/living/LivingDeathEvent;)V
dev/settledlands/npc/PossessionSystem    possess(Lnet/minecraft/server/level/ServerPlayer;Ldev/settledlands/npc/GuideNpc;)V
                                         possessModelKey(Lnet/minecraft/world/entity/Entity;)Ljava/lang/String;
                                         setPossessed(Lnet/minecraft/server/level/ServerPlayer;Ljava/lang/String;Ljava/lang/String;)V
dev/settledlands/model/BbModelManager    getModel(Ljava/lang/String;)Ldev/settledlands/model/BbModel;
dev/settledlands/model/BbModelStorage    findModelFile(Ljava/lang/String;)Ljava/io/File;
                                         getModelsDir()Ljava/nio/file/Path;
```

---

## 13. Что делать в первую очередь (чек-лист)

- [ ] Уточнить результат игровой проверки **239**; не считать JVM-стенды игрой. 237 подтверждён, 238 и 239 пользователем ещё не подтверждены.
- [ ] Если пользователь сообщил о сбое, анализировать самый свежий приложенный лог именно от 239, время, владельца, поводок, состояние списка и инвентаря; не затереть его старым `origin/main:latest.log`.
- [ ] Учесть явно выбранный scope: только смерть во вселённом теле; обычную смерть не менять.
- [ ] При необходимости чинить через `tools/classedit.py` + `tools/smt.py` и прогнать полный шлюз §8, включая `gate_build239.py`, JVM и поведенческие негативные контроли.
- [ ] Обновить `SESSION-STATE.md`, `AI-GUIDE`, собрать backup, показать jar → zip → jar, выдать ссылки, размер и хеши.
