#!/usr/bin/env python3
"""Build 272: single pursuit node with dropdown + field + toggle (replaces three separate nodes from Build271)."""
import argparse
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import tomllib
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
import classedit

BASE_NAME = 'settledlands-0.8.0-build271-pursuit-node-hotfix.jar'
BASE_SHA = 'e7c2f13e5d371bc52c23959b61f14e61f4c8223800b656a11f74532320c106b1'
BASE_VERSION = '0.8.0-build271-pursuit-node-hotfix'
NEW_VERSION = '0.8.0-build272-pursuit-single-node'
MODEL_NAME = 'ivy_oleander_professions.bbmodel'
MODEL_ASSET = 'assets/settledlands/dragon_default/' + MODEL_NAME
MODEL_SOURCE = ROOT / 'assets/settledlands/dragon_default' / MODEL_NAME
MODEL_SHA = '5c4a89e36e005d3af416c9d73755e09634a1c8553c18330ef2a245ef07953da0'
ECJ_SHA = '74c93172475fee0cd4e6eefb44233516dd40525642da35d009146d97ea598229'

SOURCES = [
    'dev/settledlands/npc/NpcPursuit269.java',
    'dev/settledlands/npc/client/PursuitGraphNode272.java',
    'dev/settledlands/mixin/NpcPursuitGraphUiMixin272.java',
    'dev/settledlands/mixin/NpcPursuitContextMenuMixin272.java',
    'dev/settledlands/mixin/NpcPursuitCanvasMixin272.java',
    'dev/settledlands/mixin/NpcPursuitActionMixin269.java',
    'dev/settledlands/mixin/NpcPursuitAiMixin269.java',
]

CHANGED = {
    'dev/settledlands/npc/NpcPursuit269.class',
    'settledlands.mixins.json',
    'META-INF/neoforge.mods.toml',
    'settledlands-patch-info.txt',
    'assets/settledlands/lang/ru_ru.json',
    'assets/settledlands/lang/en_us.json',
}
ADDED = {
    'dev/settledlands/npc/client/PursuitGraphNode272.class',
    'dev/settledlands/npc/client/PursuitGraphNode272$MenuPoint.class',
    'dev/settledlands/mixin/NpcPursuitGraphUiMixin272.class',
    'dev/settledlands/mixin/NpcPursuitContextMenuMixin272.class',
    'dev/settledlands/mixin/NpcPursuitCanvasMixin272.class',
}
REMOVED = {
    'dev/settledlands/npc/client/PursuitGraphNodes271.class',
    'dev/settledlands/npc/client/PursuitGraphNodes271$MenuPoint.class',
    'dev/settledlands/mixin/NpcPursuitGraphUiMixin271.class',
    'dev/settledlands/mixin/NpcPursuitContextMenuMixin271.class',
}
CHANGELOG = (
    'Build 272 replaces three separate pursuit menu rows with a single custom node card featuring inline dropdown (NPC/player), target field, and stop toggle. '
    'Pursuit logic and Build268 profession/skin features remain; Build263 fade remains excluded.'
)
PATCHINFO = (
    'Сборка 272 заменяет три отдельные ноды преследования одной карточкой с dropdown, полем ввода и тумблером. Build269/270 не устанавливать; CUTSCENE fade Build263 не включён.'
)

PURSUIT_RU = {
    'gui.settledlands.graph.pursuit_menu': 'Преследование',
    'gui.settledlands.graph.pursuit_node': 'Преследование',
    'gui.settledlands.pursuit.target_type': 'Тип цели:',
    'gui.settledlands.pursuit.target_npc': 'NPC',
    'gui.settledlands.pursuit.target_player': 'Игрок',
    'gui.settledlands.pursuit.field_npc': 'Идентификатор NPC:',
    'gui.settledlands.pursuit.field_player': 'Ник игрока:',
    'gui.settledlands.pursuit.field_empty': '(пусто)',
    'gui.settledlands.pursuit.stop_toggle': 'Завершить преследование',
}
PURSUIT_EN = {
    'gui.settledlands.graph.pursuit_menu': 'Pursuit',
    'gui.settledlands.graph.pursuit_node': 'Pursuit',
    'gui.settledlands.pursuit.target_type': 'Target type:',
    'gui.settledlands.pursuit.target_npc': 'NPC',
    'gui.settledlands.pursuit.target_player': 'Player',
    'gui.settledlands.pursuit.field_npc': 'NPC identifier:',
    'gui.settledlands.pursuit.field_player': 'Player nickname:',
    'gui.settledlands.pursuit.field_empty': '(empty)',
    'gui.settledlands.pursuit.stop_toggle': 'Stop pursuit',
}

def compile_sources(java: pathlib.Path, base: pathlib.Path, work: pathlib.Path) -> dict[str, bytes]:
    ecj = ROOT / 'tools/vendor/ecj-3.46.100.jar'
    assert hashlib.sha256(ecj.read_bytes()).hexdigest() == ECJ_SHA
    verify_tmp = work / 'verify-tmp'
    verify_tmp.mkdir()
    env = dict(os.environ, TMPDIR=str(verify_tmp))
    targets = [
        'dev/settledlands/npc/NpcDialogueGraph#save',
        'dev/settledlands/npc/NpcDialogueGraph#load(net.minecraft.nbt.CompoundTag)',
        'dev/settledlands/npc/NpcDialogueGraph$Node#copy',
        'dev/settledlands/npc/client/NpcDialogueGraphScreen#drawNode(net.minecraft.client.gui.GuiGraphics,dev.settledlands.npc.NpcDialogueGraph$Node)',
        'dev/settledlands/npc/client/NpcDialogueGraphScreen#mouseClicked(double,double,int)',
        'dev/settledlands/npc/NpcAutoAiEngine255#runMobilityAndAutoAi(dev.settledlands.npc.GuideNpc)',
        'dev/settledlands/npc/GuideNpc#applyProfile',
        'dev/settledlands/model/BbModelStorage#findModelFile(java.lang.String)',
        'dev/settledlands/model/BbModelManager#getModel(java.lang.String)',
    ]
    subprocess.run(
        [sys.executable, str(ROOT / 'tools/jvm_verify.py'), str(base), *targets, '--java', str(java)],
        env=env, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    stub_dirs = sorted(verify_tmp.glob('jvmverify-*'))
    assert len(stub_dirs) == 1, stub_dirs
    stubs = stub_dirs[0]
    for package in ('java', 'javax', 'jdk', 'sun', 'dev'):
        (stubs / package).mkdir(parents=True, exist_ok=True)
    src_dir = ROOT / 'src' / 'build272'
    source_files = [str(src_dir / src) for src in SOURCES]
    out_dir = work / 'classes'
    out_dir.mkdir()
    cp = os.pathsep.join([str(ecj), str(stubs)])
    result = subprocess.run(
        [str(java), '-jar', str(ecj), '-source', '21', '-target', '21', '-cp', cp, '-d', str(out_dir), *source_files],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        print(result.stdout, file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        raise RuntimeError('ECJ compilation failed')
    compiled = {}
    for cls in out_dir.rglob('*.class'):
        rel = cls.relative_to(out_dir).as_posix()
        compiled[rel] = cls.read_bytes()
    return compiled

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--java', default='java')
    parser.add_argument('--base', default=str(ROOT / 'baseline271.jar'))
    parser.add_argument('--out', default=str(ROOT / f'settledlands-{NEW_VERSION}.jar'))
    args = parser.parse_args()

    base = pathlib.Path(args.base)
    assert hashlib.sha256(base.read_bytes()).hexdigest() == BASE_SHA, f'baseline SHA mismatch: {base}'
    out = pathlib.Path(args.out)

    with tempfile.TemporaryDirectory() as tmp:
        work = pathlib.Path(tmp)
        compiled = compile_sources(args.java, base, work)

        with zipfile.ZipFile(base, 'r') as zin, zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zout:
            for info in zin.infolist():
                if info.filename in REMOVED:
                    continue
                data = zin.read(info.filename)
                if info.filename in CHANGED:
                    if info.filename == 'settledlands.mixins.json':
                        mixins = json.loads(data)
                        mixins['mixins'] = [m for m in mixins['mixins'] if 'Pursuit271' not in m and 'Pursuit269' not in m]
                        mixins['client'] = [m for m in mixins['client'] if 'Pursuit271' not in m]
                        mixins['mixins'].extend([
                            'NpcPursuitActionMixin269',
                            'NpcPursuitAiMixin269',
                            'NpcPursuitCanvasMixin272',
                        ])
                        mixins['client'].extend([
                            'NpcPursuitGraphUiMixin272',
                            'NpcPursuitContextMenuMixin272',
                        ])
                        data = json.dumps(mixins, indent=2).encode('utf-8')
                    elif info.filename == 'META-INF/neoforge.mods.toml':
                        toml_data = tomllib.loads(data.decode('utf-8'))
                        toml_data['version'] = NEW_VERSION
                        data = json.dumps(toml_data, indent=2).encode('utf-8')
                    elif info.filename == 'settledlands-patch-info.txt':
                        data = PATCHINFO.encode('utf-8')
                    elif info.filename == 'assets/settledlands/lang/ru_ru.json':
                        lang = json.loads(data)
                        lang.update(PURSUIT_RU)
                        data = json.dumps(lang, ensure_ascii=False, indent=2).encode('utf-8')
                    elif info.filename == 'assets/settledlands/lang/en_us.json':
                        lang = json.loads(data)
                        lang.update(PURSUIT_EN)
                        data = json.dumps(lang, ensure_ascii=False, indent=2).encode('utf-8')
                zout.writestr(info, data)

            for rel, bytecode in compiled.items():
                zout.writestr(rel, bytecode)

    print(f'Build 272 created: {out}')
    print(f'SHA-256: {hashlib.sha256(out.read_bytes()).hexdigest()}')
    print(f'Size: {out.stat().st_size} bytes')
    return 0

if __name__ == '__main__':
    sys.exit(main())
