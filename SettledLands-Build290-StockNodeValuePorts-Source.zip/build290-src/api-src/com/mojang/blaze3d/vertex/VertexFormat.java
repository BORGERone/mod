package com.mojang.blaze3d.vertex;

public class VertexFormat {
    public enum Mode { QUADS, LINES }
}
