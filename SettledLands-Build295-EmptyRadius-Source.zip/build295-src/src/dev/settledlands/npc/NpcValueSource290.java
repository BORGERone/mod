package dev.settledlands.npc;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;

/**
 * Build 290: the blue value wires of the stock nodes.
 *
 * <p>Build 289 gave the "В радиусе" node a blue output. Build 290 gives one to the "Урон"
 * node as well (the body that damaged the NPC, see {@link NpcDamageValue290}) and gives the
 * four nodes that use a body a blue input: реплика (LINE), триггер (TRIGGER), условие (IF)
 * and переменная (VARIABLE).</p>
 *
 * <p>The input is stored in the node's own {@code varInputNode} field - it is part of the
 * graph NBT the game already writes, so the link is saved and reloaded with no new field
 * and no new data format. What the value does on each of those nodes:</p>
 *
 * <ul>
 *   <li><b>IF</b> - the condition compares "тело есть" (1) or "тела нет" (0) using the
 *       node's own operation and number, so {@code = 1} means "кто-то есть";</li>
 *   <li><b>переменная</b> - reading that variable answers 1 while the body is there and 0
 *       when it is gone, so the same IF can compare it like any other variable;</li>
 *   <li><b>реплика</b> - {@code %target%} in the text becomes the body's name,
 *       {@code %target_kind%} its kind, {@code %target_uuid%} its uuid;</li>
 *   <li><b>триггер</b> - the node's commands run only for that body: when the chain carries
 *       somebody else, or when the source has nobody, the commands are skipped.</li>
 * </ul>
 *
 * <p>Everything here runs on the server only; the client half of the wire lives in
 * {@code PursuitGraphNode272} and the pin mixin.</p>
 */
public final class NpcValueSource290 {

    /** Body name token in a line node's text. */
    public static final String TOKEN_TARGET = "%target%";
    /** Body kind token: player, npc, monster or entity. */
    public static final String TOKEN_KIND = "%target_kind%";
    /** Body uuid token. */
    public static final String TOKEN_UUID = "%target_uuid%";

    /** Set while {@code GuideDialogue#sendGraph} builds the dialogue view. */
    private static final ThreadLocal<GuideNpc> CURRENT = new ThreadLocal<>();

    /**
     * Set while a failed check node is passing the flow through to its value consumer: the
     * node's own trigger list must not run on that pass. The first trigger call after the
     * check is always that node's, so the mark is consumed once and cleared.
     */
    private static final ThreadLocal<Boolean> PENDING = new ThreadLocal<>();
    private static final ThreadLocal<Object> PENDING_TRIGGERS = new ThreadLocal<>();

    /** Last "nobody here" pass per NPC and check node, for the node's own cooldown. */
    private static final Map<GuideNpc, Map<Integer, Long>> LAST_EMPTY =
            Collections.synchronizedMap(new WeakHashMap<>());

    /** Set once, so a failing tick hook reports itself a single time. */
    private static boolean WARNED;

    private NpcValueSource290() {}

    // ---- the two producers -------------------------------------------------

    /** Called from the damage hook: remember who hit this NPC, for the "Урон" node. */
    public static void recordDamage(GuideNpc npc, net.minecraft.world.damagesource.DamageSource source,
            float amount) {
        NpcDamageValue290.record(npc, source, amount);
    }

    /** True when this node id hands out a body at all. */
    public static boolean isSource(GuideNpc npc, int nodeId) {
        return NpcCheckValue289.isCheckSource(npc, nodeId)
                || NpcDamageValue290.isDamageSource(npc, nodeId);
    }

    /** The body a source node hands out right now, or null when it has nobody. */
    public static Entity resolve(GuideNpc npc, int nodeId) {
        if (npc == null || nodeId < 0) return null;
        if (NpcCheckValue289.isCheckSource(npc, nodeId)) {
            return NpcCheckValue289.detected(npc, nodeId);
        }
        if (NpcDamageValue290.isDamageSource(npc, nodeId)) {
            return NpcDamageValue290.damager(npc, nodeId);
        }
        return null;
    }

    /** Kind label of a body, the same words the placeholders use. */
    public static String kindOf(Entity entity) {
        if (entity == null) return "none";
        if (entity instanceof Player) return "player";
        if (entity instanceof GuideNpc) return "npc";
        if (entity instanceof Enemy) return "monster";
        return "entity";
    }

    // ---- the four consumers ------------------------------------------------

    /** The node this consumer reads, or null when its input is not a value wire. */
    public static NpcDialogueGraph.Node sourceOf(GuideNpc npc, NpcDialogueGraph.Node consumer) {
        if (npc == null || consumer == null || consumer.varInputNode < 0) return null;
        NpcProfile profile = profileOf(npc);
        if (profile == null) return null;
        // The consumer object knows which of the three graphs it lives in; find that one
        // by identity, so an id that exists in another tab cannot be picked by mistake.
        for (NpcDialogueGraph graph : graphs(profile)) {
            if (graph == null || graph.nodes == null) continue;
            if (graph.get(consumer.id) != consumer) continue;
            NpcDialogueGraph.Node from = graph.get(consumer.varInputNode);
            return from == null || from == consumer ? null : from;
        }
        return null;
    }

    /** True when this node reads a blue value wire (and not a stock variable link). */
    public static boolean inputWired(GuideNpc npc, NpcDialogueGraph.Node consumer) {
        NpcDialogueGraph.Node from = sourceOf(npc, consumer);
        return from != null && isSourceNode(from);
    }

    /** The body this consumer's input carries right now, or null. */
    public static Entity bodyOfInput(GuideNpc npc, NpcDialogueGraph.Node consumer) {
        if (!inputWired(npc, consumer)) return null;
        return resolve(npc, consumer.varInputNode);
    }

    private static boolean isSourceNode(NpcDialogueGraph.Node node) {
        return node != null
                && (node.type == NpcDialogueGraph.CHECK || node.type == NpcDialogueGraph.DAMAGE);
    }

    // ---- IF ---------------------------------------------------------------

    /**
     * Value the IF node compares: 1 while its input carries a body, 0 when the input is
     * wired but empty. Returns -1 when the node has no value wire, so the stock variable
     * comparison runs untouched.
     */
    public static int ifValue(GuideNpc npc, NpcDialogueGraph.Node node) {
        if (node == null || !inputWired(npc, node)) return -1;
        return bodyOfInput(npc, node) != null ? 1 : 0;
    }

    // ---- VARIABLE ---------------------------------------------------------

    /**
     * 1 or 0 for a variable whose node reads a value wire, -1 when no such variable node
     * exists, so a normal variable keeps its stored number.
     */
    public static int variablePresence(GuideNpc npc, String name) {
        if (npc == null || name == null || name.isEmpty()) return -1;
        NpcProfile profile = profileOf(npc);
        if (profile == null) return -1;
        for (NpcDialogueGraph graph : graphs(profile)) {
            if (graph == null || graph.nodes == null) continue;
            for (NpcDialogueGraph.Node node : graph.nodes.values()) {
                if (node == null || node.type != NpcDialogueGraph.VARIABLE) continue;
                if (node.pointsName == null || !node.pointsName.equals(name)) continue;
                if (!inputWired(npc, node)) continue;
                return bodyOfInput(npc, node) != null ? 1 : 0;
            }
        }
        return -1;
    }

    // ---- LINE -------------------------------------------------------------

    /** Called while the dialogue view is built, so a line node knows whose NPC it is. */
    public static void enter(GuideNpc npc) {
        if (npc == null) CURRENT.remove();
        else CURRENT.set(npc);
    }

    /** Replaces the body tokens in a line node's text; other text is left as it was. */
    public static String lineText(NpcDialogueGraph.Node node, String text) {
        if (node == null || text == null || text.isEmpty()) return text;
        if (text.indexOf('%') < 0) return text;
        GuideNpc npc = CURRENT.get();
        if (npc == null) return text;
        if (node.type != NpcDialogueGraph.LINE) return text;
        Entity body = bodyOfInput(npc, node);
        String name = body == null ? "" : nameOf(body);
        UUID uuid = body == null ? null : body.getUUID();
        String kind = kindOf(body);
        return text.replace(TOKEN_TARGET, name)
                .replace(TOKEN_KIND, kind)
                .replace(TOKEN_UUID, uuid == null ? "" : uuid.toString());
    }

    // ---- TRIGGER ----------------------------------------------------------

    /**
     * True when this trigger node must not run: its input is wired, and either nobody is
     * there or the chain carries a different body. The list is compared by identity - it
     * is the very list stored on the node - so the check can never hit another node.
     */
    public static boolean triggerBlocked(GuideNpc npc, NpcDialogueGraph graph,
            List<String> triggers, Entity entity) {
        if (Boolean.TRUE.equals(PENDING.get())) {
            PENDING.remove();
            Object pending = PENDING_TRIGGERS.get();
            PENDING_TRIGGERS.remove();
            // The node's own payload, skipped because its check found nobody.
            if (pending == null || pending == (Object) triggers) return true;
        }
        if (npc == null || graph == null || graph.nodes == null || triggers == null
                || triggers.isEmpty()) {
            return false;
        }
        for (NpcDialogueGraph.Node node : graph.nodes.values()) {
            if (node == null || node.type != NpcDialogueGraph.TRIGGER) continue;
            // Compared as objects: the list is the very list stored on the node.
            if ((Object) node.triggers != (Object) triggers) continue;
            if (!inputWired(npc, node)) return false;
            Entity body = bodyOfInput(npc, node);
            if (body == null) return true;
            return entity != null && body != entity;
        }
        return false;
    }

    // ---- helpers ----------------------------------------------------------

    /** Node with this id in this graph, or null. */
    public static NpcDialogueGraph.Node node(NpcDialogueGraph graph, int nodeId) {
        if (graph == null || graph.nodes == null) return null;
        return graph.get(nodeId);
    }

    private static String nameOf(Entity entity) {
        try {
            net.minecraft.network.chat.Component name = entity.getName();
            if (name != null) return name.getString();
        } catch (Throwable ignored) {
            // fall through to the class name
        }
        return entity.getClass().getSimpleName();
    }

    // ---- build 295: the empty radius ---------------------------------------

    /**
     * Build 295: a check node that found nobody still has to run its chain.
     *
     * <p>Reported after 294: the same chain "В радиусе" #4 -&gt; "Условие" #5 ({@code #4 == 0})
     * still printed nothing when the radius was empty. The log shows why - the scan only
     * starts a chain when it finds a body: "check node #4 target 0 radius 5 scanning..."
     * every half second and no walk at all. The 294 pass-through never began, because the
     * walk that would reach the check node was never started; a chain starts at the node's
     * next node, not at the node itself.</p>
     *
     * <p>Called from the NPC's own server tick. For a check node that feeds a value wire it
     * asks the node's own question through {@link NpcCheckValue289} (the scan built in 289)
     * and, when the answer is "nobody", starts the chain at the node's next node with no
     * initiator. The value wire then reads 0 and the condition takes the branch that means
     * "nobody here".</p>
     *
     * <p>Narrow on purpose: every ten ticks, only value-wired check nodes, only when the
     * radius is really empty (a body on its own cooldown is still a body - the stock scan
     * owns that case), only when the node carries no action of its own, and only once per
     * the node's own cooldown. The node's action and trigger list do not run: nothing found,
     * nothing to run.</p>
     */
    public static void tickEmptyChecks(GuideNpc npc) {
        try {
            if (npc == null || !npc.isAlive() || npc.isTalking()) return;
            if (!(npc.level() instanceof ServerLevel serverLevel)) return;
            long now = serverLevel.getGameTime();
            if (now % 10L != 0L) return;
            NpcProfile profile = profileOf(npc);
            if (profile == null) return;
            for (NpcDialogueGraph graph : graphs(profile)) {
                if (graph == null || graph.nodes == null || graph.nodes.isEmpty()) continue;
                for (NpcDialogueGraph.Node node : graph.nodes.values()) {
                    if (node == null || node.type != NpcDialogueGraph.CHECK) continue;
                    if (node.next < 0) continue;
                    if (node.action != null && !node.action.isBlank()) continue;
                    if (!feedsValueWire(npc, node)) continue;
                    if (NpcCheckValue289.detected(npc, node.id) != null) continue;
                    if (!emptyReady(npc, node, now)) continue;
                    if (!GuideDialogue.isIncomingIfSatisfied(null, npc, 0, graph, node)) continue;
                    boolean first = lastEmpty(npc, node.id) == null;
                    markEmpty(npc, node, now);
                    if (first) {
                        System.out.println("[settledlands] [graph] empty radius #" + node.id
                                + ": chain starts at node #" + node.next);
                    }
                    GuideDialogue.resolveExecutionTarget(null, npc, null, graph, node.next,
                            new HashSet<>());
                    if (npc.isTalking()) return;
                }
            }
        } catch (Throwable t) {
            // A tick hook must never take the server down: report it once, keep ticking.
            if (!WARNED) {
                WARNED = true;
                System.err.println("[settledlands] empty check chain failed: " + t);
            }
        }
    }

    /** True when this node's own cooldown has elapsed for the "nobody here" pass. */
    private static boolean emptyReady(GuideNpc npc, NpcDialogueGraph.Node node, long now) {
        Long last = lastEmpty(npc, node.id);
        long window = Math.max(0, node.checkCooldown) * 20L;
        return last == null || now - last >= window;
    }

    private static void markEmpty(GuideNpc npc, NpcDialogueGraph.Node node, long now) {
        synchronized (LAST_EMPTY) {
            Map<Integer, Long> perNode = LAST_EMPTY.get(npc);
            if (perNode == null) {
                perNode = new HashMap<>();
                LAST_EMPTY.put(npc, perNode);
            }
            perNode.put(node.id, now);
        }
    }

    private static Long lastEmpty(GuideNpc npc, int nodeId) {
        synchronized (LAST_EMPTY) {
            Map<Integer, Long> perNode = LAST_EMPTY.get(npc);
            return perNode == null ? null : perNode.get(nodeId);
        }
    }

    /**
     * Build 294: a check node that feeds a value wire must not stop the walk.
     *
     * <p>Reported chain: "В радиусе" #4 -&gt; "Условие" #5 with {@code #4 == 0}, True -&gt;
     * {@code say true}, False -&gt; {@code say false}. Somebody in the radius printed
     * {@code false}; nobody in the radius printed nothing.</p>
     *
     * <p>Why: the walk treats "В радиусе" as a gate - {@code checkProximityCondition} false
     * ends the walk on the spot, so the IF was never reached with the "nobody" answer, and
     * its {@code == 0} branch was dead. The node's blue output is a different thing: it is
     * read live by the consumer through {@link #ifValue}, and it answers 0 when the radius
     * is empty.</p>
     *
     * <p>So a failed check is allowed to let the flow through - but only when the node is
     * used as a value source, and only when the node carries no action of its own. A check
     * with an action is a gate with a payload, and keeps the stock behaviour: nothing runs,
     * the chain ends. The node's own trigger list is skipped on that pass as well, so a
     * failed check runs nothing at all and only the consumer sees the answer.</p>
     */
    public static boolean passThroughWhenValue(GuideNpc npc, NpcDialogueGraph.Node check) {
        if (npc == null || check == null) return false;
        if (check.action != null && !check.action.isBlank()) return false;
        if (!isSourceNode(check) || !feedsValueWire(npc, check)) return false;
        PENDING.set(Boolean.TRUE);
        PENDING_TRIGGERS.set(check.triggers);
        return true;
    }

    /** True when some node of this NPC's graphs takes its value from {@code check}. */
    private static boolean feedsValueWire(GuideNpc npc, NpcDialogueGraph.Node check) {
        NpcProfile profile = profileOf(npc);
        if (profile == null) return false;
        for (NpcDialogueGraph graph : graphs(profile)) {
            if (graph == null || graph.nodes == null) continue;
            if (graph.get(check.id) != check) continue;
            for (NpcDialogueGraph.Node node : graph.nodes.values()) {
                if (node != null && node.varInputNode == check.id) return true;
            }
        }
        return false;
    }

    private static NpcProfile profileOf(GuideNpc npc) {
        try {
            return npc.profile();
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static List<NpcDialogueGraph> graphs(NpcProfile profile) {
        List<NpcDialogueGraph> out = new ArrayList<>(3);
        if (profile.dialogueGraph != null) out.add(profile.dialogueGraph);
        if (profile.walkGraph != null) out.add(profile.walkGraph);
        if (profile.animGraph != null) out.add(profile.animGraph);
        return out;
    }
}
