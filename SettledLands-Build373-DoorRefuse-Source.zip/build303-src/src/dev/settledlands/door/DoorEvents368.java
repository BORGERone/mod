package dev.settledlands.door;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.InteractionResult;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Build 368: a locked door is closed to the player and cannot be broken - and the key opens that rule,
 * not the door.
 *
 * <ul>
 *   <li><b>right click with the key</b> - the door is locked (or unlocked again). The click itself is
 *       cancelled, so the key never opens a door it is locking;</li>
 *   <li><b>right click without the key</b> on a locked door - cancelled, with one line in the action
 *       bar. The door does not open, and nothing about it changes;</li>
 *   <li><b>breaking a locked door</b> - cancelled, with the same line. That covers the player and any
 *       mod that fires the break event; the zombie's own door bashing goes through
 *       {@code Level#destroyBlock}, which {@code DoorBreak368Mixin} guards with the same store.</li>
 * </ul>
 *
 * <p>NPCs are not touched here at all: {@link NpcDoors368} opens and closes doors for a walking guide
 * and ignores the lock, which is what the author asked for - the door is closed for the players and
 * for the monsters, not for the guides.</p>
 */
@EventBusSubscriber(modid = "settledlands")
public final class DoorEvents368 {

    private static final Logger LOG = LoggerFactory.getLogger("SettledLands/DoorEvents368");

    private static final String LOCKED = "message.settledlands.door.locked";
    private static final String ON = "message.settledlands.door.key_on";
    private static final String OFF = "message.settledlands.door.key_off";

    /** Build 372: how many diagnostic lines this session has written. A report, not a rule. */
    private static int said;

    private DoorEvents368() {}

    private static void note(String line) {
        if (said >= 8) return;
        said++;
        LOG.info(line);
    }

    @SubscribeEvent
    public static void onRightClick(PlayerInteractEvent.RightClickBlock event) {
        if (event == null) return;
        try {
            Level level = event.getLevel();
            BlockPos pos = event.getPos();
            if (!(level instanceof ServerLevel server) || pos == null) return;
            BlockState here = server.getBlockState(pos);
            if (!Doors368.isDoor(here)) {
                if (DoorKey368.isKey(event.getItemStack()) && here != null) {
                    note("door: the key was used on " + here.getBlock() + " at " + pos
                            + " - that is not a DoorBlock, so nothing was locked");
                }
                return;
            }
            DoorStore368 store = DoorStore368.get(server);
            if (store == null) return;
            ItemStack stack = event.getItemStack();
            boolean key = DoorKey368.isKey(stack);
            boolean locked = store.isLocked(server, pos);
            if (!key) {
                if (!locked) return;
                // A locked door is not a door for a player: no opening, no closing, no sound of a
                // door that would only teach the player to try again.
                deny(event);
                shut(server, pos);
                note("door: the click on the locked door at " + pos + " was refused (useBlock="
                        + "DENY), open now=" + Doors368.anyOpen(server, pos));
                say(event.getEntity());
                return;
            }
            deny(event);
            shut(server, pos);
            boolean nowLocked;
            if (locked) {
                store.unlock(server, pos);
                nowLocked = false;
            } else {
                store.lock(server, pos);
                nowLocked = true;
            }
            note("door: the door at " + pos + (nowLocked ? " is locked" : " is unlocked")
                    + " by the key, " + (store.size()) + " place(s) locked in this world");
            tell(event.getEntity(), Component.translatable(nowLocked ? ON : OFF).getString());
        } catch (Throwable failure) {
            LOG.warn("a door click could not be handled", failure);
        }
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent event) {
        if (event == null) return;
        try {
            if (!(event.getLevel() instanceof ServerLevel server)) return;
            BlockPos pos = event.getPos();
            if (pos == null || !Doors368.isDoor(server.getBlockState(pos))) return;
            DoorStore368 store = DoorStore368.get(server);
            if (store == null || !store.isLocked(server, pos)) return;
            event.setCanceled(true);
            if (event.getPlayer() instanceof ServerPlayer player) say(player);
        } catch (Throwable failure) {
            LOG.warn("a door break could not be handled", failure);
        }
    }

    /**
     * Refuses the click at its source.
     *
     * <p>Build 371: cancelling alone was not enough. A right click on a door is carried out by the
     * block's own use, and the yes/no the game actually reads is {@code useBlock} / {@code useItem} -
     * so both are denied explicitly, and the cancellation stays for every listener that never looks at
     * those two fields.</p>
     */
    private static void deny(PlayerInteractEvent.RightClickBlock event) {
        event.setCanceled(true);
        // Build 373: this is the answer NeoForge 1.21.1 actually reads - the same call the base mod
        // already makes elsewhere. 371 used setUseBlock/setUseItem, which do not exist on this event:
        // the call threw, the listener died before it could refuse anything, and the door opened
        // exactly as before. Nothing in this method may run after a call that can fail, which is why
        // the result is set in its own small guard.
        try {
            event.setCancellationResult(InteractionResult.FAIL);
        } catch (Throwable missing) {
            LOG.warn("the door could not be refused through the event: " + missing);
        }
    }

    /**
     * Puts the door back the way it must be, and tells the clients.
     *
     * <p>Build 371: this is what "the door opens for a second" was. The client opens a door the moment
     * it is clicked and only then asks the server; when the server refuses, nothing had changed on the
     * server, so nothing was sent back - and the client kept its open door in front of the player for
     * as long as it took. Closing the door here and pushing the state out costs two calls and ends the
     * picture: whatever the client guessed, the answer arrives in the same tick.</p>
     */
    private static void shut(ServerLevel server, BlockPos pos) {
        if (Doors368.anyOpen(server, pos)) {
            Doors368.setOpen(server, pos, false);
        }
        BlockState state = server.getBlockState(pos);
        if (state != null) {
            server.sendBlockUpdated(pos, state, state, 3);
        }
    }

    /** Is this place locked? The one question {@code DoorBreak368Mixin} asks the server. */
    public static boolean locked(Level level, BlockPos pos) {
        if (!(level instanceof ServerLevel server) || pos == null) return false;
        if (!Doors368.isDoor(server.getBlockState(pos))) return false;
        DoorStore368 store = DoorStore368.get(server);
        return store != null && store.isLocked(server, pos);
    }

    private static void say(net.minecraft.world.entity.Entity entity) {
        tell(entity, Component.translatable(LOCKED).getString());
    }

    private static void tell(net.minecraft.world.entity.Entity entity, String line) {
        if (entity instanceof ServerPlayer player && line != null && !line.isBlank()) {
            player.displayClientMessage(Component.literal(line), true);
        }
    }
}
