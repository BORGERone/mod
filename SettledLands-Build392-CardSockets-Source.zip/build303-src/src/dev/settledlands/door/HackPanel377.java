package dev.settledlands.door;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Build 378: the lock panel - "взлом" - of a locked door.
 *
 * <p>A locked door used to answer a click with a line in the action bar and nothing else. It now opens
 * this panel: a row of four to ten letters, and the door opens only when <b>every</b> button is held
 * down at the same moment. Holding that many letters with two hands is the whole game; letting go of
 * any one of them puts that button out.</p>
 *
 * <p>Build 378 changed two things the author asked for. The keycaps are <b>letters</b> now, not digits
 * ({@code Q W E R T Y U I O P} - one row, the one directly under the number row, so the hands sit where
 * they already were). And the clock no longer throws the attempt away: every five seconds <b>one</b> of
 * the keys changes to a different letter. Whatever is held stays held, so nothing is lost - but the
 * button that just changed is no longer the key the player is pressing, and the set has to be completed
 * again around it. That is the pressure; there is no failure state at all, and the door is untouched by
 * anything the panel does or refuses to do.</p>
 *
 * <p>Why the keyboard and not the mouse: one cursor cannot hold four buttons. {@code
 * InputConstants.isKeyDown} answers for real hardware every frame - the same call the base mod's own
 * screens make for the space bar - so a key already held when the panel opened, or released while the
 * window lost focus, cannot lie about its state.</p>
 *
 * <p><b>Build 385: the panel owns the keyboard.</b> Build 384 let every key it did not use fall through
 * to the screen's super method, and a screen that answers {@code false} hands the key to the game's key
 * mappings - the author pressed R in the panel and reloaded his shaders. Only ESC does anything now: it
 * closes the panel. Everything else is swallowed, so no key mapping, no hotkey and no mod shortcut can
 * fire while the panel is up. Reading the hardware directly ({@link InputConstants#isKeyDown}) is
 * unaffected - that is what the panel measures.</p>
 *
 * <p><b>Build 387: the panel leaves only when the hands do.</b> Until now the panel closed on the same
 * frame the last key went down - the door was open, and the six or eight keys the player was still
 * holding were suddenly nobody's business, so they fell straight through to the game. Solving now only
 * <b>accepts</b> the hack: the panel keeps the keyboard, says so, and closes when <b>every</b> held key
 * has come back up, so a win can never press W, drop the item in hand or open the inventory by
 * accident. A deliberate escape stays: ESC held for a moment still closes it, so a stuck key cannot
 * trap the player in a panel.</p>
 *
 * <p><b>Build 385: «Сложность».</b> The door node has a third slider, and it decides which rows of the
 * keyboard the keys are drawn from: 1 - {@code qwertyuiop[]}, 2 - those plus {@code asdfghjkl;'},
 * 3 - those plus {@code zxcvbnm,./}. A harder door does not ask for more keys; it asks for the same
 * number of keys out of a bigger board, so the same two hands have to search further.</p>
 */
public class HackPanel377 extends Screen {

    private static final Logger LOG = LoggerFactory.getLogger("SettledLands/HackPanel377");

    /**
     * Build 385: the three rows a key can come from. GLFW codes are the layout positions of the keys,
     * and for these keys the code is the ASCII value - which is why the keycap label can be the code.
     *
     * <p>Row 1 is the one the panel used since build 378 ({@code qwertyuiop}) plus the two keys to its
     * right ({@code [ ]}), because the author named the row as {@code qwertyuiop[]}. Row 2 is
     * {@code asdfghjkl;'} and row 3 is {@code zxcvbnm,./} - the three rows of a QWERTY keyboard, in the
     * order a hand reaches them.</p>
     */
    private static final int[] ROW_TOP = {81, 87, 69, 82, 84, 89, 85, 73, 79, 80, 91, 93};
    private static final int[] ROW_HOME = {65, 83, 68, 70, 71, 72, 74, 75, 76, 59, 39};
    private static final int[] ROW_BOTTOM = {90, 88, 67, 86, 66, 78, 77, 44, 46, 47};

    public static final int MIN_DIFFICULTY = 1;
    public static final int MAX_DIFFICULTY = 3;
    public static final int DEFAULT_DIFFICULTY = 1;

    /** The key ESC, and the only key this panel lets through to the screen under it. */
    private static final int ESC = 256;

    /**
     * Build 387: how long ESC has to be held before a <b>solved</b> panel closes anyway. A tap must not
     * do it - that is the whole point of the build - but a key that is stuck down in hardware must not
     * leave the player locked inside a panel either.
     */
    private static final long ESC_HOLD_MS = 1200L;

    private static final int MIN_BUTTONS = 4;
    private static final int MAX_BUTTONS = 10;

    /**
     * Build 378: how long a key stays where it is. When it runs out one key of the row changes - the
     * held keys are left alone, so the attempt is never thrown away, only made harder.
     */
    private static final long ROLL_MS = 5000L;

    /**
     * Build 382: the door's own graph can say how many keys this door asks for and how fast one of
     * them changes (the two sliders of its node). A door that was never edited in the editor has no
     * such numbers, and then the panel is exactly the panel of build 378: four to ten keys drawn at
     * random and this five-second clock.
     */

    private static final int PANEL_BG = 0xE00E1116;
    private static final int PANEL_EDGE = 0xFF6A7A6A;
    private static final int LABEL = 0xFFBFD4BF;
    private static final int DIM = 0xFF8A968A;
    private static final int BTN_BG = 0xFF1B2028;
    private static final int BTN_EDGE = 0xFF46505C;
    private static final int BTN_ON = 0xFF2F7D4F;
    private static final int BTN_ON_EDGE = 0xFF7BE0A0;
    private static final int SWAP = 0xFFD8A030;
    private static final int BAR = 0xFF3A7BD5;

    private static final int BTN = 34;
    private static final int GAP = 8;

    private final BlockPos pos;
    private final int count;
    private final int[] keys;
    private final long rollMs;
    private final int difficulty;
    /** The rows this panel draws from - fixed for the life of the panel, from the door's difficulty. */
    private final int[] pool;

    private long rolledAt;
    private long flashAt;
    private String flash = "";
    private boolean solved;
    private int swaps;

    /**
     * Build 387: the keys this panel saw go down and has not seen come up. A key that was already held
     * when the panel opened sends no press here, which is why the panel's own keys are measured on the
     * hardware as well ({@link #held()}); between the two, every key the player is holding is known.
     */
    private final java.util.Set<Integer> pressed = new java.util.LinkedHashSet<>();

    /** When ESC went down after the hack was accepted - the escape hatch needs a deliberate hold. */
    private long escDownAt;

    private HackPanel377(BlockPos pos, int count, int[] keys, long rollMs, int difficulty) {
        super(Component.literal("Взлом двери"));
        this.pos = pos;
        this.count = count;
        this.keys = keys;
        this.rollMs = rollMs > 0L ? rollMs : ROLL_MS;
        this.difficulty = clampDifficulty(difficulty);
        this.pool = pool(this.difficulty);
    }

    /**
     * Opens the panel for a locked door, unless a panel is already open.
     *
     * <p>Called from the client half of the door click. It never throws and never opens a second
     * screen on top of an existing one - an inventory that was open stays the thing the player has to
     * deal with first.</p>
     */
    public static void open(BlockPos pos) {
        try {
            if (pos == null) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc == null) return;
            if (mc.screen != null) return;
            if (mc.player == null) return;
            Random random = new Random();
            // Build 382: the door's graph wins when it has something to say. The key of the door is
            // the one the store and the sync already use, so the numbers arrive with the locks.
            int[] settings = DoorSync375.settings(mc.player.level(), pos);
            int count = settings != null
                    ? Math.max(MIN_BUTTONS, Math.min(MAX_BUTTONS, settings[0]))
                    : MIN_BUTTONS + random.nextInt(MAX_BUTTONS - MIN_BUTTONS + 1);
            long rollMs = settings != null && settings[1] > 0
                    ? settings[1] * 1000L : ROLL_MS;
            // Build 385: the third number of the door's node. A door that was never edited, or one
            // whose graph predates the difficulty, plays on difficulty 1 - the row of build 378.
            int difficulty = settings != null && settings.length > 2
                    ? clampDifficulty(settings[2]) : DEFAULT_DIFFICULTY;
            int[] keys = pick(random, count, difficulty);
            mc.setScreen(new HackPanel377(pos, count, keys, rollMs, difficulty));
            // Build 379: a panel that never appeared and a panel nobody could solve look the same in
            // game - the door stays shut either way. This line says which one happened.
            LOG.info("door: the lock panel opened at " + DoorSync375.key(mc.player.level(), pos)
                    + " with " + count + " keys every " + (rollMs / 1000L) + " s, difficulty "
                    + difficulty + ": " + spell(keys));
        } catch (Throwable failure) {
            // A panel that cannot be built must cost the player the panel, not the click.
            LOG.warn("door: the lock panel could not be opened, the door stays locked and silent", failure);
            net.minecraft.client.Minecraft.getInstance().setScreen(null);
        }
    }

    /** The keys of one difficulty: row 1, rows 1-2, or all three rows. */
    public static int[] pool(int difficulty) {
        int level = clampDifficulty(difficulty);
        int size = ROW_TOP.length + (level >= 2 ? ROW_HOME.length : 0)
                + (level >= 3 ? ROW_BOTTOM.length : 0);
        int[] out = new int[size];
        int at = 0;
        System.arraycopy(ROW_TOP, 0, out, at, ROW_TOP.length);
        at += ROW_TOP.length;
        if (level >= 2) {
            System.arraycopy(ROW_HOME, 0, out, at, ROW_HOME.length);
            at += ROW_HOME.length;
        }
        if (level >= 3) {
            System.arraycopy(ROW_BOTTOM, 0, out, at, ROW_BOTTOM.length);
        }
        return out;
    }

    public static int clampDifficulty(int value) {
        return value < MIN_DIFFICULTY ? MIN_DIFFICULTY
                : (value > MAX_DIFFICULTY ? MAX_DIFFICULTY : value);
    }

    /** {@code count} distinct keys of the rows this difficulty allows, left to right. */
    public static int[] pick(Random random, int count, int difficulty) {
        int[] pool = pool(difficulty);
        for (int i = pool.length - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            int swap = pool[i];
            pool[i] = pool[j];
            pool[j] = swap;
        }
        int take = Math.max(1, Math.min(count, pool.length));
        int[] out = new int[take];
        System.arraycopy(pool, 0, out, 0, take);
        java.util.Arrays.sort(out);
        return out;
    }

    @Override
    protected void init() {
        this.rolledAt = System.currentTimeMillis();
        this.solved = false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /**
     * Build 385: the panel owns the keyboard while it is up - every key but one.
     *
     * <p>A screen that returns {@code false} hands the key to the game's key mappings, and the author
     * pressed R in the panel of build 384 and reloaded his shaders. So an answer of {@code true} for
     * every key that is not ESC: no key mapping, no hotkey, no mod shortcut, no debug combination fires
     * while the panel is open. ESC goes to the screen's own handler, which closes the panel - and only
     * the panel: the door is untouched by anything this screen does.</p>
     */
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == ESC) {
            // Build 387: before the hack is in, ESC is the player's way out - it closes the panel and
            // nothing else; the door stays shut. After it, the panel has to leave the player free of
            // the keyboard before it goes, so ESC is swallowed unless it is held on purpose.
            if (!solved) return super.keyPressed(keyCode, scanCode, modifiers);
            if (escDownAt == 0L) escDownAt = System.currentTimeMillis();
            if (System.currentTimeMillis() - escDownAt >= ESC_HOLD_MS) this.onClose();
            return true;
        }
        if (keyCode >= 0) pressed.add(Integer.valueOf(keyCode));
        return true;
    }

    /** The same rule for a release: the panel hears about every key, the game hears about none. */
    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        if (keyCode == ESC) {
            escDownAt = 0L;
            if (!solved) return super.keyReleased(keyCode, scanCode, modifiers);
            return true;
        }
        pressed.remove(Integer.valueOf(keyCode));
        return true;
    }

    /**
     * Build 387: true when nothing the player pressed is still down.
     *
     * <p>Two sources, because neither alone is enough. {@link #pressed} knows every key the panel was
     * told about - but a key that was already held when the panel opened never sends a press, and a
     * release that happens while the window is unfocused may never arrive. So the set is pruned against
     * the hardware every frame ({@code isKeyDown} is the truth, the same call the keys are read with),
     * and the panel's own keys are checked on the hardware as well.</p>
     */
    private boolean allReleased() {
        Minecraft mc = Minecraft.getInstance();
        long window = mc == null || mc.getWindow() == null ? 0L : mc.getWindow().getWindow();
        if (window != 0L && !pressed.isEmpty()) {
            java.util.Iterator<Integer> it = pressed.iterator();
            while (it.hasNext()) {
                Integer code = it.next();
                if (code != null && !InputConstants.isKeyDown(window, code.intValue())) it.remove();
            }
        }
        return pressed.isEmpty() && held() == 0;
    }

    /**
     * How many keys are still down, as the player has to be told. The panel's own keys are counted once,
     * through {@link #held()} - a key can be both in the set and down, and telling the player "2" for
     * one finger would look like a bug in the counter rather than in his hands.
     */
    private int stillDown() {
        int extra = 0;
        for (Integer code : pressed) {
            if (code != null && !uses(code.intValue())) extra++;
        }
        return extra + held();
    }

    /** The panel's keys the keyboard is holding right now. 0 when no window is known. */
    private int held() {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.getWindow() == null) return 0;
        long window = mc.getWindow().getWindow();
        if (window == 0L) return 0;
        int down = 0;
        for (int i = 0; i < keys.length; i++) {
            if (InputConstants.isKeyDown(window, keys[i])) down++;
        }
        return down;
    }

    private boolean isDown(int keyCode) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.getWindow() == null) return false;
        long window = mc.getWindow().getWindow();
        if (window == 0L) return false;
        return InputConstants.isKeyDown(window, keyCode);
    }

    /**
     * Build 378: change exactly one key of the row to a letter the panel is not showing.
     *
     * <p>Nothing else is touched - the keys the player is holding keep their buttons, and the attempt
     * goes on. The panel chooses the button at random, so watching is not a strategy: the set has to be
     * completed fast enough that the next change does not land on the last key pressed.</p>
     */
    private void roll() {
        rolledAt = System.currentTimeMillis();
        Random random = new Random();
        int index = random.nextInt(count);
        int fresh = keys[index];
        for (int tries = 0; tries < pool.length * 4; tries++) {
            int candidate = pool[random.nextInt(pool.length)];
            if (!uses(candidate)) {
                fresh = candidate;
                break;
            }
        }
        if (fresh == keys[index]) return;
        keys[index] = fresh;
        swaps++;
        flash = "клавиша сменилась";
        flashAt = rolledAt;
    }

    private boolean uses(int keyCode) {
        for (int i = 0; i < keys.length; i++) {
            if (keys[i] == keyCode) return true;
        }
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, this.width, this.height, 0x99000000);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        long now = System.currentTimeMillis();
        // Build 387: a solved panel has no clock - the keys are the only thing left to watch.
        if (!solved && now - rolledAt > this.rollMs) {
            roll();
        }
        int down = held();
        int total = count * BTN + (count - 1) * GAP;
        int center = this.width / 2;
        int left = center - total / 2;
        int panelLeft = left - 22;
        int panelRight = left + total + 22;
        int panelTop = this.height / 2 - 78;
        int panelBottom = panelTop + 138;

        graphics.fill(panelLeft, panelTop, panelRight, panelBottom, PANEL_BG);
        graphics.fill(panelLeft, panelTop, panelRight, panelTop + 1, PANEL_EDGE);
        graphics.fill(panelLeft, panelBottom - 1, panelRight, panelBottom, PANEL_EDGE);
        graphics.fill(panelLeft, panelTop, panelLeft + 1, panelBottom, PANEL_EDGE);
        graphics.fill(panelRight - 1, panelTop, panelRight, panelBottom, PANEL_EDGE);

        if (!solved && down == count) {
            solved = true;
            LOG.info("door: all " + count + " keys of the panel are held - sending the hack for "
                    + DoorSync375.key(Minecraft.getInstance().player == null ? null
                            : Minecraft.getInstance().player.level(), pos));
            DoorHack377.send(pos);
            // Build 387: and the panel does NOT close here. The door is open on the server, but the
            // hands are still on the keys - closing now is exactly how a win used to press W, drop the
            // held item or open the inventory. It closes when every key has come back up.
            LOG.info("door: the panel stays up and keeps the keyboard until every held key is released");
        }

        if (solved) {
            // Build 387: the frame every key is up is the frame the panel goes - nowhere left to cover,
            // and nothing left to explain.
            if (allReleased()) {
                LOG.info("door: every key is up - the panel closes, the door is already open");
                this.onClose();
                return;
            }
            // The whole inner panel is repainted: a solved panel has nothing left to press.
            graphics.fill(panelLeft + 1, panelTop + 1, panelRight - 1, panelBottom - 1, PANEL_BG);
            int still = stillDown();
            graphics.drawCenteredString(this.font, Component.literal("ВЗЛОМ ПРИНЯТ"),
                    center, panelTop + 16, BTN_ON_EDGE);
            graphics.drawCenteredString(this.font, Component.literal("замок снят, дверь открыта"),
                    center, panelTop + 36, LABEL);
            graphics.drawCenteredString(this.font,
                    Component.literal("отпусти все клавиши - и панель уйдёт сама"),
                    center, panelTop + 60, LABEL);
            graphics.drawCenteredString(this.font, Component.literal("ещё зажато: " + still),
                    center, panelTop + 80, SWAP);
            graphics.drawCenteredString(this.font,
                    Component.literal("пока панель здесь, клавиатура заблокирована"),
                    center, panelTop + 100, DIM);
            graphics.drawCenteredString(this.font,
                    Component.literal("ESC удержи ~1 с, если клавиша залипла"),
                    center, panelTop + 118, DIM);
            return;
        }

        graphics.drawCenteredString(this.font, Component.literal("ВЗЛОМ ДВЕРИ"), center, panelTop + 10, LABEL);

        int top = panelTop + 30;
        boolean fresh = !flash.isEmpty() && now - flashAt < 1200L;
        for (int i = 0; i < count; i++) {
            int x = left + i * (BTN + GAP);
            boolean on = isDown(keys[i]);
            graphics.fill(x, top, x + BTN, top + BTN, on ? BTN_ON : BTN_BG);
            int edge = on ? BTN_ON_EDGE : BTN_EDGE;
            graphics.fill(x, top, x + BTN, top + 1, edge);
            graphics.fill(x, top + BTN - 1, x + BTN, top + BTN, edge);
            graphics.fill(x, top, x + 1, top + BTN, edge);
            graphics.fill(x + BTN - 1, top, x + BTN, top + BTN, edge);
            graphics.drawCenteredString(this.font, Component.literal(label(keys[i])),
                    x + BTN / 2, top + BTN / 2 - 4, on ? 0xFFFFFFFF : LABEL);
        }

        graphics.drawCenteredString(this.font,
                Component.literal("Зажми все " + count + " клавиш одновременно"), center, panelTop + 76, DIM);

        String line = fresh ? flash : (down + " / " + count);
        graphics.drawCenteredString(this.font, Component.literal(line), center, panelTop + 92,
                fresh ? SWAP : (down == count ? BTN_ON_EDGE : LABEL));

        graphics.drawCenteredString(this.font,
                Component.literal("каждые " + (this.rollMs / 1000L) + " с одна клавиша меняется"
                        + " · сложность " + this.difficulty),
                center, panelTop + 108, DIM);

        long leftMs = this.rollMs - (now - rolledAt);
        if (leftMs < 0L) leftMs = 0L;
        int filled = (int) (total * leftMs / this.rollMs);
        graphics.fill(left, panelTop + 122, left + total, panelTop + 126, 0xFF20262E);
        graphics.fill(left, panelTop + 122, left + filled, panelTop + 126, fresh ? SWAP : BAR);
    }

    /** The letters of a row as a line of text, for the log. */
    private static String spell(int[] keys) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < keys.length; i++) {
            if (i > 0) out.append(' ');
            out.append(label(keys[i]));
        }
        return out.toString();
    }

    /** "Q", "[", ";" - the character on the keycap; the GLFW code of these keys is its ASCII value. */
    private static String label(int keyCode) {
        return String.valueOf((char) keyCode);
    }
}
