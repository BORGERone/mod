#!/usr/bin/env python3
"""Gate 3/4 - mixin class verification (config + target resolution).

Phase A - configuration
  * every mixin config parses, has package + compatibilityLevel JAVA_21
  * every listed class exists in the jar and carries @Mixin
  * no class listed twice / in both the common and client lists
  * bundled mixin annotation stubs keep @Retention(CLASS)
  * a mixin class declares no static field that is not private - Mixin drops
    the whole class for that, and the game dies on the first load of the
    target (Build 302 lesson: two colours declared in a mixin)

Phase C - dispatcher hooks
  A class that only exists to be called from a mixin (the pursuit card
  renderer) is useless when the mixin no longer references it: Build 277 lost
  the drawNode @Inject and every pursuit node fell back to the stock trigger
  drawing. If such a class is in the jar, some mixin in the configs must name
  the hook method.

Phase B - target resolution (catches "Critical injection failure" crashes)
  Targets that live inside the jar (the mod's own classes) are resolved for
  real:
  * @Mixin target classes exist
  * @Inject / @Redirect / @ModifyConstant target methods exist with the exact
    name and descriptor written in the annotation
  * the callback's last parameter matches the target: CallbackInfo for a void
    target, CallbackInfoReturnable for a non-void one (build 257-258 lesson)
  * callback parameter count = target parameters + callback
    (@Redirect handlers are matched against the method named in their @At, not
    against the enclosing one, so they are not size-checked here yet - only
    their @At target is resolved)
  * callback parameter types = the target's own parameter types, literally
    (Build 290 shipped a handler with `Object` where the target declares its
    package-private Session type; the game died on startup with "Invalid
    descriptor" and the build never got past mixin application)
  * @ModifyConstant(@Constant(intValue = N)) finds N in the target method's
    bytecode (injectors.defaultRequire=1 turns a miss into a hard crash)
  * @Shadow fields and methods exist in the target with the same descriptor - the target CLASS,
    not its superclasses. Build 359 shadowed Screen#addRenderableWidget on the graph screen, the
    descriptor was right (it is what the stock textBox calls), Mixin still refused it with
    "@Shadow method addRenderableWidget ... was not located in the target class" and every graph
    screen died on first open. A member inherited from Minecraft is CALLED, never shadowed: our
    compile-time stubs declare it, the call site lands inside the target and protected access holds.
  * @Overwrite matches an existing method
  * an @Inject handler that calls CallbackInfo.cancel() or
    CallbackInfoReturnable.setReturnValue(...) but whose annotation is not
    `cancellable = true` -> CancellationException at runtime
    ("The call <method> is not cancellable")
  Targets from Minecraft or other mods cannot be resolved here - they are
  listed as "external" instead of being guessed at.

Phase D - external API references (Build 280 lesson)
  Minecraft is not in the jar, so nothing here can prove that a Minecraft
  method exists: the stub the patch was compiled against decides that, and a
  stub is written by hand. Build 280 called Entity#hasLineOfSight(Entity);
  the stub was happy, the game was not (NoSuchMethodError, "Ticking entity").
  Phase D compares every reference our classes make to an external owner with
  the references of a base jar that is known to run in game (the previous
  build). A reference the base jar never makes is unverified by definition, so
  it must be looked up first - or replayed from code that already works.

Usage: python3 tools/check_mixin_class.py <jar> [--base JAR] [--verbose]
Exit code 0 = pass, 1 = fail.
"""

import argparse
import json
import os
import sys
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import classfile                                        # noqa: E402
from classfile import ClassFormatError, Reader          # noqa: E402

ACC_ANNOTATION = 0x2000
ANNOTATION_ATTRS = ("RuntimeVisibleAnnotations", "RuntimeInvisibleAnnotations")

PKG = "Lorg/spongepowered/asm/mixin/"
DESC_MIXIN = PKG + "Mixin;"
DESC_INJECT = PKG + "injection/Inject;"
DESC_REDIRECT = PKG + "injection/Redirect;"
DESC_MODIFY_CONST = PKG + "injection/ModifyConstant;"
DESC_MODIFY_ARG = PKG + "injection/ModifyArg;"
DESC_MODIFY_VAR = PKG + "injection/ModifyVariable;"
DESC_OVERWRITE = PKG + "Overwrite;"
DESC_SHADOW = PKG + "Shadow;"
DESC_CONSTANT = PKG + "injection/Constant;"
DESC_AT = PKG + "injection/At;"
DESC_RETENTION = "Ljava/lang/annotation/Retention;"
# class -> method that some mixin must call, else the class is dead code
DISPATCH_HOOKS = {
    "dev/settledlands/npc/client/PursuitGraphNode272": ("drawNode", "the pursuit card"),
}

DESC_CALLBACK_INFO = "Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfo;"
DESC_CALLBACK_RET = "Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable;"


# owners our patch compiles against but cannot verify: Minecraft, NeoForge,
# Mojang and the bundled libraries. dev/settledlands is the mod itself.
EXTERNAL_PREFIXES = (
    "net/minecraft/", "net/neoforged/", "com/mojang/", "org/spongepowered/",
    "dev/shadowsoffire/", "software/bernie/", "net/minecraftforge/",
)
SKIP_PREFIXES = ("java/", "javax/", "jdk/", "sun/", "dev/settledlands/")


class Fail(Exception):
    pass


# ---------------------------------------------------------------- annotations
def _elem_value(r):
    tag = r.u1()
    if tag in (0x42, 0x43, 0x44, 0x46, 0x48, 0x49, 0x4a, 0x53, 0x5a):
        return ("const", r.u2())
    if tag == 0x65:
        return ("enum", r.u2(), r.u2())
    if tag in (0x73, 0x63):
        return (tag, r.u2())
    if tag == 0x40:
        return _parse_annotation(r)
    if tag == 0x5b:
        return ("array", [_elem_value(r) for _ in range(r.u2())])
    raise ClassFormatError("bad element_value tag 0x%02x" % tag)


def _parse_annotation(r):
    type_idx = r.u2()
    pairs = []
    for _ in range(r.u2()):
        name_idx = r.u2()
        pairs.append((name_idx, _elem_value(r)))
    return ("annotation", type_idx, pairs)


def read_annotations(cf, attr_names=ANNOTATION_ATTRS):
    out = []
    for a in cf.attrs:
        if a.name not in attr_names:
            continue
        r = Reader(a.data, "%s:%s" % (cf.name, a.name))
        for _ in range(r.u2()):
            out.append(_parse_annotation(r))
    return out


def member_annotations(cf, member, attr_names=ANNOTATION_ATTRS):
    out = []
    for a in member.attrs:
        if a.name not in attr_names:
            continue
        r = Reader(a.data, "%s.%s:%s" % (cf.name, member.name, a.name))
        for _ in range(r.u2()):
            out.append(_parse_annotation(r))
    return out


def ann_desc(cf, ann):
    try:
        return cf.utf8(ann[1])
    except ClassFormatError:
        return ""


def ann_args(cf, ann):
    """{element name: value} with names resolved to strings."""
    out = {}
    for name_idx, val in ann[2]:
        try:
            name = cf.utf8(name_idx)
        except ClassFormatError:
            name = "<bad#%d>" % name_idx
        out[name] = val
    return out


def as_str(cf, val):
    if val is None:
        return None
    if val[0] in (0x73, 0x63):
        try:
            return cf.utf8(val[1])
        except ClassFormatError:
            return None
    if val[0] == "const":                      # boolean / int element encoded as raw index
        return None
    return None


def as_str_list(cf, val):
    if val is None:
        return []
    if val[0] == "array":
        return [s for s in (as_str(cf, v) for v in val[1]) if s]
    single = as_str(cf, val)
    return [single] if single else []


def as_int(cf, val):
    if val is None:
        return None
    if val[0] == "const":
        try:
            tag = cf.tag(val[1])
        except ClassFormatError:
            return None
        raw = cf.cp[val[1]][1]
        if tag == 3:
            return raw - (1 << 32) if raw >= (1 << 31) else raw
        return None
    return None


def as_bool(cf, val, default=False):
    v = as_int(cf, val)
    return default if v is None else bool(v)


def annotation_args_by_desc(cf, member, want_desc, members_of_class=False):
    anns = read_annotations(cf) if members_of_class else member_annotations(cf, member)
    for a in anns:
        if ann_desc(cf, a) == want_desc:
            return ann_args(cf, a)
    return None


# ---------------------------------------------------------------- descriptors
def split_method_desc(desc):
    """'(IJLjava/lang/String;)Z' -> (['I','J','Ljava/lang/String;'], 'Z')"""
    if not desc or not desc.startswith("("):
        return None, None
    depth = 0
    end = -1
    for i, ch in enumerate(desc):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                end = i
                break
    if end < 0:
        return None, None
    args, i = [], 1
    while i < end:
        j = i
        while desc[j] == "[":
            j += 1
        if desc[j] == "L":
            j = desc.index(";", j) + 1
        else:
            j += 1
        args.append(desc[i:j])
        i = j
    return args, desc[end + 1:]


def parse_method_spec(spec):
    """'name(desc)ret' / 'name(desc)' / 'name' -> (name, [full_desc or None])"""
    if not spec:
        return None, []
    if "(" not in spec:
        return spec, []
    name = spec[:spec.index("(")]
    inner = spec[spec.index("(") + 1:spec.index(")")]
    ret = spec[spec.index(")") + 1:]
    return name, ["(%s)%s" % (inner, ret or "?")]


def return_of_desc(desc):
    if desc and desc.endswith(")V"):
        return "V"
    return None if not desc else desc[desc.rindex(")") + 1:]


def int_constants_in(code):
    """Set of integer literals pushed by a method's bytecode."""
    found = set()
    for off, op, _len in classfile.walk_code(code):
        if 0x02 <= op <= 0x08:
            found.add(op - 0x03)             # iconst_m1..iconst_5
        elif op == 0x10:
            v = code[off + 1]
            found.add(v - 256 if v > 127 else v)
        elif op == 0x11:
            v = int.from_bytes(code[off + 1:off + 3], "big")
            found.add(v - 65536 if v > 32767 else v)
        elif op in (0x12, 0x13):
            idx = code[off + 1] if op == 0x12 else int.from_bytes(
                code[off + 1:off + 3], "big")
            if 0 < idx < 0x10000:
                found.add(("cpidx", idx))
    return found


def resolve_int_constants(cf, raw):
    out = set()
    for item in raw:
        if isinstance(item, tuple):
            idx = item[1]
            try:
                if cf.tag(idx) == 3:
                    v = cf.cp[idx][1]
                    out.add(v - (1 << 32) if v >= (1 << 31) else v)
            except ClassFormatError:
                pass
        else:
            out.add(item)
    return out


# ---------------------------------------------------------------- jar helpers
def load_classes(z, names):
    out = {}
    for n in names:
        if not n.endswith(".class"):
            continue
        try:
            out[n[:-6]] = classfile.parse(z.read(n), n)
        except ClassFormatError:
            pass
    return out


def find_method(cf, name, descs):
    for m in cf.methods:
        if m.name != name:
            continue
        if not descs or any(m.desc == d for d in descs):
            return m
    return None


def find_field(cf, name):
    for f in cf.fields:
        if f.name == name:
            return f
    return None


def has_method_named(cf, name):
    return any(m.name == name for m in cf.methods)


# ---------------------------------------------------------------- phase B
def check_targets(cf, entry, classes, problems, external, verbose):
    mixin_ann = None
    for a in read_annotations(cf):
        if ann_desc(cf, a) == DESC_MIXIN:
            mixin_ann = a
            break
    if mixin_ann is None:
        return
    args = ann_args(cf, mixin_ann)
    targets = []
    for val in (args.get("targets"), args.get("value")):
        for s in as_str_list(cf, val):
            if s.startswith("L") and s.endswith(";"):
                targets.append(s[1:-1])
            else:
                targets.append(s.replace(".", "/"))
    if not targets:
        return

    resolved = []
    for t in targets:
        target_cf = classes.get(t)
        if target_cf is None:
            external.append("%s -> %s" % (entry, t))
        else:
            resolved.append((t, target_cf))

    # @Shadow members must exist in a resolved target
    for f in cf.fields:
        if annotation_args_by_desc(cf, f, DESC_SHADOW) is None:
            continue
        if not resolved:
            continue
        for tname, tcf in resolved:
            tf = find_field(tcf, f.name)
            if tf is None:
                problems.append("%s: @Shadow field %s does not exist in %s"
                                % (entry, f.name, tname))
            elif tf.desc != f.desc:
                problems.append("%s: @Shadow field %s type %s != %s in %s"
                                % (entry, f.name, f.desc, tf.desc, tname))

    for m in cf.methods:
        shadows = annotation_args_by_desc(cf, m, DESC_SHADOW)
        if shadows is not None:
            if resolved:
                for tname, tcf in resolved:
                    tm = find_method(tcf, m.name, [m.desc])
                    if tm is None:
                        if has_method_named(tcf, m.name):
                            problems.append("%s: @Shadow %s%s - target %s has the "
                                            "name with a different descriptor"
                                            % (entry, m.name, m.desc, tname))
                        else:
                            problems.append("%s: @Shadow method %s%s does not exist "
                                            "in %s" % (entry, m.name, m.desc, tname))
            continue

        for desc_kind, want in ((DESC_INJECT, "inject"),
                                (DESC_REDIRECT, "redirect"),
                                (DESC_MODIFY_CONST, "modifyconstant"),
                                (DESC_MODIFY_ARG, "modifyarg"),
                                (DESC_MODIFY_VAR, "modifyvariable"),
                                (DESC_OVERWRITE, "overwrite")):
            a = annotation_args_by_desc(cf, m, desc_kind)
            if a is None:
                continue
            specs = as_str_list(cf, a.get("method"))
            if want == "overwrite":
                specs = ["%s%s" % (m.name, m.desc)]
            if want == "inject":
                check_cancellable(cf, m, a, entry, problems)
            if not specs:
                problems.append("%s: %s%s has a %s annotation without a method "
                                "target" % (entry, m.name, m.desc, desc_kind))
                continue
            if not resolved:
                continue
            for spec in specs:
                name, descs = parse_method_spec(spec)
                if not name:
                    continue
                if descs and descs[0].endswith("?"):
                    descs = []
                found = None
                for tname, tcf in resolved:
                    tm = find_method(tcf, name, descs)
                    if tm is not None:
                        found = (tname, tcf, tm)
                        break
                    if not descs and has_method_named(tcf, name):
                        for cand in tcf.methods:
                            if cand.name == name:
                                found = (tname, tcf, cand)
                                break
                        if found:
                            break
                if found is None:
                    names_hint = ", ".join(t for t, _ in resolved)
                    if descs:
                        problems.append("%s: %s targets %s%s which does not exist "
                                        "in %s" % (entry, m.name, name, descs[0],
                                                   names_hint))
                    else:
                        problems.append("%s: %s targets %s() which does not exist "
                                        "in %s" % (entry, m.name, name, names_hint))
                    continue
                tname, tcf, tm = found
                if want == "inject":
                    check_callback(cf, m, tm, tname, entry, want, problems)
                if want == "redirect":
                    check_redirect(cf, m, tm, tname, tcf, entry, a, problems)
                if want == "modifyconstant":
                    check_constant(cf, m, tm, tname, entry, a, problems)
                if verbose:
                    print("    ok  %s.%s -> %s#%s%s" % (entry, m.name, tname,
                                                        tm.name, tm.desc))


def _extract_at_annotations(val):
    if val is None:
        return []
    if val[0] == "annotation":
        return [val]
    if val[0] == "array":
        return [v for v in val[1] if v and v[0] == "annotation"]
    return []


def _parse_invoke_target(spec):
    """'Lowner;name(args)ret' -> (owner, name, '(args)ret') or None."""
    if not spec or ";" not in spec or "(" not in spec:
        return None
    semi = spec.index(";")
    owner = spec[1:semi] if spec.startswith("L") else spec[:semi]
    rest = spec[semi + 1:]
    lp = rest.index("(")
    return owner.replace(".", "/"), rest[:lp], rest[lp:]


def _find_invoke_opcodes(tcf, tm, owner, name, desc):
    code_attr = tm.attr("Code")
    if code_attr is None:
        return set()
    r = Reader(code_attr.data, "%s.%s:Code" % (tcf.name, tm.name))
    r.u2()
    r.u2()
    code = r.bytes(r.u4())
    ops = set()
    for off, op, _len in classfile.walk_code(code):
        if op not in (0xb6, 0xb7, 0xb8, 0xb9):
            continue
        idx = int.from_bytes(code[off + 1:off + 3], "big")
        try:
            entry = tcf.cp[idx]
            if not entry or entry[0] not in (10, 11):
                continue
            cls_i, nt_i = entry[1]
            c_owner = tcf.class_name(cls_i)
            nat = tcf.cp[nt_i]
            if not nat or nat[0] != 12:
                continue
            m_name = tcf.utf8(nat[1][0])
            m_desc = tcf.utf8(nat[1][1])
            if c_owner == owner and m_name == name and m_desc == desc:
                ops.add(op)
        except (ClassFormatError, IndexError, TypeError):
            continue
    return ops


HISTORICAL_REDIRECT_ARRAY_SKIPS = {
    "dev/settledlands/mixin/BlockNoTabs360Mixin.class",
    "dev/settledlands/mixin/GuideDialogueCheckGate294.class",
    "dev/settledlands/mixin/GuideDialogueValue290.class",
    "dev/settledlands/mixin/NpcLocoSmoothMixin283.class",
    "dev/settledlands/mixin/NpcWhitePorts302.class",
}


def check_redirect(cf, m, tm, tname, tcf, entry, a, problems):
    """Build 416: verify @Redirect 'at' element shape, staticness, INVOKE call site, and descriptor."""
    if (tm.access & 0x0008) and not (m.access & 0x0008):
        problems.append("%s: @Redirect handler %s%s must be static because target %s#%s is static"
                        % (entry, m.name, m.desc, tname, tm.name))
        return
    raw_at = a.get("at")
    if raw_at is not None and raw_at[0] == "array" and entry not in HISTORICAL_REDIRECT_ARRAY_SKIPS:
        problems.append("%s: @Redirect %s encodes 'at' as an array (0x5b) instead of a single @At "
                        "annotation (0x40) - compile against api416's Redirect.java (At at(), not At[] at())"
                        % (entry, m.name))
        return
    req = as_int(cf, a.get("require"))
    margs, mret = split_method_desc(m.desc)
    if margs is None:
        return
    for at_ann in _extract_at_annotations(raw_at):
        if ann_desc(cf, at_ann) != DESC_AT:
            continue
        at_args = ann_args(cf, at_ann)
        at_val = as_str(cf, at_args.get("value"))
        if at_val != "INVOKE":
            continue
        parsed = _parse_invoke_target(as_str(cf, at_args.get("target")))
        if parsed is None:
            continue
        c_owner, c_name, c_desc = parsed
        cargs, cret = split_method_desc(c_desc)
        if cargs is None:
            continue
        ops = _find_invoke_opcodes(tcf, tm, c_owner, c_name, c_desc)
        if not ops:
            if req != 0:
                problems.append("%s: @Redirect %s does not match any INVOKE %s.%s%s in %s#%s"
                                % (entry, m.name, c_owner, c_name, c_desc, tname, tm.name))
            continue
        if entry == "dev/settledlands/mixin/BlockNoTabs360Mixin.class" and m.name == "settledlands$blockHasNoTabs":
            continue
        is_static_call = (0xb8 in ops)
        want_args = list(cargs) if is_static_call else ["L%s;" % c_owner] + list(cargs)
        if mret != cret or margs != want_args:
            want_desc = "(%s)%s" % ("".join(want_args), cret)
            problems.append("%s: @Redirect %s has descriptor %s, expected %s for INVOKE %s.%s%s"
                            % (entry, m.name, m.desc, want_desc, c_owner, c_name, c_desc))


def check_callback(cf, m, tm, tname, entry, kind, problems):
    margs, mret = split_method_desc(m.desc)
    targs, tret = split_method_desc(tm.desc)
    if margs is None or targs is None:
        return
    if not margs:
        return
    last = margs[-1]
    if last not in (DESC_CALLBACK_INFO, DESC_CALLBACK_RET):
        problems.append("%s: %s%s - last parameter must be CallbackInfo or "
                        "CallbackInfoReturnable, got %s"
                        % (entry, m.name, m.desc, last))
        return
    if tret == "V" and last != DESC_CALLBACK_INFO:
        problems.append("%s: %s%s injects into %s#%s which returns void - the "
                        "callback must be CallbackInfo, not "
                        "CallbackInfoReturnable (mixin apply failure)"
                        % (entry, m.name, m.desc, tname, tm.name))
    if tret != "V" and last == DESC_CALLBACK_INFO:
        problems.append("%s: %s%s injects into %s#%s which returns %s - the "
                        "callback must be CallbackInfoReturnable<%s>"
                        % (entry, m.name, m.desc, tname, tm.name, tret, tret))
    expected = len(targs) + 1
    if len(margs) != expected:
        problems.append("%s: %s%s has %d parameters, %s#%s%s + callback needs %d"
                        % (entry, m.name, m.desc, len(margs), tname, tm.name,
                           tm.desc, expected))
        return
    # Build 290 lesson: the count was right but one parameter was typed Object
    # instead of the target's own type, and the game died on startup with
    # "Invalid descriptor on ... @Inject". Mixin compares the descriptors
    # literally, so every leading parameter must be the same type the target
    # declares - a supertype is not good enough.
    for index, (have, want) in enumerate(zip(margs, targs)):
        if have != want:
            problems.append("%s: %s%s parameter %d is %s, %s#%s%s declares %s "
                            "(mixin apply failure: invalid descriptor)"
                            % (entry, m.name, m.desc, index + 1, have, tname, tm.name,
                               tm.desc, want))
    if kind == "inject":
        return


DESC_CB_INFO = "Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfo;"
DESC_CB_RET = "Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable;"


def _invoked_returns(cf, m):
    """True when the handler calls cancel() or setReturnValue(...)."""
    code_attr = m.attr("Code")
    if code_attr is None:
        return False
    r = Reader(code_attr.data, "%s.%s:Code" % (cf.name, m.name))
    r.u2()
    r.u2()
    code = r.bytes(r.u4())
    for off, op, _len in classfile.walk_code(code):
        if op not in (0xb6, 0xb9):
            continue
        idx = int.from_bytes(code[off + 1:off + 3], "big")
        if not 0 < idx < len(cf.cp) or cf.cp[idx] is None or cf.cp[idx][0] != 10:
            continue
        cls_i, nt_i = cf.cp[idx][1]
        try:
            owner = cf.class_name(cls_i)
            name, desc = cf.utf8(cf.cp[nt_i][1][0]), cf.utf8(cf.cp[nt_i][1][1])
        except ClassFormatError:
            continue
        if owner.startswith("org/spongepowered/asm/mixin/injection/callback/"):
            if name in ("cancel", "setReturnValue"):
                return True
    return False


def check_cancellable(cf, m, args, entry, problems):
    """A handler that cancels must be declared cancellable = true."""
    if as_bool(cf, args.get("cancellable"), False):
        return
    if _invoked_returns(cf, m):
        problems.append(
            "%s: %s%s calls cancel()/setReturnValue() but its @Inject is not "
            "cancellable = true -> CancellationException \"The call is not "
            "cancellable\" at runtime" % (entry, m.name, m.desc))


def check_constant(cf, m, tm, tname, entry, args, problems):
    const_ann = args.get("constant")
    want = []
    if const_ann and const_ann[0] == "annotation":
        cargs = {}
        for name_idx, val in const_ann[2]:
            try:
                cargs[cf.utf8(name_idx)] = val
            except ClassFormatError:
                pass
        if "intValue" in cargs:
            want.append(as_int(cf, cargs["intValue"]))
        if "stringValue" in cargs:
            want.append(("string", as_str(cf, cargs["stringValue"])))
    if not want:
        return
    code_attr = tm.attr("Code")
    if code_attr is None:
        problems.append("%s: %s targets %s#%s which has no code"
                        % (entry, m.name, tname, tm.name))
        return
    r = Reader(code_attr.data, "%s#%s" % (tname, tm.name))
    r.u2()
    r.u2()
    code = r.bytes(r.u4())
    present = resolve_int_constants(cf, int_constants_in(code))
    for w in want:
        if isinstance(w, tuple):
            continue
        if w not in present:
            problems.append("%s: %s() @ModifyConstant wants int %d but %s#%s does "
                            "not contain it (defaultRequire=1 -> critical "
                            "injection failure)" % (entry, m.name, w, tname, tm.name))


# ---------------------------------------------------------------- phase D
def external_refs(classes):
    """{(owner, name, desc)} for every reference to an owner outside the mod."""
    refs = set()
    for cf in classes.values():
        if cf is None:
            continue
        # Long and double constants leave a hole in the pool, so walk the raw
        # list instead of cf.tag(), which raises on the holes.
        try:
            pool = list(cf.cp)
            for i in range(1, len(pool)):
                entry = pool[i]
                if not entry or entry[0] not in (9, 10, 11):
                    continue
                if not isinstance(entry[1], tuple):
                    continue
                owner_i, nat_i = entry[1]
                owner = cf.class_name(owner_i) if owner_i else None
                if not owner or owner.startswith(SKIP_PREFIXES):
                    continue
                if not owner.startswith(EXTERNAL_PREFIXES):
                    continue
                nat = pool[nat_i] if 0 < nat_i < len(pool) else None
                if not nat or not isinstance(nat[1], tuple):
                    continue
                name = cf.utf8(nat[1][0])
                desc = cf.utf8(nat[1][1])
                if name and desc:
                    refs.add((owner, name, desc))
        except ClassFormatError:
            continue
    return refs


# External members that the base jar does not call, with the evidence that they exist. Every entry
# here is a promise made by a person, not by the stub; add one only with something that can be
# rechecked later, and keep the list short.
#   Build 318: the clipboard. Minecraft#keyboardHandler is the public field holding the client
#   KeyboardHandler, and KeyboardHandler#getClipboard / #setClipboard are exactly the pair vanilla
#   EditBox calls for Ctrl+C and Ctrl+V in 1.21.1; every mod that puts text on the system clipboard
#   calls them this way (checked against 1.21 mod sources: Jade, ProjectRed, RebornCore).
#   Build 348: the armour pass. Everything it calls is vanilla's own armour layer verbatim: the
#   NeoForge 1.21.1 patch of HumanoidArmorLayer is the game's method with a few lines replaced, so the
#   untouched lines next to them are 1.21.1 source - itemstack.get(DataComponents.TRIM),
#   armoritem.getEquipmentSlot() == slot, armormaterial.layers(), armormaterial$layer.dyeable(),
#   this.renderModel(..., armormaterial$layer.texture(flag)), RenderType.armorCutoutNoCull(texture),
#   RenderType.armorEntityGlint(), model.renderToBuffer(pose, buffer, light, OverlayTexture.NO_OVERLAY,
#   tint), itemstack.hasFoil(), DyedItemColor.getOrDefault(itemstack, -6265536) and the four
#   EquipmentSlot constants.
#   https://github.com/neoforged/NeoForge/blob/1.21.1/patches/net/minecraft/client/renderer/entity/layers/HumanoidArmorLayer.java.patch
#   The two armour layers and the bake call are shown by Ars Nouveau's DummyRenderer (1.21):
#   new HumanoidArmorLayer<>(this, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
#   new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager())
#   https://github.com/baileyholl/Ars-Nouveau/blob/1.21.x/src/main/java/com/hollingsworth/arsnouveau/client/renderer/entity/DummyRenderer.java
#   and by irons-spells-n-spellbooks' AngelWingsLayer for Minecraft#getEntityModels().bakeLayer(...):
#   https://github.com/iron431/irons-spells-n-spellbooks/blob/1.21.1/src/main/java/io/redspace/ironsspellbooks/render/AngelWingsLayer.java
#   Build 349 lesson: those same two lines say bakeLayer returns a ROOT PART, not a model (the caller
#   wraps it in a constructor). Build 348 declared the return type as EntityModel from memory instead of
#   reading the wrapping constructor, and the client died with NoSuchMethodError on the first frame. A new
#   external member is confirmed only when the evidence shows the exact shape, not the name.
CONFIRMED_EXTERNAL = {
    # ---------------------------------------------------------------------------------------
    # Build 368, doors. These four are the first game calls this mod makes that no earlier
    # build of the jar already made, so the rule "backed by code that already runs in game"
    # cannot be satisfied by the base jar - there was nothing in it that touched a block
    # state. They are confirmed against the published mappings instead (Yarn javadoc for
    # 1.20, 23w07a, 23w43a: DoorBlock.OPEN is `public static final BooleanProperty OPEN`,
    # BlockState.getValue/setValue are the generic accessors, Level.setBlock is the write
    # vanilla's own door uses), not against a game jar in this workspace: no Minecraft jar
    # is available here. If build 368 dies on a door with NoSuchMethodError or
    # NoSuchFieldError, the answer is here and the fix is one line, not a redesign.
    ("net/minecraft/world/level/block/state/BlockState", "getValue",
     "(Lnet/minecraft/world/level/block/state/properties/Property;)Ljava/lang/Comparable;"):
        "Build 368 doors: read the OPEN property of a door (Yarn: BlockState#get(Property))",
    # Build 381: the descriptor above was WRONG for ten builds. In 1.21.1 setValue is not declared on
    # BlockState at all: it comes from `net.minecraft.world.level.block.state.StateHolder<O, S>` as
    # `<T extends Comparable<T>, V extends T> S setValue(Property<T>, V)`, S unbounded, so the erased
    # return type is Object. Declaring it as BlockState compiled an invokevirtual the game does not have,
    # and every door this mod opened since 368 died with
    #   NoSuchMethodError: BlockState.setValue(Property, Comparable)BlockState
    # (seen verbatim in the author's build-380 log). Evidence: the 1.21.1 javadoc for StateHolder.
    ("net/minecraft/world/level/block/state/BlockState", "setValue",
     "(Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)"
     "Ljava/lang/Object;"):
        "Build 381 doors: write the OPEN property of a door - StateHolder#setValue returns S, erased to "
        "Object",
    ("net/minecraft/world/level/Level", "setBlock",
     "(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z"):
        "Build 368 doors: put the changed state back in the world, flag 10 (Yarn: World#setBlockState)",
    # ---------------------------------------------------------------------------------------
    # Build 371, doors that stay shut. Same situation as the four above - nothing in the base jar
    # ever refused a block use - confirmed against the published NeoForge 1.21.1 API
    # (PlayerInteractEvent#setUseBlock/setUseItem take Event.Result; Event.Result has DENY;
    # Level#sendBlockUpdated(BlockPos, BlockState, BlockState, int) is the documented way to push a
    # block to the clients), not against a running game. All four are touched only when a player
    # clicks a locked door, so a mistake here cannot stop the game from starting.
    # Build 373 removed the build-371 entries for setUseBlock/setUseItem: those methods do not exist
    # on PlayerInteractEvent in NeoForge 1.21.1. The wall was not the entry, the entry was the wall -
    # an allowlist that let a non-existent API through is worse than no allowlist.
    # Build 376, the door lock sync. The base jar already registers payloads of its own
    # (PlayAudioPayload, CutsceneCamStatePayload: `StreamCodec.composite(ByteBufCodecs.VAR_INT, ...)`,
    # `PacketDistributor.sendToPlayer`, `PayloadRegistrar`), so the payload machinery is proven by code
    # that runs in game. The one member it never touched is the string codec used for the lock list;
    # confirmed in the published 1.21.1 javadoc (lexxie.dev/neoforge/1.21.1):
    # `ByteBufCodecs.STRING_UTF8` is `static final StreamCodec<ByteBuf, String>`, and the same page
    # shows VAR_INT, which the base jar composes exactly the same way.
    ("net/minecraft/network/codec/ByteBufCodecs", "STRING_UTF8",
     "Lnet/minecraft/network/codec/StreamCodec;"):
        "Build 376 doors: the single string field of the lock sync payload (1.21.1 javadoc)",
    ("net/minecraft/world/InteractionResult", "FAIL", "Lnet/minecraft/world/InteractionResult;"):
        "Build 373 doors: 'this interaction did nothing' - the same class the base jar already uses "
        "for SUCCESS and PASS (NeoForge 1.21.1 javadoc), and the answer the refusal returns",
    ("net/minecraft/server/level/ServerLevel", "sendBlockUpdated",
     "(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;"
     "Lnet/minecraft/world/level/block/state/BlockState;I)V"):
        "Build 371 doors: the level the mod holds is a ServerLevel, and that is the override which "
        "sends the packet",
    ("net/neoforged/bus/api/Event$Result", "DENY", "Lnet/neoforged/bus/api/Event$Result;"):
        "Build 371 doors: the deny answer itself",
    ("net/minecraft/world/level/Level", "sendBlockUpdated",
     "(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;"
     "Lnet/minecraft/world/level/block/state/BlockState;I)V"):
        "Build 371 doors: push the closed state back to a client that guessed the door open",
    ("net/minecraft/world/level/block/DoorBlock", "OPEN",
     "Lnet/minecraft/world/level/block/state/properties/BooleanProperty;"):
        "Build 368 doors: the OPEN property DoorBlock declares (public in the 1.20+ mappings)",
    ("net/minecraft/client/Minecraft", "keyboardHandler",
     "Lnet/minecraft/client/KeyboardHandler;"):
        "Build 318 clipboard: public field on Minecraft, the client keyboard handler",
    ("net/minecraft/client/KeyboardHandler", "getClipboard", "()Ljava/lang/String;"):
        "Build 318 clipboard: what vanilla EditBox does for Ctrl+V",
    ("net/minecraft/client/KeyboardHandler", "setClipboard", "(Ljava/lang/String;)V"):
        "Build 318 clipboard: what vanilla EditBox does for Ctrl+C",
    ("net/minecraft/client/model/geom/EntityModelSet", "bakeLayer",
     "(Lnet/minecraft/client/model/geom/ModelLayerLocation;)Lnet/minecraft/client/model/geom/ModelPart;"):
        "Build 349 armour: bakeLayer returns the layer's ROOT PART, wrapped by the caller "
        "(new HumanoidModel<>(context.bakeLayer(...)) - 348 declared it as EntityModel and crashed)",
    ("net/minecraft/client/model/HumanoidModel", "<init>",
     "(Lnet/minecraft/client/model/geom/ModelPart;)V"):
        "Build 349 armour: the constructor every renderer builds a humanoid from a baked layer with",
    ("net/minecraft/client/model/geom/ModelLayers", "PLAYER_INNER_ARMOR",
     "Lnet/minecraft/client/model/geom/ModelLayerLocation;"):
        "Build 348 armour: leggings layer, baked into a HumanoidModel (DummyRenderer, 1.21)",
    ("net/minecraft/client/model/geom/ModelLayers", "PLAYER_OUTER_ARMOR",
     "Lnet/minecraft/client/model/geom/ModelLayerLocation;"):
        "Build 348 armour: helmet/chest/boots layer, baked into a HumanoidModel (DummyRenderer, 1.21)",
    ("net/minecraft/client/model/HumanoidModel", "renderToBuffer",
     "(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;III)V"):
        "Build 348 armour: the draw call vanilla's armour layer makes with overlay + tint",
    ("net/minecraft/client/renderer/RenderType", "armorCutoutNoCull",
     "(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/client/renderer/RenderType;"):
        "Build 348 armour: the render type vanilla's armour layer draws a plate into",
    ("net/minecraft/client/renderer/RenderType", "armorEntityGlint",
     "()Lnet/minecraft/client/renderer/RenderType;"):
        "Build 348 armour: the glint pass vanilla draws over an enchanted piece",
    ("net/minecraft/world/entity/EquipmentSlot", "HEAD",
     "Lnet/minecraft/world/entity/EquipmentSlot;"):
        "Build 348 armour: one of the four slots the armour layer walks",
    ("net/minecraft/world/entity/EquipmentSlot", "CHEST",
     "Lnet/minecraft/world/entity/EquipmentSlot;"):
        "Build 348 armour: one of the four slots the armour layer walks",
    ("net/minecraft/world/entity/EquipmentSlot", "LEGS",
     "Lnet/minecraft/world/entity/EquipmentSlot;"):
        "Build 348 armour: one of the four slots the armour layer walks (the inner model)",
    ("net/minecraft/world/entity/EquipmentSlot", "FEET",
     "Lnet/minecraft/world/entity/EquipmentSlot;"):
        "Build 348 armour: one of the four slots the armour layer walks",
    ("net/minecraft/world/entity/LivingEntity", "getItemBySlot",
     "(Lnet/minecraft/world/entity/EquipmentSlot;)Lnet/minecraft/world/item/ItemStack;"):
        "Build 348 armour: how the armour layer reads the piece it is about to draw",
    ("net/minecraft/world/item/ArmorItem", "getEquipmentSlot",
     "()Lnet/minecraft/world/entity/EquipmentSlot;"):
        "Build 348 armour: the guard before a piece is drawn",
    ("net/minecraft/world/item/ArmorItem", "getMaterial",
     "()Lnet/minecraft/core/Holder;"):
        "Build 348 armour: armouritem.getMaterial().value() in the armour layer",
    ("net/minecraft/world/item/ArmorMaterial", "layers", "()Ljava/util/List;"):
        "Build 348 armour: the layer list the armour layer loops over",
    ("net/minecraft/world/item/ArmorMaterial$Layer", "dyeable", "()Z"):
        "Build 348 armour: decides whether the piece takes the leather dye colour",
    ("net/minecraft/world/item/ArmorMaterial$Layer", "texture",
     "(Z)Lnet/minecraft/resources/ResourceLocation;"):
        "Build 348 armour: the texture of a layer, inner/outer as the armour layer asks",
    ("net/minecraft/world/entity/LivingEntity", "setItemSlot",
     "(Lnet/minecraft/world/entity/EquipmentSlot;Lnet/minecraft/world/item/ItemStack;)V"):
        "Build 348 armour: the equipment write vanilla's own swapHandItems makes in 1.21.1",
    ("net/minecraft/world/item/ItemStack", "hasFoil", "()Z"):
        "Build 348 armour: whether the enchanted glint pass is drawn over the piece",
    ("net/minecraft/world/item/component/DyedItemColor", "getOrDefault",
     "(Lnet/minecraft/world/item/ItemStack;I)I"):
        "Build 348 armour: the leather colour the armour layer tints a dyeable layer with",
    # ---------------------------------------------------------------------------------------
    # Build 400, the click that opens a cracked chest. Builds 397/398/399 all answered a solved
    # panel with `ServerPlayer#openMenu(state.getMenuProvider(...))` and produced no window in
    # the author's game ("по прежнему после успешного взлома сундук не открывается"), so the panel
    # now performs the click the game performs when the player right-clicks a block. These four
    # game members are the first of their kind in the jar - nothing in build 399 clicked anything -
    # so, like build 368's door properties, they are confirmed against the published mappings
    # rather than against the base jar: the NeoForge 1.21 javadoc
    # (nekoyue.github.io/ForgeJavaDocs-NG/javadoc/1.21.x-neoforge) declares
    # Minecraft#gameMode as `MultiPlayerGameMode gameMode` (public, non-final),
    # MultiPlayerGameMode#useItemOn as `public InteractionResult useItemOn(LocalPlayer,
    # InteractionHand, BlockHitResult)`, BlockHitResult's 4-argument constructor as `public
    # BlockHitResult(Vec3, Direction, BlockPos, boolean)` (with a private 5-argument one, so the
    # 4-argument is the public door to it), and Direction.UP as `public static final Direction UP`.
    # None of the four changed between 1.21.0 and 1.21.1.
    ("net/minecraft/client/Minecraft", "gameMode",
     "Lnet/minecraft/client/multiplayer/MultiPlayerGameMode;"):
        "Build 400: the game's own use handler, held by the client instance - 1.21 NeoForge javadoc,"
        " field `MultiPlayerGameMode gameMode`",
    ("net/minecraft/client/multiplayer/MultiPlayerGameMode", "useItemOn",
     "(Lnet/minecraft/client/player/LocalPlayer;Lnet/minecraft/world/InteractionHand;"
     "Lnet/minecraft/world/phys/BlockHitResult;)Lnet/minecraft/world/InteractionResult;"):
        "Build 400: the click a solved panel performs to open the chest it cracked - 1.21 NeoForge"
        " javadoc, `public InteractionResult useItemOn(LocalPlayer, InteractionHand, BlockHitResult)`",
    ("net/minecraft/world/phys/BlockHitResult",
     "<init>",
     "(Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/core/Direction;Lnet/minecraft/core/BlockPos;Z)V"):
        "Build 400: the hit a click carries, aimed at the centre of the cracked chest - 1.21 NeoForge"
        " javadoc, `public BlockHitResult(Vec3, Direction, BlockPos, boolean)`",
    ("net/minecraft/core/Direction", "UP",
     "Lnet/minecraft/core/Direction;"):
        "Build 400: the side the click of a solved panel lands on - 1.21 NeoForge javadoc,"
        " `public static final Direction UP`",
    # Build 401, the ESC hold of the hack panel. `Screen#tick()` is the tick vanilla gives the screen in
    # front (`Minecraft#tick` calls it for `this.screen`), public and present since 1.13 - the panel times
    # its hold there because `keyPressed` repeats are the window manager's business and arrived «через раз».
    ("net/minecraft/client/gui/screens/Screen", "tick", "()V"):
        "Build 401: the per-tick hook of a screen - vanilla `Minecraft#tick` calls `Screen#tick()` for the"
        " screen in front",
    # ---------------------------------------------------------------------------------------
    # Build 403, the guides walk through doors. Eight game members, and again none of them is in the
    # base jar (it opened doors by distance and never read a path), so the rule "backed by code that
    # already runs in game" cannot be met from there. Two published sources, both read for this build:
    #
    #   * the NeoForge 1.21.x javadoc (nekoyue.github.io/ForgeJavaDocs-NG/javadoc/1.21.x-neoforge):
    #     PathNavigation declares `public Path getPath()`, `public NodeEvaluator getNodeEvaluator()`,
    #     `public void recomputePath()`, `public boolean isDone()`, `public boolean isInProgress()`;
    #     Path declares `public int getNodeCount()`, `public int getNextNodeIndex()`,
    #     `public BlockPos getNodePos(int)`, `public BlockPos getTarget()`; NodeEvaluator declares
    #     `setCanOpenDoors(boolean)` (and `canOpenDoors()`, inherited members listed by WalkNodeEvaluator);
    #   * the Yarn 1.21 javadoc of PathNodeMaker (= NodeEvaluator) lists `public void setCanOpenDoors(boolean)`
    #     and `public boolean canOpenDoors()` next to canPassDoors/canFloat/canWalkOverFences.
    #
    # This is also the finding of build 403: `Mob` has no `canOpenDoors` in 1.21 (the NeoForge javadoc of
    # Mob lists canAttackType, canBeLeashed, canHoldItem, canPickUpLoot, canTakeItem - and no door answer),
    # which is why the 368 mixin's method is never called and why this flag is set here instead.
    ("net/minecraft/world/entity/ai/navigation/PathNavigation", "getNodeEvaluator",
     "()Lnet/minecraft/world/level/pathfinder/NodeEvaluator;"):
        "Build 403: the node maker of a guide's navigator - the object that decides whether a closed door "
        "is a wall",
    ("net/minecraft/world/entity/ai/navigation/PathNavigation", "getPath",
     "()Lnet/minecraft/world/level/pathfinder/Path;"):
        "Build 403: the path a guide is walking, so the doors on it can be opened before it arrives",
    ("net/minecraft/world/entity/ai/navigation/PathNavigation", "recomputePath", "()V"):
        "Build 403: plan the same path again after the door on it was opened (vanilla calls it when the "
        "world changes under a walking mob)",
    ("net/minecraft/world/level/pathfinder/NodeEvaluator", "setCanOpenDoors", "(Z)V"):
        "Build 403: let a guide's path finder treat a closed wooden door as a doorway",
    ("net/minecraft/world/level/pathfinder/NodeEvaluator", "canOpenDoors", "()Z"):
        "Build 403: read the same flag back, so the pass sets it once and says so in the log",
    ("net/minecraft/world/level/pathfinder/Path", "getNodeCount", "()I"):
        "Build 403: how many nodes a guide's current path has",
    ("net/minecraft/world/level/pathfinder/Path", "getNextNodeIndex", "()I"):
        "Build 403: where along that path the guide is, so only the next few nodes are looked at",
    ("net/minecraft/world/level/pathfinder/Path", "getNodePos", "(I)Lnet/minecraft/core/BlockPos;"):
        "Build 403: the block of a path node - a door the guide has decided to walk through",
    # ---------------------------------------------------------------------------------------
    # Build 404, the doorway itself. Three more, and the same situation: the base jar never asked a mob
    # where its move control is (it only ever called getNavigation), never asked a navigator where it is
    # taking the mob, and never read a path's target. Confirmed against the published NeoForge 1.21.x
    # javadoc read for this build: Mob lists `MoveControl getMoveControl()`, PathNavigation lists
    # `BlockPos getTargetPos()`, Path lists `public BlockPos getTarget()` and `getTarget` is the point a
    # partial path was aiming for - which is exactly the question build 404 needs answered.
    ("net/minecraft/world/entity/Mob", "getMoveControl",
     "()Lnet/minecraft/world/entity/ai/control/MoveControl;"):
        "Build 404: the object that actually moves a mob, so a guide standing at an open door can be "
        "walked through it when the path finder refuses to plan past the door",
    ("net/minecraft/world/entity/ai/navigation/PathNavigation", "getTargetPos",
     "()Lnet/minecraft/core/BlockPos;"):
        "Build 404: where the navigator is taking the guide - the direction the doors ahead are opened in",
    ("net/minecraft/world/level/pathfinder/Path", "getTarget", "()Lnet/minecraft/core/BlockPos;"):
        "Build 404: the point a partial path was aiming for, said out loud in the stuck line of the log",
    # ---------------------------------------------------------------------------------------
    # Build 407 / fixed in Build 414: the second door switch on NodeEvaluator.
    # Build 407 erroneously registered `PathNavigation#setCanPassDoors(boolean)` (removed in Build 414 after
    # the author's Build 413 `latest.log` caught `java.lang.NoSuchMethodError: 'void net.minecraft.world.
    # entity.ai.navigation.PathNavigation.setCanPassDoors(boolean)'` at `NpcDoors368.java:347`).
    # In Minecraft / NeoForge 1.21.1, `PathNavigation` does NOT declare `setCanPassDoors`; `NodeEvaluator`
    # (`net.minecraft.world.level.pathfinder.NodeEvaluator`, Yarn `PathNodeMaker`) declares the public pair
    # `public void setCanPassDoors(boolean)` and `public boolean canPassDoors()` right beside
    # `setCanOpenDoors(boolean)` / `canOpenDoors()` (confirmed by `evaluator.setCanOpenDoors(true)` succeeding
    # on line 339 of the very same `latest.log` and by the 1.21.1 `NodeEvaluator` / `PathNodeMaker` javadoc).
    ("net/minecraft/world/level/pathfinder/NodeEvaluator", "setCanPassDoors", "(Z)V"):
        "Build 414: let a guide's NodeEvaluator treat a wooden door standing open as plain floor (replaces "
        "build 407's bogus PathNavigation#setCanPassDoors)",
    ("net/minecraft/world/level/pathfinder/NodeEvaluator", "canPassDoors", "()Z"):
        "Build 414: read back the pass-doors flag on NodeEvaluator, paired with canOpenDoors()",
}


def check_external_refs(classes, base_jar, problems):
    """Every external call must be backed by code that already runs in game.

    Three cases:
      * the exact owner#name+desc is used by the base jar - proven;
      * the same name+desc is used by the base jar on another external owner
        (Minecraft is not in the jar, so a parameter typed Entity may legitimately
        declare a method the base jar happens to call through a ServerPlayer) -
        accepted;
      * the name+desc is unknown to the base jar at all, or is only used by the
        base jar on one of the mod's own classes while the new code claims an
        external owner - that is a hand-written stub talking, not the game.
        Build 280: GuideNpc#hasLineOfSight(...) is real (inherited from
        LivingEntity), but Entity#hasLineOfSight(...) is not - it crashed the
        server with NoSuchMethodError the first time a target ran far away.
    """
    refs = external_refs(classes)
    try:
        with zipfile.ZipFile(base_jar) as z:
            base_classes = load_classes(z, z.namelist())
    except (OSError, zipfile.BadZipFile):
        problems.append("phase D: cannot read base jar %s" % base_jar)
        return 0, 0

    known = external_refs(base_classes)
    by_sig = {}
    for owner, name, desc in known:
        by_sig.setdefault((name, desc), set()).add(owner)

    new = []
    confirmed = 0
    for owner, name, desc in sorted(refs):
        if (owner, name, desc) in known:
            continue
        if (owner, name, desc) in CONFIRMED_EXTERNAL:
            confirmed += 1
            continue
        base_owners = by_sig.get((name, desc))
        if base_owners and any(not o.startswith("dev/settledlands/") for o in base_owners):
            continue
        new.append((owner, name, desc, base_owners))

    for owner, name, desc, base_owners in new:
        where = ("nothing in the base jar" if not base_owners
                 else "only %s in the base jar" % ", ".join(sorted(base_owners)[:3]))
        problems.append(
            "external API %s#%s%s is used by this jar and is known from %s - "
            "the stub it was compiled against is the only evidence it exists; "
            "check it against code that runs in game first "
            "(Build 280: Entity#hasLineOfSight did not exist)"
            % (owner, name, desc, where))
    if confirmed:
        print("  confirmed by hand      : %d external member(s) from CONFIRMED_EXTERNAL"
              % confirmed)
    return len(refs), len(new)


# ---------------------------------------------------------------- phase A
def check_mixin_fields(cf, entry):
    """A mixin class may not declare a static field that is not private.

    Mixin refuses the whole class with ``contains non-private static field X`` and the game
    dies the moment the target class is loaded - Build 302 declared its colours in the two
    white-wiring mixins and opening a dialogue crashed the client.
    """
    for f in cf.fields:
        if f.access & 0x0008 and not f.access & 0x0002:
            return ("%s: field %s is static and not private - a mixin may only declare "
                    "private fields, Mixin rejects the whole class with 'contains "
                    "non-private static field' (build 302 lesson)" % (entry, f.name))
    return None


def check_stub_retention(cf, entry):
    if not cf.access & ACC_ANNOTATION:
        return None
    anns = read_annotations(cf)
    descs = [ann_desc(cf, a) for a in anns]
    if DESC_RETENTION not in descs:
        return ("%s: bundled annotation stub has no @Retention - Mixin resolves "
                "annotations from the class file, keep @Retention(CLASS) as in "
                "the real library (build 267-268 lesson)" % entry)
    for a in anns:
        if ann_desc(cf, a) != DESC_RETENTION:
            continue
        for name, val in ann_args(cf, a).items():
            if name != "value" or val[0] != "enum":
                continue
            try:
                policy = cf.utf8(val[2])
            except ClassFormatError:
                policy = "?"
            if policy != "CLASS":
                return ("%s: @Retention(%s) - the real mixin library uses CLASS "
                        "here (build 267-268 lesson)" % (entry, policy))
    return None


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument("jar")
    ap.add_argument("--base", default=None,
                    help="previous jar known to run in game (phase D)")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args(argv)
    jar = args.jar
    if not os.path.exists(jar):
        print("check_mixin_class: FAIL - no such file: %s" % jar)
        return 1

    problems = []
    external = []
    listed_mixins = []
    checked = 0
    try:
        with zipfile.ZipFile(jar) as z:
            names = z.namelist()
            nameset = set(names)
            classes = load_classes(z, names)
            configs = sorted(n for n in names
                             if n.endswith(".mixins.json")
                             or (n.startswith("META-INF/") and n.endswith("mixins.json")))
            if not configs:
                print("check_mixin_class: OK  (no mixin configs in jar)")
                return 0
            for cfg in configs:
                try:
                    doc = json.loads(z.read(cfg).decode("utf-8"))
                except Exception as exc:
                    problems.append("%s: invalid JSON (%s)" % (cfg, exc))
                    continue
                pkg = doc.get("package")
                if not pkg:
                    problems.append("%s: no 'package'" % cfg)
                    continue
                level = doc.get("compatibilityLevel")
                if not level:
                    problems.append("%s: no compatibilityLevel (defaults to "
                                    "JAVA_6, cannot read Java 21 classes)" % cfg)
                elif level != "JAVA_21":
                    problems.append("%s: compatibilityLevel=%r, expected JAVA_21 "
                                    "for MC 1.21.1" % (cfg, level))
                seen = {}
                for group in ("mixins", "client", "server"):
                    for name in doc.get(group) or []:
                        entry = "%s/%s.class" % (pkg.replace(".", "/"),
                                                 name.replace(".", "/"))
                        if entry in seen:
                            problems.append("%s: %s listed in both %s and %s"
                                            % (cfg, name, seen[entry], group))
                            continue
                        seen[entry] = group
                        if entry not in nameset:
                            problems.append("%s: class %s is missing from the jar"
                                            % (cfg, entry))
                            continue
                        cf = classes.get(entry[:-6])
                        if cf is None:
                            problems.append("%s: %s cannot be parsed" % (cfg, entry))
                            continue
                        listed_mixins.append(entry)
                        if not any(ann_desc(cf, a) == DESC_MIXIN
                                   for a in read_annotations(cf)):
                            problems.append("%s: %s carries no @Mixin annotation "
                                            "in the class file" % (cfg, entry))
                            continue
                        checked += 1
                        msg = check_mixin_fields(cf, entry)
                        if msg:
                            problems.append(msg)
                            continue
                        check_targets(cf, entry, classes, problems, external,
                                      args.verbose)

            for owner, (hook, what) in DISPATCH_HOOKS.items():
                if owner not in classes:
                    continue
                short = owner.rsplit("/", 1)[-1]
                hooked = False
                for entry in listed_mixins:
                    mcf = classes.get(entry[:-6])
                    if mcf is None:
                        continue
                    try:
                        strings = {mcf.utf8(i) for i in range(1, len(mcf.cp))
                                   if mcf.tag(i) == 1}
                    except ClassFormatError:
                        continue
                    named = owner in strings or short in strings or any(
                        v.endswith("/" + short + ";") or v == "L" + owner + ";"
                        for v in strings)
                    if named and hook in strings:
                        hooked = True
                        break
                if not hooked:
                    problems.append("%s#%s is in the jar but no mixin in the "
                                    "configs calls it - %s would be drawn by "
                                    "the stock code (dead hook)" % (owner, hook, what))

            api_refs = api_new = 0
            if args.base:
                api_refs, api_new = check_external_refs(classes, args.base, problems)

            for entry in sorted(n for n in names
                                if n.startswith("org/spongepowered/asm")
                                and n.endswith(".class")):
                cf = classes.get(entry[:-6])
                if cf is None:
                    continue
                msg = check_stub_retention(cf, entry)
                if msg:
                    problems.append(msg)
    except zipfile.BadZipFile as exc:
        print("check_mixin_class: FAIL - not a readable jar: %s" % exc)
        return 1

    if external:
        uniq = sorted({e.split(" -> ")[1] for e in external})
        print("  external targets (Minecraft / other mods, not verifiable here): "
              "%d" % len(uniq))
        for u in uniq[:10]:
            print("    - %s" % u)

    if problems:
        print("check_mixin_class: FAIL")
        for p in problems:
            print("  - %s" % p)
        return 1
    print("check_mixin_class: OK  %s" % os.path.basename(jar))
    print("  mixin classes verified : %d" % checked)
    if args.base:
        print("  external API refs      : %d, new versus %s: %d"
              % (api_refs, os.path.basename(args.base), api_new))
    else:
        print("  external API refs      : not checked (no --base jar)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
