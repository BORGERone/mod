package dev.settledlands.npc.client;

import dev.settledlands.chest.ChestGraph396;
import dev.settledlands.door.DoorGraph382;
import dev.settledlands.npc.NpcDialogueGraph;
import dev.settledlands.npc.NpcDialogueGraph.Node;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Build 277: the pursuit node card plus the action helpers.
 *
 * The card is drawn here so that pursuit nodes keep their own purple header and
 * their own two text lines instead of the generic trigger box. Everything it
 * shows is read from node.action, and the inspector writes to the same field, so
 * the card and the inspector cannot drift apart. Nothing on the card is edited
 * in place: the node is edited in the inspector panel
 * (NpcPursuitInspectorMixin277), which uses ordinary widgets.
 *
 * A pursuit node is stored as a TRIGGER node (the server-side trigger path runs
 * the "trigger:pursuit:..." action), but the screen is told to build no stock
 * inspector for it - see NpcPursuitInspectorMixin277.
 *
 * Build 279 adds the movement settings the pursuit node was missing: how close
 * the NPC is allowed to come, from what distance it starts catching up and, in
 * Build 280, how hard it accelerates. They live in the action itself, after a
 * separator the target cannot contain, so they are saved with the graph and read
 * by NpcPursuit269 on the server:
 *
 * <pre>trigger:pursuit:start:npc:&lt;target&gt;|&lt;keep&gt;|&lt;catch-up&gt;|&lt;boost&gt;</pre>
 *
 * The node also has an output, the way a blueprint node has an output pin: the
 * target it is bound to, printed on the card next to the output port and
 * available to every node that runs after it as {@code %pursuit%}.
 *
 * Build 283 gives the node the second output a blueprint node has: next to the
 * execution output there is now a value output - "Target" - that can be wired to
 * any node. The wire is a variable reference: it pulls the text value of what
 * this NPC pursues (the same text {@code %pursuit%} resolves to), and it is saved
 * with the graph. Consumers are stored as an extra parameter of the action,
 * after the three numbers, so no new field and no format change is needed:
 *
 * <pre>trigger:pursuit:start:npc:&lt;target&gt;|&lt;keep&gt;|&lt;catch-up&gt;|&lt;boost&gt;|@&lt;ids&gt;</pre>
 *
 * The server reads the three numbers by index and ignores what follows them.
 *
 * Build 284 completes the pair: the card now has a value *input* as well, a blue
 * diamond on the left edge under the execution input, so a target can be wired
 * into the node instead of typed. A wire into it makes this node follow the
 * target of the pursuit node it is wired to; the value is re-materialised into
 * this node's own action whenever the graph changes, so what the server reads is
 * always the source's current target. The source is stored as one more parameter:
 *
 * <pre>trigger:pursuit:start:npc:&lt;target&gt;|&lt;keep&gt;|&lt;catch-up&gt;|&lt;boost&gt;|@&lt;ids&gt;|#&lt;source&gt;</pre>
 *
 * Both value wires are drawn as one smooth blue cable per wire, never as dashes:
 * a value is not an execution edge and the colour says so.
 *
 * Build 289 gave the "В радиусе" node a blue output, Build 290 gives one to the
 * "Урон" node (the body that hurt the NPC) and gives the four nodes that consume a
 * body a blue input: реплика, триггер, условие и переменная. Their input is stored
 * in the node's own {@code varInputNode} field, which the graph NBT already carries,
 * so nothing new has to be saved; the pin is the same blue diamond on the left edge,
 * on the same row as the pursuit card's pins. The server half is NpcValueSource290.
 */
public final class PursuitGraphNode272 {
    public static final int PURSUIT_ROW = 16;
    public static final int MENU_ITEM_COUNT = 17;

    /** Stock node geometry (NpcGraphCanvas.NODE_W / NODE_H). */
    public static final int CARD_WIDTH = 220;
    public static final int CARD_HEIGHT = 100;

    private static final int HEADER_H = 22;

    private static final int COL_BORDER_IDLE = 0xff46576b;
    private static final int COL_BORDER_SELECTED = 0xffe9bd67;
    private static final int COL_BODY = 0xff26313f;
    private static final int COL_HEADER = 0xffc77dff;
    private static final int COL_TITLE = 0xfff0f3f7;
    private static final int COL_TEXT = 0xffe3ebf3;
    private static final int COL_MUTED = 0xff8a9ba8;
    private static final int COL_STOP = 0xffa7f2ca;
    private static final int COL_PORT_OUT = 0xffc77dff;

    public static final int TARGET_NPC = 0;
    public static final int TARGET_PLAYER = 1;

    /** Longest target the inspector field accepts. */
    public static final int MAX_VALUE_LENGTH = 64;

    /** Standoff: 1-2 blocks is the requested range, 1.6 is the default. */
    public static final double MIN_KEEP_DISTANCE = 1.0D;
    public static final double MAX_KEEP_DISTANCE = 8.0D;
    public static final double DEFAULT_KEEP_DISTANCE = 1.6D;

    /** Distance at which the NPC switches to the escort catch-up mode. */
    public static final double MIN_CATCH_UP_DISTANCE = 2.0D;
    public static final double MAX_CATCH_UP_DISTANCE = 48.0D;
    public static final double DEFAULT_CATCH_UP_DISTANCE = 8.0D;

    /** How much faster than the walking speed the NPC may run while catching up. */
    public static final double MIN_CATCH_UP_BOOST = 1.0D;
    public static final double MAX_CATCH_UP_BOOST = 3.0D;
    public static final double DEFAULT_CATCH_UP_BOOST = 1.5D;

    /** Separator between the target and its numbers; identifiers and names cannot contain it. */
    private static final char PARAM_SEPARATOR = '|';

    /**
     * Second output of the node: the target value. Drawn on the right edge below
     * the execution pin, hit the same way a blueprint data pin is hit.
     */
    public static final int TARGET_PIN_Y = CARD_HEIGHT - 8;

    /** Extra radius (in card pixels) around the value pin that still counts as a hit. */
    public static final double TARGET_PIN_RADIUS = 7.0D;
    /** Hit radius of the check node's blue output, in screen pixels. */
    public static final double CHECK_PIN_HIT = 5.0D;

    /** Marks the consumer list inside the action; identifiers and names never contain it. */
    private static final char CONSUMER_MARK = '@';

    /** Marks the value-input source inside the action. */
    private static final char SOURCE_MARK = '#';

    /** A node cannot feed more consumers than this. */
    public static final int MAX_CONSUMERS = 12;

    /** A value chain is followed at most this deep. */
    public static final int MAX_SOURCE_DEPTH = 8;

    /** Value wires are blue; execution wires belong to the canvas and keep their colour. */
    public static final int COL_VALUE = 0xff6fb6ff;
    /** Build 301: ordinary connection ports are white, not coloured by node type. */
    public static final int COL_PORT_WHITE = 0xfff2f2f2;
    /** Build 301: ordinary cables are white as well; only the value wires stay blue. */
    public static final int COL_CABLE_WHITE = 0xffe8e8e8;

    /**
     * True when a filled rectangle is one of the stock card's connection ports: a 10x10
     * square on the left or the right edge of a 220-wide card. The stock card draws its
     * ports in the card's own colours; Build 301 paints them white, and this is the test
     * that tells a port apart from the card body, the header and the label chips.
     */
    public static boolean isPortSquare(int x1, int y1, int x2, int y2) {
        return x2 - x1 == 10 && y2 - y1 == 10 && (x1 == -5 || x1 == CARD_WIDTH - 5);
    }
    public static final int COL_VALUE_WIRE = 0xff4c8dfe;

    private static final String START_NPC = "trigger:pursuit:start:npc:";
    private static final String START_PLAYER = "trigger:pursuit:start:player:";
    private static final String STOP = "trigger:pursuit:stop";

    /** Last "start" action of a node, kept while the node is switched to "stop". */
    private static final Map<Node, String> LAST_START = new WeakHashMap<>();

    private PursuitGraphNode272() {}

    // ---- action helpers ----

    public static String actionForMenuRow(int row) {
        if (row != PURSUIT_ROW) return null;
        return START_NPC + PARAM_SEPARATOR + number(DEFAULT_KEEP_DISTANCE)
                + PARAM_SEPARATOR + number(DEFAULT_CATCH_UP_DISTANCE)
                + PARAM_SEPARATOR + number(DEFAULT_CATCH_UP_BOOST);
    }

    /** "1.6" - one decimal, Locale.ROOT, the same shape the server parses. */
    private static String number(double value) {
        return String.format(Locale.ROOT, "%.1f", value);
    }

    private static double setting(String raw, double fallback, double min, double max) {
        if (raw == null || raw.isBlank()) return fallback;
        try {
            double parsed = Double.parseDouble(raw.trim());
            if (Double.isNaN(parsed)) return fallback;
            return parsed < min ? min : (parsed > max ? max : parsed);
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    public static boolean isPursuitNode(Node node) {
        if (node == null || node.type != NpcDialogueGraph.TRIGGER) return false;
        String action = node.action;
        return action != null && (action.startsWith("trigger:pursuit:") || action.startsWith("trigger:pursuit "));
    }

    public static int targetTypeIndex(Node node) {
        String action = node == null ? null : actionOf(node);
        if (action != null && action.startsWith(START_PLAYER)) return TARGET_PLAYER;
        return TARGET_NPC;
    }

    public static String targetValue(Node node) {
        String action = node == null ? null : actionOf(node);
        if (action == null) return "";
        String value;
        if (action.startsWith(START_NPC)) value = action.substring(START_NPC.length());
        else if (action.startsWith(START_PLAYER)) value = action.substring(START_PLAYER.length());
        else return "";
        int separator = value.indexOf(PARAM_SEPARATOR);
        return (separator >= 0 ? value.substring(0, separator) : value).trim();
    }

    /** Numbers written after the target, or null when the node has none. */
    private static String[] params(Node node) {
        String action = node == null ? null : actionOf(node);
        if (action == null) return new String[0];
        int separator = action.indexOf(PARAM_SEPARATOR);
        if (separator < 0) return new String[0];
        return action.substring(separator + 1).split("\\|");
    }

    private static String param(Node node, int index) {
        String[] values = params(node);
        return index < values.length ? values[index] : null;
    }

    /** Configured standoff, 1.6 blocks by default. */
    public static double keepDistance(Node node) {
        return setting(param(node, 0), DEFAULT_KEEP_DISTANCE, MIN_KEEP_DISTANCE, MAX_KEEP_DISTANCE);
    }

    /** Configured catch-up distance, 8 blocks by default. */
    public static double catchUpDistance(Node node) {
        return setting(param(node, 1), DEFAULT_CATCH_UP_DISTANCE,
                MIN_CATCH_UP_DISTANCE, MAX_CATCH_UP_DISTANCE);
    }

    /** Configured catch-up speed multiplier, 1.5 by default. */
    public static double catchUpBoost(Node node) {
        return setting(param(node, 2), DEFAULT_CATCH_UP_BOOST, MIN_CATCH_UP_BOOST, MAX_CATCH_UP_BOOST);
    }

    public static String keepDistanceText(Node node) {
        return number(keepDistance(node));
    }

    public static String catchUpDistanceText(Node node) {
        return number(catchUpDistance(node));
    }

    public static String catchUpBoostText(Node node) {
        return number(catchUpBoost(node));
    }

    public static boolean stopFlag(Node node) {
        String action = node == null ? null : node.action;
        return action != null && action.equals(STOP);
    }

    /** node.action, or the remembered start action while the node is set to stop. */
    private static String actionOf(Node node) {
        if (node == null) return null;
        if (stopFlag(node)) {
            String previous = LAST_START.get(node);
            return previous != null ? previous : node.action;
        }
        return node.action;
    }

    public static String targetTypeLabelKey(Node node) {
        return targetTypeIndex(node) == TARGET_PLAYER
                ? "gui.settledlands.pursuit.target_player"
                : "gui.settledlands.pursuit.target_npc";
    }

    /** Inspector button caption, e.g. "Target: NPC". */
    public static String targetTypeButtonKey(Node node) {
        return targetTypeIndex(node) == TARGET_PLAYER
                ? "gui.settledlands.pursuit.target_player_button"
                : "gui.settledlands.pursuit.target_npc_button";
    }

    public static String stopLabelKey(Node node) {
        return stopFlag(node)
                ? "gui.settledlands.pursuit.stop_toggle_on"
                : "gui.settledlands.pursuit.stop_toggle";
    }

    private static String buildAction(int targetType, String targetValue, double keepDistance,
            double catchUpDistance, double catchUpBoost, boolean stopFlag, List<Integer> consumers,
            int source) {
        if (stopFlag) return STOP;
        String kind = targetType == TARGET_PLAYER ? "player" : "npc";
        String value = targetValue == null ? "" : targetValue.trim();
        value = stripParams(value);
        StringBuilder action = new StringBuilder("trigger:pursuit:start:").append(kind).append(':')
                .append(value).append(PARAM_SEPARATOR)
                .append(number(keepDistance)).append(PARAM_SEPARATOR).append(number(catchUpDistance))
                .append(PARAM_SEPARATOR).append(number(catchUpBoost));
        if (consumers != null && !consumers.isEmpty()) {
            action.append(PARAM_SEPARATOR).append(CONSUMER_MARK);
            for (int i = 0; i < consumers.size(); i++) {
                if (i > 0) action.append(',');
                action.append(consumers.get(i).intValue());
            }
        }
        if (source >= 0) action.append(PARAM_SEPARATOR).append(SOURCE_MARK).append(source);
        return action.toString();
    }

    // ---- value output: the target as a variable ----

    /** Nodes wired to this pursuit node's target output, in the order they were linked. */
    public static List<Integer> consumers(Node node) {
        String[] values = params(node);
        if (values.length <= 3) return List.of();
        String token = values[3];
        if (token == null || token.isEmpty() || token.charAt(0) != CONSUMER_MARK) return List.of();
        List<Integer> ids = new ArrayList<>();
        for (String part : token.substring(1).split(",")) {
            String trimmed = part.trim();
            if (trimmed.isEmpty()) continue;
            try {
                int id = Integer.parseInt(trimmed);
                if (id >= 0 && !ids.contains(id) && ids.size() < MAX_CONSUMERS) ids.add(id);
            } catch (NumberFormatException ignored) {
                // a broken entry must never take the node down with it
            }
        }
        return ids;
    }

    public static boolean hasConsumers(Node node) {
        return !consumers(node).isEmpty();
    }

    /** Rewrites the action with exactly these consumers, keeping every setting. */
    public static void setConsumers(Node node, List<Integer> ids) {
        if (node == null) return;
        String start = buildAction(targetTypeIndex(node), targetValue(node), keepDistance(node),
                catchUpDistance(node), catchUpBoost(node), false, ids, sourceId(node));
        LAST_START.put(node, start);
        node.action = stopFlag(node) ? STOP : start;
    }

    /** Adds or removes one consumer; {@code -1} clears the whole list. */
    public static void toggleConsumer(Node node, int consumerId) {
        if (node == null) return;
        List<Integer> ids = new ArrayList<>(consumers(node));
        if (consumerId < 0) {
            ids.clear();
        } else if (!ids.remove(Integer.valueOf(consumerId)) && ids.size() < MAX_CONSUMERS) {
            ids.add(consumerId);
        }
        setConsumers(node, ids);
    }

    // ---- value input: the target taken from another node ----

    /** Node this one takes its target from, or -1. */
    public static int sourceId(Node node) {
        for (String part : params(node)) {
            if (part == null || part.isEmpty() || part.charAt(0) != SOURCE_MARK) continue;
            try {
                return Integer.parseInt(part.substring(1).trim());
            } catch (NumberFormatException ignored) {
                return -1;
            }
        }
        return -1;
    }

    public static boolean hasSource(Node node) {
        return sourceId(node) >= 0;
    }

    /** Wires this node's target to {@code source}, or clears it with -1. */
    public static void setSource(Node node, int source) {
        if (node == null) return;
        boolean stop = stopFlag(node);
        String start = buildAction(targetTypeIndex(node), targetValue(node), keepDistance(node),
                catchUpDistance(node), catchUpBoost(node), false, consumers(node), source);
        LAST_START.put(node, start);
        node.action = stop ? STOP : start;
    }

    /** The target this node uses: its own text, or the one of the node it is wired to. */
    public static String resolvedTarget(NpcDialogueGraph graph, Node node) {
        return resolve(graph, node, null, 0);
    }

    private static String resolve(NpcDialogueGraph graph, Node node, Map<Integer, String> memo, int depth) {
        if (node == null) return "";
        if (memo != null) {
            String known = memo.get(node.id);
            if (known != null) return known;
        }
        String value = targetValue(node);
        int source = sourceId(node);
        if (source >= 0 && depth < MAX_SOURCE_DEPTH && graph != null) {
            Node from = graph.get(source);
            if (from != null && from.id != node.id && isPursuitNode(from)) {
                value = resolve(graph, from, memo, depth + 1);
            }
        }
        if (memo != null) memo.put(node.id, value);
        return value;
    }

    /**
     * Writes the current target of every source into the nodes wired to it, so the
     * action the server receives carries the value the card shows. One pass, no
     * allocation beyond a small map, and only when the graph changes.
     */
    public static void refreshDependents(NpcDialogueGraph graph) {
        if (graph == null || graph.nodes == null) return;
        Map<Integer, String> memo = new HashMap<>();
        for (Node node : graph.nodes.values()) {
            if (!isPursuitNode(node)) continue;
            int source = sourceId(node);
            if (source < 0) continue;
            String value = resolve(graph, node, memo, 0);
            if (value.equals(targetValue(node)) && !stopFlag(node)) continue;
            boolean stop = stopFlag(node);
            String start = buildAction(targetTypeIndex(node), value, keepDistance(node),
                    catchUpDistance(node), catchUpBoost(node), false, consumers(node), source);
            LAST_START.put(node, start);
            node.action = stop ? STOP : start;
        }
    }

    // ---- value pins: geometry ----

    /** Screen X of the value output: the right edge of the card, like the execution port. */
    public static double targetPinScreenX(NpcGraphCanvas canvas, Node node) {
        return canvas.portScreenX(node, true);
    }

    /** Screen Y of the value pin (input and output are on the same row). */
    public static double targetPinScreenY(NpcGraphCanvas canvas, Node node) {
        return canvas.screenY(node.y) + TARGET_PIN_Y * canvas.zoom;
    }

    /** Screen X of the value input: the left edge of the card. */
    public static double targetInPinScreenX(NpcGraphCanvas canvas, Node node) {
        return canvas.portScreenX(node, false);
    }

    public static boolean hitTargetPin(NpcGraphCanvas canvas, Node node, double mouseX, double mouseY) {
        return hitPin(canvas, targetPinScreenX(canvas, node), targetPinScreenY(canvas, node), mouseX, mouseY);
    }

    public static boolean hitTargetInPin(NpcGraphCanvas canvas, Node node, double mouseX, double mouseY) {
        return hitPin(canvas, targetInPinScreenX(canvas, node), targetPinScreenY(canvas, node), mouseX, mouseY);
    }

    private static boolean hitPin(NpcGraphCanvas canvas, double pinX, double pinY, double mouseX,
            double mouseY) {
        if (canvas == null || !Double.isFinite(pinX) || !Double.isFinite(pinY)) return false;
        double dx = mouseX - pinX;
        double dy = mouseY - pinY;
        double radius = Math.max(TARGET_PIN_RADIUS, TARGET_PIN_RADIUS * canvas.zoom);
        return dx * dx + dy * dy <= radius * radius;
    }

    /**
     * Grab radius of a blue value pin: a little larger than the dot so it stays easy to hit,
     * and it follows the zoom like the dot does, with a small floor for when the graph is
     * zoomed far out.
     */
    public static double pinHitRadius(NpcGraphCanvas canvas) {
        double zoom = canvas == null ? 1.0 : canvas.zoom;
        return Math.max(3.0, CHECK_PIN_HIT * zoom);
    }

    private static String stripParams(String value) {
        int separator = value.indexOf(PARAM_SEPARATOR);
        return (separator >= 0 ? value.substring(0, separator) : value).trim();
    }

    public static void setTargetType(Node node, int targetType) {
        if (node == null) return;
        boolean stop = stopFlag(node);
        String start = buildAction(targetType, targetValue(node), keepDistance(node),
                catchUpDistance(node), catchUpBoost(node), false, consumers(node), sourceId(node));
        LAST_START.put(node, start);
        node.action = stop ? STOP : start;
    }

    public static void setTargetValue(Node node, String value) {
        if (node == null) return;
        boolean stop = stopFlag(node);
        String start = buildAction(targetTypeIndex(node), value, keepDistance(node),
                catchUpDistance(node), catchUpBoost(node), false, consumers(node), sourceId(node));
        LAST_START.put(node, start);
        node.action = stop ? STOP : start;
    }

    public static void setKeepDistance(Node node, double value) {
        applySettings(node, value, catchUpDistance(node), catchUpBoost(node));
    }

    public static void setCatchUpDistance(Node node, double value) {
        applySettings(node, keepDistance(node), value, catchUpBoost(node));
    }

    public static void setCatchUpBoost(Node node, double value) {
        applySettings(node, keepDistance(node), catchUpDistance(node), value);
    }

    private static void applySettings(Node node, double keepDistance, double catchUpDistance,
            double catchUpBoost) {
        String start = buildAction(targetTypeIndex(node), targetValue(node), keepDistance,
                catchUpDistance, catchUpBoost, false, consumers(node), sourceId(node));
        if (start.equals(actionOf(node))) return;
        LAST_START.put(node, start);
        node.action = stopFlag(node) ? STOP : start;
    }

    public static void setStop(Node node, boolean stop) {
        if (node == null) return;
        if (stop) {
            if (!stopFlag(node)) LAST_START.put(node, node.action);
            node.action = STOP;
            return;
        }
        String previous = LAST_START.get(node);
        node.action = previous != null ? previous
                : buildAction(targetTypeIndex(node), "", keepDistance(node), catchUpDistance(node),
                        catchUpBoost(node), false, consumers(node), sourceId(node));
    }

    // ---- context menu ----

    public static boolean isOpenForCreation(NpcGraphContextMenu menu) {
        return menu != null && menu.open && menu.targetNodeId < 0;
    }

    public static int rowAt(NpcGraphContextMenu menu, double x, double y) {
        return menu == null ? -1 : menu.rowAt(x, y);
    }

    public record MenuPoint(int row, double x, double y, int wireFrom, int wirePort) {}

    public static MenuPoint capture(NpcGraphContextMenu menu, int row) {
        if (menu == null) return null;
        return new MenuPoint(row, menu.worldX, menu.worldY, menu.pendingWireFrom, menu.pendingWirePort);
    }

    public static void drawMenuRow(NpcGraphContextMenu menu, GuiGraphics graphics, Font font,
            int mouseX, int mouseY) {
        if (!isOpenForCreation(menu) || graphics == null || font == null) return;
        int hovered = menu.rowAt(mouseX, mouseY);
        int visible = PURSUIT_ROW - menu.scrollRow;
        if (visible < 0 || visible >= 5) return;
        // Same geometry as the stock rows: the menu draws its scrollbar in the
        // rightmost 10 px, so the row stops before it.
        int y = menu.top + 20 + visible * 22;
        int right = menu.left + menu.width - 10;
        graphics.pose().pushPose();
        graphics.pose().translate(0.0, 0.0, 600.0);
        graphics.fill(menu.left + 2, y, right, y + 22,
                hovered == PURSUIT_ROW ? 0xff33485a : 0xff1a2027);
        String text = clip(font, Component.translatable("gui.settledlands.graph.pursuit_menu").getString(),
                right - menu.left - 12);
        graphics.drawString(font, text, menu.left + 8, y + 7, COL_HEADER, false);
        graphics.pose().popPose();
    }

    // ---- card ----

    /**
     * Build 299: the stock card, drawn with the body link taken out of the node.
     *
     * <p>An "Условие" node whose blue input comes from a body node ("В радиусе", "Урон")
     * has {@code varInputNode} pointing at a node with no variable name, and the stock card
     * prints {@code #<id> == <number>} for that case instead of the variable written into
     * the condition - that is what looked like the wire rewriting the condition.</p>
     *
     * <p>The link is removed for exactly one call and put back immediately, in a
     * {@code finally}, so the rest of the frame (cables, hit tests, saving) sees the real
     * graph. Build 298 did this for the whole frame and the screen started repainting
     * wires against a graph that changed under it every frame; this is the same result
     * without touching the graph outside the single draw call.</p>
     */
    private static void drawStockCard(NpcDialogueGraphScreen screen, GuiGraphics graphics, Node node) {
        NpcDialogueGraph graph = screen.settledlands$graph();
        if (node == null || graph == null || node.varInputNode < 0
                || node.type != NpcDialogueGraph.IF) {
            screen.settledlands$drawOriginal(graphics, node);
            return;
        }
        Node source = graph.get(node.varInputNode);
        if (!isValueSourceNode(source)) {
            // A link to a "Переменная" node is a real variable link: the card must show it.
            screen.settledlands$drawOriginal(graphics, node);
            return;
        }
        int saved = node.varInputNode;
        node.varInputNode = -1;
        try {
            screen.settledlands$drawOriginal(graphics, node);
        } finally {
            node.varInputNode = saved;
        }
    }

    public static void drawNode(NpcDialogueGraphScreen screen, GuiGraphics graphics, Node node) {
        if (screen == null || graphics == null || !isPursuitNode(node)) {
            drawStockCard(screen, graphics, node);
            return;
        }

        NpcGraphCanvas canvas = screen.settledlands$canvas();
        Font font = screen.settledlands$font();
        if (canvas == null || font == null) return;

        NpcDialogueGraph graph = screen.settledlands$graph();
        String targetValue = resolvedTarget(graph, node);
        boolean stop = stopFlag(node);
        boolean wired = sourceId(node) >= 0;
        // A target wired in from an "In Radius" node has no text of its own - the card
        // names the node the body comes from instead of showing an empty field.
        String sourceLabel = sourceLabel(graph, node);
        int mid = CARD_HEIGHT / 2;

        graphics.pose().pushPose();
        graphics.pose().translate(canvas.screenX(node.x), canvas.screenY(node.y), 0.0);
        graphics.pose().scale((float) canvas.zoom, (float) canvas.zoom, 1.0f);

        // Same frame, header height and port dots as the stock node.
        graphics.fill(-2, -2, CARD_WIDTH + 2, CARD_HEIGHT + 2,
                screen.settledlands$isSelected(node.id) ? COL_BORDER_SELECTED : COL_BORDER_IDLE);
        graphics.fill(0, 0, CARD_WIDTH, CARD_HEIGHT, COL_BODY);
        graphics.fill(0, 0, CARD_WIDTH, HEADER_H, COL_HEADER);

        graphics.drawString(font, clip(font,
                Component.translatable("gui.settledlands.graph.pursuit_node").getString(), CARD_WIDTH - 16),
                8, 7, COL_TITLE, false);

        // Line 1 - target type.
        String type = Component.translatable(targetTypeLabelKey(node)).getString();
        graphics.drawString(font, clip(font,
                Component.translatable("gui.settledlands.pursuit.target_value").getString() + " " + type,
                CARD_WIDTH - 16), 8, 30, COL_TEXT, false);

        // Line 2 - target value.
        String value = sourceLabel != null ? sourceLabel : targetValue.isEmpty()
                ? Component.translatable("gui.settledlands.pursuit.field_empty").getString()
                : targetValue;
        graphics.drawString(font, clip(font, value, CARD_WIDTH - 16), 8, 42,
                sourceLabel == null && targetValue.isEmpty() ? COL_MUTED : COL_TEXT, false);

        // Line 3 - movement settings the server reads from the action.
        String settings = Component.translatable("gui.settledlands.pursuit.keep_distance").getString() + " "
                + keepDistanceText(node) + "   "
                + Component.translatable("gui.settledlands.pursuit.catch_up").getString() + " "
                + catchUpDistanceText(node) + "   \u00d7" + catchUpBoostText(node);
        graphics.drawString(font, clip(font, settings, CARD_WIDTH - 16), 8, 54, COL_TEXT, false);

        // Line 4 - stop switch state.
        if (stop) {
            graphics.drawString(font, clip(font,
                    Component.translatable("gui.settledlands.pursuit.stop_toggle").getString() + " \u2713",
                    CARD_WIDTH - 16), 8, 66, COL_STOP, false);
        }

        // The value row, the way a blueprint node shows a data pin: the execution
        // ports stay where they were, and under them the target - which is what
        // %pursuit% resolves to. An arrow shows where it comes from: <- when it is
        // wired in from another node, -> when this node owns the text.
        int consumed = consumers(node).size();
        String shown = sourceLabel != null ? sourceLabel : targetValue;
        String output = (wired ? "\u2190 " : "\u2192 ")
                + Component.translatable("gui.settledlands.pursuit.output").getString()
                + ": " + (shown.isEmpty()
                        ? Component.translatable("gui.settledlands.pursuit.field_empty").getString()
                        : shown);
        graphics.drawString(font, clip(font, output, CARD_WIDTH - 42), 8, 78,
                shown.isEmpty() ? COL_MUTED : COL_VALUE, false);

        // Stock port dots: execution input on the left edge, execution output on the right.
        graphics.fill(-5, mid - 5, 5, mid + 5, COL_PORT_WHITE);
        graphics.fill(CARD_WIDTH - 5, mid - 5, CARD_WIDTH + 5, mid + 5, COL_PORT_WHITE);

        // Value pins: blue diamonds, so they cannot be mistaken for the round
        // execution ports. Input on the left edge, output on the right edge, one row.
        int pinY = TARGET_PIN_Y;
        if (consumed > 0) {
            String count = String.valueOf(consumed);
            graphics.drawString(font, count, CARD_WIDTH - 10 - font.width(count) - 4, pinY - 4,
                    COL_VALUE, false);
        }

        graphics.pose().popPose();

        // The pins themselves are drawn in screen space so their radius follows the zoom.
        drawValuePin(graphics, canvas, node, 0.0, pinY);
        drawValuePin(graphics, canvas, node, CARD_WIDTH, pinY);
    }

    /**
     * True when any pursuit node carries a value link or a pin is being dragged, so
     * the renderer can skip setting up a buffer that would draw nothing.
     */
    // ---- blue wires: which two nodes they join, and where their ends are ----

    /**
     * True when a blue value wire runs between these two nodes, in either direction.
     *
     * <p>Only three shapes exist: a pursuit card taking its target from another card or from a
     * blue source pin ("В радиусе", "Урон"), a pursuit card feeding its target to consumers, and a
     * stock "Условие" node reading a blue source. A point on a blue wire is kept under the source
     * end, so this has to know them all - it is also what drops a point whose wire was cut.</p>
     */
    /**
     * True when the blue wire whose source end is {@code from} still ends at {@code toId}.
     *
     * <p>The form the drawing pass needs: it has the node that holds the points and the id on the
     * far end, and nothing else. A point whose value wire was cut is dropped with it.</p>
     */
    public static boolean blueLinked(NpcDialogueGraph graph, Node from, int toId) {
        if (graph == null || from == null || toId < 0 || from.id == toId) return false;
        Node to = graph.get(toId);
        return to != null && blueLinked(from, to);
    }

    public static boolean blueLinked(Node a, Node b) {
        if (a == null || b == null || a == b) return false;
        if (isPursuitNode(a) && sourceId(a) == b.id) return true;
        if (isPursuitNode(b) && sourceId(b) == a.id) return true;
        if (consumers(a).contains(b.id) || consumers(b).contains(a.id)) return true;
        // stockInputSource, not inputSource: while the wire pass runs the link is temporarily out
        // of the node, and a point must not be dropped because of a frame.
        if (isValueInputNode(a) && isValueSourceNode(b) && stockInputSource(a) == b.id) return true;
        return isValueInputNode(b) && isValueSourceNode(a) && stockInputSource(b) == a.id;
    }

    /**
     * The screen ends of the blue wire between these nodes, laid out {@code {fromId, toId, x1, y1,
     * x2, y2}}, or null when no blue wire joins them.
     *
     * <p>Direction is the one the value pass draws in: source pin first, consumer pin second. The
     * point of a blue wire is stored under {@code fromId} with {@code toId} as its far end, and
     * this is the single place that decides which end is which - so the store, the hit test and
     * the drawing can never disagree about it.</p>
     */
    public static double[] blueEnds(NpcGraphCanvas canvas, Node a, Node b) {
        if (canvas == null || a == null || b == null || a == b) return null;
        if (isPursuitNode(b) && sourceId(b) == a.id) {
            if (isPursuitNode(a)) {
                return ends(a, b, targetPinScreenX(canvas, a), targetPinScreenY(canvas, a),
                        targetInPinScreenX(canvas, b), targetPinScreenY(canvas, b));
            }
            if (isValueSourceNode(a)) {
                return ends(a, b, checkPinScreenX(canvas, a), checkPinScreenY(canvas, a),
                        targetInPinScreenX(canvas, b), targetPinScreenY(canvas, b));
            }
            return null;
        }
        if (isPursuitNode(a) && consumers(a).contains(b.id)) {
            return ends(a, b, targetPinScreenX(canvas, a), targetPinScreenY(canvas, a),
                    consumerAnchorX(canvas, b), consumerAnchorY(canvas, b));
        }
        if (isValueInputNode(b) && isValueSourceNode(a) && stockInputSource(b) == a.id) {
            return ends(a, b, checkPinScreenX(canvas, a), checkPinScreenY(canvas, a),
                    inputPinScreenX(canvas, b), inputPinScreenY(canvas, b));
        }
        return null;
    }

    private static double[] ends(Node from, Node to, double x1, double y1, double x2, double y2) {
        if (!Double.isFinite(x1) || !Double.isFinite(y1) || !Double.isFinite(x2)
                || !Double.isFinite(y2)) {
            return null;
        }
        return new double[] {from.id, to.id, x1, y1, x2, y2};
    }

    public static boolean hasValueWires(NpcDialogueGraph graph, int dragOut, int dragIn) {
        if (graph == null || graph.nodes == null) return false;
        if (dragOut >= 0 || dragIn >= 0) return true;
        for (NpcDialogueGraph.Node node : graph.nodes.values()) {
            // Hidden-aware: the cable pass runs with the body links taken out of the nodes,
            // so a plain inputSource() here would report "no wires" and nothing would be
            // drawn at all - the blue cable would vanish for the whole pass.
            if (isValueInputNode(node) && stockInputSource(node) >= 0
                    && isValueSourceNode(graph.get(stockInputSource(node)))) {
                return true;
            }
            if (!isPursuitNode(node)) continue;
            String action = node.action;
            if (action == null) continue;
            if (action.indexOf(CONSUMER_MARK) < 0 && action.indexOf(SOURCE_MARK) < 0) continue;
            if (!consumers(node).isEmpty() || sourceId(node) >= 0) return true;
        }
        return false;
    }

    /**
     * Where a value wire ends on {@code node}: a pursuit node is entered through its
     * value input, any other node through its ordinary input port.
     */
    public static double consumerAnchorX(NpcGraphCanvas canvas, Node consumer) {
        return consumer != null && isPursuitNode(consumer)
                ? targetInPinScreenX(canvas, consumer)
                : canvas.portScreenX(consumer, false);
    }

    // ---------------------------------------------------------------------
    // Build 289: the blue output of an "In Radius" node.
    //
    // The check node already looks for a body in its radius; that body is the value
    // this pin carries. It is drawn on the same row as the pursuit node's pins and on
    // the right edge, so a wire from it lands on a pursuit node's blue input exactly
    // like a wire between two pursuit nodes.
    // ---------------------------------------------------------------------

    /** True for the "In Radius" node - the one whose radius scan finds a body. */
    public static boolean isCheckValueNode(Node node) {
        return node != null && node.type == NpcDialogueGraph.CHECK;
    }

    /** True for the "Урон" node - the one that hands out whoever hit the NPC. */
    public static boolean isDamageValueNode(Node node) {
        return node != null && node.type == NpcDialogueGraph.DAMAGE;
    }

    /** True for a node with a blue output: it hands out a body. */
    public static boolean isValueSourceNode(Node node) {
        return isCheckValueNode(node) || isDamageValueNode(node) || isDoorValueNode(node)
                || isChestValueNode(node);
    }

    /**
     * Build 398: the blue socket of a chest's card is a value source like the door's - the author's report
     * «сейчас нельзя вытаскивать из синего узла провод» is about exactly this pin, and the cause was one
     * missing term in this predicate: every half of the blue pin (the hit test that starts the drag, the drop,
     * the cut, the stored link and the pass that draws it) is keyed on {@code isValueSourceNode}, so a pin
     * this predicate does not know is painted and unreachable.
     */
    public static boolean isChestValueNode(Node node) {
        return ChestGraph396.isChestNode(node);
    }

    /**
     * Build 392: the door card has a blue output too - the socket the author asked for («синий узел цели»
     * as a socket of the card, not a node beside it). What it hands out is the player who hacked the door,
     * which is exactly the body {@code %target%} resolves to in a «Реплика» wired to it.
     *
     * <p>Everything the blue pin does is already keyed on this one predicate - the diamond, its hit test,
     * dragging a wire out of it, cutting that wire, and the blue pass that draws it - so the door needs no
     * code of its own here: it is a value source like «В радиусе» and «Урон».</p>
     */
    public static boolean isDoorValueNode(Node node) {
        return DoorGraph382.isDoorNode(node);
    }

    /**
     * True for a stock node that takes a body: реплика, триггер, условие, переменная.
     * A pursuit node is a trigger node on disk, so it is excluded here - it has its own
     * blue input further up the card.
     */
    public static boolean isValueInputNode(Node node) {
        if (node == null || isPursuitNode(node)) return false;
        return node.type == NpcDialogueGraph.LINE
                || node.type == NpcDialogueGraph.TRIGGER
                || node.type == NpcDialogueGraph.IF
                || node.type == NpcDialogueGraph.VARIABLE;
    }

    public static double checkPinScreenX(NpcGraphCanvas canvas, Node node) {
        return canvas.portScreenX(node, true);
    }

    public static double checkPinScreenY(NpcGraphCanvas canvas, Node node) {
        return canvas.screenY(node.y) + TARGET_PIN_Y * canvas.zoom;
    }

    /**
     * The pin is drawn at a fixed screen size, so it stays as easy to grab when the
     * graph is zoomed out; the hit radius matches what is drawn.
     */
    public static boolean hitCheckPin(NpcGraphCanvas canvas, Node node, double mouseX, double mouseY) {
        if (canvas == null || node == null || !isValueSourceNode(node)) return false;
        double dx = mouseX - checkPinScreenX(canvas, node);
        double dy = mouseY - checkPinScreenY(canvas, node);
        double hit = pinHitRadius(canvas);
        return dx * dx + dy * dy <= hit * hit;
    }

    /**
     * Draws the blue diamond on the right edge of a check node, plus the number of nodes
     * already wired to it - the same feedback the pursuit card gives.
     */
    public static void drawCheckPin(NpcDialogueGraphScreen screen, GuiGraphics graphics, Node node) {
        if (screen == null || graphics == null || node == null || !isValueSourceNode(node)) return;
        NpcGraphCanvas canvas = screen.settledlands$canvas();
        Font font = screen.settledlands$font();
        if (canvas == null || font == null) return;
        double x = Math.round(checkPinScreenX(canvas, node));
        double y = Math.round(checkPinScreenY(canvas, node));
        // Build 302: the pin is drawn where the wire actually starts - the check card is not
        // as wide as a pursuit card, so the pursuit card's coordinates put it in the wrong
        // place. The radius still follows the zoom, like the stock ports.
        drawPin(graphics, x, y, PIN_RADIUS * canvas.zoom, COL_VALUE);
        int wired = wiredTo(screen.settledlands$graph(), node.id);
        if (wired > 0) {
            String count = String.valueOf(wired);
            graphics.drawString(font, count, (int) x - 8 - font.width(count), (int) y - 4,
                    COL_VALUE, false);
        }
    }

    /** How many nodes read this source node's blue output. */
    public static int wiredTo(NpcDialogueGraph graph, int nodeId) {
        if (graph == null || graph.nodes == null) return 0;
        int count = 0;
        for (Node node : graph.nodes.values()) {
            if (isPursuitNode(node) && sourceId(node) == nodeId) count++;
            else if (isValueInputNode(node) && stockInputSource(node) == nodeId) count++;
        }
        return count;
    }

    /** Drops every wire that reads this source node's blue output. */
    public static void unplugFrom(NpcDialogueGraph graph, int nodeId) {
        if (graph == null || graph.nodes == null) return;
        for (Node node : graph.nodes.values()) {
            if (isPursuitNode(node) && sourceId(node) == nodeId) setSource(node, -1);
            else if (isValueInputNode(node) && inputSource(node) == nodeId) setInputSource(node, -1);
        }
    }

    // ---------------------------------------------------------------------
    // Build 290: the blue input of the stock nodes that take a body.
    // ---------------------------------------------------------------------

    /** Node this consumer reads, or -1. Stored in the field the graph NBT already has. */
    public static int inputSource(Node node) {
        return node == null ? -1 : node.varInputNode;
    }

    public static void setInputSource(Node node, int source) {
        if (node == null) return;
        // A node may not read itself; -1 clears the input.
        node.varInputNode = source == node.id ? -1 : source;
    }

    /** Screen X of the blue input: the left edge of the card. */
    public static double inputPinScreenX(NpcGraphCanvas canvas, Node node) {
        return canvas.portScreenX(node, false);
    }

    /** Screen Y of the blue input: the same row as every other value pin. */
    public static double inputPinScreenY(NpcGraphCanvas canvas, Node node) {
        return canvas.screenY(node.y) + TARGET_PIN_Y * canvas.zoom;
    }

    public static boolean hitInputPin(NpcGraphCanvas canvas, Node node, double mouseX, double mouseY) {
        if (canvas == null || node == null || !isValueInputNode(node)) return false;
        if (!Double.isFinite(inputPinScreenX(canvas, node))) return false;
        double dx = mouseX - inputPinScreenX(canvas, node);
        double dy = mouseY - inputPinScreenY(canvas, node);
        double hit = pinHitRadius(canvas);
        return dx * dx + dy * dy <= hit * hit;
    }

    /**
     * Wires hidden for the whole render pass, as {nodeId, sourceId}.
     *
     * <p>Build 298: an "Условие" node whose blue input comes from a body node ("В радиусе",
     * "Урон") must keep its own condition on its card. The stock card does the opposite: with
     * {@code varInputNode} pointing at a node that has no variable name, it prints
     * {@code #<id> == <number>} instead of the variable written into the condition, and the
     * player sees the condition "change" the moment the wire is connected. The condition
     * itself never changed - the stock server reads the node's own variable, because the
     * source is not a variable node - so this is purely the card.</p>
     *
     * <p>The link is therefore taken out of {@code varInputNode} for the whole render and put
     * back right after: the card draws its own variable, the stock cable pass draws no cable
     * into the input field, and the blue pass draws its own from the source pin. What is
     * stored in the graph is never touched - the link is back before the frame is over.</p>
     */
    private static final List<int[]> HIDDEN_WIRES = new ArrayList<>();

    /** How many passes currently want the links hidden. Nested callers are counted, so an
     *  inner pass can never restore the links while an outer one still draws. */
    private static int HIDE_DEPTH;

    /**
     * Starts the cable pass: clears anything a previous pass failed to put back (a thrown
     * frame must not leave the links hidden), then hides for this pass.
     */
    /**
     * Puts back anything a previous frame failed to restore. Never hides, so calling it at
     * the start of a frame cannot make anything flicker: it only repairs.
     */
    public static void resetStockInputHide(NpcDialogueGraph graph) {
        while (HIDE_DEPTH > 0) restoreStockInputWires(graph);
    }

    public static void beginWiresPass(NpcDialogueGraph graph) {
        while (HIDE_DEPTH > 0) restoreStockInputWires(graph);
        hideStockInputWires(graph);
    }

    /** Takes the links out of {@code varInputNode}. Counted, so nesting is safe. */
    public static void hideStockInputWires(NpcDialogueGraph graph) {
        HIDE_DEPTH++;
        if (HIDE_DEPTH != 1 || !HIDDEN_WIRES.isEmpty()) return;
        if (graph == null || graph.nodes == null) return;
        for (Node node : graph.nodes.values()) {
            if (node == null || node.type != NpcDialogueGraph.IF) continue;
            int source = inputSource(node);
            Node from = source < 0 ? null : graph.get(source);
            if (from == null || !isValueSourceNode(from)) continue;
            HIDDEN_WIRES.add(new int[] {node.id, source});
            node.varInputNode = -1;
        }
    }

    /** The input source of a stock node while its link is hidden, or -1. */
    public static int hiddenInputSource(Node node) {
        if (node == null || HIDDEN_WIRES.isEmpty()) return -1;
        for (int[] entry : HIDDEN_WIRES) {
            if (entry[0] == node.id) return entry[1];
        }
        return -1;
    }

    /** Input source of a stock node, hidden or not - what the blue pass must draw. */
    public static int stockInputSource(Node node) {
        int hidden = hiddenInputSource(node);
        return hidden >= 0 ? hidden : inputSource(node);
    }

    /** True while the render pass has the links hidden. */
    public static boolean stockInputHidden() {
        return !HIDDEN_WIRES.isEmpty();
    }

    public static void restoreStockInputWires(NpcDialogueGraph graph) {
        if (HIDE_DEPTH == 0) return;
        if (--HIDE_DEPTH > 0) return;
        if (HIDDEN_WIRES.isEmpty()) return;
        if (graph != null && graph.nodes != null) {
            for (int[] entry : HIDDEN_WIRES) {
                Node node = graph.nodes.get(entry[0]);
                if (node != null) node.varInputNode = entry[1];
            }
        }
        HIDDEN_WIRES.clear();
    }

    /**
     * Draws the blue pins a stock node gained in Build 290: the output of an "Урон" node
     * (the "В радиусе" one is drawn by the same call) and the input of a node that takes
     * a body. Fixed screen size, so they stay easy to grab at any zoom.
     */
    /**
     * Radius of a blue value pin in card units, so it scales with the zoom exactly like the
     * stock ports do. Build 301: 300 drew the pins at a fixed screen size, which made them
     * look oversized when zoomed out and tiny when zoomed in; they are now part of the card
     * geometry, and small - half the size of a stock port square.
     */
    public static final double PIN_RADIUS = 2.0D;

    /** A filled circle in screen pixels. Round on purpose: a pin is a dot, not a cross. */
    public static void drawPin(GuiGraphics graphics, double cx, double cy, double radius, int color) {
        if (graphics == null || radius <= 0.0) return;
        int r = (int) Math.max(1.0, Math.round(radius));
        int x = (int) Math.round(cx);
        int y = (int) Math.round(cy);
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.sqrt((double) (r * r - dy * dy));
            graphics.fill(x - half, y + dy, x + half + 1, y + dy + 1, color);
        }
    }

    /**
     * A blue value pin at card coordinates {@code (xCard, yCard)} of {@code node}: the screen
     * position comes from the canvas, the radius from the zoom - the same rule the stock
     * ports follow, so a pin grows and shrinks with the card it sits on.
     */
    public static void drawValuePin(GuiGraphics graphics, NpcGraphCanvas canvas, Node node,
            double xCard, double yCard) {
        if (graphics == null || canvas == null || node == null) return;
        drawPin(graphics, canvas.screenX(node.x + xCard), canvas.screenY(node.y + yCard),
                PIN_RADIUS * canvas.zoom, COL_VALUE);
    }

    public static void drawValuePins(NpcDialogueGraphScreen screen, GuiGraphics graphics, Node node) {
        if (screen == null || graphics == null || node == null) return;
        if (isValueSourceNode(node)) {
            drawCheckPin(screen, graphics, node);
        }
        if (isValueInputNode(node)) {
            NpcGraphCanvas canvas = screen.settledlands$canvas();
            if (canvas == null) return;
            drawValuePin(graphics, canvas, node, 0.0, TARGET_PIN_Y);
        }
    }

    /**
     * Label for a pursuit node whose target is wired in from another node, or null when
     * it owns its text. The check node has no text to copy, so the card names the node
     * the body comes from instead of showing an empty field.
     */
    public static String sourceLabel(NpcDialogueGraph graph, Node node) {
        if (graph == null || node == null) return null;
        int source = sourceId(node);
        if (source < 0) return null;
        Node from = graph.get(source);
        if (isCheckValueNode(from)) {
            return Component.translatable("gui.settledlands.graph.check").getString() + " #" + from.id;
        }
        if (isDamageValueNode(from)) {
            return Component.translatable("gui.settledlands.graph.damage").getString() + " #" + from.id;
        }
        return null;
    }

    public static double consumerAnchorY(NpcGraphCanvas canvas, Node consumer) {
        return consumer != null && isPursuitNode(consumer)
                ? targetPinScreenY(canvas, consumer)
                : canvas.portScreenY(consumer, false, 0);
    }

    /**
     * Distance test for one drawn value wire, used by the middle click that cuts it.
     *
     * <p>The sample is the same cubic {@code NpcDialogueGraphScreen#curve} builds for the
     * wire - horizontal tangents, the reach taken from the horizontal span - and the
     * tolerance is the one {@code NpcGraphCanvas#hitCable} gives its own cables, so a
     * value wire is as easy to grab as an execution cable and the cut removes exactly the
     * wire the cursor is on.</p>
     */
    public static boolean hitValueWire(NpcGraphCanvas canvas, double x1, double y1, double x2,
            double y2, double mouseX, double mouseY) {
        if (canvas == null) return false;
        double reach = Math.max(25.0D * canvas.zoom, Math.abs(x2 - x1) * 0.45D);
        double tolerance = Math.max(1.8D, Math.min(5.5D, 4.0D * canvas.zoom + 1.2D));
        double best = tolerance * tolerance;
        for (int step = 1; step <= 20; step++) {
            double t = step / 20.0D;
            double left = 1.0D - t;
            double x = left * left * left * x1
                    + 3.0D * left * left * t * (x1 + reach)
                    + 3.0D * left * t * t * (x2 - reach)
                    + t * t * t * x2;
            double y = left * left * left * y1
                    + 3.0D * left * left * t * y1
                    + 3.0D * left * t * t * y2
                    + t * t * t * y2;
            double dx = x - mouseX;
            double dy = y - mouseY;
            if (dx * dx + dy * dy <= best) return true;
        }
        return false;
    }

    /**
     * Culling and hit test for the pursuit card. They are called through the canvas
     * mixin ({@code NpcPursuitCanvasMixin272}), which is compiled once and kept in the
     * jar, so their signatures must stay exactly as they were: Build 286 dropped them
     * with the old drawing code and the dialogue screen died with NoSuchMethodError.
     */
    public static boolean visible(NpcGraphCanvas c, Node n) {
        if (!isPursuitNode(n)) return true;
        double x = c.screenX(n.x), y = c.screenY(n.y);
        return x + CARD_WIDTH * c.zoom >= c.left && x <= c.right && y + CARD_HEIGHT * c.zoom >= c.top && y <= c.bottom;
    }

    public static int hit(NpcGraphCanvas c, NpcDialogueGraph graph, double sx, double sy) {
        if (!c.contains(sx, sy)) return -1;
        double x = c.worldX(sx), y = c.worldY(sy);
        int found = -1;
        for (Node n : graph.nodes.values()) {
            if (isPursuitNode(n)) {
                if (n.x <= x && x <= n.x + CARD_WIDTH && n.y <= y && y <= n.y + CARD_HEIGHT) found = n.id;
            }
        }
        return found;
    }

    private static String clip(Font font, String text, int width) {
        if (font == null || text == null) return "";
        String out = text;
        while (!out.isEmpty() && font.width(out) > width) out = out.substring(0, out.length() - 1);
        return out;
    }
}
