package dev.settledlands.npc;

import dev.settledlands.npc.NpcDialogueGraph.Node;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.function.BiPredicate;

/**
 * Build 325: a point is a hub on the canvas, and a wire may run through a run of them.
 *
 * <p>A wire either carries a connection or it waits. A point sits on a wire either way, and a wire
 * may pass through any number of points in a row - node, point, point, node - so the canvas can be
 * tidied without adding nodes to the dialogue.</p>
 *
 * <ul>
 *   <li><b>carrying wires</b> - wires that pass through points. The stock connection is untouched;
 *       the cable is drawn through the points instead of going straight, and a point never changes
 *       where the wire goes.</li>
 *   <li><b>waiting wires</b> - wires whose end was dropped on a point. They carry no connection at
 *       all: the wire stops at the point, exactly as the author dropped it. Nothing is connected
 *       behind their back. Points may be added along a waiting wire as well, in any number.</li>
 * </ul>
 *
 * <p>The continuation is a separate, deliberate step: a wire is pulled out of a point's port and
 * dropped on a node, and every wire at that point - carrying and waiting - goes there. Until then a
 * waiting wire waits, which is the whole point of a hub: the author decides the destination, not the
 * node the point was made on.</p>
 *
 * <p>Where the points live. A graph node has no spare field, so the records of every wire that
 * leaves a node are kept as text in one string field of that node, and the field is picked so that
 * the node's own type never reads it: {@code animBone} for every type except an animation node,
 * {@code mobilityGroupId} for an animation node. Both are saved with the graph, so the points
 * travel with it, through Ctrl+C/Ctrl+V, undo and a world reload. Nothing outside this class ever
 * reads those fields as points.</p>
 *
 * <p>The text. {@code SLP2} then one entry per wire. A carrying wire is
 * {@code p<port>t<target>:x,y x,y ...} - the points of that one wire, in the order the cable visits
 * them. A waiting wire is {@code h<port>@x,y x,y ...} - the same run of points, ending at the point
 * the wire stops at. Build 321/322 wrote {@code SLP1} with carrying wires only, and Build 323/324
 * wrote waiting wires with a single point; both are still read, so an older graph keeps its points.
 * A field value without a marker is not ours: it is never overwritten and never parsed.</p>
 */
public final class NpcWirePoints321 {

    /** First token of the text this build writes. */
    public static final String MARK = "SLP2";

    /**
     * The port a {@link Bend} carries when the point sits on a blue value wire instead of a stock
     * connection. A value wire has no port number of its own, so the port is the marker.
     */
    public static final int VALUE_PORT = -1;

    /** First token of the text Build 321/322 wrote - still read. */
    public static final String MARK_OLD = "SLP1";

    /** Points are placed on the same eight-unit grid the canvas snaps nodes to. */
    public static final int GRID = 8;

    /** Parsed text of a node, kept until the field changes under it. */
    private static final Map<Node, Object[]> CACHE = new WeakHashMap<>();

    private NpcWirePoints321() {
    }

    /** A wire passing through points. */
    public static final class Bend {
        public final Node from;
        public final int fromPort;
        public final int toId;
        public final int x;
        public final int y;

        Bend(Node from, int fromPort, int toId, int x, int y) {
            this.from = from;
            this.fromPort = fromPort;
            this.toId = toId;
            this.x = x;
            this.y = y;
        }
    }

    /** Marker port/channel constants for colored non-stock wires. Build 453. */
    public static final char KIND_VALUE = 'v';
    public static final char KIND_ORANGE = 'o';
    public static final char KIND_AMBER = 'a';
    public static final char KIND_TRIAL_START = 'g';
    public static final char KIND_TRIAL_MOD = 'm';

    @FunctionalInterface
    public interface CustomWireCheck {
        boolean isAlive(Node from, char kind, int toId);
    }

    /** A colored wire passing through points (orange var, amber event, trial start, module). Build 453. */
    public static final class ColorBend {
        public final Node from;
        public final char kind;
        public final int toId;
        public final int x;
        public final int y;

        ColorBend(Node from, char kind, int toId, int x, int y) {
            this.from = from;
            this.kind = kind;
            this.toId = toId;
            this.x = x;
            this.y = y;
        }
    }

    /** A colored wire that stops at a point waiting for a target. Build 453. */
    public static final class ColorHang {
        public final Node from;
        public final char kind;
        public final int arg;
        public final List<int[]> route;

        ColorHang(Node from, char kind, int arg, List<int[]> route) {
            this.from = from;
            this.kind = kind;
            this.arg = arg;
            this.route = route;
        }

        public int endX() {
            return route.isEmpty() ? 0 : route.get(route.size() - 1)[0];
        }

        public int endY() {
            return route.isEmpty() ? 0 : route.get(route.size() - 1)[1];
        }
    }

    /**
     * A wire that stops at a point: the points it visits, in order, the last one being where it
     * stops.
     */
    public static final class Hang {
        public final Node from;
        public final int fromPort;
        public final List<int[]> route;

        Hang(Node from, int fromPort, List<int[]> route) {
            this.from = from;
            this.fromPort = fromPort;
            this.route = route;
        }

        /** Where the wire stops. */
        public int endX() {
            return route.isEmpty() ? 0 : route.get(route.size() - 1)[0];
        }

        public int endY() {
            return route.isEmpty() ? 0 : route.get(route.size() - 1)[1];
        }
    }

    /**
     * What one node's text holds. Bends are keyed {@code port:target}; a waiting wire is a raw
     * array {@code {port, x1, y1, x2, y2, ...}} of the points it visits, in order.
     */
    private static final class Data {
        final Map<String, List<int[]>> bends = new LinkedHashMap<>();
        /** Points of a blue value wire, keyed by the node on its far end. Build 332. */
        final Map<Integer, List<int[]>> value = new LinkedHashMap<>();
        /** Points of colored wires keyed by {@code kind + ":" + toId}. Build 453. */
        final Map<String, List<int[]>> custom = new LinkedHashMap<>();
        final List<int[]> hangs = new ArrayList<>();
        /** Colored waiting wires stored as {@code {kindCode, arg, x1, y1, ...}}. Build 453. */
        final List<int[]> colorHangs = new ArrayList<>();

        boolean empty() {
            return bends.isEmpty() && value.isEmpty() && custom.isEmpty()
                    && hangs.isEmpty() && colorHangs.isEmpty();
        }
    }

    // -- storage ------------------------------------------------------------

    /** The field a node keeps its wire records in. See the class comment. */
    private static String field(Node node) {
        return node.type == NpcDialogueGraph.ANIMATION ? node.mobilityGroupId : node.animBone;
    }

    private static void field(Node node, String value) {
        if (node.type == NpcDialogueGraph.ANIMATION) {
            node.mobilityGroupId = value;
        } else {
            node.animBone = value;
        }
        CACHE.remove(node);
    }

    private static boolean ours(String raw) {
        return raw != null
                && (raw.equals(MARK) || raw.equals(MARK_OLD)
                        || raw.startsWith(MARK + "|") || raw.startsWith(MARK_OLD + "|"));
    }

    private static String key(int fromPort, int toId) {
        return fromPort + ":" + toId;
    }

    private static int keyPort(String key) {
        int colon = key.indexOf(':');
        return colon < 0 ? 0 : number(key.substring(0, colon), 0);
    }

    private static int keyTarget(String key) {
        int colon = key.indexOf(':');
        return colon < 0 ? -1 : number(key.substring(colon + 1), -1);
    }

    private static Data read(Node node) {
        String raw = field(node);
        Object[] cached = CACHE.get(node);
        if (cached != null && Objects.equals(raw, cached[0])) {
            return (Data) cached[1];
        }
        Data data = new Data();
        String body = null;
        if (raw != null && raw.startsWith(MARK + "|")) {
            body = raw.substring(MARK.length() + 1);
        } else if (raw != null && raw.startsWith(MARK_OLD + "|")) {
            body = raw.substring(MARK_OLD.length() + 1);
        }
        if (body != null) {
            for (String entry : body.split("\\|")) {
                if (entry.isEmpty()) continue;
                if (entry.startsWith("h")) {
                    int at = entry.indexOf('@');
                    if (at < 0) continue;
                    int port = number(entry.substring(1, at), 0);
                    List<int[]> route = new ArrayList<>();
                    for (String pair : entry.substring(at + 1).trim().split(" ")) {
                        int comma = pair.indexOf(',');
                        if (comma < 0) continue;
                        route.add(new int[] { number(pair.substring(0, comma), 0),
                                number(pair.substring(comma + 1), 0) });
                    }
                    if (route.isEmpty()) continue;
                    int[] flat = new int[1 + route.size() * 2];
                    flat[0] = port;
                    for (int i = 0; i < route.size(); i++) {
                        flat[1 + i * 2] = route.get(i)[0];
                        flat[2 + i * 2] = route.get(i)[1];
                    }
                    data.hangs.add(flat);
                    continue;
                }
                if (entry.startsWith("k") && entry.length() >= 4) {
                    int at = entry.indexOf('@');
                    if (at > 2) {
                        char kind = entry.charAt(1);
                        int arg = number(entry.substring(2, at), 0);
                        List<int[]> route = new ArrayList<>();
                        for (String pair : entry.substring(at + 1).trim().split(" ")) {
                            int comma = pair.indexOf(',');
                            if (comma < 0) continue;
                            route.add(new int[] { number(pair.substring(0, comma), 0),
                                    number(pair.substring(comma + 1), 0) });
                        }
                        if (!route.isEmpty()) {
                            int[] flat = new int[2 + route.size() * 2];
                            flat[0] = (int) kind;
                            flat[1] = arg;
                            for (int i = 0; i < route.size(); i++) {
                                flat[2 + i * 2] = route.get(i)[0];
                                flat[3 + i * 2] = route.get(i)[1];
                            }
                            data.colorHangs.add(flat);
                        }
                    }
                    continue;
                }
                int colon = entry.indexOf(':');
                if (colon < 0) continue;
                String head = entry.substring(0, colon);
                if (head.startsWith("c") && head.length() >= 3) {
                    char kind = head.charAt(1);
                    int to = number(head.substring(2), -1);
                    List<int[]> points = new ArrayList<>();
                    for (String pair : entry.substring(colon + 1).trim().split(" ")) {
                        int comma = pair.indexOf(',');
                        if (comma < 0) continue;
                        points.add(new int[] { number(pair.substring(0, comma), 0),
                                number(pair.substring(comma + 1), 0) });
                    }
                    if (to >= 0 && !points.isEmpty()) {
                        data.custom.put(customKey(kind, to), points);
                    }
                    continue;
                }
                if (head.startsWith("v")) {
                    // A blue value wire: the node on the far end after the marker.
                    int to = number(head.substring(1), -1);
                    List<int[]> points = new ArrayList<>();
                    for (String pair : entry.substring(colon + 1).trim().split(" ")) {
                        int comma = pair.indexOf(',');
                        if (comma < 0) continue;
                        points.add(new int[] { number(pair.substring(0, comma), 0),
                                number(pair.substring(comma + 1), 0) });
                    }
                    if (to >= 0 && !points.isEmpty()) data.value.put(to, points);
                    continue;
                }
                if (!head.startsWith("p") || head.indexOf('t') < 0) continue;
                int t = head.indexOf('t');
                int port = number(head.substring(1, t), 0);
                int to = number(head.substring(t + 1), -1);
                if (to < 0) continue;
                List<int[]> points = new ArrayList<>();
                for (String pair : entry.substring(colon + 1).trim().split(" ")) {
                    int comma = pair.indexOf(',');
                    if (comma < 0) continue;
                    points.add(new int[] { number(pair.substring(0, comma), 0),
                            number(pair.substring(comma + 1), 0) });
                }
                if (!points.isEmpty()) data.bends.put(key(port, to), points);
            }
        }
        CACHE.put(node, new Object[] { raw, data });
        return data;
    }

    private static String format(Data data) {
        if (data.empty()) return "";
        StringBuilder out = new StringBuilder(MARK);
        for (Map.Entry<String, List<int[]>> entry : data.bends.entrySet()) {
            if (entry.getValue().isEmpty()) continue;
            int to = keyTarget(entry.getKey());
            if (to < 0) continue;
            out.append('|').append('p').append(keyPort(entry.getKey())).append('t').append(to)
                    .append(':');
            boolean first = true;
            for (int[] point : entry.getValue()) {
                if (!first) out.append(' ');
                out.append(point[0]).append(',').append(point[1]);
                first = false;
            }
        }
        for (Map.Entry<Integer, List<int[]>> entry : data.value.entrySet()) {
            if (entry.getValue().isEmpty()) continue;
            out.append('|').append('v').append(entry.getKey()).append(':');
            boolean first = true;
            for (int[] point : entry.getValue()) {
                if (!first) out.append(' ');
                out.append(point[0]).append(',').append(point[1]);
                first = false;
            }
        }
        for (Map.Entry<String, List<int[]>> entry : data.custom.entrySet()) {
            if (entry.getValue().isEmpty()) continue;
            String k = entry.getKey();
            int colon = k.indexOf(':');
            if (colon != 1) continue;
            out.append('|').append('c').append(k.charAt(0)).append(k.substring(2)).append(':');
            boolean first = true;
            for (int[] point : entry.getValue()) {
                if (!first) out.append(' ');
                out.append(point[0]).append(',').append(point[1]);
                first = false;
            }
        }
        for (int[] hang : data.hangs) {
            out.append('|').append('h').append(hang[0]).append('@');
            for (int i = 1; i + 1 < hang.length; i += 2) {
                if (i > 1) out.append(' ');
                out.append(hang[i]).append(',').append(hang[i + 1]);
            }
        }
        for (int[] hang : data.colorHangs) {
            out.append('|').append('k').append((char) hang[0]).append(hang[1]).append('@');
            for (int i = 2; i + 1 < hang.length; i += 2) {
                if (i > 2) out.append(' ');
                out.append(hang[i]).append(',').append(hang[i + 1]);
            }
        }
        return out.toString();
    }

    private static String customKey(char kind, int toId) {
        return kind + ":" + toId;
    }

    private static char customKind(String k) {
        return k.isEmpty() ? '?' : k.charAt(0);
    }

    private static int customTarget(String k) {
        int c = k.indexOf(':');
        return c < 0 ? -1 : number(k.substring(c + 1), -1);
    }

    private static void write(Node node, Data data) {
        scannedGraph = null;                 // the graph's contents just changed
        String next = format(data);
        String current = field(node);
        if (next.isEmpty()) {
            if (ours(current)) field(node, "");
            CACHE.put(node, new Object[] { field(node), data });
            return;
        }
        if (current != null && !current.isEmpty() && !ours(current)) {
            // Somebody else's text is in the field. Do not destroy it: the records stay for this
            // session and are simply not saved.
            CACHE.put(node, new Object[] { current, data });
            return;
        }
        field(node, next);
        CACHE.put(node, new Object[] { next, data });
    }

    private static int number(String raw, int fallback) {
        try {
            return Integer.parseInt(raw.trim());
        } catch (NumberFormatException invalid) {
            return fallback;
        }
    }

    // -- links --------------------------------------------------------------

    /**
     * True when the node still has a link to {@code toId} on {@code fromPort}.
     *
     * <p>This is what makes a carrying wire real: a bend whose wire was rewired or cut belongs to no
     * cable any more, and is dropped by {@link #points} instead of hanging around invisibly.</p>
     */
    public static boolean linkExists(Node node, int fromPort, int toId) {
        if (node == null || toId < 0) return false;
        if (fromPort == 1) return node.falseNext == toId;
        return node.next == toId || node.varInputNode == toId
                || node.choices.contains(toId) || node.triggers.contains(toId)
                || node.randomBranches.contains(toId);
    }

    /**
     * True when the screen really draws a cable for this exact record.
     *
     * <p>The screen does not draw "a link"; it walks the node's fields with fixed port numbers:
     * {@code next}, {@code choices} and {@code triggers} with port 0, the false branch of a
     * condition with port 1, and the branches of a random node with the index of the branch. A
     * record keyed with a port the screen never uses is stored, drawn as a point, and then no cable
     * ever passes through it - a dot floating on an empty canvas. That is why the key has to be
     * checked against the drawing, not just against the link.</p>
     */
    public static boolean drawn(Node node, int fromPort, int toId) {
        if (node == null || toId < 0) return false;
        // A random node uses the port numbers for its branches, so its port 1 is branch 1, not the
        // false branch of a condition.
        if (node.type == NpcDialogueGraph.RANDOM) {
            if (fromPort < node.randomBranches.size()
                    && node.randomBranches.get(fromPort) == toId) {
                return true;
            }
            // The screen also draws `next` at port 0, on every node type, so that key is drawn too.
            return fromPort == 0 && node.next == toId;
        }
        if (fromPort == 1) return node.falseNext == toId;
        return node.next == toId || node.choices.contains(toId) || node.triggers.contains(toId);
    }

    /** Points of the blue value wire from this node to {@code toId}, in order. Drawing path. */
    public static List<int[]> valueBends(Node from, int toId) {
        if (from == null) return List.of();
        return read(from).value.getOrDefault(toId, List.of());
    }

    /** Puts a point on a blue value wire, at {@code index} of its run. */
    public static void addValuePoint(Node from, int toId, int x, int y, int index) {
        if (from == null || toId < 0) return;
        Data data = read(from);
        List<int[]> points = data.value.computeIfAbsent(toId, k -> new ArrayList<>());
        for (int[] point : points) {
            if (Math.abs(point[0] - x) <= GRID && Math.abs(point[1] - y) <= GRID) return;
        }
        int at = Math.max(0, Math.min(index, points.size()));
        points.add(at, new int[] {x, y});
        write(from, data);
    }

    /** Drops bend points stored on a cut blue value wire. Build 453. */
    public static void clearValueWire(Node from, int toId) {
        if (from == null || toId < 0) return;
        Data data = read(from);
        if (data.value.remove(toId) != null) {
            write(from, data);
        }
    }

    /** Points of a colored wire (orange, amber, green trial start, module), in order. Build 453. */
    public static List<int[]> customBends(Node from, char kind, int toId) {
        if (from == null) return List.of();
        if (kind == KIND_VALUE) return valueBends(from, toId);
        return read(from).custom.getOrDefault(customKey(kind, toId), List.of());
    }

    /** Adds a bend point on a colored wire at {@code index}. Build 453. */
    public static void addCustomPoint(Node from, char kind, int toId, int x, int y, int index) {
        if (from == null || toId < 0) return;
        if (kind == KIND_VALUE) {
            addValuePoint(from, toId, x, y, index);
            return;
        }
        Data data = read(from);
        List<int[]> points = data.custom.computeIfAbsent(customKey(kind, toId), k -> new ArrayList<>());
        for (int[] point : points) {
            if (Math.abs(point[0] - x) <= GRID && Math.abs(point[1] - y) <= GRID) return;
        }
        points.add(Math.max(0, Math.min(index, points.size())), new int[] {x, y});
        write(from, data);
    }

    /** Drops bend points of a cut colored wire. Build 453. */
    public static void clearCustomWire(Node from, char kind, int toId) {
        if (from == null || toId < 0) return;
        if (kind == KIND_VALUE) {
            clearValueWire(from, toId);
            return;
        }
        Data data = read(from);
        if (data.custom.remove(customKey(kind, toId)) != null) {
            write(from, data);
        }
    }

    /** Colored waiting wires leaving {@code from}. Build 453. */
    public static List<ColorHang> colorHangs(Node from) {
        if (from == null) return List.of();
        Data data = read(from);
        if (data.colorHangs.isEmpty()) return List.of();
        List<ColorHang> out = new ArrayList<>(data.colorHangs.size());
        for (int[] flat : data.colorHangs) {
            List<int[]> route = new ArrayList<>();
            for (int i = 2; i + 1 < flat.length; i += 2) {
                route.add(new int[] { flat[i], flat[i + 1] });
            }
            if (!route.isEmpty()) {
                out.add(new ColorHang(from, (char) flat[0], flat[1], route));
            }
        }
        return out;
    }

    public static List<ColorHang> colorHangsAt(NpcDialogueGraph graph, int x, int y) {
        List<ColorHang> out = new ArrayList<>();
        if (graph == null || graph.nodes == null) return out;
        for (Node n : graph.nodes.values()) {
            for (ColorHang h : colorHangs(n)) {
                if (h.endX() == x && h.endY() == y) out.add(h);
            }
        }
        return out;
    }

    public static List<ColorBend> customBendsAt(NpcDialogueGraph graph, int x, int y) {
        List<ColorBend> out = new ArrayList<>();
        if (graph == null || graph.nodes == null) return out;
        for (Node n : graph.nodes.values()) {
            Data data = read(n);
            for (Map.Entry<String, List<int[]>> entry : data.custom.entrySet()) {
                char kind = customKind(entry.getKey());
                int to = customTarget(entry.getKey());
                for (int[] pt : entry.getValue()) {
                    if (pt[0] == x && pt[1] == y) {
                        out.add(new ColorBend(n, kind, to, x, y));
                    }
                }
            }
        }
        return out;
    }

    public static List<Bend> valueBendsAt(NpcDialogueGraph graph, int x, int y) {
        List<Bend> out = new ArrayList<>();
        if (graph == null || graph.nodes == null) return out;
        for (Node n : graph.nodes.values()) {
            Data data = read(n);
            for (Map.Entry<Integer, List<int[]>> entry : data.value.entrySet()) {
                for (int[] pt : entry.getValue()) {
                    if (pt[0] == x && pt[1] == y) {
                        out.add(new Bend(n, VALUE_PORT, entry.getKey(), x, y));
                    }
                }
            }
        }
        return out;
    }

    public static void attachColor(Node from, char kind, int arg, int x, int y) {
        if (from == null) return;
        Data data = read(from);
        for (int[] flat : data.colorHangs) {
            int size = (flat.length - 2) / 2;
            if ((char) flat[0] == kind && flat[1] == arg && size > 0
                    && flat[2 + (size - 1) * 2] == x && flat[3 + (size - 1) * 2] == y) {
                return;
            }
        }
        data.colorHangs.add(new int[] { (int) kind, arg, x, y });
        write(from, data);
    }

    public static boolean addColorRoutePoint(Node from, char kind, int arg, int endX, int endY,
            int x, int y, int index) {
        if (from == null) return false;
        Data data = read(from);
        for (int i = data.colorHangs.size() - 1; i >= 0; i--) {
            int[] flat = data.colorHangs.get(i);
            if ((char) flat[0] != kind || flat[1] != arg) continue;
            int size = (flat.length - 2) / 2;
            if (size <= 0) continue;
            if (flat[2 + (size - 1) * 2] != endX || flat[3 + (size - 1) * 2] != endY) continue;
            for (int k = 0; k < size; k++) {
                if (Math.abs(flat[2 + k * 2] - x) <= GRID
                        && Math.abs(flat[3 + k * 2] - y) <= GRID) {
                    return false;
                }
            }
            int at = Math.max(0, Math.min(index, size));
            int[] grown = new int[flat.length + 2];
            System.arraycopy(flat, 0, grown, 0, 2 + at * 2);
            grown[2 + at * 2] = x;
            grown[3 + at * 2] = y;
            System.arraycopy(flat, 2 + at * 2, grown, 4 + at * 2, flat.length - 2 - at * 2);
            data.colorHangs.set(i, grown);
            write(from, data);
            return true;
        }
        return false;
    }

    public static boolean promoteColor(Node from, char kind, int arg, int x, int y, int toId) {
        if (from == null || toId < 0) return false;
        Data data = read(from);
        for (int i = data.colorHangs.size() - 1; i >= 0; i--) {
            int[] flat = data.colorHangs.get(i);
            if ((char) flat[0] != kind || flat[1] != arg) continue;
            int size = (flat.length - 2) / 2;
            if (size <= 0 || flat[2 + (size - 1) * 2] != x || flat[3 + (size - 1) * 2] != y) continue;
            data.colorHangs.remove(i);
            List<int[]> points = kind == KIND_VALUE
                    ? data.value.computeIfAbsent(toId, k -> new ArrayList<>())
                    : data.custom.computeIfAbsent(customKey(kind, toId), k -> new ArrayList<>());
            for (int k = 0; k < size; k++) {
                int px = flat[2 + k * 2];
                int py = flat[3 + k * 2];
                if (!contains(points, px, py)) points.add(new int[] { px, py });
            }
            write(from, data);
            return true;
        }
        return false;
    }

    public static boolean retargetColor(Node from, char kind, int oldTarget, int newTarget) {
        if (from == null || oldTarget < 0 || newTarget < 0 || oldTarget == newTarget) return false;
        Data data = read(from);
        List<int[]> pts = kind == KIND_VALUE
                ? data.value.remove(oldTarget)
                : data.custom.remove(customKey(kind, oldTarget));
        if (pts == null) return false;
        List<int[]> target = kind == KIND_VALUE
                ? data.value.computeIfAbsent(newTarget, k -> new ArrayList<>())
                : data.custom.computeIfAbsent(customKey(kind, newTarget), k -> new ArrayList<>());
        for (int[] pt : pts) {
            if (!contains(target, pt[0], pt[1])) target.add(pt);
        }
        write(from, data);
        return true;
    }

    /**
     * The route of a cable, found by its two ends rather than by one exact key.
     *
     * <p>The drawing asks for a route with the port number it happens to use, and the store keeps
     * whichever port the point was made with. When the two disagree - a port the screen numbers
     * differently, a point made before a link was renumbered, a record saved on the other end of
     * the same link - the cable is drawn straight while the point is drawn on the canvas: a dot
     * with no wire through it. This lookup takes any record between the same two nodes, in either
     * direction, on any port, so a point can no longer be orphaned by a numbering difference. Only
     * called when the exact key is empty, so an ordinary frame never pays for it.</p>
     */
    public static List<int[]> routed(NpcDialogueGraph graph, int fromId, int toId) {
        if (graph == null || graph.nodes == null || fromId < 0 || toId < 0) return List.of();
        for (Node node : graph.nodes.values()) {
            Data data = read(node);
            for (Map.Entry<String, List<int[]>> entry : data.bends.entrySet()) {
                int target = keyTarget(entry.getKey());
                boolean forward = node.id == fromId && target == toId;
                boolean backward = node.id == toId && target == fromId;
                if ((forward || backward) && !entry.getValue().isEmpty()) {
                    return entry.getValue();
                }
            }
        }
        return List.of();
    }

    /** What the store holds, in one line - for the diagnostic line in the log. */
    public static String dump(NpcDialogueGraph graph) {
        if (graph == null || graph.nodes == null) return "no graph";
        StringBuilder out = new StringBuilder();
        for (Node node : graph.nodes.values()) {
            Data data = read(node);
            if (data.empty()) continue;
            out.append(" #").append(node.id).append('{');
            for (Map.Entry<String, List<int[]>> entry : data.bends.entrySet()) {
                out.append(entry.getKey()).append('=').append(entry.getValue().size()).append(' ');
            }
            for (Map.Entry<Integer, List<int[]>> entry : data.value.entrySet()) {
                out.append("v").append(entry.getKey()).append('=')
                        .append(entry.getValue().size()).append(' ');
            }
            for (Map.Entry<String, List<int[]>> entry : data.custom.entrySet()) {
                out.append("c").append(entry.getKey()).append('=')
                        .append(entry.getValue().size()).append(' ');
            }
            for (int[] hang : data.hangs) {
                out.append("h").append(hang[0]).append('=').append(routeSize(hang)).append(' ');
            }
            for (int[] hang : data.colorHangs) {
                out.append("k").append((char) hang[0]).append(hang[1]).append('=')
                        .append((hang.length - 2) / 2).append(' ');
            }
            out.append('}');
        }
        return out.length() == 0 ? "empty" : out.toString().trim();
    }

    /**
     * True when the graph holds at least one point, cached for a fraction of a second.
     *
     * <p>The drawing asks this for every cable on the screen, every frame. The store is empty in
     * almost every ordinary frame, so a graph with no points must cost one timestamp comparison per
     * cable - a route lookup per cable would walk every node of the graph instead. The cache is
     * dropped the moment anything is written, so a point appears in the same frame it was made.</p>
     */
    public static boolean anyPoints(NpcDialogueGraph graph) {
        if (graph == null) return false;
        long now = System.currentTimeMillis();
        if (graph != scannedGraph || now - scannedAt > 500L) {
            scannedGraph = graph;
            scannedAt = now;
            boolean any = false;
            if (graph.nodes != null) {
                for (Node node : graph.nodes.values()) {
                    if (!read(node).empty()) {
                        any = true;
                        break;
                    }
                }
            }
            scannedAny = any;
        }
        return scannedAny;
    }

    private static NpcDialogueGraph scannedGraph;
    private static long scannedAt;
    private static boolean scannedAny;

    /** True while there is room for another one-shot diagnostic line. Checked before any text is
     *  built, so once the limit is reached a frame costs nothing. */
    public static boolean onceRoom() {
        return ONCE.size() < ONCE_LIMIT;
    }

    /** Writes a line the first time this channel is seen, and never again. */
    public static void noteOnce(String channel, String text) {
        if (ONCE.size() >= ONCE_LIMIT) return;
        if (ONCE.add(channel)) System.out.println("[settledlands/wires] " + text);
    }

    private static final Set<String> ONCE = new HashSet<>();
    private static final int ONCE_LIMIT = 24;

    /**
     * Writes one diagnostic line, at most twice a second and only when it changes.
     *
     * <p>Points live in a field of a node and are read back every frame; when they do not reach the
     * cable there is nothing on screen to tell why. This is the only way to see, from a log, which
     * key the drawing asks for and which keys the store holds.</p>
     */
    public static void note(String channel, String text) {
        long now = System.currentTimeMillis();
        Object[] state = NOTES.get(channel);
        if (state != null && text.equals(state[1]) && now - (Long) state[0] < 2000L) return;
        NOTES.put(channel, new Object[] { now, text });
        System.out.println("[settledlands/wires] " + text);
    }

    private static final Map<String, Object[]> NOTES = new HashMap<>();

    // -- reading what is drawn ----------------------------------------------

    /** Points of one carrying wire, in order. Read only - this is the drawing path. */
    public static List<int[]> bends(Node from, int fromPort, int toId) {
        if (from == null) return List.of();
        return read(from).bends.getOrDefault(key(fromPort, toId), List.of());
    }

    /** Waiting wires of a node as {@code {port, x1, y1, ...}}, in order. Drawing path. */
    public static List<int[]> hangs(Node from) {
        if (from == null) return List.of();
        return read(from).hangs;
    }

    /** Number of points a raw waiting wire visits. */
    public static int routeSize(int[] hang) {
        return (hang.length - 1) / 2;
    }

    public static int routeX(int[] hang, int index) {
        return hang[1 + index * 2];
    }

    public static int routeY(int[] hang, int index) {
        return hang[2 + index * 2];
    }

    /** Every point of the graph, in the order the nodes were written. Stale bends are dropped. */
    public static List<int[]> points(NpcDialogueGraph graph) {
        return points(graph, null);
    }

    /**
     * Every point of the graph, with blue value wires checked against {@code valueAlive} so a
     * point does not outlive the value wire it was made on.
     */
    public static List<int[]> points(NpcDialogueGraph graph, BiPredicate<Node, Integer> valueAlive) {
        return points(graph, valueAlive, null);
    }

    /**
     * Every point of the graph, validating both blue value wires and colored wires (orange,
     * amber, trial start, trial module). Build 453.
     */
    public static List<int[]> points(NpcDialogueGraph graph,
            BiPredicate<Node, Integer> valueAlive, CustomWireCheck customAlive) {
        List<Bend> bends = new ArrayList<>();
        List<Hang> hangs = new ArrayList<>();
        List<ColorHang> colorHangs = new ArrayList<>();
        collect(graph, bends, hangs, colorHangs, true, valueAlive, customAlive);
        Set<Long> seen = new LinkedHashSet<>();
        List<int[]> out = new ArrayList<>();
        for (Bend bend : bends) {
            if (seen.add(pack(bend.x, bend.y))) out.add(new int[] { bend.x, bend.y });
        }
        for (Hang hang : hangs) {
            for (int[] point : hang.route) {
                if (seen.add(pack(point[0], point[1]))) out.add(new int[] { point[0], point[1] });
            }
        }
        for (ColorHang hang : colorHangs) {
            for (int[] point : hang.route) {
                if (seen.add(pack(point[0], point[1]))) out.add(new int[] { point[0], point[1] });
            }
        }
        return out;
    }

    /** True when a point is already within {@code tolerance} graph units of this place. */
    public static boolean pointWithin(NpcDialogueGraph graph, int x, int y, int tolerance) {
        for (int[] point : points(graph)) {
            if (Math.abs(point[0] - x) <= tolerance && Math.abs(point[1] - y) <= tolerance) {
                return true;
            }
        }
        return false;
    }

    public static boolean hasPoint(NpcDialogueGraph graph, int x, int y) {
        for (int[] point : points(graph)) {
            if (point[0] == x && point[1] == y) return true;
        }
        return false;
    }

    /** Every point of every carrying wire. */
    public static List<Bend> bendsAt(NpcDialogueGraph graph, int x, int y) {
        List<Bend> bends = new ArrayList<>();
        collect(graph, bends, new ArrayList<>(), false);
        List<Bend> out = new ArrayList<>();
        for (Bend bend : bends) {
            if (bend.x == x && bend.y == y) out.add(bend);
        }
        return out;
    }

    /** Every waiting wire that stops at this point. */
    public static List<Hang> hangsAt(NpcDialogueGraph graph, int x, int y) {
        List<Hang> hangs = new ArrayList<>();
        collect(graph, new ArrayList<>(), hangs, false);
        List<Hang> out = new ArrayList<>();
        for (Hang hang : hangs) {
            if (hang.endX() == x && hang.endY() == y) out.add(hang);
        }
        return out;
    }

    /**
     * Walks every node once.
     *
     * @param prune drop carrying wires whose connection no longer exists, so a point never outlives
     *              the cable it was made on
     */
    private static void collect(NpcDialogueGraph graph, List<Bend> bends, List<Hang> hangs,
            boolean prune) {
        collect(graph, bends, hangs, null, prune, null, null);
    }

    private static void collect(NpcDialogueGraph graph, List<Bend> bends, List<Hang> hangs,
            List<ColorHang> colorHangs, boolean prune,
            BiPredicate<Node, Integer> valueAlive, CustomWireCheck customAlive) {
        if (graph == null || graph.nodes == null) return;
        for (Node node : graph.nodes.values()) {
            Data data = read(node);
            boolean changed = false;
            List<String> dead = new ArrayList<>();
            for (Map.Entry<String, List<int[]>> entry : data.bends.entrySet()) {
                int port = keyPort(entry.getKey());
                int to = keyTarget(entry.getKey());
                if (prune && !drawn(node, port, to)) {
                    dead.add(entry.getKey());
                    continue;
                }
                for (int[] point : entry.getValue()) {
                    bends.add(new Bend(node, port, to, point[0], point[1]));
                }
            }
            if (!dead.isEmpty()) {
                for (String key : dead) data.bends.remove(key);
                changed = true;
            }
            List<Integer> deadValue = new ArrayList<>();
            for (Map.Entry<Integer, List<int[]>> entry : data.value.entrySet()) {
                if (prune && valueAlive != null && !valueAlive.test(node, entry.getKey())) {
                    deadValue.add(entry.getKey());
                    continue;
                }
                for (int[] point : entry.getValue()) {
                    bends.add(new Bend(node, VALUE_PORT, entry.getKey(), point[0], point[1]));
                }
            }
            if (!deadValue.isEmpty()) {
                for (Integer key : deadValue) data.value.remove(key);
                changed = true;
            }
            List<String> deadCustom = new ArrayList<>();
            for (Map.Entry<String, List<int[]>> entry : data.custom.entrySet()) {
                char kind = customKind(entry.getKey());
                int to = customTarget(entry.getKey());
                if (prune && customAlive != null && !customAlive.isAlive(node, kind, to)) {
                    deadCustom.add(entry.getKey());
                    continue;
                }
                for (int[] point : entry.getValue()) {
                    bends.add(new Bend(node, VALUE_PORT, to, point[0], point[1]));
                }
            }
            if (!deadCustom.isEmpty()) {
                for (String key : deadCustom) data.custom.remove(key);
                changed = true;
            }
            for (int[] hang : data.hangs) {
                List<int[]> route = new ArrayList<>();
                for (int i = 0; i + 1 < hang.length; i += 2) {
                    route.add(new int[] { hang[1 + i], hang[2 + i] });
                }
                if (!route.isEmpty()) hangs.add(new Hang(node, hang[0], route));
            }
            if (colorHangs != null) {
                for (int[] flat : data.colorHangs) {
                    List<int[]> route = new ArrayList<>();
                    for (int i = 2; i + 1 < flat.length; i += 2) {
                        route.add(new int[] { flat[i], flat[i + 1] });
                    }
                    if (!route.isEmpty()) {
                        colorHangs.add(new ColorHang(node, (char) flat[0], flat[1], route));
                    }
                }
            }
            if (changed) write(node, data);
        }
    }

    private static long pack(int x, int y) {
        return ((long) x << 32) ^ (y & 0xffffffffL);
    }

    // -- editing ------------------------------------------------------------

    /** Puts a point on a carrying wire at the end of its run. */
    public static void addBend(Node from, int fromPort, int toId, int x, int y) {
        addBend(from, fromPort, toId, x, y, Integer.MAX_VALUE);
    }

    /**
     * Puts a point on a carrying wire at {@code index} of its run, so a wire can be made to pass
     * through points in the order they were clicked.
     */
    public static void addBend(Node from, int fromPort, int toId, int x, int y, int index) {
        if (from == null || toId < 0) return;
        Data data = read(from);
        List<int[]> points = data.bends.computeIfAbsent(key(fromPort, toId),
                unused -> new ArrayList<>());
        // Not snapped again: the canvas already chose a spot, and snapping it here is what pulled
        // a freshly made point off the cable it was put on.
        int sx = x;
        int sy = y;
        // Two dots on the same wire a few pixels apart look like one dot and cannot be told apart
        // by a click, so a second point is never made next to an existing one.
        for (int[] point : points) {
            if (Math.abs(point[0] - sx) <= GRID && Math.abs(point[1] - sy) <= GRID) return;
        }
        points.add(Math.max(0, Math.min(index, points.size())), new int[] { sx, sy });
        write(from, data);
    }

    /**
     * Adds a point along a waiting wire: the wire visits one more point before it stops.
     *
     * @param endX  the point the wire stops at now - identifies the waiting wire
     * @param index where in the run the new point goes
     */
    public static boolean addRoutePoint(Node from, int fromPort, int endX, int endY, int x, int y,
            int index) {
        if (from == null) return false;
        int sx = x;
        int sy = y;
        Data data = read(from);
        for (int i = data.hangs.size() - 1; i >= 0; i--) {
            int[] hang = data.hangs.get(i);
            if (hang[0] != fromPort) continue;
            int size = routeSize(hang);
            if (size == 0) continue;
            if (hang[1 + (size - 1) * 2] != endX || hang[2 + (size - 1) * 2] != endY) continue;
            for (int k = 0; k < size; k++) {
                if (Math.abs(hang[1 + k * 2] - sx) <= GRID
                        && Math.abs(hang[2 + k * 2] - sy) <= GRID) {
                    return false;
                }
            }
            int at = Math.max(0, Math.min(index, size));
            int[] grown = new int[hang.length + 2];
            System.arraycopy(hang, 0, grown, 0, 1 + at * 2);
            grown[1 + at * 2] = sx;
            grown[2 + at * 2] = sy;
            System.arraycopy(hang, 1 + at * 2, grown, 3 + at * 2, hang.length - 1 - at * 2);
            data.hangs.set(i, grown);
            write(from, data);
            return true;
        }
        return false;
    }

    /**
     * Ends one wire of a node on a point. Nothing is connected: the wire waits at the point until
     * the point is given a target.
     */
    public static void attach(Node from, int fromPort, int x, int y) {
        if (from == null) return;
        Data data = read(from);
        int sx = x;
        int sy = y;
        for (int[] hang : data.hangs) {
            int size = routeSize(hang);
            if (hang[0] == fromPort && size > 0
                    && hang[1 + (size - 1) * 2] == sx && hang[2 + (size - 1) * 2] == sy) {
                return;
            }
        }
        // The wire cannot also be routed through that very spot: it ends here now.
        List<String> emptied = new ArrayList<>();
        for (Map.Entry<String, List<int[]>> entry : data.bends.entrySet()) {
            if (keyPort(entry.getKey()) != fromPort) continue;
            List<int[]> points = entry.getValue();
            points.removeIf(point -> point[0] == sx && point[1] == sy);
            if (points.isEmpty()) emptied.add(entry.getKey());
        }
        for (String key : emptied) data.bends.remove(key);
        data.hangs.add(new int[] { fromPort, sx, sy });
        write(from, data);
    }

    /** Moves every record of the point: all carrying and all waiting wires follow it. */
    public static boolean movePoint(NpcDialogueGraph graph, int x, int y, int nx, int ny) {
        if (graph == null || graph.nodes == null) return false;
        int tx = nx;
        int ty = ny;
        if (tx == x && ty == y) return false;
        boolean any = false;
        for (Node node : graph.nodes.values()) {
            Data data = read(node);
            boolean changed = false;
            for (List<int[]> points : data.bends.values()) {
                for (int[] point : points) {
                    if (point[0] == x && point[1] == y) {
                        point[0] = tx;
                        point[1] = ty;
                        changed = true;
                    }
                }
            }
            for (List<int[]> points : data.value.values()) {
                for (int[] point : points) {
                    if (point[0] == x && point[1] == y) {
                        point[0] = tx;
                        point[1] = ty;
                        changed = true;
                    }
                }
            }
            for (List<int[]> points : data.custom.values()) {
                for (int[] point : points) {
                    if (point[0] == x && point[1] == y) {
                        point[0] = tx;
                        point[1] = ty;
                        changed = true;
                    }
                }
            }
            for (int[] hang : data.hangs) {
                for (int i = 1; i + 1 < hang.length; i += 2) {
                    if (hang[i] == x && hang[i + 1] == y) {
                        hang[i] = tx;
                        hang[i + 1] = ty;
                        changed = true;
                    }
                }
            }
            for (int[] hang : data.colorHangs) {
                for (int i = 2; i + 1 < hang.length; i += 2) {
                    if (hang[i] == x && hang[i + 1] == y) {
                        hang[i] = tx;
                        hang[i + 1] = ty;
                        changed = true;
                    }
                }
            }
            if (changed) {
                write(node, data);
                any = true;
            }
        }
        return any;
    }

    /** Removes the point: the carrying wires go straight again, the waiting wires are let go. */
    public static boolean removePoint(NpcDialogueGraph graph, int x, int y) {
        if (graph == null || graph.nodes == null) return false;
        boolean any = false;
        for (Node node : graph.nodes.values()) {
            Data data = read(node);
            boolean changed = false;
            List<String> dead = new ArrayList<>();
            for (Map.Entry<String, List<int[]>> entry : data.bends.entrySet()) {
                List<int[]> points = entry.getValue();
                for (int i = points.size() - 1; i >= 0; i--) {
                    if (points.get(i)[0] == x && points.get(i)[1] == y) {
                        points.remove(i);
                        changed = true;
                    }
                }
                if (points.isEmpty()) dead.add(entry.getKey());
            }
            for (String key : dead) data.bends.remove(key);
            List<Integer> deadValue = new ArrayList<>();
            for (Map.Entry<Integer, List<int[]>> entry : data.value.entrySet()) {
                List<int[]> points = entry.getValue();
                for (int i = points.size() - 1; i >= 0; i--) {
                    if (points.get(i)[0] == x && points.get(i)[1] == y) {
                        points.remove(i);
                        changed = true;
                    }
                }
                if (points.isEmpty()) deadValue.add(entry.getKey());
            }
            for (Integer key : deadValue) data.value.remove(key);
            List<String> deadCustom = new ArrayList<>();
            for (Map.Entry<String, List<int[]>> entry : data.custom.entrySet()) {
                List<int[]> points = entry.getValue();
                for (int i = points.size() - 1; i >= 0; i--) {
                    if (points.get(i)[0] == x && points.get(i)[1] == y) {
                        points.remove(i);
                        changed = true;
                    }
                }
                if (points.isEmpty()) deadCustom.add(entry.getKey());
            }
            for (String key : deadCustom) data.custom.remove(key);
            for (int i = data.hangs.size() - 1; i >= 0; i--) {
                int[] hang = data.hangs.get(i);
                int size = routeSize(hang);
                int kept = size;
                List<int[]> route = new ArrayList<>();
                for (int k = 0; k < size; k++) {
                    int px = hang[1 + k * 2];
                    int py = hang[2 + k * 2];
                    if (px == x && py == y) {
                        kept--;
                        continue;
                    }
                    route.add(new int[] { px, py });
                }
                if (kept == size) continue;
                changed = true;
                if (route.isEmpty()) {
                    data.hangs.remove(i);
                    continue;
                }
                int[] smaller = new int[1 + route.size() * 2];
                smaller[0] = hang[0];
                for (int k = 0; k < route.size(); k++) {
                    smaller[1 + k * 2] = route.get(k)[0];
                    smaller[2 + k * 2] = route.get(k)[1];
                }
                data.hangs.set(i, smaller);
            }
            for (int i = data.colorHangs.size() - 1; i >= 0; i--) {
                int[] flat = data.colorHangs.get(i);
                int size = (flat.length - 2) / 2;
                int kept = size;
                List<int[]> route = new ArrayList<>();
                for (int k = 0; k < size; k++) {
                    int px = flat[2 + k * 2];
                    int py = flat[3 + k * 2];
                    if (px == x && py == y) {
                        kept--;
                        continue;
                    }
                    route.add(new int[] { px, py });
                }
                if (kept == size) continue;
                changed = true;
                if (route.isEmpty()) {
                    data.colorHangs.remove(i);
                    continue;
                }
                int[] smaller = new int[2 + route.size() * 2];
                smaller[0] = flat[0];
                smaller[1] = flat[1];
                for (int k = 0; k < route.size(); k++) {
                    smaller[2 + k * 2] = route.get(k)[0];
                    smaller[3 + k * 2] = route.get(k)[1];
                }
                data.colorHangs.set(i, smaller);
            }
            if (changed) {
                write(node, data);
                any = true;
            }
        }
        return any;
    }

    /**
     * Turns one waiting wire into a real one to {@code toId}, keeping the points it passes through:
     * from that moment the wire carries the connection instead of stopping at the point.
     */
    public static boolean promote(Node from, int fromPort, int x, int y, int toId) {
        if (from == null || toId < 0) return false;
        Data data = read(from);
        for (int i = data.hangs.size() - 1; i >= 0; i--) {
            int[] hang = data.hangs.get(i);
            int size = routeSize(hang);
            if (hang[0] != fromPort || size == 0) continue;
            if (hang[1 + (size - 1) * 2] != x || hang[2 + (size - 1) * 2] != y) continue;
            data.hangs.remove(i);
            List<int[]> points = data.bends.computeIfAbsent(key(fromPort, toId),
                    unused -> new ArrayList<>());
            for (int k = 0; k < size; k++) {
                int px = hang[1 + k * 2];
                int py = hang[2 + k * 2];
                if (!contains(points, px, py)) points.add(new int[] { px, py });
            }
            write(from, data);
            return true;
        }
        return false;
    }

    private static boolean contains(List<int[]> points, int x, int y) {
        for (int[] point : points) {
            if (point[0] == x && point[1] == y) return true;
        }
        return false;
    }

    /**
     * Rewrites the target of one carrying wire, keeping the whole route where it is: every point of
     * the old wire moves to the new one, so the cable keeps its shape.
     */
    public static boolean retarget(Node from, int fromPort, int oldTarget, int newTarget) {
        if (from == null || oldTarget < 0 || newTarget < 0 || oldTarget == newTarget) return false;
        Data data = read(from);
        List<int[]> points = data.bends.remove(key(fromPort, oldTarget));
        if (points == null) return false;
        List<int[]> target = data.bends.computeIfAbsent(key(fromPort, newTarget),
                unused -> new ArrayList<>());
        for (int[] point : points) {
            if (!contains(target, point[0], point[1])) target.add(point);
        }
        write(from, data);
        return true;
    }

    public static boolean removeHang(Node from, int fromPort, int endX, int endY) {
        if (from == null) return false;
        Data data = read(from);
        for (int i = data.hangs.size() - 1; i >= 0; i--) {
            int[] h = data.hangs.get(i);
            int size = routeSize(h);
            if (h[0] == fromPort && size > 0
                    && h[1 + (size - 1) * 2] == endX && h[2 + (size - 1) * 2] == endY) {
                data.hangs.remove(i);
                write(from, data);
                return true;
            }
        }
        return false;
    }

    public static boolean removeColorHang(Node from, char kind, int arg, int endX, int endY) {
        if (from == null) return false;
        Data data = read(from);
        for (int i = data.colorHangs.size() - 1; i >= 0; i--) {
            int[] h = data.colorHangs.get(i);
            int size = (h.length - 2) / 2;
            if ((char) h[0] == kind && h[1] == arg && size > 0
                    && h[2 + (size - 1) * 2] == endX && h[3 + (size - 1) * 2] == endY) {
                data.colorHangs.remove(i);
                write(from, data);
                return true;
            }
        }
        return false;
    }

    public static int snap(int value) {
        return Math.round((float) value / GRID) * GRID;
    }
}
