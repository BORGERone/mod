#!/usr/bin/env python3
"""Compile only changed classes and overlay them onto the exact Build 83 baseline.
Usage: JAVA_HOME=/path/to/jdk21 python3 build_patch.py --cache /path/to/temporary/cache
The output is a complete mod JAR, not an addon requiring two copies of SettledLands.
"""
import argparse, hashlib, json, os, subprocess, zipfile
from pathlib import Path
from prepare_classpath import prepare, digest

ROOT = Path(__file__).resolve().parent
VERSION = '0.8.0-build132-cutscene-full'
BASELINE_SHA256 = 'dcbdb263e6d932c2026254668597100ae9f60f47a6c2fa5869f0fcb7392b8614'


def package(classes, output):
    patched = {}
    for base in [classes, ROOT/'resources']:
        for path in sorted(base.rglob('*')):
            if path.is_file(): patched[path.relative_to(base).as_posix()] = path.read_bytes()
    roots = [p.relative_to(ROOT/'patch-src').with_suffix('').as_posix() for p in (ROOT/'patch-src').rglob('*.java')]
    def replaced_class(name):
        return name.endswith('.class') and any(name == r+'.class' or name.startswith(r+'$') for r in roots)
    entries = {}
    with zipfile.ZipFile(ROOT/'baseline-build83.jar') as baseline:
        for entry in baseline.infolist():
            if entry.is_dir() or replaced_class(entry.filename): continue
            if entry.filename.endswith(('.SF', '.RSA', '.DSA')) and entry.filename.startswith('META-INF/'): continue
            entries[entry.filename] = baseline.read(entry.filename)
    jlayer_sources = [ROOT / 'libs/jlayer-1.0.1.jar']
    for jl_path in jlayer_sources:
        if jl_path.exists():
            with zipfile.ZipFile(jl_path) as jl:
                for entry in jl.infolist():
                    if entry.filename.startswith('javazoom/') and entry.filename.endswith('.class'):
                        entries[entry.filename] = jl.read(entry.filename)
            break
    entries.update(patched)
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as jar:
        for name, data in sorted(entries.items()):
            info = zipfile.ZipInfo(name, (1980,1,1,0,0,0)); info.compress_type = zipfile.ZIP_DEFLATED
            jar.writestr(info, data, compresslevel=9)
    with zipfile.ZipFile(output) as jar:
        if jar.testzip(): raise ValueError('JAR ZIP integrity failure')
        for name in ['assets/settledlands/lang/ru_ru.json','assets/settledlands/lang/en_us.json']:
            json.loads(jar.read(name))
        if VERSION.encode() not in jar.read('META-INF/neoforge.mods.toml'): raise ValueError('Version metadata mismatch')
        for name in ['NpcEscort','NpcEscortCommands','EscortRules']:
            if f'dev/settledlands/npc/{name}.class' not in jar.namelist(): raise ValueError('Missing escort class')
    return output


def build(java_home, cache, output):
    if digest(ROOT/'baseline-build83.jar') != BASELINE_SHA256: raise ValueError('Not the original Build 83 baseline')
    cp = prepare(cache/'toolchain', java_home, ROOT)
    classes = cache/'classes'; classes.mkdir(parents=True, exist_ok=True)
    # Stale compiler output cannot leak into the packaged result.
    for path in classes.rglob('*.class'): path.unlink()
    sources = sorted((ROOT/'patch-src').rglob('*.java'))
    args = ['-encoding', 'UTF-8', '--release', '21', '-proc:none', '-classpath', os.pathsep.join(map(str,cp)), '-d', str(classes)]
    args += list(map(str,sources))
    with (ROOT/'compile.log').open('w') as log:
        subprocess.run([str(java_home/'bin/javac'), '-J-Xmx384m', '-J-XX:ActiveProcessorCount=1', '-J-XX:+UseSerialGC', *args],
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    package(classes, output)
    (cache/'classpath.txt').write_text(os.pathsep.join(map(str,cp)))
    result={'version':VERSION,'minecraft':'1.21.1','neoforge':'21.1.252','source_files_compiled':len(sources),
            'class_files':len(list(classes.rglob('*.class'))),'jar':output.name,'bytes':output.stat().st_size,
            'sha256':digest(output),'baseline_sha256':BASELINE_SHA256,
            'compiler':'JDK 21, javac --release 21, -proc:none','max_compiler_heap_mib':384,
            'minecraft_decompilation':False,'minecraft_launch_test':False}
    (ROOT/'build-report.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--java-home', type=Path, default=Path(os.environ.get('JAVA_HOME','')))
    parser.add_argument('--cache',type=Path,default=ROOT/'.cache/compile88')
    parser.add_argument('--output',type=Path,default=ROOT/f'settledlands-{VERSION}.jar')
    args=parser.parse_args()
    build(args.java_home.resolve(),args.cache.resolve(),args.output.resolve())
