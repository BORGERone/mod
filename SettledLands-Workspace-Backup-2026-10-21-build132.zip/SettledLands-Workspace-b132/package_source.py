#!/usr/bin/env python3
"""Pack the authoritative project plus a merged reference tree from the original ZIP.
No game binaries/toolchain caches are bundled (the exact mod baseline is included).
"""
import argparse, hashlib, json, zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent
PREFIX = 'SettledLands-Build132-Cutscene-Full/'


def put(archive, name, data):
    info = zipfile.ZipInfo(PREFIX + name, (1980, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    archive.writestr(info, data, compresslevel=6)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--original-zip', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=ROOT / 'SettledLands-Build132-Cutscene-Full-Source.zip')
    args = parser.parse_args()
    entries = {}
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or path.resolve() == args.output.resolve(): continue
        rel = path.relative_to(ROOT)
        if any(part in ('__pycache__', '.cache', 'cache', '.git') for part in rel.parts): continue
        if rel.suffix == '.zip': continue
        if rel.suffix == '.jar' and rel.name not in ('baseline-build83.jar', 'jlayer-1.0.1.jar'): continue
        name = rel.as_posix()
        if name == 'apply_source_patch.py': name = 'historical/apply_source_patch_USED_ONCE.py'
        entries[name] = path.read_bytes()
    with zipfile.ZipFile(args.original_zip) as original:
        for item in original.infolist():
            if item.is_dir(): continue
            rel = item.filename.split('/', 1)[-1]
            if rel.startswith('decompiled-java/'):
                entries['reference-' + rel] = original.read(item.filename)
            elif rel.startswith('reference-decompiled-java/'):
                entries[rel] = original.read(item.filename)
            elif rel.startswith('resources/'):
                entries['reference-' + rel] = original.read(item.filename)
            elif rel.startswith('reference-resources/') or rel.startswith('historical/'):
                entries[rel] = original.read(item.filename)
            elif rel in ('build.gradle', 'settings.gradle', 'gradle.properties') or rel.lower().startswith('readme'):
                entries['historical/Build83-' + rel] = original.read(item.filename)
    for section, target in [('patch-src', 'reference-decompiled-java'), ('resources', 'reference-resources')]:
        for path in sorted((ROOT / section).rglob('*')):
            if path.is_file(): entries[target + '/' + path.relative_to(ROOT / section).as_posix()] = path.read_bytes()
    manifest = {name: hashlib.sha256(data).hexdigest() for name, data in sorted(entries.items())}
    entries['SOURCE-MANIFEST.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, 'w') as archive:
        for name, data in sorted(entries.items()): put(archive, name, data)
    with zipfile.ZipFile(args.output) as archive:
        if archive.testzip(): raise ValueError('Source ZIP integrity failure')
        for name, expected in manifest.items():
            if hashlib.sha256(archive.read(PREFIX + name)).hexdigest() != expected:
                raise ValueError('Source ZIP checksum mismatch: ' + name)
    print(json.dumps({'file': str(args.output), 'bytes': args.output.stat().st_size,
        'sha256': hashlib.sha256(args.output.read_bytes()).hexdigest(), 'files': len(entries)}, indent=2))


if __name__ == '__main__': main()
