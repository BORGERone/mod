#!/usr/bin/env python3
"""Small compile-only toolchain; no Gradle, game launch or decompilation.
Minecraft binaries are fetched from Mojang, renamed with ART and kept ONLY in cache.
NeoForge makes Screen.renderables public via its access transformer. Mirror that single
access change in the compile classpath, never in the shipped mod/game files.
"""
import argparse, hashlib, json, os, struct, subprocess, urllib.request, zipfile
from pathlib import Path


def digest(path, algorithm='sha256'):
    h = hashlib.new(algorithm)
    with Path(path).open('rb') as f:
        while block := f.read(1024 * 1024): h.update(block)
    return h.hexdigest()


def download(url, path, expected=None, algorithm='sha256'):
    path = Path(path)
    if path.exists() and (not expected or digest(path, algorithm) == expected): return
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_name(path.name + '.partial')
    with urllib.request.urlopen(url, timeout=60) as response, partial.open('wb') as f:
        while block := response.read(512 * 1024): f.write(block)
    if expected and digest(partial, algorithm) != expected:
        partial.unlink()
        raise ValueError('Download checksum mismatch: ' + path.name)
    partial.replace(path)


def public_screen_renderables(data):
    """Minimal class-file flag patch; no additional Java tool or AST/decompiler."""
    b = bytearray(data)
    if b[:4] != b'\xca\xfe\xba\xbe': raise ValueError('Not a class file')
    u2 = lambda offset: struct.unpack_from('>H', b, offset)[0]
    count = u2(8); offset = 10; strings = {}; index = 1
    while index < count:
        tag = b[offset]; offset += 1
        if tag == 1:
            n = u2(offset); offset += 2
            strings[index] = bytes(b[offset:offset+n]).decode('utf-8', errors='replace'); offset += n
        elif tag in (3, 4): offset += 4
        elif tag in (5, 6): offset += 8; index += 1
        elif tag in (7, 8, 16, 19, 20): offset += 2
        elif tag in (9, 10, 11, 12, 17, 18): offset += 4
        elif tag == 15: offset += 3
        else: raise ValueError('Unknown constant tag ' + str(tag))
        index += 1
    offset += 6 # class access, this class, superclass
    interfaces = u2(offset); offset += 2 + interfaces * 2
    fields = u2(offset); offset += 2; changed = False
    for _ in range(fields):
        access_offset = offset
        access, name_index, _, attributes = struct.unpack_from('>HHHH', b, offset); offset += 8
        if strings[name_index] == 'renderables':
            struct.pack_into('>H', b, access_offset, (access & ~6) | 1); changed = True
        for _ in range(attributes):
            length = struct.unpack_from('>I', b, offset+2)[0]; offset += 6 + length
    if not changed: raise ValueError('Screen.renderables not found')
    return bytes(b)


def prepare(cache, java_home, root):
    cache.mkdir(parents=True, exist_ok=True)
    java = str(java_home / 'bin/java')
    env = dict(os.environ, JAVA_HOME=str(java_home))
    subprocess.run([java, '-version'], env=env, check=True)
    locked = json.loads((root / 'dependencies.lock.json').read_text())
    version_file = cache / 'minecraft-version.json'
    download(locked['version_url'], version_file, locked['version_sha256'])
    version = json.loads(version_file.read_text())
    for artifact in locked['tools']:
        download(artifact['url'], cache/artifact['file'], artifact['sha256'])
    libs = cache/'libraries'
    for artifact in locked['libraries']:
        algorithm = 'sha1' if 'sha1' in artifact else 'sha256'
        download(artifact['url'], libs/artifact['file'], artifact[algorithm], algorithm)
    accessible = cache/'minecraft-compile.jar'
    manifest = cache/'compile-cache-manifest.json'
    if accessible.exists() and manifest.exists():
        expected = json.loads(manifest.read_text())['sha256'][accessible.name]
        if digest(accessible) != expected: raise ValueError('Cached Minecraft compile JAR checksum mismatch')
    named = cache/'minecraft-named.jar'
    if not accessible.exists() and not named.exists():
        for key, name in [('client', 'client-obf.jar'), ('client_mappings', 'client-mappings.txt')]:
            artifact = version['downloads'][key]
            download(artifact['url'], cache/name, artifact['sha1'], 'sha1')
        with (cache/'remap.log').open('w') as log:
            subprocess.run([java, '-Xms64m', '-Xmx512m', '-XX:ActiveProcessorCount=1', '-XX:+UseSerialGC',
                '-jar', str(cache/'art.jar'), '--input', str(cache/'client-obf.jar'), '--output', str(named),
                '--map', str(cache/'client-mappings.txt'), '--reverse', '--threads', '1', '--ann-fix', '--record-fix'],
                env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    if not accessible.exists():
        with zipfile.ZipFile(named) as source, zipfile.ZipFile(accessible, 'w', compression=zipfile.ZIP_DEFLATED) as target:
            for entry in source.infolist():
                # The signatures authenticate obfuscated names; remapped development JARs cannot retain them.
                if entry.filename.startswith('META-INF/') and entry.filename.upper().endswith(('.SF', '.RSA', '.DSA')): continue
                data = source.read(entry.filename)
                if entry.filename == 'net/minecraft/client/gui/screens/Screen.class': data = public_screen_renderables(data)
                target.writestr(entry, data)
    extra_libs = list((root/'libs').glob('*.jar')) if (root/'libs').exists() else []
    return [root/'baseline-build83.jar', accessible, cache/'neoforge.jar', *sorted(libs.glob('*.jar')), *sorted(extra_libs)]

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cache', type=Path, default=Path('.cache/settledlands84/toolchain'))
    parser.add_argument('--java-home', type=Path, default=Path(os.environ.get('JAVA_HOME', '')))
    args = parser.parse_args()
    cp = prepare(args.cache.resolve(), args.java_home.resolve(), Path(__file__).resolve().parent)
    print(os.pathsep.join(map(str, cp)))
