import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.tree.CommandNode;
import dev.settledlands.audio.AudioStorage;
import dev.settledlands.audio.AudioStreamPlayer;
import dev.settledlands.audio.ClientAudioEvents;
import dev.settledlands.audio.ClientAudioService;
import dev.settledlands.audio.PlayAudioCommand;
import dev.settledlands.audio.PlayAudioPayload;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.SelectMusicEvent;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

public final class AudioHarness {
    static int checks;
    static void check(boolean b, String s) { checks++; if (!b) throw new AssertionError(s); }
    static void near(double a, double b, String s) { check(Math.abs(a - b) < 1e-4, s + " expected " + b + " got " + a); }

    public static void main(String[] args) {
        // 1. AudioStorage tests
        AudioStorage.init();
        Path testMusicDir = Path.of("settledlands/music");
        Path testSoundsDir = Path.of("settledlands/sounds");
        check(Files.exists(testMusicDir), "AudioStorage creates settledlands/music directory");
        check(Files.exists(testSoundsDir), "AudioStorage creates settledlands/sounds directory");
        check(Files.exists(testMusicDir.resolve("README.txt")), "AudioStorage creates music README.txt");
        check(Files.exists(testSoundsDir.resolve("README.txt")), "AudioStorage creates sounds README.txt");

        Path dummyOgg = testMusicDir.resolve("test_track.ogg");
        Path dummyWav = testMusicDir.resolve("ambient_loop.wav");
        Path dummyMp3 = testMusicDir.resolve("epic_battle.mp3");
        Path dummySound = testSoundsDir.resolve("bell_ding.wav");

        try {
            Files.writeString(dummyOgg, "OggS dummy content");
            Files.writeString(dummyWav, "RIFF dummy content");
            Files.writeString(dummyMp3, "ID3 dummy MP3 content");
            Files.writeString(dummySound, "RIFF dummy bell sound");

            File foundOgg = AudioStorage.findAudioFile("test_track.ogg");
            check(foundOgg != null && foundOgg.getName().equals("test_track.ogg"), "Find audio file with extension");

            File foundNoExt = AudioStorage.findAudioFile("test_track");
            check(foundNoExt != null && foundNoExt.getName().equals("test_track.ogg"), "Find audio file without extension");

            File foundWav = AudioStorage.findAudioFile("ambient_loop");
            check(foundWav != null && foundWav.getName().equals("ambient_loop.wav"), "Find WAV file without extension");

            File foundMp3 = AudioStorage.findAudioFile("epic_battle");
            check(foundMp3 != null && foundMp3.getName().equals("epic_battle.mp3"), "Find MP3 file without extension");

            File foundSfx = AudioStorage.findAudioFile("bell_ding");
            check(foundSfx != null && foundSfx.getName().equals("bell_ding.wav"), "Find sound in sounds dir");

            // Distinction between music and sound files:
            check(AudioStorage.isMusicFile(foundOgg), "test_track in music dir is recognized as music");
            check(AudioStorage.isMusicFile(foundMp3), "epic_battle in music dir is recognized as music");
            check(!AudioStorage.isMusicFile(foundSfx), "bell_ding in sounds dir is NOT recognized as music");

            // Folder prefix lookup:
            File musicPrefixed = AudioStorage.findAudioFile("music/test_track");
            check(musicPrefixed != null && AudioStorage.isMusicFile(musicPrefixed), "Find with music/ prefix");
            File soundPrefixed = AudioStorage.findAudioFile("sounds/bell_ding");
            check(soundPrefixed != null && !AudioStorage.isMusicFile(soundPrefixed), "Find with sounds/ prefix");

            var list = AudioStorage.listAvailableFiles();
            check(list.contains("test_track.ogg"), "listAvailableFiles contains test_track.ogg");
            check(list.contains("ambient_loop.wav"), "listAvailableFiles contains ambient_loop.wav");
            check(list.contains("epic_battle.mp3"), "listAvailableFiles contains epic_battle.mp3");
            check(list.contains("bell_ding.wav"), "listAvailableFiles contains bell_ding.wav");
            check(list.contains("music/test_track.ogg"), "listAvailableFiles contains prefixed music/test_track.ogg");
            check(list.contains("sounds/bell_ding.wav"), "listAvailableFiles contains prefixed sounds/bell_ding.wav");
            check(!list.contains("README.txt"), "listAvailableFiles filters out README.txt");

            // Verify JLayer MP3 decoder is available
            Class<?> decoderCls = Class.forName("javazoom.jl.decoder.Decoder");
            check(decoderCls != null, "JLayer MP3 decoder is bundled in mod");

        } catch (Exception e) {
            throw new AssertionError("AudioStorage file operations failed", e);
        }

        // 2. PlayAudioCommand Brigadier tree inspection
        CommandDispatcher<CommandSourceStack> dispatcher = new CommandDispatcher<>();
        PlayAudioCommand.register(dispatcher);
        CommandNode<CommandSourceStack> playNode = dispatcher.getRoot().getChild("play");
        check(playNode != null, "/play root node registered");
        check(playNode.getChild("stop") != null, "/play stop branch registered");
        check(playNode.getChild("stop").getChild("fade_sec") != null, "/play stop <fade_sec> branch registered");

        CommandNode<CommandSourceStack> fileNode = playNode.getChild("file");
        check(fileNode != null, "/play <file> node registered");
        CommandNode<CommandSourceStack> radiusNode = fileNode.getChild("radius");
        check(radiusNode != null, "/play <file> <radius> node registered");
        CommandNode<CommandSourceStack> volumeNode = radiusNode.getChild("volume");
        check(volumeNode != null, "/play <file> <radius> <volume> node registered");
        CommandNode<CommandSourceStack> loopNode = volumeNode.getChild("loop");
        check(loopNode != null, "/play <file> <radius> <volume> <loop> node registered");
        CommandNode<CommandSourceStack> fadeNode = loopNode.getChild("fade_sec");
        check(fadeNode != null, "/play <file> <radius> <volume> <loop> <fade_sec> node registered");
        CommandNode<CommandSourceStack> pitchNode = fadeNode.getChild("pitch");
        check(pitchNode != null, "/play <file> <radius> <volume> <loop> <fade_sec> <pitch> node registered");

        // 3. PlayAudioPayload record inspection
        PlayAudioPayload p1 = new PlayAudioPayload("boss.ogg", 100.0, 64.0, -200.0, 50.0f, 0.8f, true, 2.0f, 1.2f, false);
        check(p1.file().equals("boss.ogg"), "Payload file matches");
        near(p1.originX(), 100.0, "Payload originX");
        near(p1.originY(), 64.0, "Payload originY");
        near(p1.originZ(), -200.0, "Payload originZ");
        near(p1.radius(), 50.0, "Payload radius");
        near(p1.volume(), 0.8, "Payload volume");
        check(p1.loop(), "Payload loop is true");
        near(p1.fadeSec(), 2.0, "Payload fadeSec");
        near(p1.pitch(), 1.2, "Payload pitch");
        check(!p1.stop(), "Payload stop is false");
        check(p1.type().equals(PlayAudioPayload.TYPE), "Payload type is settledlands:play_audio");

        // Stop payload:
        PlayAudioPayload pStop = new PlayAudioPayload("", 0.0, 0.0, 0.0, 0.0f, 0.0f, false, 1.5f, 1.0f, true);
        check(pStop.stop(), "Stop payload stop is true");
        near(pStop.fadeSec(), 1.5, "Stop payload fadeSec");

        // 4. AudioStreamPlayer distance attenuation and fade math
        File dummyFile = new File("dummy.ogg");
        Vec3 origin = new Vec3(0, 0, 0);

        // Test non-spatial sound (radius <= 0):
        AudioStreamPlayer player2D = new AudioStreamPlayer(dummyFile, origin, 0.0f, 0.9f, false, 0.0f, 1.0f, false);
        near(player2D.computeEffectiveVolume(), 0.9, "Radius <= 0 has no distance attenuation");
        check(!player2D.isMusic(), "player2D is not music");

        // Test spatial sound (radius = 50, volume = 1.0):
        AudioStreamPlayer playerSpatial = new AudioStreamPlayer(dummyFile, origin, 50.0f, 1.0f, false, 0.0f, 1.0f, true);
        near(playerSpatial.computeEffectiveVolume(), 1.0, "Base volume preserved");
        check(playerSpatial.isMusic(), "playerSpatial is music");

        // Test stop fade triggering:
        player2D.stopPlaying(0.0f);
        near(player2D.computeEffectiveVolume(), 0.0, "Instant stop gives 0 volume");

        // 5. ClientAudioService differentiation: music suppresses vanilla, sounds do not
        ClientAudioService.stopAll(0.0f);
        check(!ClientAudioService.isCustomMusicPlaying(), "Initially custom music is not playing");
        check(ClientAudioService.getActiveMusicPlayer() == null, "No active music player initially");

        // Handling a sound payload:
        PlayAudioPayload soundPkt = new PlayAudioPayload("bell_ding.wav", 0, 0, 0, 0, 1.0f, false, 0, 1.0f, false);
        ClientAudioService.handlePacket(soundPkt);
        check(!ClientAudioService.isCustomMusicPlaying(), "Playing a sound does NOT flag custom music active");
        check(ClientAudioService.getActiveMusicPlayer() == null, "Playing a sound leaves activeMusicPlayer null");

        // Handling a music payload:
        PlayAudioPayload musicPkt = new PlayAudioPayload("test_track.ogg", 0, 0, 0, 0, 1.0f, false, 0, 1.0f, false);
        ClientAudioService.handlePacket(musicPkt);
        check(ClientAudioService.getActiveMusicPlayer() != null, "Playing music registers activeMusicPlayer");
        check(ClientAudioService.isCustomMusicPlaying(), "Playing music flags custom music active");

        // Playing a sound while music is playing:
        ClientAudioService.handlePacket(soundPkt);
        check(ClientAudioService.getActiveMusicPlayer() != null, "Playing a sound does NOT stop currently playing music!");
        check(ClientAudioService.isCustomMusicPlaying(), "Custom music remains active when sound is played");

        // Testing ClientAudioEvents suppression:
        SelectMusicEvent selEvent1 = new SelectMusicEvent(null, null);
        ClientAudioEvents.onSelectMusic(selEvent1);
        check(selEvent1.isCanceled(), "Vanilla SelectMusicEvent is canceled while custom music is playing");

        // Testing replacing track instantly without fade (fadeSec == 0.0f):
        PlayAudioPayload musicPkt2 = new PlayAudioPayload("epic_battle.mp3", 0, 0, 0, 0, 0.8f, false, 0.0f, 1.0f, false);
        ClientAudioService.handlePacket(musicPkt2);
        check(ClientAudioService.getActiveMusicPlayer() != null, "Replaced music player is active");
        check(ClientAudioService.getActiveMusicPlayer().getFile().getName().equals("epic_battle.mp3"), "New track is epic_battle.mp3");
        check(ClientAudioService.isCustomMusicPlaying(), "Custom music remains active after instant replacement");

        // Stop music and verify suppression is released:
        ClientAudioService.stopMusic(0.0f);
        check(!ClientAudioService.isCustomMusicPlaying(), "Custom music inactive after stopMusic");
        SelectMusicEvent selEvent2 = new SelectMusicEvent(null, null);
        ClientAudioEvents.onSelectMusic(selEvent2);
        check(!selEvent2.isCanceled(), "Vanilla SelectMusicEvent is NOT canceled when no custom music is playing");

        // Clean up dummy test files
        try {
            Files.deleteIfExists(dummyOgg);
            Files.deleteIfExists(dummyWav);
            Files.deleteIfExists(dummyMp3);
            Files.deleteIfExists(dummySound);
            ClientAudioService.stopAll(0.0f);
        } catch (Exception ignored) {}

        System.out.println("PASS: " + checks + " assertions on audio subsystem, radius attenuation, and /play command");
        System.out.println("No Minecraft client, world, or audio hardware was started.");
    }
}
