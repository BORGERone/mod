import dev.settledlands.model.BbAnimation;
import dev.settledlands.model.BbModel;
import dev.settledlands.model.BbModelManager;
import dev.settledlands.model.BbModelParser;
import dev.settledlands.model.BbModelStorage;
import net.minecraft.client.model.geom.ModelPart;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class BbModelHarness {
    static int checks;
    static void check(boolean b, String s) { checks++; if (!b) throw new AssertionError(s); }
    static void near(double a, double b, String s) { check(Math.abs(a - b) < 1e-3, s + " expected " + b + " got " + a); }

    public static void main(String[] args) {
        // 1. BbModelStorage tests
        BbModelStorage.init();
        Path modelsDir = Path.of("settledlands/models");
        check(Files.exists(modelsDir), "BbModelStorage creates settledlands/models directory");
        check(Files.exists(modelsDir.resolve("README.txt")), "BbModelStorage creates README.txt");

        try {
            Path dummy1 = modelsDir.resolve("guard.bbmodel");
            Path dummy2 = modelsDir.resolve("wizard.bbmodel");
            Path dummyTxt = modelsDir.resolve("notes.txt");
            Files.writeString(dummy1, "dummy");
            Files.writeString(dummy2, "dummy");
            Files.writeString(dummyTxt, "dummy");

            List<String> list = BbModelStorage.listAvailableModels();
            check(list.contains("guard.bbmodel"), "listAvailableModels contains guard.bbmodel");
            check(list.contains("wizard.bbmodel"), "listAvailableModels contains wizard.bbmodel");
            check(!list.contains("notes.txt"), "listAvailableModels excludes non-bbmodel files");
            check(!list.contains("README.txt"), "listAvailableModels excludes README.txt");

            File foundNoExt = BbModelStorage.findModelFile("guard");
            check(foundNoExt != null && foundNoExt.getName().equals("guard.bbmodel"), "findModelFile without extension");

            File foundExt = BbModelStorage.findModelFile("guard.bbmodel");
            check(foundExt != null && foundExt.getName().equals("guard.bbmodel"), "findModelFile with extension");

            Files.deleteIfExists(dummy1);
            Files.deleteIfExists(dummy2);
            Files.deleteIfExists(dummyTxt);
        } catch (Exception e) {
            throw new AssertionError("BbModelStorage file test failed", e);
        }

        // 2. BbAnimation keyframe interpolation tests
        Map<String, List<BbAnimation.Keyframe>> channels = Map.of(
            "head/rotation", List.of(
                new BbAnimation.Keyframe(0.0f, 0.0f, 0.0f, 0.0f, "linear"),
                new BbAnimation.Keyframe(1.0f, 10.0f, 20.0f, 0.0f, "linear"),
                new BbAnimation.Keyframe(2.0f, 0.0f, 0.0f, 0.0f, "linear")
            ),
            "head/position", List.of(
                new BbAnimation.Keyframe(0.0f, 0.0f, 0.0f, 0.0f, "step"),
                new BbAnimation.Keyframe(1.0f, 5.0f, 0.0f, 0.0f, "step")
            )
        );
        BbAnimation anim = new BbAnimation("idle", 2.0f, "loop", channels);
        check(anim.getName().equals("idle"), "Animation name is idle");
        near(anim.getLength(), 2.0f, "Animation length");
        check(anim.hasBoneChannel("head", "rotation"), "Has head/rotation channel");
        check(!anim.hasBoneChannel("leg", "rotation"), "Does not have leg/rotation channel");
        check(anim.getAnimatedBones().contains("head"), "Animation tracks head bone");

        // Test linear interpolation at t=0.5s:
        float[] rotHalf = anim.sample(0.5f, "head", "rotation");
        near(rotHalf[0], 5.0f, "Rot X at t=0.5");
        near(rotHalf[1], 10.0f, "Rot Y at t=0.5");

        // Test loop wrapping at t=2.5s (should equal t=0.5s):
        float[] rotWrapped = anim.sample(2.5f, "head", "rotation");
        near(rotWrapped[0], 5.0f, "Rot X wrapped at t=2.5");

        // Test step interpolation at t=0.5s:
        float[] posStep = anim.sample(0.5f, "head", "position");
        near(posStep[0], 0.0f, "Step interpolation holds first value before step");

        // 3. BbModelParser full integration test
        String sampleBbmodel = """
        {
          "meta": { "format_version": "4.10", "model_format": "free" },
          "name": "test_npc",
          "resolution": { "width": 64, "height": 64 },
          "elements": [
            {
              "name": "body_box",
              "from": [-4, 12, -2],
              "to": [4, 24, 2],
              "origin": [0, 12, 0],
              "faces": {
                "north": { "uv": [20, 20, 28, 32], "texture": 0 },
                "south": { "uv": [32, 20, 40, 32], "texture": 0 },
                "up":    { "uv": [20, 16, 28, 20], "texture": 0 }
              },
              "uuid": "elem-body"
            },
            {
              "name": "head_box",
              "from": [-4, 24, -4],
              "to": [4, 32, 4],
              "origin": [0, 24, 0],
              "faces": {
                "north": { "uv": [8, 8, 16, 16], "texture": 0 },
                "up":    { "uv": [8, 0, 16, 8], "texture": 0 }
              },
              "uuid": "elem-head"
            }
          ],
          "outliner": [
            {
              "name": "body",
              "origin": [0, 12, 0],
              "rotation": [0, 0, 0],
              "uuid": "group-body",
              "children": [
                "elem-body",
                {
                  "name": "head",
                  "origin": [0, 24, 0],
                  "rotation": [0, 0, 0],
                  "uuid": "group-head",
                  "children": [ "elem-head" ]
                }
              ]
            }
          ],
          "textures": [
            {
              "name": "skin.png",
              "id": "0",
              "source": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
            }
          ],
          "animations": [
            {
              "name": "idle",
              "length": 2.0,
              "loop": "loop",
              "animators": {
                "group-head": {
                  "name": "head",
                  "type": "bone",
                  "keyframes": [
                    { "channel": "rotation", "time": 0.0, "data_points": [{ "x": 0, "y": 0, "z": 0 }] },
                    { "channel": "rotation", "time": 1.0, "data_points": [{ "x": 5, "y": 0, "z": 0 }] }
                  ]
                }
              }
            },
            {
              "name": "walk",
              "length": 1.0,
              "loop": "loop",
              "animators": {}
            },
            {
              "name": "talk",
              "length": 1.5,
              "loop": "loop",
              "animators": {}
            }
          ]
        }
        """;

        try {
            BbModel model = BbModelParser.parse("test_npc", sampleBbmodel, null);
            check(model != null, "Parsed BbModel is not null");
            check(model.getName().equals("test_npc"), "Model name is test_npc");
            check(model.getTextureWidth() == 64, "Texture width is 64");
            check(model.getTextureHeight() == 64, "Texture height is 64");
            check(model.getRootPart() != null, "Root ModelPart baked successfully");

            check(model.getPart("body") != null, "Contains body ModelPart");
            check(model.getPart("head") != null, "Contains head ModelPart");

            check(model.hasAnimation("idle"), "Has idle animation");
            check(model.hasAnimation("walk"), "Has walk animation");
            check(model.hasAnimation("talk"), "Has talk animation");

            BbAnimation idleAnim = model.findAnimation("idle");
            check(idleAnim != null, "findAnimation finds idle");
            near(idleAnim.getLength(), 2.0f, "Idle animation length is 2.0s");

            BbAnimation foundIdle = model.findIdleAnimation();
            check(foundIdle != null && foundIdle.getName().equals("idle"), "findIdleAnimation resolves idle clip");

            // 4. BbModelManager caching tests
            BbModelManager.clearCache();
            Path testFile = modelsDir.resolve("sample.bbmodel");
            Files.writeString(testFile, sampleBbmodel);

            BbModel loaded = BbModelManager.getModel("sample");
            check(loaded != null, "BbModelManager loads model by name without extension");
            check(loaded.hasAnimation("idle"), "Loaded model has idle animation");

            BbModel loadedAgain = BbModelManager.getModel("sample.bbmodel");
            check(loadedAgain == loaded, "BbModelManager returns cached instance");

            BbModelManager.clearCache();
            Files.deleteIfExists(testFile);

            // 5. Real Provodnik Blockbench 5.0 / GeckoLib Model verification
            File provodnikFile = new File("/home/user/google_drive/provodnik.bbmodel");
            if (!provodnikFile.exists()) {
                provodnikFile = new File("/tmp/provodnik.bbmodel");
            }
            if (provodnikFile.exists()) {
                BbModel provodnikModel = BbModelParser.parse(provodnikFile);
                check(provodnikModel != null, "Parsed provodnik.bbmodel is not null");
                check(provodnikModel.getTextureWidth() == 192, "provodnik.bbmodel texture width is 192");
                check(provodnikModel.getTextureHeight() == 128, "provodnik.bbmodel texture height is 128");
                check(provodnikModel.getPart("root") != null, "Contains root ModelPart");
                check(provodnikModel.getPart("body") != null, "Contains body ModelPart");
                check(provodnikModel.getPart("head") != null, "Contains head ModelPart");
                check(provodnikModel.getPart("right_arm") != null, "Contains right_arm ModelPart");
                check(provodnikModel.getPart("left_arm") != null, "Contains left_arm ModelPart");
                check(provodnikModel.getPart("right_leg") != null, "Contains right_leg ModelPart");
                check(provodnikModel.getPart("left_leg") != null, "Contains left_leg ModelPart");
                check(provodnikModel.getPart("weapon") != null, "Contains weapon ModelPart");
                check(provodnikModel.getPartsByName().size() >= 38, "Contains at least 38 indexed bones: got " + provodnikModel.getPartsByName().size());

                // Verify that provodnik does NOT accidentally run non-looping action animation as idle:
                check(provodnikModel.findIdleAnimation() == null, "findIdleAnimation returns null for provodnik (no false idle playback of attack pose)");
                check(provodnikModel.hasAnimation("animation"), "Has parsed combat action animation clip");
            }

            // 6. NpcConfigScreen UI bytecode verification
            try {
                Class<?> screenCls = Class.forName("dev.settledlands.npc.client.NpcConfigScreen");
                check(screenCls != null, "NpcConfigScreen class is loadable");
            } catch (ClassNotFoundException ignored) {}

            // 7. GuideNpc scale synchronization verification
            try {
                Class<?> npcCls = Class.forName("dev.settledlands.npc.GuideNpc", false, BbModelHarness.class.getClassLoader());
                check(npcCls != null, "GuideNpc class is loadable");
                check(npcCls.getMethod("visualScale") != null, "GuideNpc has visualScale() method");
                check(npcCls.getMethod("setClientScale", int.class) != null, "GuideNpc has setClientScale(int) method");
                check(npcCls.getMethod("getScale") != null, "GuideNpc overrides getScale() method");
            } catch (Throwable t) {
                throw new AssertionError("GuideNpc scale verification failed", t);
            }

            // 8. Multi-level LOD and Black Cavity Protection Verification
            String lodTestModelJson = """
            {
              "meta": { "format_version": "4.10", "model_format": "free" },
              "name": "lod_test",
              "resolution": { "width": 128, "height": 128 },
              "elements": [
                {
                  "name": "main_torso",
                  "from": [-4, 0, -2],
                  "to": [4, 12, 2],
                  "faces": {
                    "north": { "uv": [10, 10, 20, 20], "texture": 0 }
                  },
                  "uuid": "elem-torso"
                },
                {
                  "name": "skull_cavity",
                  "from": [-2, 2, -1],
                  "to": [2, 10, 1],
                  "faces": {
                    "north": { "uv": [127, 127, 128, 128], "texture": 0 }
                  },
                  "uuid": "elem-cavity"
                },
                {
                  "name": "micro_stitch",
                  "from": [0, 0, 0],
                  "to": [0.5, 0.5, 0.5],
                  "faces": {
                    "north": { "uv": [10, 10, 11, 11], "texture": 0 }
                  },
                  "uuid": "elem-micro"
                },
                {
                  "name": "medium_belt_buckle",
                  "from": [-1, 0, 0],
                  "to": [1, 2, 0.5],
                  "faces": {
                    "north": { "uv": [10, 10, 12, 12], "texture": 0 }
                  },
                  "uuid": "elem-buckle"
                }
              ],
              "outliner": [
                {
                  "name": "body",
                  "origin": [0, 0, 0],
                  "rotation": [0, 0, 0],
                  "uuid": "group-body",
                  "children": [ "elem-torso", "elem-cavity", "elem-micro", "elem-buckle" ]
                }
              ],
              "textures": [
                {
                  "name": "t.png",
                  "id": "0",
                  "source": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
                }
              ]
            }
            """;
            BbModel lodModel = BbModelParser.parse("lod_test", lodTestModelJson, null);
            check(lodModel != null, "Parsed lod_test model");
            ModelPart bodyPart = lodModel.getPart("body");
            check(bodyPart != null, "Found body part in lod_test model");
            java.lang.reflect.Field cubesField = ModelPart.class.getDeclaredField("cubes");
            cubesField.setAccessible(true);
            @SuppressWarnings("unchecked")
            List<ModelPart.Cube> cubes = (List<ModelPart.Cube>) cubesField.get(bodyPart);
            check(cubes.size() == 1, "Body has 1 combined BbPerFaceCube");
            BbModelParser.BbPerFaceCube perFaceCube = (BbModelParser.BbPerFaceCube) cubes.get(0);

            // LOD 0: all 4 quads present
            check(perFaceCube.quads.length == 4, "LOD 0 contains all 4 quads: torso, cavity, micro, buckle (got " + perFaceCube.quads.length + ")");

            // LOD 1: micro_stitch is culled, but torso, cavity, buckle are kept (3 quads)
            check(perFaceCube.lod1Quads.length == 3, "LOD 1 culls micro_stitch, keeps torso, cavity, buckle (got " + perFaceCube.lod1Quads.length + ")");

            // LOD 2: both micro_stitch and medium_belt_buckle are culled; torso and black cavity MUST BE KEPT! (2 quads)
            check(perFaceCube.lod2Quads.length == 2, "LOD 2 silhouette culls small accessories, but strictly preserves torso and black cavity (got " + perFaceCube.lod2Quads.length + ")");

            // Verify black cavity UV [127, 127, 128, 128] is preserved in LOD 2
            boolean cavityFoundInLod2 = false;
            for (BbModelParser.Quad q : perFaceCube.lod2Quads) {
                if (Math.abs(q.u0 - 128.0f / 128.0f) < 1e-3f || Math.abs(q.u1 - 127.0f / 128.0f) < 1e-3f) {
                    cavityFoundInLod2 = true;
                    break;
                }
            }
            check(cavityFoundInLod2, "Internal black cavity [127, 127, 128, 128] is strictly present in LOD 2");

            // Build 106: Bone Masking & Layering tests
            check(lodModel.isBoneInMask("head", "head"), "head matches head mask");
            check(!lodModel.isBoneInMask("body", "head"), "body does not match head mask");
            check(lodModel.isBoneInMask("head_box", "голова"), "head_box matches russian 'голова' alias");
            check(lodModel.isBoneInMask("right_arm", "right_arm"), "right_arm matches right_arm mask");
            check(lodModel.isBoneInMask("left_leg", "all"), "'all' mask matches any bone");
            check(lodModel.isBoneInMask("any_bone", ""), "empty mask matches any bone");

            // Build 106+: Bezier Curves & Easing Functions tests
            near(BbAnimation.evalEasing("easeInQuad", 0.5f), 0.25f, "easeInQuad at 0.5 is 0.25");
            near(BbAnimation.evalEasing("easeOutQuad", 0.5f), 0.75f, "easeOutQuad at 0.5 is 0.75");
            check(BbAnimation.evalEasing("easeInBack", 0.5f) < 0.0f, "easeInBack has negative anticipation dip at 0.5");
            near(BbAnimation.evalEasing("linear", 0.5f), 0.5f, "linear easing at 0.5 is 0.5");

            // Test Bezier & Easing keyframe sampling
            Map<String, List<BbAnimation.Keyframe>> testChannels = new HashMap<>();
            List<BbAnimation.Keyframe> easeKfs = new ArrayList<>();
            easeKfs.add(new BbAnimation.Keyframe(0.0f, 0.0f, 0.0f, 0.0f, "linear", "easeInQuad", null, null, null, null));
            easeKfs.add(new BbAnimation.Keyframe(1.0f, 100.0f, 0.0f, 0.0f, "linear", "easeInQuad", null, null, null, null));
            testChannels.put("arm/rotation", easeKfs);

            List<BbAnimation.Keyframe> bezKfs = new ArrayList<>();
            bezKfs.add(new BbAnimation.Keyframe(0.0f, 0.0f, 0.0f, 0.0f, "bezier", "", null, null, new float[]{0.3f, 0.3f, 0.3f}, new float[]{50.0f, 0.0f, 0.0f}));
            bezKfs.add(new BbAnimation.Keyframe(1.0f, 10.0f, 0.0f, 0.0f, "bezier", "", new float[]{-0.3f, -0.3f, -0.3f}, new float[]{20.0f, 0.0f, 0.0f}, null, null));
            testChannels.put("head/rotation", bezKfs);

            BbAnimation testAnim = new BbAnimation("test_curves", 1.0f, "once", testChannels);
            float[] sampleEase = testAnim.sample(0.5f, "arm", "rotation");
            check(sampleEase != null, "Sampled ease animation at 0.5s");
            near(sampleEase[0], 25.0f, "easeInQuad produces 25.0 instead of linear 50.0");

            float[] sampleBez = testAnim.sample(0.5f, "head", "rotation");
            check(sampleBez != null, "Sampled bezier animation at 0.5s");
            check(sampleBez[0] > 10.0f, "Bezier curve with upward handles produces non-linear arch > 10.0");

            // Test null-safe JSON parsing with null easing and handles
            String jsonWithNulls = """
            {
              "meta": {"format_version": "4.10"},
              "name": "null_test",
              "resolution": {"width": 64, "height": 64},
              "elements": [],
              "outliner": [],
              "animations": [
                {
                  "name": "idle_null",
                  "length": 1.0,
                  "loop": "loop",
                  "animators": {
                    "bone1": {
                      "name": "body",
                      "keyframes": [
                        {
                          "channel": null,
                          "time": null,
                          "interpolation": null,
                          "easing": null,
                          "bezier_left_time": null,
                          "bezier_left_value": null,
                          "bezier_right_time": null,
                          "bezier_right_value": null,
                          "data_points": [{"x": 0, "y": 0, "z": 0}]
                        },
                        {
                          "channel": "rotation",
                          "time": 1.0,
                          "interpolation": "linear",
                          "easing": null,
                          "data_points": [{"x": 10, "y": 20, "z": 30}]
                        }
                      ]
                    }
                  }
                }
              ]
            }
            """;
            BbModel nullModel = BbModelParser.parse("null_test", jsonWithNulls, null);
            check(nullModel != null, "BbModelParser cleanly parses models with null JSON properties without throwing JsonNull");
            check(nullModel.hasAnimation("idle_null"), "Parsed animation with null properties");
            BbAnimation nullAnim = nullModel.findAnimation("idle_null");
            check(nullAnim != null, "findAnimation finds idle_null");
            float[] nullSample = nullAnim.sample(0.5f, "body", "rotation");
            check(nullSample != null, "Sampled animation with null properties successfully");
            near(nullSample[0], 5.0f, "Linear interpolation with null easing defaults to clean lerp (x=5.0)");

        } catch (Exception e) {
            throw new AssertionError("BbModelParser test failed", e);
        }

        System.out.println("PASS: " + checks + " assertions on Blockbench .bbmodel loader, geometry, texture, and animations");
        System.out.println("No Minecraft client, world, or renderer was started.");
    }
}
