import dev.settledlands.npc.NpcDialogueGraph;
import dev.settledlands.npc.client.NpcGraphCanvas;
import dev.settledlands.npc.client.NpcGraphContextMenu;

/** Actual popup/gesture/viewport/model bytecode; no input/render API doubles required. */
public final class ContextMenuHarness {
    static int checks;
    static void check(boolean b,String s){checks++;if(!b)throw new AssertionError(s);}
    static void near(double a,double b,String s){check(Math.abs(a-b)<1e-7,s);}
    public static void main(String[] args){
        NpcGraphCanvas c=new NpcGraphCanvas();c.bounds(8,64,500,400);
        NpcGraphContextMenu m=new NpcGraphContextMenu();
        m.press(200,200);check(m.isPressed()&&!m.open,"press only arms gesture");
        check(m.release(200,200,c)&&m.open&&!m.isPressed(),"stationary right release opens popup");
        near(m.worldX,c.worldX(200),"spawn x captured under mouse");near(m.worldY,c.worldY(200),"spawn y captured under mouse");
        check(m.rowAt(m.left+10,m.top+5)==-1,"header is not an action");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+5)==0,"line creation row");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+NpcGraphContextMenu.ROW_H+5)==1,"button creation row");
        check(m.rowAt(m.left-1,m.top)==-1&&!m.contains(m.left+m.width,m.top),"popup hit bounds exclude outside");
        m.close();check(!m.open&&m.rowAt(200,200)==-1,"dismiss disables popup clicks");
        m.press(210,180);check(!m.drag(212,181),"small hand jitter does not pan");
        check(m.release(212,181,c)&&m.open,"small hand jitter still opens menu");
        near(m.worldX,c.worldX(210),"spawn uses original click, not jitter");
        m.press(220,180);check(m.drag(224,180),"four pixels crosses pan threshold");
        near(m.deltaX,4,"first pan includes threshold motion");near(m.deltaY,0,"first vertical pan");
        double pan=c.panX;c.pan(m.deltaX,m.deltaY);check(m.drag(234,188),"continued right drag pans");
        near(m.deltaX,10,"subsequent pan is incremental");near(m.deltaY,8,"subsequent vertical pan");c.pan(m.deltaX,m.deltaY);
        near(c.panX,pan+14,"no panning motion lost or doubled");
        check(!m.release(234,188,c)&&!m.open,"right drag release never opens creation menu");
        m.press(200,200);check(!m.release(210,200,c)&&!m.open,"large motion without drag events cannot accidentally click");
        m.press(0,0);check(!m.release(0,0,c)&&!m.open,"outside canvas does not open");
        m.press(200,200);m.cancel();check(!m.isPressed()&&!m.open&&!m.drag(220,220),"Escape/cancel clears gesture");
        check(!m.release(200,200,c),"unarmed release is ignored");
        m.show(c.right-1,c.bottom-1,c);check(m.left+m.width<=c.right&&m.top+m.height<=c.bottom,"popup stays inside bottom/right canvas edge");
        m.show(c.left,c.top,c);check(m.left==c.left&&m.top==c.top,"popup stays inside top/left edge");
        c.zoomAt(-100,100,100);c.pan(42,-15);m.show(180,220,c);
        near(m.worldX,c.worldX(180),"spawn follows current zoom and pan");near(m.worldY,c.worldY(220),"spawn y follows zoom and pan");
        NpcDialogueGraph g=new NpcDialogueGraph();var n=g.add(NpcDialogueGraph.LINE,0,0);c.move(n,m.worldX,m.worldY);
        check(Math.abs(n.x-m.worldX)<=4&&Math.abs(n.y-m.worldY)<=4,"created node is at click point within grid snap tolerance");
        c.bounds(8,64,100,200);m.show(99,199,c);check(m.width==92&&m.left==8&&m.top+m.height<=200,"narrow canvas popup remains bounded");
        m.showForWire(150,160,c,42);
        check(m.open&&m.pendingWireFrom==42,"showForWire sets open and pendingWireFrom");
        near(m.worldX,c.worldX(150),"wire release worldX matches drop coordinates");
        near(m.worldY,c.worldY(160),"wire release worldY matches drop coordinates");
        m.close();
        check(!m.open&&m.pendingWireFrom==-1,"close resets pendingWireFrom");
        m.showForWire(180,190,c,7);
        m.cancel();
        check(!m.open&&m.pendingWireFrom==-1,"cancel resets pendingWireFrom");
        check(NpcGraphContextMenu.TOTAL_ROWS==15,"context menu has 15 total items (+cutscene)");
        check(NpcGraphContextMenu.VISIBLE_ROWS==5,"context menu displays 5 rows at a time for compactness");
        c.bounds(8,64,500,400);
        m.show(200,200,c);
        check(m.scrollRow==0,"initially scrollRow is 0");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+5)==0,"visual row 0 is line");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+NpcGraphContextMenu.ROW_H*2+5)==2,"visual row 2 is trigger");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+NpcGraphContextMenu.ROW_H*4+5)==4,"visual row 4 is variable");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+NpcGraphContextMenu.ROW_H*5+5)==-1,"row 5 is beyond visible rows when scrollRow=0");

        // Test scrolling down:
        m.scroll(1);
        check(m.scrollRow==1,"scroll(1) increments scrollRow to 1");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+5)==1,"after scroll(1), top row is button (row 1)");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+NpcGraphContextMenu.ROW_H*4+5)==5,"after scroll(1), bottom row is check (row 5)");

        m.scroll(9);
        check(m.scrollRow==10,"scrollRow reaches maximum 10 (15 - 5)");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+NpcGraphContextMenu.ROW_H*2+5)==12,"row 12 is MOBILITY node");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+NpcGraphContextMenu.ROW_H*3+5)==13,"row 13 is RANDOM node");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+NpcGraphContextMenu.ROW_H*4+5)==14,"row 14 is CUTSCENE node");

        m.scroll(10);
        check(m.scrollRow==10,"scroll does not exceed maximum scroll limit");
        m.scroll(-10);
        check(m.scrollRow==0,"scroll does not go below 0");

        // Test scrollbar hit detection and dragging:
        int sbX = m.left + m.width - 3;
        int sbY = m.top + NpcGraphContextMenu.HEADER_H + 20;
        check(m.isScrollbar(sbX, sbY),"isScrollbar detects click on scrollbar track");
        check(m.rowAt(sbX, sbY)==-1,"clicking scrollbar track does not select an action item");

        m.scrollbarDrag(m.top + m.height - 2);
        check(m.scrollRow==10,"dragging scrollbar to bottom sets scrollRow to max");
        m.scrollbarDrag(m.top + NpcGraphContextMenu.HEADER_H + 2);
        check(m.scrollRow==0,"dragging scrollbar to top sets scrollRow to 0");

        m.showForWire(220,240,c,99,1);
        check(m.open&&m.pendingWireFrom==99&&m.pendingWirePort==1,"wire pull with port sets pendingWireFrom and pendingWirePort");
        m.close();

        // Node-specific context menu (copy/delete):
        m.showForNode(200,200,c,42);
        check(m.open&&m.targetNodeId==42,"node context menu sets targetNodeId");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+5)==0,"node copy row");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+NpcGraphContextMenu.ROW_H+5)==1,"node delete row");
        check(m.rowAt(m.left+10,m.top+NpcGraphContextMenu.HEADER_H+NpcGraphContextMenu.ROW_H*2+5)==-1,"node context menu only has 2 rows");
        m.close();
        check(!m.open&&m.targetNodeId==-1,"close resets targetNodeId");

        // Build 89: PopupHost dropdown and CommandTabCompleter on NpcDialogueGraphScreen
        try {
            Class<?> hostCls = Class.forName("dev.settledlands.npc.client.NpcUi$PopupHost");
            Class<?> screenCls = Class.forName("dev.settledlands.npc.client.NpcDialogueGraphScreen");
            check(hostCls.isAssignableFrom(screenCls), "NpcDialogueGraphScreen implements NpcUi.PopupHost");

            java.lang.reflect.Method trigBoxMethod = dev.settledlands.npc.client.CommandTabCompleter.class.getDeclaredMethod("triggerBox", Object.class);
            trigBoxMethod.setAccessible(true);

            dev.settledlands.npc.NpcProfile profile = new dev.settledlands.npc.NpcProfile();
            profile.dialogueGraph = g;
            dev.settledlands.npc.client.NpcDialogueGraphScreen screen = new dev.settledlands.npc.client.NpcDialogueGraphScreen(1, profile, null, -1);
            check(screen.activeDropdown() == null, "activeDropdown initially null");

            java.lang.reflect.Field trigBoxField = screenCls.getDeclaredField("triggerBox");
            trigBoxField.setAccessible(true);
            check(trigBoxMethod.invoke(null, screen) == null, "triggerBox without widget returns null");

            net.minecraft.client.gui.components.EditBox box = new net.minecraft.client.gui.components.EditBox(null, 10, 20, 100, 20, net.minecraft.network.chat.Component.empty());
            trigBoxField.set(screen, box);
            check(trigBoxMethod.invoke(null, screen) == box, "triggerBox on NpcDialogueGraphScreen correctly discovered");

            java.lang.reflect.Method fallbackMethod = dev.settledlands.npc.client.CommandTabCompleter.class.getDeclaredMethod("fallbackCandidates", Class.forName("dev.settledlands.npc.client.CommandTabCompleter$Context"));
            fallbackMethod.setAccessible(true);
            java.lang.reflect.Constructor<?> ctxCons = Class.forName("dev.settledlands.npc.client.CommandTabCompleter$Context").getDeclaredConstructor(String.class, int.class, int.class, String.class, String.class, String.class, boolean.class);
            ctxCons.setAccessible(true);
            Object ctx = ctxCons.newInstance("/go ", 4, 0, "/", "go ", "", false);
            java.util.List<?> fallbacks = (java.util.List<?>)fallbackMethod.invoke(null, ctx);
            check(!fallbacks.isEmpty(), "fallback candidates available for /go command tab completion");

            Object ctxTrig = ctxCons.newInstance("trigger:", 8, 0, "trigger:", "", "", true);
            java.lang.reflect.Method trigCandMethod = dev.settledlands.npc.client.CommandTabCompleter.class.getDeclaredMethod("triggerCandidates", Class.forName("dev.settledlands.npc.client.CommandTabCompleter$Context"));
            trigCandMethod.setAccessible(true);
            java.util.List<?> trigCands = (java.util.List<?>)trigCandMethod.invoke(null, ctxTrig);
            check(trigCands.size() >= 10, "trigger tab candidates include all standard SettledLands actions");

            // Build 92: Box selection, multiSelected and MMB / Space panning
            dev.settledlands.npc.NpcProfile testProfile = new dev.settledlands.npc.NpcProfile();
            NpcDialogueGraph testGraph = new NpcDialogueGraph();
            NpcDialogueGraph.Node n1 = testGraph.add(NpcDialogueGraph.LINE, 96, 96);
            NpcDialogueGraph.Node n2 = testGraph.add(NpcDialogueGraph.BUTTON, 288, 96);
            NpcDialogueGraph.Node n3 = testGraph.add(NpcDialogueGraph.TRIGGER, 600, 96);
            testProfile.dialogueGraph = testGraph;
            dev.settledlands.npc.client.NpcDialogueGraphScreen boxScreen = new dev.settledlands.npc.client.NpcDialogueGraphScreen(1, testProfile, null, -1);

            check(boxScreen.multiSelected.isEmpty(), "multiSelected initially empty");

            boxScreen.multiSelected.add(n1.id);
            boxScreen.multiSelected.add(n2.id);
            check(boxScreen.multiSelected.size() == 2, "multiSelected holds 2 nodes");
            check(boxScreen.multiSelected.contains(n1.id) && boxScreen.multiSelected.contains(n2.id), "multiSelected contains n1 and n2");

            // Test box selection calculation:
            java.lang.reflect.Field boxStartXField = screenCls.getDeclaredField("boxStartX");
            java.lang.reflect.Field boxStartYField = screenCls.getDeclaredField("boxStartY");
            java.lang.reflect.Field boxCurrentXField = screenCls.getDeclaredField("boxCurrentX");
            java.lang.reflect.Field boxCurrentYField = screenCls.getDeclaredField("boxCurrentY");
            java.lang.reflect.Method updateBoxMethod = screenCls.getDeclaredMethod("updateBoxSelection");
            boxStartXField.setAccessible(true);
            boxStartYField.setAccessible(true);
            boxCurrentXField.setAccessible(true);
            boxCurrentYField.setAccessible(true);
            updateBoxMethod.setAccessible(true);

            // Canvas bounds and coordinates
            java.lang.reflect.Field canvasField = screenCls.getDeclaredField("canvas");
            canvasField.setAccessible(true);
            NpcGraphCanvas scCanvas = (NpcGraphCanvas)canvasField.get(boxScreen);
            scCanvas.bounds(0, 0, 1000, 1000);
            scCanvas.panX = 0; scCanvas.panY = 0; scCanvas.zoom = 1.0;

            // Box encompassing n1 and n2, but not n3
            boxStartXField.set(boxScreen, scCanvas.screenX(50));
            boxStartYField.set(boxScreen, scCanvas.screenY(50));
            boxCurrentXField.set(boxScreen, scCanvas.screenX(450));
            boxCurrentYField.set(boxScreen, scCanvas.screenY(250));
            updateBoxMethod.invoke(boxScreen);

            check(boxScreen.multiSelected.contains(n1.id), "box selection includes n1");
            check(boxScreen.multiSelected.contains(n2.id), "box selection includes n2");
            check(!boxScreen.multiSelected.contains(n3.id), "box selection excludes n3");

            // Test group drag relative offset preservation (using 8-pixel grid aligned deltas):
            int origN1X = n1.x, origN1Y = n1.y;
            int origN2X = n2.x, origN2Y = n2.y;
            int deltaMoveX = 32, deltaMoveY = 64;
            scCanvas.move(n1, origN1X + deltaMoveX, origN1Y + deltaMoveY);
            scCanvas.move(n2, origN2X + deltaMoveX, origN2Y + deltaMoveY);
            check(n1.x - origN1X == deltaMoveX && n1.y - origN1Y == deltaMoveY, "n1 moved by delta");
            check(n2.x - origN2X == deltaMoveX && n2.y - origN2Y == deltaMoveY, "n2 moved by same delta");
            check((n2.x - n1.x) == (origN2X - origN1X), "relative distance preserved between n1 and n2");

            // Test Delete key with multiSelected (key 261 = Delete):
            java.lang.reflect.Field graphField = screenCls.getDeclaredField("graph");
            graphField.setAccessible(true);
            NpcDialogueGraph activeGraph = (NpcDialogueGraph)graphField.get(boxScreen);
            boxScreen.keyPressed(261, 0, 0);
            check(activeGraph.get(n1.id) == null, "n1 removed on multi-delete");
            check(activeGraph.get(n2.id) == null, "n2 removed on multi-delete");
            check(activeGraph.get(n3.id) != null, "n3 untouched by multi-delete");
            check(boxScreen.multiSelected.isEmpty(), "multiSelected cleared after delete");

            // Test Space key tracking:
            java.lang.reflect.Field spaceDownField = screenCls.getDeclaredField("spaceDown");
            java.lang.reflect.Method isSpaceDownMethod = screenCls.getDeclaredMethod("isSpaceDown");
            spaceDownField.setAccessible(true);
            isSpaceDownMethod.setAccessible(true);
            check(!((Boolean)isSpaceDownMethod.invoke(boxScreen)), "isSpaceDown initially false");
            boxScreen.keyPressed(32, 0, 0);
            check(((Boolean)isSpaceDownMethod.invoke(boxScreen)), "keyPressed 32 sets spaceDown");
            boxScreen.keyReleased(32, 0, 0);
            check(!((Boolean)isSpaceDownMethod.invoke(boxScreen)), "keyReleased 32 clears spaceDown");

            // Test Middle Mouse Button (button 2) vs Right Mouse Button (button 1):
            java.lang.reflect.Field panningField = screenCls.getDeclaredField("panning");
            panningField.setAccessible(true);
            java.lang.reflect.Field selectingBoxField = screenCls.getDeclaredField("selectingBox");
            selectingBoxField.setAccessible(true);

            // MMB on canvas triggers panning, not box selection, not context menu:
            boxScreen.mouseClicked(100, 100, 2);
            check((Boolean)panningField.get(boxScreen), "MMB on empty canvas starts panning");
            check(!(Boolean)selectingBoxField.get(boxScreen), "MMB does not start box selection");
            boxScreen.mouseReleased(100, 100, 2);
            check(!(Boolean)panningField.get(boxScreen), "MMB release ends panning");

            // LMB without Space starts box selection, not panning:
            boxScreen.mouseClicked(100, 100, 0);
            check((Boolean)selectingBoxField.get(boxScreen), "LMB without Space starts box selection");
            check(!(Boolean)panningField.get(boxScreen), "LMB without Space does not start panning");
            boxScreen.mouseReleased(100, 100, 0);
            check(!(Boolean)selectingBoxField.get(boxScreen), "LMB release ends box selection");

            // LMB with Space starts panning, not box selection:
            boxScreen.keyPressed(32, 0, 0);
            boxScreen.mouseClicked(100, 100, 0);
            check((Boolean)panningField.get(boxScreen), "LMB with Space starts canvas panning");
            check(!(Boolean)selectingBoxField.get(boxScreen), "LMB with Space does not start box selection");
            boxScreen.mouseReleased(100, 100, 0);
            check(!(Boolean)panningField.get(boxScreen), "LMB release ends canvas panning");
            boxScreen.keyReleased(32, 0, 0);
        } catch (Exception ex) {
            throw new AssertionError("PopupHost / CommandTabCompleter test failed", ex);
        }

        System.out.println("PASS: "+checks+" assertions on actual context-menu gesture/spawn/viewport policy");
        System.out.println("No Minecraft client, world, GUI or renderer was started.");
    }
}
