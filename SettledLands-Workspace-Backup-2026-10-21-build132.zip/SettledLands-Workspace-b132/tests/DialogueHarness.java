import dev.settledlands.npc.*;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.neoforged.neoforge.event.tick.ServerTickEvent.Post;

/** Actual GuideDialogue/NpcEscort bytecode; the network is a capture-only API double. */
public final class DialogueHarness {
    static int checks;
    static void check(boolean condition,String message){checks++;if(!condition)throw new AssertionError(message);}
    static void restricted(NpcNet.DlgView view,String expected){
        check(view!=null&&view.text().equals(expected),"correct single line");
        check(!view.shop()&&!view.style().tradeTab()&&!view.style().questTab()&&!view.style().phrasesTab(),"no trade, quest or legacy tabs");
        check(view.options().size()==1,"only finish option");
        check(view.state()==2&&!view.observer(),"restricted state and player ownership");
    }
    public static void main(String[] args){
        MinecraftServer server=new MinecraftServer();ServerLevel level=new ServerLevel(server);
        ServerPlayer owner=new ServerPlayer(level),stranger=new ServerPlayer(level);
        GuideNpc npc=new GuideNpc(level,42);npc.profile.escortCode="road";npc.profile.escortCoordinates="100 64 0";
        npc.profile.escortTravelLine="Почти пришли";npc.profile.escortArrivalLine="Добро пожаловать домой";
        npc.beginEscort(owner,"road",new BlockPos(100,64,0));
        GuideDialogue.startEscort(owner,npc,false);restricted(NpcNet.lastView(owner),"Почти пришли");
        check(GuideDialogue.isInDialogue(owner)&&npc.isTalking(),"travel line registers a real session");
        for(int index:new int[]{-2,-3,-4,-5,1,99}){
            GuideDialogue.pick(owner,42,index);restricted(NpcNet.lastView(owner),"Почти пришли");
        }
        GuideDialogue.pick(owner,42,0);
        check(!GuideDialogue.isInDialogue(owner)&&npc.escort.phase()==NpcEscort.WALKING,"finish of travel line does not end escort");
        GuideDialogue.startEscort(stranger,npc,false);GuideDialogue.pick(stranger,42,-4);
        restricted(NpcNet.lastView(stranger),"Почти пришли");
        check(npc.escort.belongsTo(owner),"another conversation cannot replace owner");
        for(int i=0;i<20;i++){server.tick++;npc.escort.tick(npc);}
        check(npc.navigation.calls>0,"bystander travel dialogue does not hold the bound player's route hostage");
        npc.x=100.5;npc.z=0.5;owner.x=103.5;owner.z=0.5;
        npc.escort.tick(npc);npc.escort.tick(npc);
        check(npc.escort.phase()==NpcEscort.ARRIVAL_DIALOGUE,"arrival begins automatically");
        check(!GuideDialogue.isInDialogue(stranger),"bystander session cannot block the owner's automatic arrival dialogue");
        check(GuideDialogue.hasEscortArrival(owner,npc),"real arrival session recognized");
        restricted(NpcNet.lastView(owner),"Добро пожаловать домой");
        GuideDialogue.onServerTick(new Post(server));
        check(GuideDialogue.hasEscortArrival(owner,npc),"normal server tick retains arrival session");
        npc.profile.escortArrivalLine="Изменённая фраза";GuideDialogue.resend(owner,npc.profile);
        restricted(NpcNet.lastView(owner),"Изменённая фраза");
        GuideDialogue.pick(owner,42,-2);restricted(NpcNet.lastView(owner),"Изменённая фраза");
        GuideDialogue.pick(owner,42,0);
        check(!GuideDialogue.isInDialogue(owner)&&npc.escort.phase()==NpcEscort.FINISH_WAIT,"real finish button starts five-second wait");
        for(int i=0;i<99;i++){server.tick++;npc.escort.tick(npc);}
        check(npc.isEscorting(),"still escorting after 99 ticks");server.tick++;npc.escort.tick(npc);
        check(!npc.isEscorting()&&npc.finished==1,"real dialogue callback completes escort at 100 ticks");
        npc.x=0;npc.z=0;owner.x=0;owner.z=0;
        npc.beginEscort(owner,"road",new BlockPos(100,64,0));GuideDialogue.startEscort(owner,npc,false);
        GuideDialogue.closeNpcDialogues(npc);
        check(!GuideDialogue.isInDialogue(owner)&&!npc.isTalking(),"close-all clears stale sessions");
        System.out.println("PASS: "+checks+" assertions on real GuideDialogue/NpcEscort bytecode and captured packets");
        System.out.println("No renderer, game world, client or NeoForge server was started.");
    }
}
