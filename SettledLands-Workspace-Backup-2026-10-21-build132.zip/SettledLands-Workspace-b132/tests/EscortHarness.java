import dev.settledlands.npc.*;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.commands.CommandSourceStack;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import java.util.*;

/** Headless tests of production JAR bytecode with deliberately small server API doubles. */
public final class EscortHarness {
    static int checks;
    static final List<String> groups = new ArrayList<>();
    static void check(boolean value, String message) { checks++; if (!value) throw new AssertionError(message); }
    static void group(String name) { groups.add(name); }
    static final class Context {
        final MinecraftServer server = new MinecraftServer();
        final ServerLevel level = new ServerLevel(server);
        final ServerPlayer owner = new ServerPlayer(level);
        final GuideNpc npc = new GuideNpc(level, 0);
        Context() { GuideDialogue.reset(); npc.profile.escortCode="road"; npc.profile.escortCoordinates="100 64 0"; }
        void begin() { npc.beginEscort(owner,"road",new BlockPos(100,64,0)); }
        void tick() { server.tick++; if (npc.escort!=null) npc.escort.tick(npc); }
        void atGoal() { npc.x=100.5; npc.y=64; npc.z=0.5; }
        void ownerAt(double x,double z) { owner.x=x;owner.z=z; }
    }

    static void policy() {
        group("Codes, coordinate validation, distance boundaries and retry policy");
        check(EscortRules.validCode("route_12-A.b"),"legal code");
        for(String s:new String[]{"", "a b", "a/b", "рус", "x".repeat(65), "\u0000", "a+"}) check(!EscortRules.validCode(s),"invalid code: "+s);
        check(!EscortRules.validCode(null),"null code");
        check(EscortRules.validCode("a".repeat(64)),"64 character code");
        check(NpcEscort.parseCoordinates("120 64 -35",-64,320)!=null,"space coordinates");
        check(NpcEscort.parseCoordinates("120, 64, -35",-64,320)!=null,"comma coordinates");
        for(String s:new String[]{"", "1 2", "1 2 3 4", "1.5 64 2", "1 320 2", "1 -65 2", "30000000 64 1", "1 64 2147483648", "~ ~ ~"})
            check(NpcEscort.parseCoordinates(s,-64,320)==null,"invalid coordinates: "+s);
        check(NpcEscort.parseCoordinates("-29999984 -64 29999984",-64,320)!=null,"coordinate boundary");
        check(!EscortRules.shouldWait(7.49*7.49,false),"before stop margin");
        check(EscortRules.shouldWait(7.5*7.5,false),"stop at safe margin");
        check(EscortRules.shouldWait(7*7,true),"hysteresis retains pause");
        check(!EscortRules.shouldWait(6.5*6.5,true),"resume boundary");
        check(EscortRules.atDestination(100.5,64,0.5,100,64,0),"block centre arrival");
        check(!EscortRules.atDestination(100.5,67,0.5,100,64,0),"wrong floor is not arrival");
        check(EscortRules.atDestination(101,64,1,100,64,0,1.35F),"normal large NPC navigator centre");
        check(EscortRules.atDestination(101.5,64,1.5,100,64,0,2.025F),"150-percent scaled NPC can arrive");
        check(EscortRules.atDestination(100.5,64,0.5,100,64,0,0.675F),"50-percent scaled NPC can arrive");
        check(EscortRules.atDestination(102.49,64,2.49,100,64,0,2.025F),"scaled NPC arriving at vanilla axis tolerance does not loop forever");
        check(EscortRules.retryTicks(0)==20&&EscortRules.retryTicks(1)==40&&EscortRules.retryTicks(2)==80&&EscortRules.retryTicks(100)==160,"bounded backoff");
    }

    static void waiting() {
        group("Eight-block safety margin, hysteresis, talking pause and no per-tick entity query");
        Context c=new Context();c.begin();c.tick();check(c.npc.navigation.calls==1,"initial path");
        c.owner.x=7.5;c.tick();check(c.npc.navigation.done,"stop at margin");
        int calls=c.npc.navigation.calls;
        for(int i=0;i<100;i++){c.owner.x=7;c.tick();}
        check(c.npc.navigation.calls==calls,"no replan while waiting");
        c.owner.x=6.5;for(int i=0;i<25;i++)c.tick();check(c.npc.navigation.calls>calls,"resume close to player");
        c.npc.talking=true;calls=c.npc.navigation.calls;for(int i=0;i<100;i++)c.tick();
        check(c.npc.navigation.done&&c.npc.navigation.calls==calls,"pause during travel line");
        check(c.level.queries==0,"no per-tick world entity scan");
        c=new Context();c.begin();double maxDistance=0;
        for(int i=0;i<500;i++){c.tick();c.npc.advance();maxDistance=Math.max(maxDistance,Math.sqrt(c.owner.distanceToSqr(c.npc)));}
        check(maxDistance<=8,"simulated walking never goes beyond 8; got "+maxDistance);
        check(c.npc.x>7&&c.npc.x<8,"waits rather than teleporting");
    }

    static void ownerLifecycle() {
        group("Disconnect, death, spectator and dimension pauses; stable UUID ownership");
        Context c=new Context();c.begin();c.server.players.players.clear();
        for(int i=0;i<50;i++)c.tick();check(c.npc.navigation.calls==0,"offline no paths");
        c.server.players.players.put(c.owner.uuid,c.owner);c.owner.alive=false;c.tick();check(c.npc.navigation.calls==0,"dead no paths");
        c.owner.alive=true;c.owner.spectator=true;c.tick();check(c.npc.navigation.calls==0,"spectator no paths");
        c.owner.spectator=false;c.owner.world=new ServerLevel(c.server);c.tick();check(c.npc.navigation.calls==0,"different dimension no paths");
        c.owner.world=c.level;c.tick();check(c.npc.navigation.calls==1,"same owner resumes");
        ServerPlayer stranger=new ServerPlayer(c.level);check(!c.npc.escort.belongsTo(stranger),"cannot steal owner");
        check(c.npc.escort.belongsTo(c.owner),"correct UUID owner");
        CompoundTag saved=c.npc.escort.save();c.npc.escort=NpcEscort.load(saved,-64,320);
        check(c.npc.escort.owner().equals(c.owner.uuid)&&c.npc.escort.route().equals("road"),"runtime NBT round trip");
        saved.putInt("Phase",999);check(NpcEscort.load(saved,-64,320)==null,"bad phase rejected");
        saved=c.npc.escort.save();saved.putInt("Y",320);check(NpcEscort.load(saved,-64,320)==null,"bad runtime height rejected");
        check(NpcEscort.load(new CompoundTag(),-64,320)==null,"empty runtime does not activate");
    }

    static void arrival() {
        group("Arrival only for the bound player within 3 blocks; no dialogue hijack or duplicate initiation");
        Context c=new Context();c.begin();c.atGoal();c.tick();check(c.npc.escort.phase()==NpcEscort.WAIT_PLAYER,"stops at destination");
        ServerPlayer stranger=new ServerPlayer(c.level);stranger.x=100.5;stranger.z=0.5;
        for(int i=0;i<10;i++)c.tick();check(GuideDialogue.opened==0,"stranger does not trigger arrival");
        c.ownerAt(103.501,0.5);c.tick();check(GuideDialogue.opened==0,"3.001 is outside");
        c.ownerAt(103.5,0.5);GuideDialogue.busy.add(c.owner.uuid);c.tick();check(GuideDialogue.opened==0,"does not replace another dialogue");
        GuideDialogue.busy.clear();c.owner.containerMenu=new AbstractContainerMenu();c.tick();check(GuideDialogue.opened==0,"does not replace a container");
        c.owner.containerMenu=c.owner.inventoryMenu;c.tick();check(GuideDialogue.opened==1,"3 block boundary opens dialogue");
        check(c.npc.escort.phase()==NpcEscort.ARRIVAL_DIALOGUE,"arrival phase");
        for(int i=0;i<50;i++)c.tick();check(GuideDialogue.opened==1&&c.npc.finished==0,"single initiation and waits for dialogue end");
        CompoundTag saved=c.npc.escort.save();check(NpcEscort.load(saved,-64,320).phase()==NpcEscort.WAIT_PLAYER,"reload cannot restore a stale GUI");
        c.npc.escort.dialogueClosed(stranger,true);check(c.npc.escort.phase()==NpcEscort.ARRIVAL_DIALOGUE,"stranger cannot complete arrival");
        c.npc.escort.dialogueClosed(c.owner,false);check(c.npc.escort.phase()==NpcEscort.ARRIVAL_DIALOGUE,"travel dialogue does not finish escort");
        GuideDialogue.close(c.owner,c.npc);check(c.npc.escort.phase()==NpcEscort.FINISH_WAIT,"close starts cooldown");
        for(int i=0;i<99;i++)c.tick();check(c.npc.finished==0,"still active after 99 ticks");
        c.tick();check(c.npc.finished==1&&!c.npc.isEscorting(),"finished after exactly 100 ticks");
    }

    static void finishOfflineAndReload() {
        group("Five-second cooldown persists and finishes even if the owner disconnects");
        Context c=new Context();c.begin();c.atGoal();c.ownerAt(100.5,0.5);c.tick();c.tick();GuideDialogue.close(c.owner,c.npc);
        for(int i=0;i<30;i++)c.tick();CompoundTag saved=c.npc.escort.save();c.npc.escort=NpcEscort.load(saved,-64,320);
        c.server.players.players.clear();for(int i=0;i<69;i++)c.tick();check(c.npc.finished==0,"persisted 70-tick remaining cooldown");
        c.tick();check(c.npc.finished==1,"offline final cooldown completes");
        c=new Context();c.begin();c.atGoal();c.ownerAt(100.5,0.5);c.tick();c.tick();c.server.players.players.clear();c.tick();
        check(c.npc.escort.phase()==NpcEscort.FINISH_WAIT,"disconnect during arrival counts as close");
        for(int i=0;i<100;i++)c.tick();check(c.npc.finished==1,"arrival disconnect never locks NPC forever");
    }

    static void budgets() {
        group("Global path budget, bounded retry cadence, local waypoints and unloaded-chunk safety");
        Context c=new Context();c.begin();c.npc.navigation.canPath=false;
        for(int i=0;i<10000;i++)c.tick();check(c.npc.navigation.calls<70,"blocked route backoff: "+c.npc.navigation.calls);
        check(c.level.queries==0,"blocked route never scans world");
        c=new Context();c.begin();
        for(int i=0;i<10000;i++){c.npc.navigation.done=true;c.tick();}
        check(c.npc.navigation.calls<100,"partial/done paths without progress also back off: "+c.npc.navigation.calls);
        c=new Context();c.begin();c.level.loaded=false;for(int i=0;i<500;i++)c.tick();
        check(c.npc.navigation.calls==0,"does not path into unloaded waypoint");
        c=new Context();c.npc.profile.escortCoordinates="10000 64 0";c.npc.beginEscort(c.owner,"road",new BlockPos(10000,64,0));c.tick();
        check(c.npc.navigation.tx<20,"far destinations use local waypoints");
        c=new Context();List<GuideNpc> crowd=new ArrayList<>();
        for(int i=0;i<500;i++){GuideNpc n=new GuideNpc(c.level,0);n.beginEscort(c.owner,"road",new BlockPos(100,64,0));crowd.add(n);}
        int previous=0;
        for(int t=0;t<20;t++){c.server.tick++;for(GuideNpc n:crowd)n.escort.tick(n);int total=crowd.stream().mapToInt(n->n.navigation.calls).sum();
            check(total-previous<=2,"no more than 2 path searches/server tick");previous=total;}
        check(previous==40,"path budget grants exactly 40 searches over 20 ticks");
    }

    static void commandsAndGuards() throws Exception {
        group("Real Brigadier /go, contextual trigger target, duplicate-code rejection and server trade/quest guards");
        Context c=new Context();RegisterCommandsEvent event=new RegisterCommandsEvent();NpcEscortCommands.register(event);
        check(event.dispatcher.execute("go road",new CommandSourceStack(c.owner))==1,"actual /go parses and starts");
        check(c.npc.escort.belongsTo(c.owner),"command binds executing player");
        NpcEscort state=c.npc.escort;c.server.tick+=5;
        check(NpcEscortCommands.start(c.owner,c.npc,"road")&&c.npc.escort==state,"repeated go is idempotent");
        ServerPlayer stranger=new ServerPlayer(c.level);check(!NpcEscortCommands.start(stranger,c.npc,"road"),"busy owner cannot be replaced");
        NpcShop.send(c.owner,c.npc);NpcShop.buy(c.owner,c.npc.id,0,8);
        check(!NpcQuests.runActionSingle(c.owner,c.npc,0,"quest:take"),"quest action blocked");
        NpcQuests.take(c.owner,c.npc,0);NpcQuests.drop(c.owner,c.npc,0);
        check(!NpcQuests.handIn(c.owner,c.npc,null),"quest hand-in blocked");
        check(c.owner.messages==1,"guarded trade/quests neither pay nor emit normal feedback");
        c=new Context();GuideNpc duplicate=new GuideNpc(c.level,7);duplicate.profile.escortCode="road";duplicate.profile.escortCoordinates="200 64 0";
        check(!NpcEscortCommands.startNearby(c.owner,"road")&&!c.npc.isEscorting()&&!duplicate.isEscorting(),"duplicate local route not guessed");
        c.server.tick+=5;check(NpcEscortCommands.start(c.owner,duplicate,"road"),"context selects actual dialogue NPC");
        check(duplicate.isEscorting()&&!c.npc.isEscorting(),"other same-code NPC unaffected");
        c=new Context();c.npc.x=8.001;check(!NpcEscortCommands.startNearby(c.owner,"road"),"start outside eight blocks refused");
        c.server.tick+=5;c.npc.x=8;check(NpcEscortCommands.startNearby(c.owner,"road"),"start at eight block boundary permitted");
        c=new Context();c.npc.profile.escortCoordinates="1 320 2";check(!NpcEscortCommands.start(c.owner,c.npc,"road"),"invalid coordinates never activate");
        c=new Context();c.level.border.allowed=false;check(!NpcEscortCommands.start(c.owner,c.npc,"road"),"border rejects destination");
        c=new Context();check(!NpcEscortCommands.start(c.owner,c.npc,"different"),"context code must match");
        c=new Context();check(!NpcEscortCommands.startNearby(c.owner,"bad code"),"invalid manual code refused");
    }

    static void dialogueActions() {
        group("Actual dialogue command/trigger bytecode preserves player and NPC context");
        for (String action : new String[]{"/go road", "go road", "cmd: /go road", "trigger:go road", "trigger go road", "trigger:/go road", "trigger:settledlands:go road"}) {
            Context c = new Context();
            GuideNpc intended = new GuideNpc(c.level, 77);
            intended.profile.escortCode = "road"; intended.profile.escortCoordinates = "200 64 0";
            check(NpcActions.runSingle(c.owner, intended, 0, action), "dialogue action accepted: " + action);
            check(intended.isEscorting() && intended.escort.belongsTo(c.owner), "action binds speaking player: " + action);
            check(!c.npc.isEscorting(), "action never chooses another nearby same-code NPC: " + action);
            check(c.level.queries == 0, "contextual go requires no NPC search: " + action);
        }
    }


    static void catchUpPolicyAndSpeed() {
        group("Ahead-only catch-up boundaries and vanilla Mob/player walking-speed normalisation");
        check(!EscortRules.shouldCatchUp(64,10,20,false),"exactly 8 does not start catch-up");
        check(EscortRules.shouldCatchUp(64.001,10,20,false),"over 8 and closer to goal starts catch-up");
        check(!EscortRules.shouldCatchUp(100,20,10,false),"player behind goal progress cannot pull NPC back");
        check(!EscortRules.shouldCatchUp(100,20,20,false),"equal goal distance is not ahead");
        check(EscortRules.shouldCatchUp(16,10,20,true),"catch-up stays latched inside 8 until close");
        check(!EscortRules.shouldCatchUp(9,10,20,true),"catch-up ends at 3 blocks");
        check(!EscortRules.shouldCatchUp(16,20,10,true),"reversing behind NPC cancels catch-up");
        for(double attribute:new double[]{0.12,0.24,0.5}){
            double walk=EscortRules.navigationSpeed(attribute,false),run=EscortRules.navigationSpeed(attribute,true);
            check(Math.abs(Math.pow(walk*attribute,2)-0.1)<1e-12,"NPC walking acceleration matches player's 0.1");
            check(Math.abs(Math.pow(run*attribute,2)-0.16)<1e-12,"catch-up is 1.6 times walking, not a squared multiplier mistake");
            check(run>walk,"catch-up speed is faster than walking");
        }
        for(double attribute:new double[]{0,-1,Double.NaN,Double.POSITIVE_INFINITY})
            check(EscortRules.navigationSpeed(attribute,false)==0,"invalid/disabled movement is safe");
    }

    static void catchUpRuntime() {
        group("Immediate running toward ahead player, close rejoin, moving targets, persistence and budgets");
        Context c=new Context();c.owner.x=20;c.begin();c.tick();
        check(c.npc.escort.isCatchingUp(),"far ahead player starts catch-up on first tick");
        check(c.npc.navigation.calls==1&&c.npc.navigation.tx==20.5,"path targets ahead player, not destination");
        check(c.npc.x==0,"starts navigation without teleporting");
        check(Math.abs(Math.pow(c.npc.navigation.speed*c.npc.movementAttribute,2)-0.16)<1e-12,"runtime running speed");
        CompoundTag saved=c.npc.escort.save();
        check(NpcEscort.load(saved,-64,320).isCatchingUp(),"catch-up latch survives NBT reload");
        saved.putInt("Phase",NpcEscort.WAIT_PLAYER);
        check(!NpcEscort.load(saved,-64,320).isCatchingUp(),"arrival wait cannot reload as chasing");
        int ticks=0;
        while(c.npc.escort.isCatchingUp()&&ticks++<200){c.npc.advance();c.tick();}
        check(ticks<200&&c.owner.distanceToSqr(c.npc)<=9,"runs until within 3, not merely back inside 8");
        check(c.npc.navigation.tx>c.owner.x+5&&!c.npc.escort.isCatchingUp(),"returns toward route goal by a local waypoint after close rejoin");
        check(Math.abs(Math.pow(c.npc.navigation.speed*c.npc.movementAttribute,2)-0.1)<1e-12,"restores player walking pace");

        c=new Context();c.owner.x=20;c.begin();c.tick();c.owner.x=24;
        for(int i=0;i<19;i++)c.tick();
        check(c.npc.navigation.calls==1,"moving-player path not recalculated every tick");
        c.tick();check(c.npc.navigation.calls==2&&c.npc.navigation.tx==24.5,"updates moving-player target after 20 ticks");
        int calls=c.npc.navigation.calls;for(int i=0;i<20;i++)c.tick();
        check(c.npc.navigation.calls==calls,"stationary player does not force periodic path searches");
        c.owner.x=-20;c.tick();
        check(!c.npc.escort.isCatchingUp()&&c.npc.navigation.done,"player going behind stops chase and waits");
        check(c.npc.x==0,"reverse case never teleports");

        c=new Context();c.owner.x=-20;c.begin();for(int i=0;i<30;i++)c.tick();
        check(!c.npc.escort.isCatchingUp()&&c.npc.navigation.calls==0,"far player farther from goal keeps old waiting rule");
        c=new Context();c.owner.x=20;c.level.loaded=false;c.begin();for(int i=0;i<100;i++)c.tick();
        check(c.npc.navigation.calls==0,"catch-up does not search toward unloaded target");
        c=new Context();c.owner.x=20;c.npc.navigation.canPath=false;c.begin();
        for(int i=0;i<10000;i++)c.tick();
        check(c.npc.navigation.calls<70,"blocked player catch-up retains bounded retries");
        c=new Context();c.owner.x=20;c.begin();c.tick();c.server.players.players.clear();c.tick();
        check(c.npc.navigation.done,"logout safely pauses catch-up");

        c=new Context();c.owner.x=20;List<GuideNpc> crowd=new ArrayList<>();
        for(int i=0;i<500;i++){GuideNpc n=new GuideNpc(c.level,i);n.beginEscort(c.owner,"road",new BlockPos(100,64,0));crowd.add(n);}
        int previous=0;
        for(int t=0;t<20;t++){c.server.tick++;for(GuideNpc n:crowd)n.escort.tick(n);
            int total=crowd.stream().mapToInt(n->n.navigation.calls).sum();
            check(total-previous<=2,"500 simultaneous catch-ups share <=2 searches/tick");previous=total;}
        check(previous==40&&c.level.queries==0,"catch-up budget works without global entity scans");
    }

    public static void main(String[] args) throws Exception {
        policy();waiting();ownerLifecycle();arrival();finishOfflineAndReload();budgets();commandsAndGuards();dialogueActions();catchUpPolicyAndSpeed();catchUpRuntime();
        System.out.println("PASS: "+checks+" assertions across "+groups.size()+" groups");
        groups.forEach(name->System.out.println("  "+name));
        System.out.println("API doubles test policy and authority; this is not a real Minecraft world/playtest.");
    }
}
