import dev.settledlands.npc.*;
import dev.settledlands.npc.client.NpcGraphCanvas;
import net.minecraft.nbt.*;
import java.util.*;

/** Actual graph/profile/NBT/canvas bytecode, without API doubles or renderer/game startup. */
public final class GraphHarness {
    static int checks;
    static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    static void near(double a,double b,String message){check(Math.abs(a-b)<1e-7,message+" "+a+" != "+b);}
    static NpcProfile legacy(){
        NpcProfile p=new NpcProfile();p.welcome="Hello";p.welcomeLines.add("Second welcome");
        NpcProfile.Topic t=new NpcProfile.Topic("Conversation");NpcProfile.Step a=new NpcProfile.Step();a.line="Choose";a.action="trigger:relation 2";
        a.variants.add(new NpcProfile.Variant(40,"Friend version"));
        NpcProfile.Answer b=new NpcProfile.Answer();b.player="Continue";b.reaction="Response";b.action="/go road";b.next=1;
        b.relation=3;b.minRelation=20;b.maxRelation=80;b.pointsName="Coins";b.minPoints=2;b.maxPoints=7;b.pointsShared=true;a.answers.add(b);
        NpcProfile.Step end=new NpcProfile.Step();end.line="End";t.steps.add(a);t.steps.add(end);p.topics.add(t);
        NpcProfile.Topic trade=new NpcProfile.Topic("Store",NpcProfile.TYPE_TRADE);p.topics.add(trade);return p;
    }
    public static void main(String[] args){
        NpcProfile p=legacy();NpcDialogueGraph g=NpcDialogueGraph.fromLegacy(p);
        check(g.error().isEmpty()&&!g.enabled,"migration valid without automatically changing gameplay");
        check(p.dialogueGraph==null&&p.topics.size()==2&&p.welcome.equals("Hello"),"old profile is not mutated");
        check(g.get(g.entry).text.equals("Hello"),"entry migrated");
        check(g.get(g.get(g.entry).next).text.equals("Second welcome"),"welcome chain migrated");
        int root=g.topicNode(0);check(root>=0&&g.get(root).text.equals("Conversation"),"topic becomes a button");
        NpcDialogueGraph.Node line=g.get(g.get(root).next);check(line.text.equals("Choose")&&line.action.equals("trigger:relation 2"),"line trigger preserved");
        check(line.lineFor(39).equals("Choose")&&line.lineFor(40).equals("Friend version"),"reputation variants preserved");
        NpcDialogueGraph.Node button=g.get(line.choices.get(0));check(button.type==NpcDialogueGraph.BUTTON&&button.text.equals("Continue")&&button.action.equals("/go road"),"answer and action preserved");
        check(button.relation==3&&button.minRelation==20&&button.maxRelation==80,"answer relation conditions preserved");
        check(button.pointsName.equals("Coins")&&button.minPoints==2&&button.maxPoints==7&&button.pointsShared,"points conditions preserved");
        NpcDialogueGraph.Node response=g.get(button.next);check(response.text.equals("Response")&&g.get(response.next).text.equals("End"),"reaction and destination are separate connected lines");
        check(g.get(g.topicNode(1)).builtinTopic==1,"built-in trade retained");
        int travel=g.specialNode(NpcDialogueGraph.TRAVEL),arrival=g.specialNode(NpcDialogueGraph.ARRIVAL);
        check(travel>=0&&arrival>=0,"escort lines included as protected independent nodes");
        check(!g.connect(travel,line.id)&&!g.connect(line.id,travel)&&!g.remove(arrival),"special node protection");
        check(g.connect(line.id,line.id),"direct line self-cycle allowed");
        check(g.connect(button.id,line.id),"button return allowed");
        check(!g.connect(button.id,root),"button to button rejected");
        check(g.connect(line.id,root)&&g.connect(line.id,root)&&Collections.frequency(line.choices,root)==1,"shared choice not duplicated");
        g.enabled=true;check(g.error().isEmpty(),"cycles are valid data, not auto-executed loops");
        CompoundTag tag=g.save();NpcDialogueGraph loaded=NpcDialogueGraph.load(tag);
        check(loaded!=null&&loaded.enabled&&loaded.get(line.id).next==line.id,"real NBT round trip and cycle");
        check(loaded.save().equals(tag),"all graph node fields/layout survive exact NBT round trip");
        NpcDialogueGraph copy=g.copy();copy.get(line.id).text="Different";check(!g.get(line.id).text.equals("Different"),"deep independent node copy");
        copy.get(line.id).choices.clear();check(!g.get(line.id).choices.isEmpty(),"deep independent edge list");
        p.dialogueGraph=g;p.name="Unchanged name";NpcProfile roundTrip=NpcProfile.load(p.save(null),null);
        check(roundTrip.dialogueGraph!=null&&roundTrip.dialogueGraph.enabled,"graph included in actual profile save/load");
        check(roundTrip.name.equals(p.name)&&roundTrip.topics.size()==p.topics.size(),"legacy definitions and unrelated settings remain");
        check(p.copy().dialogueGraph!=g&&p.sanitized().dialogueGraph!=g,"profile copy/sanitize make independent graph");
        g.get(travel).text="Travel changed";g.get(arrival).text="Arrival changed";g.applySpecialLines(p);
        check(p.escortTravelLine.equals("Travel changed")&&p.escortArrivalLine.equals("Arrival changed"),"escort text commits independently");
        CompoundTag old=p.save(null);old.remove("DialogueGraph");check(NpcProfile.load(old,null).dialogueGraph==null,"old world without graph is compatible");
        NpcDialogueGraph broken=g.copy();broken.entry=9999;check(broken.error().equals("entry"),"bad entry flagged");
        check(NpcDialogueGraph.load(broken.save())!=null,"soft-invalid graph kept as loadable data, not dropped");
        NpcProfile tabs=new NpcProfile();tabs.dialogueGraph=broken.copy();tabs.walkGraph=g.copy();tabs.animGraph=g.copy();
        NpcProfile tabsLoaded=NpcProfile.load(tabs.save(null),null);
        check(tabsLoaded.dialogueGraph!=null&&tabsLoaded.dialogueGraph.entry==9999,"NPC main graph survives profile NBT even with soft errors");
        check(tabsLoaded.walkGraph!=null&&tabsLoaded.animGraph!=null,"NPC keeps all three graphs through profile NBT");
        check(tabsLoaded.sanitized().walkGraph!=null&&tabsLoaded.sanitized().animGraph!=null,"sanitized() preserves graphs as NPC data");
        broken=g.copy();broken.get(line.id).next=9999;check(broken.error().equals("link"),"missing target rejected");
        broken=g.copy();broken.get(line.id).next=button.id;check(broken.error().equals("link"),"continuation must target a line");
        broken=g.copy();broken.get(line.id).x=40000;check(broken.error().equals("position"),"bounded layout coordinates");
        broken=g.copy();broken.get(line.id).text="a".repeat(481);check(broken.error().equals("text"),"bounded node text");
        broken=g.copy();broken.get(button.id).minRelation=81;check(broken.error().equals("relation"),"inverted relation rejected");
        broken=g.copy();broken.get(button.id).minPoints=8;check(broken.error().equals("points"),"inverted points rejected");
        tag=g.save();ListTag nodes=tag.getList("Nodes",10);nodes.add(nodes.getCompound(0).copy());check(NpcDialogueGraph.load(tag)==null,"duplicate IDs rejected");
        broken=g.copy();broken.remove(button.id);check(!broken.get(line.id).choices.contains(button.id),"delete removes incoming edges");
        broken.disconnectOutputs(line.id);check(broken.get(line.id).next==-1&&broken.get(line.id).choices.isEmpty(),"disconnect outputs");

        check(NpcDialogueGraph.encodedSize(g.save())>100&&NpcDialogueGraph.encodedSize(g.save())<NpcDialogueGraph.MAX_PACKET_BYTES,"constant-memory network preflight for ordinary graph");
        NpcProfile many=new NpcProfile();
        for(int i=0;i<20;i++)many.topics.add(new NpcProfile.Topic("Builtin "+i,NpcProfile.TYPE_TRADE));
        NpcDialogueGraph pages=NpcDialogueGraph.fromLegacy(many);
        int rootPage=pages.entry,total=0,pageCount=0;
        while(rootPage>=0&&pageCount++<5){NpcDialogueGraph.Node page=pages.get(rootPage);total+=page.choices.size();rootPage=page.next;}
        check(total==20&&pageCount==2,"large legacy root menus migrate without dropped buttons");
        check(pages.error().isEmpty(),"paged migration respects choice limits");
        NpcProfile builtinReaction=legacy();builtinReaction.topics.get(0).steps.get(0).answers.get(0).next=1001;
        NpcDialogueGraph migrated=NpcDialogueGraph.fromLegacy(builtinReaction);
        NpcDialogueGraph.Node first=migrated.get(migrated.get(migrated.topicNode(0)).next);
        NpcDialogueGraph.Node choice=migrated.get(first.choices.get(0)),reaction=migrated.get(choice.next);
        check(choice.builtinTopic==-1&&reaction.builtinTopic==1&&reaction.text.equals("Response"),"reaction remains before legacy built-in destination");
        check(migrated.error().isEmpty(),"built-in reaction bridge validates");
        NpcProfile largest=new NpcProfile();
        for(int ti=0;ti<8;ti++){
            NpcProfile.Topic topic=new NpcProfile.Topic("Topic "+ti);
            for(int si=0;si<16;si++){
                NpcProfile.Step step=new NpcProfile.Step();step.line="Line "+si;
                for(int ai=0;ai<6;ai++){NpcProfile.Answer answer=new NpcProfile.Answer();answer.player="Choice "+ai;answer.reaction="Reaction";step.answers.add(answer);}topic.steps.add(step);
            }largest.topics.add(topic);
        }
        NpcDialogueGraph big=NpcDialogueGraph.fromLegacy(largest);
        check(big.nodes.size()>1600&&big.nodes.size()<=NpcDialogueGraph.MAX_NODES&&big.error().isEmpty(),"maximum ordinary legacy topology imports without truncation");
        check(NpcDialogueGraph.load(big.save())!=null,"large topology real NBT load bounded and valid");
        check(NpcDialogueGraph.encodedSize(big.save())<NpcDialogueGraph.MAX_PACKET_BYTES,"large short-text migration fits network preflight");

        NpcGraphCanvas canvas=new NpcGraphCanvas();canvas.bounds(8,38,800,500);
        double x=123.5,y=-87.25;near(canvas.worldX(canvas.screenX(x)),x,"x transform invertible");near(canvas.worldY(canvas.screenY(y)),y,"y transform invertible");
        double wx=canvas.worldX(400),wy=canvas.worldY(300);canvas.zoomAt(3,400,300);near(canvas.worldX(400),wx,"zoom anchored under cursor x");near(canvas.worldY(300),wy,"zoom anchored under cursor y");
        canvas.zoomAt(100,400,300);near(canvas.zoom,NpcGraphCanvas.MAX_ZOOM,"zoom upper clamp");canvas.zoomAt(-200,400,300);near(canvas.zoom,NpcGraphCanvas.MIN_ZOOM,"zoom lower clamp");
        canvas.focus(line);check(canvas.visible(line),"focus makes selected node visible");
        check(canvas.hit(g,canvas.screenX(line.x+15),canvas.screenY(line.y+15))==line.id,"hit-test in scaled/panned coordinates");
        check(canvas.hitPort(g,canvas.screenX(line.x+NpcGraphCanvas.NODE_W),canvas.screenY(line.y+50),true)==line.id,"output-port hit test");
        check(canvas.hitPort(g,canvas.screenX(line.x),canvas.screenY(line.y+50),false)==line.id,"input-port hit test");
        canvas.move(line,19,23);check(line.x==16&&line.y==24,"node drag grid snap");canvas.move(line,1e9,-1e9);check(line.x==32768&&line.y==-32768,"node drag coordinate clamp");
        canvas.frameAll(g);check(canvas.zoom>=NpcGraphCanvas.MIN_ZOOM&&canvas.zoom<=1,"frame all bounded zoom");
        canvas.zoomAt(-500,400,300);near(canvas.zoom,NpcGraphCanvas.MIN_ZOOM,"extended zoom out reaches 0.05 (5%)");
        check(NpcGraphCanvas.MIN_ZOOM==0.05,"minimum zoom is 0.05 (5%)");
        g.panX=350.5;g.panY=-120.25;g.zoom=0.125;g.hasCamera=true;
        CompoundTag camTag=g.save();
        check(camTag.getBoolean("HasCamera")&&Math.abs(camTag.getDouble("PanX")-350.5)<1e-6&&Math.abs(camTag.getDouble("Zoom")-0.125)<1e-6,"camera coordinates saved to NBT");
        NpcDialogueGraph camLoaded=NpcDialogueGraph.load(camTag);
        check(camLoaded.hasCamera&&Math.abs(camLoaded.panX-350.5)<1e-6&&Math.abs(camLoaded.zoom-0.125)<1e-6,"camera coordinates restored from NBT");
        NpcDialogueGraph camCopy=camLoaded.copy();
        check(camCopy.hasCamera&&Math.abs(camCopy.panX-350.5)<1e-6&&Math.abs(camCopy.zoom-0.125)<1e-6,"camera coordinates survive deep copy");
        check(line.next>=0||!line.choices.isEmpty(),"line has connections before disconnect");
        g.disconnectOutputs(line.id);
        check(line.next==-1&&line.choices.isEmpty(),"disconnectOutputs clears both next and choices");
        canvas.pan(1e9,-1e9);check(canvas.panX==100000&&canvas.panY==-100000,"pan clamp");
        check(canvas.hit(g,-50,-50)==-1,"hit outside canvas does not select");
                // Build 89: Trigger node tests
        NpcDialogueGraph.Node trig=g.add(NpcDialogueGraph.TRIGGER,100,100);
        check(trig!=null&&trig.type==NpcDialogueGraph.TRIGGER,"trigger node created");
        check(g.connect(line.id,trig.id),"connect line to trigger");
        check(line.triggers.contains(trig.id),"line records trigger in triggers list");
        check(g.connect(button.id,trig.id),"connect button to trigger");
        check(button.triggers.contains(trig.id),"button records trigger in triggers list");
        NpcDialogueGraph.Node trig2=g.add(NpcDialogueGraph.TRIGGER,250,100);
        check(g.connect(trig.id,trig2.id),"chain trigger to trigger");
        check(trig.triggers.contains(trig2.id),"trigger chains to another trigger");
        check(g.connect(trig2.id,line.id),"trigger connects to line");
        check(trig2.next==line.id,"trigger next points to line");
        trig.action="/give @p diamond 1";
        CompoundTag trSave=g.save();
        NpcDialogueGraph trLoaded=NpcDialogueGraph.load(trSave);
        check(trLoaded!=null&&trLoaded.get(line.id).triggers.contains(trig.id),"triggers survive NBT save/load");
        check(trLoaded.get(trig.id).action.equals("/give @p diamond 1"),"trigger action survives NBT");
        g.disconnect(line.id,trig.id);
        check(!line.triggers.contains(trig.id),"disconnect removes trigger link");
        check(button.triggers.contains(trig.id),"disconnect only removed specific link");
        g.remove(trig.id);
        check(!button.triggers.contains(trig.id),"remove trigger node cleans references");

        // Build 91: IF and VARIABLE node topology & NBT tests
        NpcDialogueGraph.Node varNode = g.add(NpcDialogueGraph.VARIABLE, 120, 200);
        check(varNode != null && varNode.type == NpcDialogueGraph.VARIABLE, "variable node created");
        varNode.pointsName = "reputation";
        varNode.varValue = 10;
        varNode.pointsShared = false;

        NpcDialogueGraph.Node ifNode = g.add(NpcDialogueGraph.IF, 360, 200);
        check(ifNode != null && ifNode.type == NpcDialogueGraph.IF, "if node created");
        ifNode.varCompare = 15;
        ifNode.varOp = 2; // >=

        check(g.connect(varNode.id, ifNode.id), "connect variable node to if node");
        check(ifNode.varInputNode == varNode.id, "if records varInputNode");
        check(ifNode.pointsName.equals("reputation"), "if inherits variable name from connected variable");
        check(varNode.next == ifNode.id, "variable next links to if");

        NpcDialogueGraph.Node lineTrue = g.add(NpcDialogueGraph.LINE, 600, 150);
        lineTrue.text = "Success";
        NpcDialogueGraph.Node lineFalse = g.add(NpcDialogueGraph.LINE, 600, 250);
        lineFalse.text = "Failure";

        check(g.connect(ifNode.id, lineTrue.id, 0), "connect if True output to lineTrue");
        check(ifNode.next == lineTrue.id, "if next points to lineTrue");
        check(g.connect(ifNode.id, lineFalse.id, 1), "connect if False output to lineFalse");
        check(ifNode.falseNext == lineFalse.id, "if falseNext points to lineFalse");

        CompoundTag ifVarSave = g.save();
        NpcDialogueGraph ifVarLoaded = NpcDialogueGraph.load(ifVarSave);
        check(ifVarLoaded != null, "if/variable graph NBT loads cleanly");
        check(ifVarLoaded.get(varNode.id).varValue == 10, "variable varValue preserved in NBT");
        check(ifVarLoaded.get(ifNode.id).varCompare == 15, "if varCompare preserved in NBT");
        check(ifVarLoaded.get(ifNode.id).varOp == 2, "if varOp preserved in NBT");
        check(ifVarLoaded.get(ifNode.id).varInputNode == varNode.id, "if varInputNode preserved in NBT");
        check(ifVarLoaded.get(ifNode.id).falseNext == lineFalse.id, "if falseNext preserved in NBT");

        // Canvas hitPort for dual-output IF
        canvas.panX = 60; canvas.panY = 90; canvas.zoom = 1.0;
        check(canvas.hitPort(g, canvas.portScreenX(ifNode, true), canvas.portScreenY(ifNode, true, 0), true) == ifNode.id && canvas.hitPortIndex == 0, "IF port 0 hit");
        check(canvas.hitPort(g, canvas.portScreenX(ifNode, true), canvas.portScreenY(ifNode, true, 1), true) == ifNode.id && canvas.hitPortIndex == 1, "IF port 1 hit");

        g.remove(varNode.id);
        check(ifNode.varInputNode == -1, "removing variable node cleans varInputNode in if");
        g.remove(ifNode.id);
        g.remove(lineTrue.id);
        g.remove(lineFalse.id);

        // Build 102: CHECK node topology & NBT tests
        NpcDialogueGraph.Node checkNode = g.add(NpcDialogueGraph.CHECK, 150, 300);
        check(checkNode != null && checkNode.type == NpcDialogueGraph.CHECK, "check node created");
        checkNode.checkTarget = NpcDialogueGraph.TARGET_PLAYER;
        checkNode.checkRadius = 5;
        checkNode.checkCooldown = 15;
        NpcDialogueGraph.Node checkTargetLine = g.add(NpcDialogueGraph.LINE, 400, 300);
        checkTargetLine.text = "Hello Traveler";
        check(g.connect(checkNode.id, checkTargetLine.id), "connect check node to line");
        check(checkNode.next == checkTargetLine.id, "check next points to line");

        CompoundTag checkSave = g.save();
        NpcDialogueGraph checkLoaded = NpcDialogueGraph.load(checkSave);
        check(checkLoaded != null, "check node graph NBT loads cleanly");
        check(checkLoaded.get(checkNode.id).checkTarget == NpcDialogueGraph.TARGET_PLAYER, "checkTarget preserved in NBT");
        check(checkLoaded.get(checkNode.id).checkRadius == 5, "checkRadius preserved in NBT");
        check(checkLoaded.get(checkNode.id).checkCooldown == 15, "checkCooldown preserved in NBT");
        check(checkLoaded.get(checkNode.id).next == checkTargetLine.id, "check connection preserved in NBT");

        g.remove(checkNode.id);
        g.remove(checkTargetLine.id);

        // Build 103: DAMAGE node topology & NBT tests
        NpcDialogueGraph.Node dmgNode = g.add(NpcDialogueGraph.DAMAGE, 180, 320);
        check(dmgNode != null && dmgNode.type == NpcDialogueGraph.DAMAGE, "damage node created");
        dmgNode.damageFilter = NpcDialogueGraph.DAMAGE_PLAYER;
        dmgNode.damageCooldown = 2;
        dmgNode.minDamage = 3;
        NpcDialogueGraph.Node dmgTargetLine = g.add(NpcDialogueGraph.LINE, 450, 320);
        dmgTargetLine.text = "Ouch!";
        check(g.connect(dmgNode.id, dmgTargetLine.id), "connect damage node to line");
        check(dmgNode.next == dmgTargetLine.id, "damage next points to line");

        NpcDialogueGraph copyDmg = g.copy();
        check(copyDmg.get(dmgNode.id).damageFilter == NpcDialogueGraph.DAMAGE_PLAYER, "copy damageFilter");
        check(copyDmg.get(dmgNode.id).damageCooldown == 2, "copy damageCooldown");
        check(copyDmg.get(dmgNode.id).minDamage == 3, "copy minDamage");

        CompoundTag dmgSave = g.save();
        NpcDialogueGraph dmgLoaded = NpcDialogueGraph.load(dmgSave);
        check(dmgLoaded != null, "damage node graph NBT loads cleanly");
        check(dmgLoaded.get(dmgNode.id).damageFilter == NpcDialogueGraph.DAMAGE_PLAYER, "damageFilter preserved in NBT");
        check(dmgLoaded.get(dmgNode.id).damageCooldown == 2, "damageCooldown preserved in NBT");
        check(dmgLoaded.get(dmgNode.id).minDamage == 3, "minDamage preserved in NBT");
        check(dmgLoaded.get(dmgNode.id).next == dmgTargetLine.id, "damage connection preserved in NBT");

        g.remove(dmgNode.id);
        g.remove(dmgTargetLine.id);

        // Build 104/105: TIME, TIMER, and ANIMATION ("play anim") node topology, NBT & copy tests
        NpcDialogueGraph.Node timeNode = g.add(NpcDialogueGraph.TIME, 100, 400);
        check(timeNode != null && timeNode.type == NpcDialogueGraph.TIME, "time node created");
        check(timeNode.timeMode == NpcDialogueGraph.TIME_CUSTOM, "TIME node defaults to TIME_CUSTOM (свое значение)");
        timeNode.timeTicks = 12000;
        NpcDialogueGraph.Node timeTargetLine = g.add(NpcDialogueGraph.LINE, 350, 400);
        timeTargetLine.text = "The sun is setting...";
        check(g.connect(timeNode.id, timeTargetLine.id), "connect time node to line");
        check(timeNode.next == timeTargetLine.id, "time node next points to target line");

        NpcDialogueGraph.Node timerNode = g.add(NpcDialogueGraph.TIMER, 100, 520);
        check(timerNode != null && timerNode.type == NpcDialogueGraph.TIMER, "timer node created");
        timerNode.timerInterval = 15;
        timerNode.timerRepeat = false;
        NpcDialogueGraph.Node timerTargetLine = g.add(NpcDialogueGraph.LINE, 350, 520);
        timerTargetLine.text = "15 seconds elapsed!";
        check(g.connect(timerNode.id, timerTargetLine.id), "connect timer node to line");
        check(timerNode.next == timerTargetLine.id, "timer node next points to target line");

        NpcDialogueGraph.Node animNode = g.add(NpcDialogueGraph.ANIMATION, 100, 640);
        check(animNode != null && animNode.type == NpcDialogueGraph.ANIMATION, "animation node created");
        animNode.animName = "wave_hand";
        animNode.animLoop = true;
        animNode.animBone = "head";
        NpcDialogueGraph.Node animTargetLine = g.add(NpcDialogueGraph.LINE, 350, 640);
        animTargetLine.text = "Hello traveler!";
        check(g.connect(animNode.id, animTargetLine.id), "connect anim node to line");
        check(animNode.next == animTargetLine.id, "anim node next points to target line");

        NpcDialogueGraph copyTimeTimerAnim = g.copy();
        check(copyTimeTimerAnim.get(timeNode.id).timeMode == NpcDialogueGraph.TIME_CUSTOM, "copy timeMode custom");
        check(copyTimeTimerAnim.get(timeNode.id).timeTicks == 12000, "copy timeTicks");
        check(copyTimeTimerAnim.get(timerNode.id).timerInterval == 15, "copy timerInterval");
        check(!copyTimeTimerAnim.get(timerNode.id).timerRepeat, "copy timerRepeat");
        check(copyTimeTimerAnim.get(animNode.id).animName.equals("wave_hand"), "copy animName");
        check(copyTimeTimerAnim.get(animNode.id).animLoop, "copy animLoop");
        check(copyTimeTimerAnim.get(animNode.id).animBone.equals("head"), "copy animBone");

        CompoundTag timeTimerAnimSave = g.save();
        NpcDialogueGraph timeTimerAnimLoaded = NpcDialogueGraph.load(timeTimerAnimSave);
        check(timeTimerAnimLoaded != null, "time/timer/anim graph NBT loads cleanly");
        check(timeTimerAnimLoaded.get(timeNode.id).timeMode == NpcDialogueGraph.TIME_CUSTOM, "timeMode custom in NBT");
        check(timeTimerAnimLoaded.get(timeNode.id).timeTicks == 12000, "timeTicks in NBT");
        check(timeTimerAnimLoaded.get(timeNode.id).next == timeTargetLine.id, "time node link in NBT");
        check(timeTimerAnimLoaded.get(timerNode.id).timerInterval == 15, "timerInterval in NBT");
        check(!timeTimerAnimLoaded.get(timerNode.id).timerRepeat, "timerRepeat in NBT");
        check(timeTimerAnimLoaded.get(timerNode.id).next == timerTargetLine.id, "timer node link in NBT");
        check(timeTimerAnimLoaded.get(animNode.id).animName.equals("wave_hand"), "animName in NBT");
        check(timeTimerAnimLoaded.get(animNode.id).animLoop, "animLoop in NBT");
        check(timeTimerAnimLoaded.get(animNode.id).animBone.equals("head"), "animBone in NBT");
        check(timeTimerAnimLoaded.get(animNode.id).next == animTargetLine.id, "anim node link in NBT");

        g.remove(timeNode.id);
        g.remove(timeTargetLine.id);
        g.remove(timerNode.id);
        g.remove(timerTargetLine.id);
        g.remove(animNode.id);
        g.remove(animTargetLine.id);

        // Build 111: QUEST node topology, NBT & copy tests
        NpcDialogueGraph.Node qNode = g.add(NpcDialogueGraph.QUEST, 100, 760);
        check(qNode != null && qNode.type == NpcDialogueGraph.QUEST, "quest node created");
        check(g.hasQuestNodes(), "hasQuestNodes returns true");
        qNode.text = "Find the ancient relic";
        qNode.minRelation = 15;
        NpcDialogueGraph.Node qTargetLine = g.add(NpcDialogueGraph.LINE, 350, 760);
        qTargetLine.text = "You accepted the quest: Find the ancient relic!";
        check(g.connect(qNode.id, qTargetLine.id), "connect quest node to line");
        check(qNode.next == qTargetLine.id, "quest node next points to target line");

        NpcDialogueGraph copyQuest = g.copy();
        check(copyQuest.hasQuestNodes(), "copied graph hasQuestNodes");
        check(copyQuest.get(qNode.id).text.equals("Find the ancient relic"), "copy quest title text");
        check(copyQuest.get(qNode.id).minRelation == 15, "copy quest minRelation");
        check(copyQuest.get(qNode.id).next == qTargetLine.id, "copy quest target link");

        CompoundTag questSave = g.save();
        NpcDialogueGraph questLoaded = NpcDialogueGraph.load(questSave);
        check(questLoaded != null && questLoaded.hasQuestNodes(), "quest node in loaded graph");
        check(questLoaded.get(qNode.id).text.equals("Find the ancient relic"), "quest title in NBT");
        check(questLoaded.get(qNode.id).minRelation == 15, "quest minRelation in NBT");
        check(questLoaded.get(qNode.id).next == qTargetLine.id, "quest node link in NBT");

        g.remove(qNode.id);
        g.remove(qTargetLine.id);

        // Build 112/113: MOVE node topology, NBT & copy tests
        NpcDialogueGraph.Node mNode = g.add(NpcDialogueGraph.MOVE, 100, 800);
        check(mNode != null && mNode.type == NpcDialogueGraph.MOVE, "move node created");
        mNode.moveCoords = "~10 ~ ~5";
        mNode.moveSpeed = 1.5;
        mNode.moveEscort = true;
        NpcDialogueGraph.Node mTargetLine = g.add(NpcDialogueGraph.LINE, 350, 800);
        mTargetLine.text = "I arrived at destination!";
        check(g.connect(mNode.id, mTargetLine.id), "connect move node to line");
        check(mNode.next == mTargetLine.id, "move node next points to target line");

        NpcDialogueGraph copyMove = g.copy();
        check(copyMove.get(mNode.id).type == NpcDialogueGraph.MOVE, "copied graph has MOVE node");
        check(copyMove.get(mNode.id).moveCoords.equals("~10 ~ ~5"), "copy move coords");
        check(copyMove.get(mNode.id).moveSpeed == 1.5, "copy move speed");
        check(copyMove.get(mNode.id).moveEscort, "copy move escort flag");
        check(copyMove.get(mNode.id).next == mTargetLine.id, "copy move target link");

        CompoundTag moveSave = g.save();
        NpcDialogueGraph moveLoaded = NpcDialogueGraph.load(moveSave);
        check(moveLoaded != null && moveLoaded.get(mNode.id) != null, "move node in loaded graph");
        check(moveLoaded.get(mNode.id).type == NpcDialogueGraph.MOVE, "move node type in NBT");
        check(moveLoaded.get(mNode.id).moveCoords.equals("~10 ~ ~5"), "move coords in NBT");
        check(moveLoaded.get(mNode.id).moveSpeed == 1.5, "move speed in NBT");
        check(moveLoaded.get(mNode.id).moveEscort, "move escort flag in NBT");
        check(moveLoaded.get(mNode.id).next == mTargetLine.id, "move node link in NBT");

        g.remove(mNode.id);
        g.remove(mTargetLine.id);

        // Build 115: MOBILITY node topology, NBT & copy tests
        NpcDialogueGraph.Node mobNode = g.add(NpcDialogueGraph.MOBILITY, 120, 900);
        check(mobNode != null && mobNode.type == NpcDialogueGraph.MOBILITY, "mobility node created");
        mobNode.mobilityGroupId = "route_village_patrol";
        mobNode.mobilityGroupName = "Village Patrol";
        NpcDialogueGraph.Node mobTargetLine = g.add(NpcDialogueGraph.LINE, 360, 900);
        mobTargetLine.text = "Patrol point 1 reached!";
        check(g.connect(mobNode.id, mobTargetLine.id), "connect mobility node to line");
        check(mobNode.next == mobTargetLine.id, "mobility node next points to target line");

        NpcDialogueGraph copyMob = g.copy();
        check(copyMob.get(mobNode.id).type == NpcDialogueGraph.MOBILITY, "copied graph has MOBILITY node");
        check(copyMob.get(mobNode.id).mobilityGroupId.equals("route_village_patrol"), "copy mobilityGroupId");
        check(copyMob.get(mobNode.id).mobilityGroupName.equals("Village Patrol"), "copy mobilityGroupName");
        check(copyMob.get(mobNode.id).next == mobTargetLine.id, "copy mobility target link");

        CompoundTag mobSave = g.save();
        NpcDialogueGraph mobLoaded = NpcDialogueGraph.load(mobSave);
        check(mobLoaded != null && mobLoaded.get(mobNode.id) != null, "mobility node in loaded graph");
        check(mobLoaded.get(mobNode.id).type == NpcDialogueGraph.MOBILITY, "mobility node type in NBT");
        check(mobLoaded.get(mobNode.id).mobilityGroupId.equals("route_village_patrol"), "mobilityGroupId in NBT");
        check(mobLoaded.get(mobNode.id).mobilityGroupName.equals("Village Patrol"), "mobilityGroupName in NBT");
        check(mobLoaded.get(mobNode.id).next == mobTargetLine.id, "mobility node link in NBT");

        g.remove(mobNode.id);
        g.remove(mobTargetLine.id);

        // Hitbox zoom scaling tests
        NpcDialogueGraph.Node testNodeA = g.add(NpcDialogueGraph.LINE, 0, 0);
        NpcDialogueGraph.Node testNodeB = g.add(NpcDialogueGraph.LINE, 400, 0);
        canvas.panX = 0; canvas.panY = 0; canvas.zoom = 1.0;
        double sx1 = canvas.portScreenX(testNodeA, true);
        double sy1 = canvas.portScreenY(testNodeA, true, 0);
        double sx2 = canvas.portScreenX(testNodeB, false);
        double sy2 = canvas.portScreenY(testNodeB, false, 0);
        double midX = (sx1 + sx2) / 2.0;
        double midY = (sy1 + sy2) / 2.0;

        // At zoom 1.0, 3px away hits cable
        check(canvas.hitCable(testNodeA, 0, testNodeB, 0, midX, midY + 3.0), "hitCable hits within 3px at zoom 1.0");
        // At zoom 1.0, 25px away misses cable
        check(!canvas.hitCable(testNodeA, 0, testNodeB, 0, midX, midY + 25.0), "hitCable misses at 25px distance");

        // At high zoom out (zoom = 0.05)
        canvas.zoom = 0.05;
        double zsx1 = canvas.portScreenX(testNodeA, true);
        double zsy1 = canvas.portScreenY(testNodeA, true, 0);
        double zsx2 = canvas.portScreenX(testNodeB, false);
        double zsy2 = canvas.portScreenY(testNodeB, false, 0);
        double zmidX = (zsx1 + zsx2) / 2.0;
        double zmidY = (zsy1 + zsy2) / 2.0;

        // 1px away hits cable at zoom 0.05
        check(canvas.hitCable(testNodeA, 0, testNodeB, 0, zmidX, zmidY + 1.0), "hitCable hits within 1px at zoom 0.05");
        // 7px away does NOT hit cable at zoom 0.05 (preventing huge hitbox when zoomed out)
        check(!canvas.hitCable(testNodeA, 0, testNodeB, 0, zmidX, zmidY + 7.0), "hitCable does not trigger at 7px distance at zoom 0.05");

        g.remove(testNodeA.id);
        g.remove(testNodeB.id);

        // Test RANDOM = 13 node
        NpcDialogueGraph.Node rnd = g.add(NpcDialogueGraph.RANDOM, 100, 100);
        check(rnd.type == NpcDialogueGraph.RANDOM, "node type is RANDOM");
        check(rnd.randomMin == 1 && rnd.randomMax == 2, "default randomMin=1, randomMax=2");
        rnd.randomMin = 1;
        rnd.randomMax = 5;
        NpcDialogueGraph.Node t1 = g.add(NpcDialogueGraph.LINE, 300, 50);
        NpcDialogueGraph.Node t2 = g.add(NpcDialogueGraph.LINE, 300, 100);
        NpcDialogueGraph.Node t3 = g.add(NpcDialogueGraph.LINE, 300, 150);
        check(g.connect(rnd.id, t1.id, 0), "connect random branch 0");
        check(g.connect(rnd.id, t2.id, 1), "connect random branch 1");
        check(g.connect(rnd.id, t3.id, 4), "connect random branch 4");
        check(rnd.randomBranches.size() == 5, "random branches size is 5");
        check(rnd.randomBranches.get(0) == t1.id, "branch 0 points to t1");
        check(rnd.randomBranches.get(1) == t2.id, "branch 1 points to t2");
        check(rnd.randomBranches.get(4) == t3.id, "branch 4 points to t3");

        // Canvas port testing for RANDOM
        canvas.zoom = 1.0; canvas.panX = 0; canvas.panY = 0;
        double rPort0Y = canvas.portScreenY(rnd, true, 0);
        double rPort4Y = canvas.portScreenY(rnd, true, 4);
        check(rPort4Y > rPort0Y, "random port 4 is positioned below port 0");
        int hitP0 = canvas.hitPort(g, canvas.portScreenX(rnd, true), rPort0Y, true);
        check(hitP0 == rnd.id && canvas.hitPortIndex == 0, "hitPort detects random port 0");
        int hitP4 = canvas.hitPort(g, canvas.portScreenX(rnd, true), rPort4Y, true);
        check(hitP4 == rnd.id && canvas.hitPortIndex == 4, "hitPort detects random port 4");

        // NBT round-trip for graph with RANDOM node
        net.minecraft.nbt.CompoundTag gTag = g.save();
        NpcDialogueGraph loadedG = NpcDialogueGraph.load(gTag);
        check(loadedG != null, "graph with RANDOM node loaded successfully");
        NpcDialogueGraph.Node loadedRnd = loadedG.get(rnd.id);
        check(loadedRnd.type == NpcDialogueGraph.RANDOM, "loaded type is RANDOM");
        check(loadedRnd.randomMin == 1 && loadedRnd.randomMax == 5, "loaded range is 1-5");
        check(loadedRnd.randomBranches.size() == 5, "loaded branches count is 5");
        check(loadedRnd.randomBranches.get(0) == t1.id && loadedRnd.randomBranches.get(4) == t3.id, "loaded branches targets match");

        g.remove(rnd.id);
        g.remove(t1.id);
        g.remove(t2.id);
        g.remove(t3.id);

        System.out.println("PASS: "+checks+" assertions on actual graph/model/profile/NBT and canvas math");
        System.out.println("No Minecraft world, server, client, renderer or GUI was started.");
    }
}
