import dev.settledlands.npc.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import java.lang.reflect.*;
import java.util.*;

/** Actual GuideDialogue/graph/action/controller bytecode, capture-only network and small API doubles. */
public final class GraphRuntimeHarness {
    static int checks;
    static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    static void pick(ServerPlayer player,GuideNpc npc,int index)throws Exception{
        Field field=GuideDialogue.class.getDeclaredField("SESSIONS");field.setAccessible(true);
        Object session=((Map<?,?>)field.get(null)).get(player.getUUID());
        if(session!=null){Field debounce=session.getClass().getDeclaredField("lastPick");debounce.setAccessible(true);debounce.setLong(session,0);}
        GuideDialogue.pick(player,npc.id,index);
    }
    public static void main(String[] args)throws Exception{
        MinecraftServer server=new MinecraftServer();ServerLevel level=new ServerLevel(server);ServerPlayer player=new ServerPlayer(level);GuideNpc npc=new GuideNpc(level,81);
        NpcDialogueGraph g=new NpcDialogueGraph();g.enabled=true;
        NpcDialogueGraph.Node a=g.add(NpcDialogueGraph.LINE,0,0),b=g.add(NpcDialogueGraph.BUTTON,300,100),c=g.add(NpcDialogueGraph.LINE,600,0);
        a.text="Entry";b.text="Go forward";c.text="Second";b.relation=5;g.entry=a.id;g.connect(a.id,b.id);g.connect(b.id,c.id);g.connect(c.id,a.id);
        npc.profile.dialogueGraph=g;GuideDialogue.start(player,npc);
        check(GuideDialogue.isInDialogue(player),"actual graph start creates a dialogue session");
        NpcNet.DlgView view=NpcNet.lastView(player);check(view.text().equals("Entry")&&view.options().equals(List.of("Go forward")),"entry text and connected button sent");
        check(view.state()==1&&!view.observer(),"normal player graph state");
        pick(player,npc,999);check(NpcNet.lastView(player).text().equals("Entry"),"forged option cannot advance");
        pick(player,npc,0);check(NpcNet.lastView(player).text().equals("Second")&&npc.relation==5,"button advances and relation changes once");
        check(NpcNet.lastView(player).options().isEmpty(),"replica chain continuation has no buttons");
        for(int i=0;i<8;i++){GuideDialogue.onServerTick(new net.neoforged.neoforge.event.tick.ServerTickEvent.Post(server));}
        check(NpcNet.lastView(player).text().equals("Second"),"no automatic transition or cycle on server tick");
        pick(player,npc,0);check(NpcNet.lastView(player).text().equals("Entry"),"backward line link follows explicit Next");
        b.relation=0;for(int i=0;i<40;i++){pick(player,npc,0);pick(player,npc,0);}
        check(NpcNet.lastView(player).text().equals("Entry"),"forty cycles remain bounded by explicit picks");
        check(npc.relation==5,"no hidden action/relation repetitions outside picks");

        b.minRelation=20;GuideDialogue.resend(player,npc.profile);
        check(NpcNet.lastView(player).options().equals(List.of("#gui.settledlands.dlg.finish")),"invisible choice replaced with finish");
        b.minRelation=0;b.pointsName="Coins";b.minPoints=2;b.maxPoints=5;NpcPoints.balance=3;GuideDialogue.resend(player,npc.profile);
        check(NpcNet.lastView(player).options().equals(List.of("Go forward")),"points requirement displays available button");
        NpcPoints.balance=0;pick(player,npc,0);
        check(NpcNet.lastView(player).text().equals("Entry")&&GuideDialogue.isInDialogue(player),"stale click rechecks current points before acting");
        b.pointsName="";GuideDialogue.resend(player,npc.profile);pick(player,npc,0);
        check(NpcNet.lastView(player).text().equals("Second"),"recovered valid choice");
        c.next=-1;GuideDialogue.resend(player,npc.profile);pick(player,npc,0);
        check(!GuideDialogue.isInDialogue(player),"unconnected leaf closes explicitly");

        npc.profile.escortCode="road";npc.profile.escortCoordinates="100 64 0";b.action="trigger:go road";GuideDialogue.start(player,npc);pick(player,npc,0);
        check(npc.isEscorting()&&npc.escort.belongsTo(player),"graph button trigger preserves speaking player and actual NPC");
        check(!GuideDialogue.isInDialogue(player),"go transition clears old graph session instead of sending stale graph");
        GuideDialogue.start(player,npc);
        check(NpcNet.lastView(player).text().equals("Мы почти пришли")&&NpcNet.lastView(player).options().size()==1,"escort still overrides graph dialogue");
        GuideDialogue.stop(player);npc.finishEscort();
        npc.profile.dialogueGraph=g;g.connect(a.id,c.id);b.action="";GuideDialogue.start(player,npc);
        check(NpcNet.lastView(player).options().size()==2,"choice and direct continuation coexist");
        pick(player,npc,1);check(NpcNet.lastView(player).text().equals("Second"),"direct continuation index is distinct from button");
        // Build 89: Live Trigger node execution
        NpcDialogueGraph.Node trig1=g.add(NpcDialogueGraph.TRIGGER,150,200);
        trig1.action="trigger:relation 10";
        g.connect(a.id,trig1.id);
        GuideDialogue.start(player,npc);
        int prevRel=npc.relation;
        pick(player,npc,1);
        check(npc.relation==prevRel+10,"line attached trigger executes on line advance");

        g.disconnect(a.id,trig1.id);
        NpcDialogueGraph.Node trig2=g.add(NpcDialogueGraph.TRIGGER,350,200);
        trig2.action="trigger:relation 7";
        g.connect(b.id,trig2.id);
        g.connect(c.id,a.id);
        GuideDialogue.start(player,npc);
        prevRel=npc.relation;
        pick(player,npc,0);
        check(npc.relation==prevRel+7,"button attached trigger executes on button click");

        NpcDialogueGraph.Node trig3=g.add(NpcDialogueGraph.TRIGGER,500,200);
        trig3.action="trigger:relation 3";
        g.connect(trig2.id,trig3.id);
        GuideDialogue.start(player,npc);
        prevRel=npc.relation;
        pick(player,npc,0);
        check(npc.relation==prevRel+10,"chained triggers execute in sequence");

        // Sequential replica chain test (no choices, LMB continuation)
        NpcDialogueGraph chainGraph=new NpcDialogueGraph();chainGraph.enabled=true;
        NpcDialogueGraph.Node line1=chainGraph.add(NpcDialogueGraph.LINE,0,0);
        NpcDialogueGraph.Node line2=chainGraph.add(NpcDialogueGraph.LINE,300,0);
        NpcDialogueGraph.Node lineTrig=chainGraph.add(NpcDialogueGraph.TRIGGER,150,150);
        line1.text="Replica 1";line2.text="Replica 2";lineTrig.action="trigger:relation 15";
        chainGraph.entry=line1.id;
        chainGraph.connect(line1.id,line2.id);
        chainGraph.connect(line1.id,lineTrig.id);
        npc.profile.dialogueGraph=chainGraph;
        GuideDialogue.start(player,npc);
        check(NpcNet.lastView(player).options().isEmpty(),"replica chain line 1 has no buttons");
        check(NpcNet.lastView(player).text().equals("Replica 1"),"replica chain starts at line 1");
        prevRel=npc.relation;
        pick(player,npc,0); // LMB click on empty space sends pick(0)
        check(NpcNet.lastView(player).options().isEmpty(),"replica chain line 2 has no buttons");
        check(NpcNet.lastView(player).text().equals("Replica 2"),"replica chain advances to line 2 on LMB");
        check(npc.relation==prevRel+15,"trigger executed on replica advance");

        // Close trigger execution test (closing via Esc/stop executes pending line triggers)
        NpcDialogueGraph.Node exitTrig=chainGraph.add(NpcDialogueGraph.TRIGGER,450,150);
        exitTrig.action="trigger:relation 8";
        chainGraph.connect(line2.id,exitTrig.id);
        prevRel=npc.relation;
        GuideDialogue.stop(player); // Player presses Esc
        check(npc.relation==prevRel+8,"closing dialogue via Esc/stop executes pending node triggers");
        check(!GuideDialogue.isInDialogue(player),"dialogue stopped cleanly");

        // Build 90: Sequential Trigger routing: Replica 1 -> Trigger -> Replica 2
        NpcDialogueGraph seqGraph=new NpcDialogueGraph();seqGraph.enabled=true;
        NpcDialogueGraph.Node r1=seqGraph.add(NpcDialogueGraph.LINE,0,0);
        NpcDialogueGraph.Node midTrig=seqGraph.add(NpcDialogueGraph.TRIGGER,200,0);
        NpcDialogueGraph.Node r2=seqGraph.add(NpcDialogueGraph.LINE,400,0);
        r1.text="First phrase";r2.text="Second phrase";midTrig.action="trigger:relation 25";
        seqGraph.entry=r1.id;
        seqGraph.connect(r1.id,midTrig.id); // r1 triggers midTrig
        seqGraph.connect(midTrig.id,r2.id);  // midTrig leads to r2
        npc.profile.dialogueGraph=seqGraph;
        GuideDialogue.start(player,npc);
        check(NpcNet.lastView(player).text().equals("First phrase"),"starts on first phrase");
        check(NpcNet.lastView(player).options().isEmpty(),"no buttons in sequential chain");
        prevRel=npc.relation;
        pick(player,npc,0); // LMB click advances through trigger to r2
        check(npc.relation==prevRel+25,"trigger between replicas executes upon LMB advance");
        check(NpcNet.lastView(player).text().equals("Second phrase"),"dialogue advances to second phrase through trigger");
        check(NpcNet.lastView(player).options().isEmpty(),"second phrase continuation has no buttons");
        pick(player,npc,0); // LMB click closes last phrase
        check(!GuideDialogue.isInDialogue(player), "dialogue finishes cleanly after second phrase");

        // Build 90: Screenshot Topology Test:
        // Button #4 ("Пшелнах") -> Replica #6 ("Ну и кто так начинает общение?")
        // Replica #6 -> Replica #7 ("Давай начнем сначала?")
        // Trigger #8 ("/tp ~ ~5 ~") -> Replica #7 (incoming trigger directly into Replica #7!)
        NpcDialogueGraph userGraph=new NpcDialogueGraph();userGraph.enabled=true;
        NpcDialogueGraph.Node uRoot=userGraph.add(NpcDialogueGraph.LINE,0,0);
        NpcDialogueGraph.Node uBtn4=userGraph.add(NpcDialogueGraph.BUTTON,150,0);
        NpcDialogueGraph.Node uRep6=userGraph.add(NpcDialogueGraph.LINE,300,0);
        NpcDialogueGraph.Node uRep7=userGraph.add(NpcDialogueGraph.LINE,500,0);
        NpcDialogueGraph.Node uTrig8=userGraph.add(NpcDialogueGraph.TRIGGER,400,150);

        uRoot.text="Hello!";
        uBtn4.text="Пшелнах";
        uRep6.text="Ну и кто так начинает общение?";
        uRep7.text="Давай начнем сначала?";
        uTrig8.action="trigger:relation 42"; // models trigger command (e.g. /tp ~ ~5 ~)

        userGraph.entry=uRoot.id;
        userGraph.connect(uRoot.id,uBtn4.id); // Root has Button 4
        userGraph.connect(uBtn4.id,uRep6.id);  // Button 4 leads to Replica 6
        userGraph.connect(uRep6.id,uRep7.id);  // Replica 6 leads to Replica 7 (cyan cable)
        userGraph.connect(uTrig8.id,uRep7.id); // Trigger 8 leads to Replica 7 (white cable!)

        npc.profile.dialogueGraph=userGraph;
        GuideDialogue.start(player,npc);
        check(NpcNet.lastView(player).options().size()==1,"root has one button option");
        check(NpcNet.lastView(player).options().get(0).equals("Пшелнах"),"button option is Пшелнах");

        // Click button "Пшелнах" -> opens Replica 6
        prevRel=npc.relation;
        pick(player,npc,0);
        check(NpcNet.lastView(player).text().equals("Ну и кто так начинает общение?"),"dialogue is on Replica 6");
        check(NpcNet.lastView(player).options().isEmpty(),"Replica 6 is sequential continuation without buttons");
        check(npc.relation==prevRel,"Trigger 8 has not executed yet on Replica 6");

        // Click LMB to advance from Replica 6 to Replica 7 -> Trigger 8 must execute upon entering Replica 7!
        pick(player,npc,0);
        check(npc.relation==prevRel+42,"Trigger 8 (/tp ~ ~5 ~) executed upon entering Replica 7 via incoming cable!");
        check(NpcNet.lastView(player).text().equals("Давай начнем сначала?"),"dialogue is on Replica 7");
        check(NpcNet.lastView(player).options().isEmpty(),"Replica 7 is continuation");

        // Next LMB finishes dialogue cleanly
        pick(player,npc,0);
        check(!GuideDialogue.isInDialogue(player),"dialogue finishes cleanly after Replica 7");

        // Build 90: Explicit Timing Test:
        // Incoming triggers activate at the START of the replica
        // Outgoing triggers activate at the END of the replica
        NpcDialogueGraph timingGraph=new NpcDialogueGraph();timingGraph.enabled=true;
        NpcDialogueGraph.Node tRep1=timingGraph.add(NpcDialogueGraph.LINE,0,0);
        NpcDialogueGraph.Node tRep2=timingGraph.add(NpcDialogueGraph.LINE,300,0);
        NpcDialogueGraph.Node inTrig=timingGraph.add(NpcDialogueGraph.TRIGGER,150,100);
        NpcDialogueGraph.Node outTrig=timingGraph.add(NpcDialogueGraph.TRIGGER,450,100);

        tRep1.text="Replica 1";
        tRep2.text="Replica 2";
        inTrig.action="trigger:relation 100";  // incoming to Replica 2
        outTrig.action="trigger:relation 200"; // outgoing from Replica 2

        timingGraph.entry=tRep1.id;
        timingGraph.connect(tRep1.id,tRep2.id); // Rep1 -> Rep2
        timingGraph.connect(inTrig.id,tRep2.id); // inTrig -> Rep2 (Incoming to Rep2)
        timingGraph.connect(tRep2.id,outTrig.id); // Rep2 -> outTrig (Outgoing from Rep2)

        npc.profile.dialogueGraph=timingGraph;
        GuideDialogue.start(player,npc);
        prevRel=npc.relation;
        check(NpcNet.lastView(player).text().equals("Replica 1"),"starts at Replica 1");
        check(npc.relation==prevRel,"neither inTrig nor outTrig executed on Replica 1");

        // Player finishes Replica 1 -> entering Replica 2
        pick(player,npc,0);
        check(NpcNet.lastView(player).text().equals("Replica 2"),"now at Replica 2");
        check(npc.relation==prevRel+100,"inTrig executed at the START of Replica 2");
        check(npc.relation<prevRel+300,"outTrig has NOT executed yet while reading Replica 2");

        // Player finishes Replica 2 -> leaving Replica 2
        pick(player,npc,0);
        check(npc.relation==prevRel+300,"outTrig executed at the END of Replica 2");
        check(!GuideDialogue.isInDialogue(player),"dialogue ended cleanly");

        // Build 91: Variable and IF nodes runtime test
        npc.relation = 0;
        NpcDialogueGraph varIfGraph=new NpcDialogueGraph();varIfGraph.enabled=true;
        NpcDialogueGraph.Node vEntry=varIfGraph.add(NpcDialogueGraph.LINE,0,0);
        NpcDialogueGraph.Node vBtn=varIfGraph.add(NpcDialogueGraph.BUTTON,150,0);
        NpcDialogueGraph.Node vNode=varIfGraph.add(NpcDialogueGraph.VARIABLE,300,0);
        NpcDialogueGraph.Node ifCond=varIfGraph.add(NpcDialogueGraph.IF,500,0);
        NpcDialogueGraph.Node trueRep=varIfGraph.add(NpcDialogueGraph.LINE,700,-50);
        NpcDialogueGraph.Node falseRep=varIfGraph.add(NpcDialogueGraph.LINE,700,100);

        vEntry.text="Greeting";
        vBtn.text="Drink potion";
        vNode.pointsName="mana";
        vNode.varValue=5;
        ifCond.varCompare=10;
        ifCond.varOp=2; // >= 10
        trueRep.text="You feel powerful!";
        falseRep.text="You need more mana.";

        varIfGraph.entry=vEntry.id;
        varIfGraph.connect(vEntry.id,vBtn.id);
        varIfGraph.connect(vBtn.id,vNode.id);
        varIfGraph.connect(vNode.id,ifCond.id); // wire variable to if
        varIfGraph.connect(ifCond.id,trueRep.id,0); // True branch
        varIfGraph.connect(ifCond.id,falseRep.id,1); // False branch

        npc.profile.dialogueGraph=varIfGraph;
        NpcPoints.pointsStore.put("mana",0);

        // Turn 1: mana starts at 0, drink potion adds +5, 5 < 10 -> goes to falseRep
        GuideDialogue.start(player,npc);
        check(NpcNet.lastView(player).text().equals("Greeting"),"starts at Greeting");
        pick(player,npc,0); // click "Drink potion"
        check(NpcPoints.get(server).get(player.getUUID(),"mana",false)==5,"variable node added +5 mana to player points");
        check(NpcNet.lastView(player).text().equals("You need more mana."),"mana=5 was < 10, correctly branched to False branch");

        pick(player,npc,0); // finish dialogue
        check(!GuideDialogue.isInDialogue(player),"dialogue finished");

        // Turn 2: mana is now 5, drink potion adds +5 = 10, 10 >= 10 -> goes to trueRep
        GuideDialogue.start(player,npc);
        pick(player,npc,0); // click "Drink potion"
        check(NpcPoints.get(server).get(player.getUUID(),"mana",false)==10,"variable node added another +5 mana, now 10");
        check(NpcNet.lastView(player).text().equals("You feel powerful!"),"mana=10 was >= 10, correctly branched to True branch");

        pick(player,npc,0); // finish dialogue
        check(!GuideDialogue.isInDialogue(player),"dialogue finished");

        // Test subtraction (negative delta):
        NpcDialogueGraph.Node subNode=varIfGraph.add(NpcDialogueGraph.VARIABLE,300,150);
        subNode.pointsName="mana";
        subNode.varValue=-4; // subtract 4
        NpcDialogueGraph.Node castRep=varIfGraph.add(NpcDialogueGraph.LINE,500,150);
        castRep.text="Cast spell";
        NpcDialogueGraph.Node vBtnCast=varIfGraph.add(NpcDialogueGraph.BUTTON,150,150);
        vBtnCast.text="Cast";
        varIfGraph.connect(vEntry.id,vBtnCast.id);
        varIfGraph.connect(vBtnCast.id,subNode.id);
        varIfGraph.connect(subNode.id,castRep.id);

        GuideDialogue.start(player,npc);
        pick(player,npc,1); // click "Cast" (option 1)
        check(NpcPoints.get(server).get(player.getUUID(),"mana",false)==6,"variable node with -4 subtracted points from 10 to 6");
        check(NpcNet.lastView(player).text().equals("Cast spell"),"transitioned to castRep");
        pick(player,npc,0);
        check(!GuideDialogue.isInDialogue(player),"dialogue finished");

        // Build 102: Proximity CHECK Node test:
        // [check player (radius 5)] -> [if first_visit <= 0] -> [replica "Приветствую путник!"]
        NpcDialogueGraph checkGraph = new NpcDialogueGraph();
        checkGraph.enabled = true;
        NpcDialogueGraph.Node cEntry = checkGraph.add(NpcDialogueGraph.LINE, 0, 0);
        cEntry.text = "Regular greeting";
        checkGraph.entry = cEntry.id;

        NpcDialogueGraph.Node chkNode = checkGraph.add(NpcDialogueGraph.CHECK, 200, 200);
        chkNode.checkTarget = NpcDialogueGraph.TARGET_PLAYER;
        chkNode.checkRadius = 5;
        chkNode.checkCooldown = 10;

        NpcDialogueGraph.Node ifNodeCheck = checkGraph.add(NpcDialogueGraph.IF, 400, 200);
        ifNodeCheck.pointsName = "first_visit";
        ifNodeCheck.varOp = 4; // <= 0
        ifNodeCheck.varCompare = 0;

        NpcDialogueGraph.Node welcomeRep = checkGraph.add(NpcDialogueGraph.LINE, 600, 200);
        welcomeRep.text = "Приветствую путник!";

        checkGraph.connect(chkNode.id, ifNodeCheck.id);
        checkGraph.connect(ifNodeCheck.id, welcomeRep.id, 0); // True branch -> replica

        npc.profile.dialogueGraph = checkGraph;
        NpcPoints.pointsStore.put("first_visit", 0);

        // Step 1: Player is outside radius (distance 20 blocks > 5)
        player.x = 20; player.y = 64; player.z = 20;
        npc.x = 0; npc.y = 64; npc.z = 0;
        npc.tickCheckNodes(true);
        check(!GuideDialogue.isInDialogue(player), "player outside radius does not trigger check node");

        // Step 2: Player approaches NPC (distance 3 blocks <= 5) and has points <= 0
        player.x = 3; player.y = 64; player.z = 0;
        npc.tickCheckNodes(true);
        check(GuideDialogue.isInDialogue(player), "check node triggered dialogue automatically upon entering radius without right-click");
        check(NpcNet.lastView(player).text().equals("Приветствую путник!"), "dialogue opened directly at the welcome replica");

        // Step 3: Player finishes reading replica
        pick(player, npc, 0);
        check(!GuideDialogue.isInDialogue(player), "dialogue finished cleanly");

        // Step 4: Player remains inside radius -> cooldown prevents instant re-triggering
        npc.tickCheckNodes(true);
        check(!GuideDialogue.isInDialogue(player), "cooldown prevents re-triggering while remaining in radius");

        // Step 5: Advance time past cooldown, but first_visit is now > 0 (not <= 0)
        level.gameTime += 300; // +15 seconds > 10s cooldown
        NpcPoints.pointsStore.put("first_visit", 5);
        npc.tickCheckNodes(true);
        check(!GuideDialogue.isInDialogue(player), "IF condition failed (> 0), so dialogue is NOT opened");

        // Test Trigger-only proximity chain:
        // [check player (radius 4)] -> [trigger relation +15] (no replica)
        NpcDialogueGraph trigOnlyGraph = new NpcDialogueGraph();
        trigOnlyGraph.enabled = true;
        NpcDialogueGraph.Node tEntry = trigOnlyGraph.add(NpcDialogueGraph.LINE, 0, 0);
        tEntry.text = "Root";
        trigOnlyGraph.entry = tEntry.id;
        NpcDialogueGraph.Node chkTrig = trigOnlyGraph.add(NpcDialogueGraph.CHECK, 150, 0);
        chkTrig.checkRadius = 4;
        chkTrig.checkCooldown = 5;
        NpcDialogueGraph.Node actionTrig = trigOnlyGraph.add(NpcDialogueGraph.TRIGGER, 300, 0);
        actionTrig.action = "trigger:relation 15";
        trigOnlyGraph.connect(chkTrig.id, actionTrig.id);

        npc.profile.dialogueGraph = trigOnlyGraph;
        prevRel = npc.relation;
        level.gameTime += 200;
        player.x = 2; player.y = 64; player.z = 0; // within radius 4
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel + 15, "proximity check executed trigger command");
        check(!GuideDialogue.isInDialogue(player), "trigger-only chain does NOT open dialogue window");

        // Test Variable + Replica proximity chain:
        // [check player (radius 6)] -> [variable visits +1] -> [replica "Welcome back!"]
        NpcDialogueGraph varRepGraph = new NpcDialogueGraph();
        varRepGraph.enabled = true;
        NpcDialogueGraph.Node vRoot = varRepGraph.add(NpcDialogueGraph.LINE, 0, 0);
        vRoot.text = "Root";
        varRepGraph.entry = vRoot.id;
        NpcDialogueGraph.Node chkVar = varRepGraph.add(NpcDialogueGraph.CHECK, 150, 0);
        chkVar.checkRadius = 6;
        chkVar.checkCooldown = 5;
        NpcDialogueGraph.Node vNodeVisits = varRepGraph.add(NpcDialogueGraph.VARIABLE, 300, 0);
        vNodeVisits.pointsName = "visits";
        vNodeVisits.varValue = 1;
        NpcDialogueGraph.Node repBack = varRepGraph.add(NpcDialogueGraph.LINE, 500, 0);
        repBack.text = "Welcome back!";
        varRepGraph.connect(chkVar.id, vNodeVisits.id);
        varRepGraph.connect(vNodeVisits.id, repBack.id);

        npc.profile.dialogueGraph = varRepGraph;
        NpcPoints.pointsStore.put("visits", 0);
        level.gameTime += 200;
        player.x = 4; player.y = 64; player.z = 0; // within radius 6
        npc.tickCheckNodes(true);
        check(NpcPoints.get(server).get(player.getUUID(), "visits", false) == 1, "proximity check incremented variable visits");
        check(GuideDialogue.isInDialogue(player), "proximity check reached replica and opened dialogue");
        check(NpcNet.lastView(player).text().equals("Welcome back!"), "opened replica matches chain destination");
        pick(player, npc, 0);
        check(!GuideDialogue.isInDialogue(player), "dialogue finished cleanly");

        // Build 103: Live DAMAGE node tests
        NpcDialogueGraph dmgGraph = new NpcDialogueGraph();
        dmgGraph.enabled = true;
        NpcDialogueGraph.Node dRoot = dmgGraph.add(NpcDialogueGraph.LINE, 0, 0);
        dRoot.text = "Idle";
        dmgGraph.entry = dRoot.id;

        NpcDialogueGraph.Node dNodePlayer = dmgGraph.add(NpcDialogueGraph.DAMAGE, 150, 0);
        dNodePlayer.damageFilter = NpcDialogueGraph.DAMAGE_PLAYER;
        dNodePlayer.minDamage = 2;
        dNodePlayer.damageCooldown = 5; // 5 seconds = 100 ticks

        NpcDialogueGraph.Node dOuch = dmgGraph.add(NpcDialogueGraph.LINE, 350, 0);
        dOuch.text = "Why did you hit me?!";
        dmgGraph.connect(dNodePlayer.id, dOuch.id);

        npc.profile.dialogueGraph = dmgGraph;

        // Damage source from player
        net.minecraft.world.damagesource.DamageSource playerDmg = new net.minecraft.world.damagesource.DamageSource(player);

        // 1. Damage below minDamage (1.0 < 2.0)
        npc.hurt(playerDmg, 1.0f);
        check(!GuideDialogue.isInDialogue(player), "damage below minDamage does not trigger node");

        // 2. Damage from monster when filter is PLAYER
        class TestMonster extends net.minecraft.world.entity.Entity implements net.minecraft.world.entity.monster.Enemy {}
        TestMonster monster = new TestMonster();
        net.minecraft.world.damagesource.DamageSource monsterDmg = new net.minecraft.world.damagesource.DamageSource(monster);
        npc.hurt(monsterDmg, 5.0f);
        check(!GuideDialogue.isInDialogue(player), "monster damage does not match DAMAGE_PLAYER filter");

        // 3. Valid damage from player (3.0 >= 2.0)
        npc.hurt(playerDmg, 3.0f);
        check(GuideDialogue.isInDialogue(player), "player damage triggers DAMAGE_PLAYER and opens dialogue");
        check(NpcNet.lastView(player).text().equals("Why did you hit me?!"), "dialogue line matches damage next");
        pick(player, npc, 0);
        check(!GuideDialogue.isInDialogue(player), "damage dialogue closed");

        // 4. Cooldown prevents immediate re-trigger
        npc.hurt(playerDmg, 5.0f);
        check(!GuideDialogue.isInDialogue(player), "cooldown prevents immediate re-trigger of DAMAGE node");

        // 5. After cooldown expires, triggers again
        level.gameTime += 120; // +6 seconds > 5s cooldown
        npc.hurt(playerDmg, 5.0f);
        check(GuideDialogue.isInDialogue(player), "after cooldown, damage node triggers again");
        pick(player, npc, 0);

        // 6. Test DAMAGE_MONSTER with trigger action
        NpcDialogueGraph monsterGraph = new NpcDialogueGraph();
        monsterGraph.enabled = true;
        NpcDialogueGraph.Node mRoot = monsterGraph.add(NpcDialogueGraph.LINE, 0, 0);
        mRoot.text = "Root";
        monsterGraph.entry = mRoot.id;

        NpcDialogueGraph.Node dNodeMonster = monsterGraph.add(NpcDialogueGraph.DAMAGE, 150, 0);
        dNodeMonster.damageFilter = NpcDialogueGraph.DAMAGE_MONSTER;
        dNodeMonster.minDamage = 1;
        dNodeMonster.damageCooldown = 2;
        dNodeMonster.action = "trigger:relation -10";

        npc.profile.dialogueGraph = monsterGraph;
        prevRel = npc.relation;
        level.gameTime += 100;
        npc.hurt(monsterDmg, 2.0f);
        check(npc.relation == prevRel - 10, "DAMAGE_MONSTER triggered command on monster attack");
        check(!GuideDialogue.isInDialogue(player), "monster damage without player context does not open dialogue for player");

        // 7. Test DAMAGE_NON_PLAYER
        NpcDialogueGraph nonPlayerGraph = new NpcDialogueGraph();
        nonPlayerGraph.enabled = true;
        NpcDialogueGraph.Node npRoot = nonPlayerGraph.add(NpcDialogueGraph.LINE, 0, 0);
        npRoot.text = "Root";
        nonPlayerGraph.entry = npRoot.id;

        NpcDialogueGraph.Node dNodeNonPlayer = nonPlayerGraph.add(NpcDialogueGraph.DAMAGE, 150, 0);
        dNodeNonPlayer.damageFilter = NpcDialogueGraph.DAMAGE_NON_PLAYER;
        dNodeNonPlayer.minDamage = 1;
        dNodeNonPlayer.action = "trigger:relation -5";

        npc.profile.dialogueGraph = nonPlayerGraph;
        prevRel = npc.relation;
        level.gameTime += 100;
        // Player damage should NOT trigger NON_PLAYER
        npc.hurt(playerDmg, 5.0f);
        check(npc.relation == prevRel, "DAMAGE_NON_PLAYER ignored player damage");

        // Monster damage should trigger NON_PLAYER
        npc.hurt(monsterDmg, 2.0f);
        check(npc.relation == prevRel - 5, "DAMAGE_NON_PLAYER triggered on monster damage");

        // Build 104/105: TIME, TIMER, and ANIMATION runtime tests
        // 1. TIME node runtime test (TIME_CUSTOM at 6000 ticks)
        NpcDialogueGraph timeGraph = new NpcDialogueGraph();
        timeGraph.enabled = true;
        NpcDialogueGraph.Node timeRoot = timeGraph.add(NpcDialogueGraph.LINE, 0, 0);
        timeRoot.text = "Time Root";
        timeGraph.entry = timeRoot.id;

        NpcDialogueGraph.Node tNode = timeGraph.add(NpcDialogueGraph.TIME, 150, 0);
        tNode.timeMode = NpcDialogueGraph.TIME_CUSTOM;
        tNode.timeTicks = 6000; // Noon
        tNode.action = "trigger:relation 10";
        NpcDialogueGraph.Node tLine = timeGraph.add(NpcDialogueGraph.LINE, 300, 0);
        tLine.text = "Sun is high in the sky!";
        timeGraph.connect(tNode.id, tLine.id);

        npc.profile.dialogueGraph = timeGraph;
        prevRel = npc.relation;
        level.dayTime = 5000; // Before 6000
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel, "TIME node does not trigger before reaching target time (5000 < 6000)");

        level.dayTime = 6050; // Passed 6000
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel + 10, "TIME node triggered action upon reaching target time");
        check(GuideDialogue.isInDialogue(player), "TIME node opened dialogue for nearest player");
        check(NpcNet.lastView(player).text().equals("Sun is high in the sky!"), "TIME node showed target line to player");
        GuideDialogue.stop(player);

        level.dayTime = 7000; // Same day later
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel + 10, "TIME node does not re-trigger on the same day");

        level.dayTime = 24000 + 6050; // Next day at noon
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel + 20, "TIME node triggers again on next day at noon");
        GuideDialogue.stop(player);

        // 2. TIMER node runtime test (repeat vs one-shot)
        NpcDialogueGraph timerGraph = new NpcDialogueGraph();
        timerGraph.enabled = true;
        NpcDialogueGraph.Node tmRoot = timerGraph.add(NpcDialogueGraph.LINE, 0, 0);
        tmRoot.text = "Timer Root";
        timerGraph.entry = tmRoot.id;

        NpcDialogueGraph.Node tmNode = timerGraph.add(NpcDialogueGraph.TIMER, 150, 0);
        tmNode.timerInterval = 5; // 5 seconds = 100 ticks
        tmNode.timerRepeat = true;
        tmNode.action = "trigger:relation 3";

        npc.profile.dialogueGraph = timerGraph;
        prevRel = npc.relation;
        level.gameTime = 1000;
        npc.tickCheckNodes(true); // First tick initializes base timer
        check(npc.relation == prevRel, "TIMER node does not fire on initial start tick");

        level.gameTime = 1050; // 50 ticks < 100 ticks
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel, "TIMER node does not fire before 100 ticks elapse");

        level.gameTime = 1105; // 105 ticks >= 100 ticks
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel + 3, "TIMER node fires after 5s interval");

        level.gameTime = 1210; // Another 105 ticks
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel + 6, "Repeating TIMER node fires again after second interval");

        // Test one-shot timer
        tmNode.timerRepeat = false;
        level.gameTime = 1320;
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel + 9, "One-shot timer fires once");

        level.gameTime = 1450;
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel + 9, "One-shot timer does not fire a second time");

        // 2b. TIMER nodes inside Walk/Anim sub-graphs run through the same engine,
        // independently of the main dialogue graph (editor stores sub-graphs disabled)
        NpcDialogueGraph walkSub = new NpcDialogueGraph();
        NpcDialogueGraph.Node wTimer = walkSub.add(NpcDialogueGraph.TIMER, 150, 0);
        wTimer.timerInterval = 5; wTimer.timerRepeat = true; wTimer.action = "trigger:relation 7";
        NpcDialogueGraph animSub = new NpcDialogueGraph();
        NpcDialogueGraph.Node aTimer = animSub.add(NpcDialogueGraph.TIMER, 150, 0);
        aTimer.timerInterval = 5; aTimer.timerRepeat = true; aTimer.action = "trigger:relation 11";

        npc.profile.dialogueGraph = null; // no main graph at all
        npc.profile.walkGraph = walkSub;
        npc.profile.animGraph = animSub;
        prevRel = npc.relation;
        level.gameTime = 2000;
        npc.tickCheckNodes(true); // arms sub-graph timers
        check(npc.relation == prevRel, "sub-graph timers arm without firing");
        level.gameTime = 2105; // 105 ticks >= 100 ticks
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel + 18, "walk and anim timers fire without a main graph (+7+11)");
        level.gameTime = 2210;
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel + 36, "walk and anim timers keep repeating on interval");
        npc.profile.walkGraph = null;
        npc.profile.animGraph = null;

        // 3. ANIMATION node runtime test ("play anim")
        NpcDialogueGraph animGraph = new NpcDialogueGraph();
        animGraph.enabled = true;
        NpcDialogueGraph.Node anNode = animGraph.add(NpcDialogueGraph.ANIMATION, 100, 0);
        anNode.animName = "dance";
        anNode.animLoop = true;
        anNode.animBone = "head";
        anNode.action = "trigger:relation 5";

        NpcDialogueGraph.Node anLine = animGraph.add(NpcDialogueGraph.LINE, 300, 0);
        anLine.text = "Look at my dance moves!";
        animGraph.connect(anNode.id, anLine.id);
        animGraph.entry = anNode.id;

        npc.profile.dialogueGraph = animGraph;
        prevRel = npc.relation;
        GuideDialogue.start(player, npc);
        check(npc.getCustomAnimName().equals("dance"), "ANIMATION node activated 'dance' animation on NPC");
        check(npc.isCustomAnimLoop(), "ANIMATION node set loop flag to true");
        check(npc.getCustomAnimBone().equals("head"), "ANIMATION node set bone mask to 'head'");
        check(npc.relation == prevRel + 5, "ANIMATION node trigger executed during dialogue start");
        check(NpcNet.lastView(player).text().equals("Look at my dance moves!"), "Dialogue signal seamlessly resolved through ANIMATION node to target line");
        GuideDialogue.stop(player);

        // 4. Test "anim" command via NpcActions (with bone target and Russian alias)
        dev.settledlands.npc.NpcActions.run(player, npc, 0, "trigger:anim wave false right_arm");
        check(npc.getCustomAnimName().equals("wave"), "NpcActions 'anim wave false right_arm' changed NPC animation to 'wave'");
        check(!npc.isCustomAnimLoop(), "NpcActions 'anim wave false right_arm' set loop flag to false");
        check(npc.getCustomAnimBone().equals("right_arm"), "NpcActions 'anim wave false right_arm' set bone to 'right_arm'");

        dev.settledlands.npc.NpcActions.run(player, npc, 0, "анимация dance цикл head");
        check(npc.getCustomAnimName().equals("dance"), "NpcActions russian 'анимация dance цикл head' set anim name");
        check(npc.isCustomAnimLoop(), "NpcActions russian 'анимация dance цикл head' set loop true");
        check(npc.getCustomAnimBone().equals("head"), "NpcActions russian 'анимация dance цикл head' set bone to head");

        dev.settledlands.npc.NpcActions.run(player, npc, 0, "anim idle true");
        check(npc.getCustomAnimName().equals("idle"), "NpcActions 'anim idle true' changed NPC animation to 'idle'");
        check(npc.isCustomAnimLoop(), "NpcActions 'anim idle true' set loop flag to true");

        // 5. Test "heal" action via NpcActions
        npc.health = 5.0f;
        dev.settledlands.npc.NpcActions.run(player, npc, 0, "heal 5");
        check(npc.getHealth() == 10.0f, "NpcActions 'heal 5' healed NPC from 5 to 10 HP");

        dev.settledlands.npc.NpcActions.run(player, npc, 0, "лечение");
        check(npc.getHealth() == 20.0f, "NpcActions 'лечение' fully restored NPC to maxHealth (20 HP)");

        npc.health = 8.0f;
        dev.settledlands.npc.NpcActions.run(player, npc, 0, "trigger: heal 4");
        check(npc.getHealth() == 12.0f, "NpcActions 'trigger: heal 4' restored 4 HP");

        // 6. Build 111: QUEST node runtime test
        NpcDialogueGraph questGraph = new NpcDialogueGraph();
        questGraph.enabled = true;
        NpcDialogueGraph.Node qRoot = questGraph.add(NpcDialogueGraph.LINE, 0, 0);
        qRoot.text = "Hello! Check my quest tab.";
        questGraph.entry = qRoot.id;

        NpcDialogueGraph.Node qn = questGraph.add(NpcDialogueGraph.QUEST, 100, 200);
        qn.text = "Slay the Dragon";
        qn.action = "trigger:relation 10";

        NpcDialogueGraph.Node qLine = questGraph.add(NpcDialogueGraph.LINE, 300, 200);
        qLine.text = "The dragon lives on top of the mountain!";
        questGraph.connect(qn.id, qLine.id);

        npc.profile.dialogueGraph = questGraph;
        GuideDialogue.start(player, npc);
        check(NpcNet.lastView(player).text().equals("Hello! Check my quest tab."), "Dialogue started at root line");

        // Open quest tab (-4)
        pick(player, npc, -4);
        NpcNet.DlgView qListView = NpcNet.lastView(player);
        check(qListView.options().contains("Slay the Dragon"), "Quest tab lists QUEST node title 'Slay the Dragon'");

        // Pick the quest (index 0)
        prevRel = npc.relation;
        pick(player, npc, 0);
        check(npc.relation == prevRel + 10, "Quest node trigger executed on pick");
        check(NpcNet.lastView(player).text().equals("The dragon lives on top of the mountain!"), "Dialogue moved to target quest line");
        GuideDialogue.stop(player);

        // 7. Build 111: IF condition connected to the back of QUEST node controls visibility
        NpcDialogueGraph.Node qIf = questGraph.add(NpcDialogueGraph.IF, 50, 200);
        qIf.pointsName = "hero_rank";
        qIf.varOp = 2; // >=
        qIf.varCompare = 5;
        // Connect IF True branch (port 0) to QUEST node input
        questGraph.connect(qIf.id, qn.id, 0);

        // Player hero_rank is 0 (< 5), quest should NOT be visible
        GuideDialogue.start(player, npc);
        pick(player, npc, -4);
        check(!NpcNet.lastView(player).options().contains("Slay the Dragon"), "Quest is HIDDEN when incoming IF condition (hero_rank >= 5) is false");
        GuideDialogue.stop(player);

        // Now set hero_rank to 5 in NpcPoints
        NpcPoints.get(player.server).set(player.getUUID(), "hero_rank", false, 5);
        GuideDialogue.start(player, npc);
        pick(player, npc, -4);
        check(NpcNet.lastView(player).options().contains("Slay the Dragon"), "Quest is VISIBLE when incoming IF condition (hero_rank >= 5) is true");

        // Test IF False branch (port 1) controlling visibility:
        NpcDialogueGraph.Node qn2 = questGraph.add(NpcDialogueGraph.QUEST, 100, 350);
        qn2.text = "Rookie Task";
        NpcDialogueGraph.Node qIfDone = questGraph.add(NpcDialogueGraph.IF, 50, 350);
        qIfDone.pointsName = "rookie_done";
        qIfDone.varOp = 0; // == 1
        qIfDone.varCompare = 1;
        // Connect port 1 (False) to qn2: visible only while rookie_done != 1
        questGraph.connect(qIfDone.id, qn2.id, 1);

        // Set rookie_done = 0 in NpcPoints
        NpcPoints.get(player.server).set(player.getUUID(), "rookie_done", false, 0);
        pick(player, npc, -4);
        check(NpcNet.lastView(player).options().contains("Rookie Task"), "Rookie Task is visible while rookie_done is 0 (False branch active)");

        // Set rookie_done = 1: rookie_done == 1 becomes true, so False branch is no longer active
        NpcPoints.get(player.server).set(player.getUUID(), "rookie_done", false, 1);
        pick(player, npc, -4);
        check(!NpcNet.lastView(player).options().contains("Rookie Task"), "Rookie Task is HIDDEN when rookie_done == 1 (False branch inactive)");
        GuideDialogue.stop(player);

        // 8. Build 112: MOVE node execution & coordinates parsing
        net.minecraft.world.phys.Vec3 orig = new net.minecraft.world.phys.Vec3(10.0, 64.0, 20.0);
        net.minecraft.world.phys.Vec3 parsedAbs = GuideDialogue.parseCoordinates("100 65 -200", orig);
        check(parsedAbs != null && parsedAbs.x == 100.0 && parsedAbs.y == 65.0 && parsedAbs.z == -200.0, "parse absolute coords");
        net.minecraft.world.phys.Vec3 parsedRel = GuideDialogue.parseCoordinates("~15 ~ ~-10", orig);
        check(parsedRel != null && parsedRel.x == 25.0 && parsedRel.y == 64.0 && parsedRel.z == 10.0, "parse relative ~ coords");
        net.minecraft.world.phys.Vec3 parsedDec = GuideDialogue.parseCoordinates("~5.5 ~1.5 ~-2.5", orig);
        check(parsedDec != null && Math.abs(parsedDec.x - 15.5) < 1e-6 && Math.abs(parsedDec.y - 65.5) < 1e-6, "parse decimal ~ coords");
        net.minecraft.world.phys.Vec3 parsedSpaced = GuideDialogue.parseCoordinates("~ 10 ~ ~ 5", orig);
        check(parsedSpaced != null && parsedSpaced.x == 20.0 && parsedSpaced.y == 64.0 && parsedSpaced.z == 25.0, "parse spaced ~ coords");
        net.minecraft.world.phys.Vec3 parsedCmd = GuideDialogue.parseCoordinates("/tp 150 70 80", orig);
        check(parsedCmd != null && parsedCmd.x == 150.0 && parsedCmd.y == 70.0 && parsedCmd.z == 80.0, "parse /tp prefixed coords");
        net.minecraft.world.phys.Vec3 parsedLabeled = GuideDialogue.parseCoordinates("X: 120, Y: 65, Z: -30", orig);
        check(parsedLabeled != null && parsedLabeled.x == 120.0 && parsedLabeled.y == 65.0 && parsedLabeled.z == -30.0, "parse labeled coords");
        net.minecraft.world.phys.Vec3 parsed2D = GuideDialogue.parseCoordinates("100 -200", orig);
        check(parsed2D != null && parsed2D.x == 100.0 && parsed2D.y == 64.0 && parsed2D.z == -200.0, "parse 2-component X Z coords");
        net.minecraft.world.phys.Vec3 parsed2DLabeled = GuideDialogue.parseCoordinates("X: 120, Z: -30", orig);
        check(parsed2DLabeled != null && parsed2DLabeled.x == 120.0 && parsed2DLabeled.y == 64.0 && parsed2DLabeled.z == -30.0, "parse 2-component labeled coords");

        NpcDialogueGraph moveGraph = new NpcDialogueGraph();
        moveGraph.enabled = true;
        npc.profile.dialogueGraph = moveGraph;
        NpcDialogueGraph.Node mStart = moveGraph.add(NpcDialogueGraph.LINE, 0, 0);
        mStart.text = "Where should we go?";
        moveGraph.entry = mStart.id;
        NpcDialogueGraph.Node mBtn = moveGraph.add(NpcDialogueGraph.BUTTON, 200, 0);
        mBtn.text = "Go to the Castle";
        mStart.choices.add(mBtn.id);
        NpcDialogueGraph.Node mNode = moveGraph.add(NpcDialogueGraph.MOVE, 400, 0);
        mNode.moveCoords = "100 64 200";
        mNode.moveSpeed = 1.8;
        mBtn.next = mNode.id;
        NpcDialogueGraph.Node mEndLine = moveGraph.add(NpcDialogueGraph.LINE, 600, 0);
        mEndLine.text = "I am on my way!";
        mNode.next = mEndLine.id;

        npc.x = 0; npc.y = 64; npc.z = 0;
        npc.customMoveTarget = null;
        GuideDialogue.start(player, npc);
        pick(player, npc, 0); // Click "Go to the Castle"
        check(npc.customMoveTarget != null && npc.customMoveTarget.x == 100.0 && npc.customMoveTarget.z == 200.0, "MOVE node sets customMoveTarget coordinates");
        check(npc.customMoveSpeed == 1.8, "MOVE node sets customMoveSpeed");
        check(NpcNet.lastView(player).text().equals("I am on my way!"), "Dialogue advanced through MOVE node to next LINE");
        GuideDialogue.stop(player);

        // Test MOVE node with moveEscort = true
        mNode.moveEscort = true;
        npc.customMoveTarget = null;
        if (npc.isEscorting()) npc.finishEscort();
        GuideDialogue.start(player, npc);
        pick(player, npc, 0); // Click "Go to the Castle" with moveEscort=true
        check(npc.isEscorting(), "MOVE node with moveEscort=true initiates beginEscort on NPC");
        check(npc.escort() != null && npc.escort().destination().getX() == 100 && npc.escort().destination().getZ() == 200, "Escort destination matches MOVE node coordinates");
        npc.finishEscort();

        // Build 114: Terminal MOVE node (mNode.next == -1) without subsequent replica
        mNode.next = -1;
        mNode.moveEscort = false;
        npc.customMoveTarget = null;
        GuideDialogue.start(player, npc);
        pick(player, npc, 0); // Click "Go to the Castle" -> terminal MOVE node
        check(npc.customMoveTarget != null && npc.customMoveTarget.x == 100.0 && npc.customMoveTarget.z == 200.0, "Terminal MOVE node (next=-1) executes custom movement on button click");
        check(!npc.isTalking(), "Terminal MOVE node closes dialogue cleanly");

        // Build 114: Terminal MOVE node with moveEscort = true (mNode.next == -1)
        mNode.moveEscort = true;
        npc.customMoveTarget = null;
        if (npc.isEscorting()) npc.finishEscort();
        GuideDialogue.start(player, npc);
        pick(player, npc, 0); // Click "Go to the Castle" -> terminal ESCORT MOVE node
        check(npc.isEscorting(), "Terminal MOVE node with moveEscort=true initiates beginEscort on button click");
        npc.finishEscort();

        // Build 114: Sequential line without choices directly transitioning to terminal MOVE node
        NpcDialogueGraph seqMoveGraph = new NpcDialogueGraph();
        seqMoveGraph.enabled = true;
        npc.profile.dialogueGraph = seqMoveGraph;
        NpcDialogueGraph.Node sLine = seqMoveGraph.add(NpcDialogueGraph.LINE, 0, 0);
        sLine.text = "Follow me to the village!";
        seqMoveGraph.entry = sLine.id;
        NpcDialogueGraph.Node sMove = seqMoveGraph.add(NpcDialogueGraph.MOVE, 200, 0);
        sMove.moveCoords = "300 64 400";
        sMove.moveEscort = true;
        sLine.next = sMove.id;

        if (npc.isEscorting()) npc.finishEscort();
        GuideDialogue.start(player, npc);
        pick(player, npc, 0); // Advance sequential replica via GRAPH_NEXT
        check(npc.isEscorting(), "Sequential line without choices transitions to terminal MOVE escort node via GRAPH_NEXT");
        check(npc.escort() != null && npc.escort().destination().getX() == 300 && npc.escort().destination().getZ() == 400, "Sequential escort destination matches MOVE node coords");
        npc.finishEscort();

        // 9. Build 112: Universal incoming IF condition on CHECK and BUTTON nodes
        npc.profile.dialogueGraph = moveGraph;
        // (a) CHECK node with incoming IF condition
        NpcDialogueGraph.Node chkIf = moveGraph.add(NpcDialogueGraph.IF, 100, 200);
        chkIf.pointsName = "allowed_to_scan";
        chkIf.varOp = 0; // == 1
        chkIf.varCompare = 1;
        NpcDialogueGraph.Node chkNodeIf = moveGraph.add(NpcDialogueGraph.CHECK, 300, 200);
        chkNodeIf.checkTarget = NpcDialogueGraph.TARGET_PLAYER;
        chkNodeIf.checkRadius = 16;
        chkNodeIf.checkCooldown = 0;
        chkNodeIf.action = "trigger:relation 5";
        moveGraph.connect(chkIf.id, chkNodeIf.id, 0); // Connect True branch to CHECK node

        // When allowed_to_scan == 0, CHECK node must NOT trigger
        NpcPoints.get(player.server).set(player.getUUID(), "allowed_to_scan", false, 0);
        prevRel = npc.relation;
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel, "CHECK node is NOT triggered when incoming IF condition is false");

        // When allowed_to_scan == 1, CHECK node triggers
        NpcPoints.get(player.server).set(player.getUUID(), "allowed_to_scan", false, 1);
        npc.tickCheckNodes(true);
        check(npc.relation == prevRel + 5, "CHECK node triggers when incoming IF condition is true");

        // (b) BUTTON node with incoming IF condition
        NpcDialogueGraph.Node btnIf = moveGraph.add(NpcDialogueGraph.IF, 100, -100);
        btnIf.pointsName = "secret_found";
        btnIf.varOp = 0; // == 1
        btnIf.varCompare = 1;
        NpcDialogueGraph.Node secretBtn = moveGraph.add(NpcDialogueGraph.BUTTON, 200, -100);
        secretBtn.text = "Secret Option";
        mStart.choices.add(secretBtn.id);
        moveGraph.connect(btnIf.id, secretBtn.id, 0); // Connect True branch to secretBtn

        // secret_found == 0 -> button must be hidden
        NpcPoints.get(player.server).set(player.getUUID(), "secret_found", false, 0);
        GuideDialogue.start(player, npc);
        check(!NpcNet.lastView(player).options().contains("Secret Option"), "BUTTON is hidden when incoming IF condition is false");
        GuideDialogue.stop(player);

        // secret_found == 1 -> button is visible
        NpcPoints.get(player.server).set(player.getUUID(), "secret_found", false, 1);
        GuideDialogue.start(player, npc);
        check(NpcNet.lastView(player).options().contains("Secret Option"), "BUTTON is visible when incoming IF condition is true");
        GuideDialogue.stop(player);

        // 10. Build 115: MOBILITY node execution and arrival triggering
        NpcDialogueGraph.Node mobNode = moveGraph.add(NpcDialogueGraph.MOBILITY, 400, 300);
        mobNode.mobilityGroupId = "group_patrol";
        mobNode.mobilityGroupName = "Patrol Route";
        NpcDialogueGraph.Node mobTrigger = moveGraph.add(NpcDialogueGraph.TRIGGER, 600, 300);
        mobTrigger.action = "trigger:relation 10";
        moveGraph.connect(mobNode.id, mobTrigger.id, 0);

        // Execute mobility node
        prevRel = npc.relation;
        GuideDialogue.executeMobilityNode(npc, mobNode);
        check("group_patrol".equals(npc.profile.mobilityGroupId), "executeMobilityNode sets profile mobilityGroupId");
        check(npc.isWatchingMobilityArrival(), "executeMobilityNode initiates arrival watching");

        // When NPC physically reaches the first point:
        npc.triggerMobilityArrival();
        check(!npc.isWatchingMobilityArrival(), "triggerMobilityArrival clears watch state");
        check(npc.relation == prevRel + 10, "triggerMobilityArrival fired downstream TRIGGER node");

        // 11. Build 116: RANDOM node runtime execution in dialogue graph
        NpcDialogueGraph.Node rndNode = moveGraph.add(NpcDialogueGraph.RANDOM, 100, 500);
        rndNode.randomMin = 1;
        rndNode.randomMax = 2;
        NpcDialogueGraph.Node rLine1 = moveGraph.add(NpcDialogueGraph.LINE, 300, 450);
        rLine1.text = "Random Line One";
        NpcDialogueGraph.Node rLine2 = moveGraph.add(NpcDialogueGraph.LINE, 300, 550);
        rLine2.text = "Random Line Two";
        moveGraph.connect(rndNode.id, rLine1.id, 0);
        moveGraph.connect(rndNode.id, rLine2.id, 1);

        int resolvedTarget = GuideDialogue.resolveExecutionTarget(player, npc, null, moveGraph, rndNode.id, null);
        check(resolvedTarget == rLine1.id || resolvedTarget == rLine2.id, "resolveExecutionTarget selects one of the random output branches");

        // 12. Mobility graph points with RANDOM and IF transitions
        NpcProfile.MobilityPoint pt0 = new NpcProfile.MobilityPoint("100 64 100", 100, "5-10");
        NpcProfile.MobilityPoint ptIf = new NpcProfile.MobilityPoint();
        ptIf.type = NpcProfile.MobilityPoint.TYPE_IF;
        ptIf.chance = 100; // Always true
        NpcProfile.MobilityPoint pt1 = new NpcProfile.MobilityPoint("120 64 100", 100, "5-10");
        NpcProfile.MobilityPoint pt2 = new NpcProfile.MobilityPoint("140 64 100", 100, "5-10");

        pt0.next = 1; // pt0 connects to ptIf (index 1)
        ptIf.next = 2; // True branch -> pt1 (index 2)
        ptIf.falseNext = 3; // False branch -> pt2 (index 3)

        java.util.List<NpcProfile.MobilityPoint> mobList = java.util.List.of(pt0, ptIf, pt1, pt2);
        java.lang.reflect.Method resolveMobMethod = GuideNpc.class.getDeclaredMethod("resolveNextMobilityPoint", java.util.List.class, int.class, int.class);
        resolveMobMethod.setAccessible(true);
        int nextMobIdx = (int) resolveMobMethod.invoke(npc, mobList, 1, 0);
        check(nextMobIdx == 2, "resolveNextMobilityPoint follows IF True branch to pt1");

        ptIf.chance = 0; // Always false
        nextMobIdx = (int) resolveMobMethod.invoke(npc, mobList, 1, 0);
        check(nextMobIdx == 3, "resolveNextMobilityPoint follows IF False branch to pt2");

        System.out.println("PASS: "+checks+" assertions on actual graph runtime/dialogue/trigger bytecode and captured packets");
        System.out.println("No Minecraft world, server, client, renderer or GUI was started.");
    }
}
