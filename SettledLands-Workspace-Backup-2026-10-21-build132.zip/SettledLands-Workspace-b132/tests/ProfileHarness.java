import dev.settledlands.npc.*;
import net.minecraft.nbt.CompoundTag;
import java.util.*;

/** Uses real Minecraft NBT classes and the actual Build 87 NpcProfile/NpcEdit bytecode. */
public final class ProfileHarness {
    static int checks;
    static void check(boolean condition,String label) {checks++;if(!condition)throw new AssertionError(label);}
    static void fields(NpcProfile a,NpcProfile b) {
        check(a.escortCode.equals(b.escortCode),"route survives");
        check(a.escortCoordinates.equals(b.escortCoordinates),"coordinates survive");
        check(a.escortTravelLine.equals(b.escortTravelLine),"travel line survives");
        check(a.escortArrivalLine.equals(b.escortArrivalLine),"arrival line survives");
    }
    public static void main(String[] args) throws Exception {
        NpcProfile p=new NpcProfile();
        check(p.escortCode.isEmpty()&&p.escortCoordinates.isEmpty(),"old/new NPC starts inactive");
        check(p.escortTravelLine.equals("Мы почти пришли"),"default travel line");
        p.escortCode="road_a";p.escortCoordinates="120 64 -35";p.escortTravelLine="Уже недалеко, %player%.";p.escortArrivalLine="Вот мы и дома.";
        p.name="Original NPC";p.idleWalking=true;p.mobilityGroupId="group-1";p.mobilityGroupName="Usual route";
        p.mobilityPoints.add(new NpcProfile.MobilityPoint("10 64 20",100,"5-10"));
        p.mobilitySchedule.add(new NpcProfile.MobilityScheduleEntry(200,"group-1"));
        p.mobilitySchedule.add(new NpcProfile.MobilityScheduleEntry(800,"group-2"));
        p.welcome="Welcome remains unchanged";
        NpcProfile copy=p.copy();fields(p,copy);
        check(copy!=p&&copy.mobilitySchedule!=p.mobilitySchedule,"copy is independent");
        NpcProfile sanitized=p.sanitized();fields(p,sanitized);
        check(sanitized.name.equals(p.name)&&sanitized.idleWalking&&sanitized.welcome.equals(p.welcome),"existing NPC settings preserved");
        CompoundTag tag=p.save(null);NpcProfile loaded=NpcProfile.load(tag,null);fields(p,loaded);
        check(loaded.mobilityPoints.size()==1&&loaded.mobilitySchedule.size()==2,"ordinary route persists");
        check(loaded.mobilityScheduleAt(0).groupId.equals("group-1"),"schedule start remains compatible");
        check(loaded.mobilityScheduleAt(800).groupId.equals("group-2"),"schedule boundary remains compatible");
        check(loaded.mobilityScheduleAt(2000).groupId.equals("group-2"),"schedule next day remains compatible");
        CompoundTag old=p.save(null);for(String key:List.of("EscortCode","EscortCoordinates","EscortTravelLine","EscortArrivalLine"))old.remove(key);
        NpcProfile migrated=NpcProfile.load(old,null);
        check(migrated.escortCode.isEmpty()&&migrated.escortCoordinates.isEmpty(),"Build 83 profile does not automatically activate escort");
        check(migrated.escortTravelLine.equals("Мы почти пришли"),"Build 83 default migration");
        check(migrated.name.equals(p.name)&&migrated.mobilitySchedule.size()==2,"migration keeps ordinary data");
        NpcProfile edited=NpcEdit.apply(p,"escort.settings",0,0,0,"new_road","1 64 2");
        check(edited.escortCode.equals("new_road")&&edited.escortCoordinates.equals("1 64 2"),"atomic editor settings packet");
        check(p.escortCode.equals("road_a"),"editing does not mutate previous snapshot");
        edited=NpcEdit.apply(edited,"field",0,0,0,"escortTravelLine","Edited travel");
        edited=NpcEdit.apply(edited,"field",0,0,0,"escortArrivalLine","Edited arrival");
        check(edited.escortTravelLine.equals("Edited travel")&&edited.escortArrivalLine.equals("Edited arrival"),"dialogue editing both lines");
        edited=NpcEdit.apply(edited,"field",0,0,0,"escortTravelLine","");
        check(edited.escortTravelLine.equals("Мы почти пришли"),"empty line restores safe default");
        edited=NpcEdit.apply(edited,"field",0,0,0,"escortArrivalLine","a".repeat(600));
        check(edited.escortArrivalLine.length()==480,"line cap");
        p.escortCode="a".repeat(100);p.escortCoordinates="1".repeat(100);sanitized=p.sanitized();
        check(sanitized.escortCode.length()==64&&sanitized.escortCoordinates.length()==64,"field caps");
        var constructor=NpcEscort.class.getDeclaredConstructor(java.util.UUID.class,String.class,net.minecraft.core.BlockPos.class);
        constructor.setAccessible(true);
        java.util.UUID owner=java.util.UUID.randomUUID();
        NpcEscort state=constructor.newInstance(owner,"road_a",new net.minecraft.core.BlockPos(120,64,-35));
        CompoundTag runtime=state.save();
        check(runtime.hasUUID("Owner")&&runtime.getUUID("Owner").equals(owner),"real runtime UUID encoding");
        check(runtime.getInt("X")==120&&runtime.getInt("Y")==64&&runtime.getInt("Z")==-35,"real runtime destination encoding");
        NpcEscort restored=NpcEscort.load(runtime,-64,320);
        check(restored!=null&&restored.owner().equals(owner)&&restored.route().equals("road_a"),"real runtime NBT round trip");
        runtime.putInt("Phase",NpcEscort.ARRIVAL_DIALOGUE);restored=NpcEscort.load(runtime,-64,320);
        check(restored.phase()==NpcEscort.WAIT_PLAYER,"real arrival reload recovery");
        runtime.putInt("Phase",NpcEscort.FINISH_WAIT);runtime.putInt("FinishTicks",70);restored=NpcEscort.load(runtime,-64,320);
        check(restored.save().getInt("FinishTicks")==70,"real remaining cooldown persists");
        runtime.putInt("Phase",99);check(NpcEscort.load(runtime,-64,320)==null,"real bad-phase rejection");
        runtime.putInt("Phase",NpcEscort.WALKING);runtime.putBoolean("CatchingUp",true);
        restored=NpcEscort.load(runtime,-64,320);
        check(restored.isCatchingUp()&&restored.save().getBoolean("CatchingUp"),"real catch-up boolean NBT round trip");
        runtime.putInt("Phase",NpcEscort.WAIT_PLAYER);
        check(!NpcEscort.load(runtime,-64,320).isCatchingUp(),"real arrived NPC cannot reload as chasing");
        runtime.putInt("Phase",NpcEscort.WALKING);runtime.remove("CatchingUp");
        check(!NpcEscort.load(runtime,-64,320).isCatchingUp(),"Build 84 runtime without catch-up field is compatible");

        // Test NpcPointsCommand: addpoint and add point with negative counts
        var dispatcher = new com.mojang.brigadier.CommandDispatcher<net.minecraft.commands.CommandSourceStack>();
        NpcPointsCommand.registerAdd(dispatcher);
        check(dispatcher.getRoot().getChild("addpoint") != null, "addpoint registered as command");
        check(dispatcher.getRoot().getChild("add") != null, "add registered as command");
        check(dispatcher.getRoot().getChild("add-point") != null, "add-point registered as command");

        var addpointCountNode = (com.mojang.brigadier.tree.ArgumentCommandNode<?, ?>) dispatcher.getRoot().getChild("addpoint").getChild("name").getChild("count");
        var addpointIntType = (com.mojang.brigadier.arguments.IntegerArgumentType) addpointCountNode.getType();
        check(addpointIntType.getMinimum() == -1000000, "addpoint count minimum allows negative -1000000");
        check(addpointIntType.getMaximum() == 1000000, "addpoint count maximum is 1000000");
        check(addpointIntType.parse(new com.mojang.brigadier.StringReader("-10")) == -10, "addpoint parses negative count -10");

        var addPointCountNode = (com.mojang.brigadier.tree.ArgumentCommandNode<?, ?>) dispatcher.getRoot().getChild("add").getChild("point").getChild("name").getChild("count");
        var addPointIntType = (com.mojang.brigadier.arguments.IntegerArgumentType) addPointCountNode.getType();
        check(addPointIntType.getMinimum() == -1000000, "add point count minimum allows negative -1000000");
        check(addPointIntType.getMaximum() == 1000000, "add point count maximum is 1000000");
        check(addPointIntType.parse(new com.mojang.brigadier.StringReader("-10")) == -10, "add point parses negative count -10");

        System.out.println("PASS: "+checks+" assertions on real Minecraft NBT and Build 87 profile/edit/runtime classes");
        System.out.println("No world, client, NeoForge server or renderer was started.");
    }
}
