"""Generate tiny API doubles; NEVER packaged into the production JAR.
The harness runs the actual compiled escort, command, shop and quest bytecode.
This tests state/authority without starting Minecraft or allocating a world.
"""
import sys
from pathlib import Path
files = {
'net/minecraft/core/BlockPos.java': '''package net.minecraft.core;
public class BlockPos { final int x,y,z; public BlockPos(int x,int y,int z){this.x=x;this.y=y;this.z=z;}
 public int getX(){return x;} public int getY(){return y;} public int getZ(){return z;}
 public BlockPos immutable(){return this;} public BlockPos offset(int x,int y,int z){return new BlockPos(this.x+x,this.y+y,this.z+z);}
 public static BlockPos containing(double x,double y,double z){return new BlockPos((int)Math.floor(x),(int)Math.floor(y),(int)Math.floor(z));}}
''',
'net/minecraft/nbt/CompoundTag.java': '''package net.minecraft.nbt;
import java.util.*; public class CompoundTag {
 public void putBoolean(String key,boolean value){putInt(key,value?1:0);}
 public boolean getBoolean(String key){return getInt(key)!=0;} final Map<String,Object> data=new HashMap<>();
 public void putUUID(String k,UUID v){data.put(k,v);} public UUID getUUID(String k){return (UUID)data.get(k);}
 public boolean hasUUID(String k){return data.get(k) instanceof UUID;}
 public void putString(String k,String v){data.put(k,v);} public String getString(String k){return data.get(k) instanceof String s?s:"";}
 public void putInt(String k,int v){data.put(k,v);} public int getInt(String k){return data.get(k) instanceof Integer n?n:0;}}
''',
'net/minecraft/world/phys/Vec3.java': '''package net.minecraft.world.phys;
public class Vec3 {public final double x,y,z; public Vec3(double x,double y,double z){this.x=x;this.y=y;this.z=z;}}
''',
'net/minecraft/world/phys/AABB.java': '''package net.minecraft.world.phys;
public class AABB {public final double x,y,z,r; public AABB(double x,double y,double z,double r){this.x=x;this.y=y;this.z=z;this.r=r;}
 public AABB inflate(double amount){return new AABB(x,y,z,r+amount);}}
''',
'net/minecraft/world/level/border/WorldBorder.java': '''package net.minecraft.world.level.border;
import net.minecraft.core.BlockPos; public class WorldBorder {public boolean allowed=true; public boolean isWithinBounds(BlockPos pos){return allowed;}}
''',
'net/minecraft/world/level/Level.java': '''package net.minecraft.world.level;
import net.minecraft.world.level.border.WorldBorder; public class Level {public final WorldBorder border=new WorldBorder();
 public int getMinBuildHeight(){return -64;} public int getMaxBuildHeight(){return 320;}
 public WorldBorder getWorldBorder(){return border;}}
''',
'net/minecraft/world/entity/Entity.java': '''package net.minecraft.world.entity;
import java.util.UUID; import net.minecraft.world.level.Level; import net.minecraft.world.phys.AABB;
public class Entity {public double x=0,y=64,z=0; public Level world; public boolean alive=true,removed=false; public UUID uuid=UUID.randomUUID();
 public double getX(){return x;} public double getY(){return y;} public double getZ(){return z;} public Level level(){return world;}
 public net.minecraft.world.phys.Vec3 position(){return new net.minecraft.world.phys.Vec3(x,y,z);}
 public boolean isAlive(){return alive;} public boolean isRemoved(){return removed;} public UUID getUUID(){return uuid;}
 public double distanceToSqr(Entity e){double dx=x-e.x,dy=y-e.y,dz=z-e.z;return dx*dx+dy*dy+dz*dz;}
 public AABB getBoundingBox(){return new AABB(x,y,z,0.3);}}
''',
'net/minecraft/world/inventory/AbstractContainerMenu.java': '''package net.minecraft.world.inventory; public class AbstractContainerMenu {}\n''',
'net/minecraft/world/inventory/InventoryMenu.java': '''package net.minecraft.world.inventory; public class InventoryMenu extends AbstractContainerMenu {}\n''',
'net/minecraft/world/entity/player/Player.java': '''package net.minecraft.world.entity.player;
import net.minecraft.world.entity.Entity; import net.minecraft.world.inventory.AbstractContainerMenu; import net.minecraft.world.inventory.InventoryMenu;
public class Player extends Entity {public InventoryMenu inventoryMenu=new InventoryMenu();public AbstractContainerMenu containerMenu=inventoryMenu;}
''',
'net/minecraft/network/chat/Component.java': '''package net.minecraft.network.chat;
import java.util.Arrays; public interface Component {
 static MutableComponent translatable(String key,Object... args){return new MutableComponent(key+Arrays.toString(args));}
 static MutableComponent literal(String s){return new MutableComponent(s);} String getString();}
''',
'net/minecraft/network/chat/MutableComponent.java': '''package net.minecraft.network.chat;
public class MutableComponent implements Component {public final String text;public MutableComponent(String text){this.text=text;}public String getString(){return text;}public String toString(){return text;}}\n''',
'net/minecraft/server/players/PlayerList.java': '''package net.minecraft.server.players;
import java.util.*;import net.minecraft.server.level.ServerPlayer; public class PlayerList {public final Map<UUID,ServerPlayer> players=new HashMap<>();
 public ServerPlayer getPlayer(UUID id){return players.get(id);}}
''',
'net/minecraft/server/MinecraftServer.java': '''package net.minecraft.server;
import net.minecraft.server.players.PlayerList; public class MinecraftServer {public int tick; public final PlayerList players=new PlayerList();
 public int getTickCount(){return tick;} public PlayerList getPlayerList(){return players;}}
''',
'net/minecraft/server/level/ServerLevel.java': '''package net.minecraft.server.level;
import net.minecraft.server.MinecraftServer;import net.minecraft.world.level.Level;import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;import net.minecraft.core.BlockPos;import java.util.*;import java.util.function.Predicate;
public class ServerLevel extends Level {public final MinecraftServer server; public boolean loaded=true; public int queries,chunkChecks;public final List<Entity> entities=new ArrayList<>();
 public ServerLevel(MinecraftServer s){server=s;} public MinecraftServer getServer(){return server;}
 public ServerChunkCache getChunkSource(){return new ServerChunkCache(this);}
 public boolean hasChunkAt(BlockPos p){chunkChecks++;return loaded;}
 public <T extends Entity> List<T> getEntitiesOfClass(Class<T> type,AABB box,Predicate<? super T> filter){queries++;List<T> found=new ArrayList<>();
 for(Entity e:entities)if(type.isInstance(e)&&Math.abs(e.x-box.x)<=box.r&&Math.abs(e.y-box.y)<=box.r&&Math.abs(e.z-box.z)<=box.r&&filter.test(type.cast(e)))found.add(type.cast(e));return found;}}
''',
'net/minecraft/world/level/chunk/LevelChunk.java': '''package net.minecraft.world.level.chunk; public class LevelChunk {}\n''',
'net/minecraft/server/level/ServerChunkCache.java': '''package net.minecraft.server.level;
import net.minecraft.world.level.chunk.LevelChunk; public class ServerChunkCache {final ServerLevel level;public ServerChunkCache(ServerLevel level){this.level=level;}public LevelChunk getChunkNow(int x,int z){level.chunkChecks++;return level.loaded?new LevelChunk():null;}}\n''',
'net/minecraft/server/level/ServerPlayer.java': '''package net.minecraft.server.level;
import net.minecraft.server.MinecraftServer;import net.minecraft.world.entity.player.Player;import net.minecraft.network.chat.Component;
public class ServerPlayer extends Player {public final MinecraftServer server;public boolean spectator;public int messages; public Component lastMessage;
 public ServerPlayer(ServerLevel level){world=level;server=level.server;server.players.players.put(uuid,this);}
 public boolean isSpectator(){return spectator;} public ServerLevel serverLevel(){return (ServerLevel)world;}
 public MinecraftServer getServer(){return server;}
 public void displayClientMessage(Component c,boolean actionBar){messages++;lastMessage=c;}}
''',
'net/minecraft/world/entity/ai/navigation/PathNavigation.java': '''package net.minecraft.world.entity.ai.navigation;
import net.minecraft.core.BlockPos;public class PathNavigation {public boolean done=true,canPath=true;public int calls,stops;public double tx,ty,tz;
 public double speed;public void setSpeedModifier(double value){speed=value;}
 public boolean isDone(){return done;}public void stop(){done=true;stops++;}
 public boolean moveTo(double x,double y,double z,double speed){calls++;this.speed=speed;tx=x;ty=y;tz=z;done=!canPath;return canPath;}
 public boolean moveTo(double x,double y,double z,int accuracy,double speed){return moveTo(x,y,z,speed);}
 public boolean isStableDestination(BlockPos p){return p.getY()==64;}}
''',
'net/minecraft/world/entity/ai/control/MoveControl.java': '''package net.minecraft.world.entity.ai.control;
public class MoveControl {public int stops; public void setWantedPosition(double x,double y,double z,double speed){if(speed==0)stops++;}}
''',
'dev/settledlands/npc/NpcProfile.java': '''package dev.settledlands.npc;
public class NpcProfile {public String escortCode="",escortCoordinates="",mobilityGroupId="",mobilityGroupName=""; public boolean idleWalking=false; public static class Quest {}
 public static final class MobilityPoint {
    public static final int TYPE_POINT = 0;
    public static final int TYPE_RANDOM = 1;
    public static final int TYPE_IF = 2;
    public static final int TYPE_LINK = 3;
    public int type = TYPE_POINT;
    public String coordinates = "";
    public int chance = 100;
    public String duration = "5-10";
    public int next = -1;
    public int falseNext = -1;
    public int randomMin = 1;
    public int randomMax = 2;
    public final java.util.List<Integer> randomBranches = new java.util.ArrayList<>();
    public int canvasX = 0;
    public int canvasY = 0;
    public String targetGroupId = "";
    public MobilityPoint() {}
    public MobilityPoint(String coords, int chance, String duration) { this.coordinates = coords; this.chance = chance; this.duration = duration; }
 }
 public final java.util.List<MobilityPoint> mobilityPoints = new java.util.ArrayList<>();
 public static class Topic {public int type=0; public final java.util.List<Step> steps=new java.util.ArrayList<>();}
 public static class Step {public final java.util.List<Answer> answers=new java.util.ArrayList<>();}
 public static class Answer {public int next=-1;}
 public final java.util.List<Topic> topics=new java.util.ArrayList<>();
 public static String actionKind(String text){return text!=null&&text.trim().startsWith("trigger:")?"trigger":"cmd";}
 public static String fill(String text,net.minecraft.world.entity.player.Player player,int relation){return text==null?"":text;}}
''',
'dev/settledlands/npc/GuideNpc.java': '''package dev.settledlands.npc;
import net.minecraft.world.entity.Entity;import net.minecraft.server.level.*;import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.navigation.PathNavigation;import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.phys.Vec3;import net.minecraft.network.chat.Component;
public class GuideNpc extends Entity {public int id,finished;public boolean talking;public float xxa,yya,zza;public NpcEscort escort;
 public final NpcProfile profile=new NpcProfile();public final PathNavigation navigation=new PathNavigation();public final MoveControl control=new MoveControl();public Vec3 movement=new Vec3(0,0,0);
 public GuideNpc(ServerLevel level,int id){world=level;this.id=id;level.entities.add(this);}
 public double movementAttribute=0.24;public double walkingNavigationSpeed(boolean catchUp){return EscortRules.navigationSpeed(movementAttribute,catchUp);}
 public float width=1.35F;public float getBbWidth(){return width;}
 public int getId(){return id;}public boolean isTalking(){return talking;}public boolean isEscorting(){return escort!=null;}
 public NpcEscort escort(){return escort;}public NpcProfile profile(){return profile;}
 public PathNavigation getNavigation(){return navigation;}public MoveControl getMoveControl(){return control;}
 public Vec3 getDeltaMovement(){return movement;}public void setDeltaMovement(double x,double y,double z){movement=new Vec3(x,y,z);}
 public void finishEscort(){finished++;escort=null;navigation.stop();}
 public void beginEscort(ServerPlayer p,String code,BlockPos target){escort=NpcEscort.begin(this,p,code,target);}
 public Component getName(){return Component.literal("npc-"+id);}
 public static GuideNpc find(ServerPlayer p,int id){for(Entity e:p.serverLevel().entities)if(e instanceof GuideNpc n&&n.id==id&&p.distanceToSqr(n)<=64)return n;return null;}
 public int scale = 100;
 public float getScale(){return (float)scale / 100.0f;}
 public int visualScale(){return scale;}
 public void setClientScale(int s){scale=s;}
 public void advance(){if(navigation.done||talking)return;double dx=navigation.tx-x,dy=navigation.ty-y,dz=navigation.tz-z;double distance=Math.sqrt(dx*dx+dy*dy+dz*dz);
 double step=Math.min(0.35,movementAttribute*movementAttribute*navigation.speed*navigation.speed*2.16);
 if(distance<=step){x=navigation.tx;y=navigation.ty;z=navigation.tz;navigation.done=true;}else{x+=dx/distance*step;y+=dy/distance*step;z+=dz/distance*step;}}}
''',
'dev/settledlands/npc/GuideDialogue.java': '''package dev.settledlands.npc;
import java.util.*;import net.minecraft.server.level.ServerPlayer;
public class GuideDialogue {public static final Set<UUID> busy=new HashSet<>();public static final Map<UUID,GuideNpc> arrivals=new HashMap<>();public static int opened;
 public static boolean isInDialogue(ServerPlayer p){return busy.contains(p.uuid)||arrivals.containsKey(p.uuid);}
 public static boolean hasEscortConversation(ServerPlayer p,GuideNpc n){return n.talking;}
 public static void closeNpcDialogues(GuideNpc n){arrivals.values().removeIf(v->v==n);n.talking=false;}
 public static boolean hasEscortArrival(ServerPlayer p,GuideNpc n){return arrivals.get(p.uuid)==n;}
 public static void startEscort(ServerPlayer p,GuideNpc n,boolean arrival){opened++;if(arrival)arrivals.put(p.uuid,n);n.talking=true;}
 public static boolean isObserver(ServerPlayer p){return false;}
 public static void close(ServerPlayer p,GuideNpc n){arrivals.remove(p.uuid);n.talking=false;n.escort.dialogueClosed(p,true);}
 public static void reset(){opened=0;busy.clear();arrivals.clear();}}
''',
'net/minecraft/commands/CommandSourceStack.java': '''package net.minecraft.commands;
import net.minecraft.server.level.ServerPlayer;import net.minecraft.world.entity.Entity;public class CommandSourceStack {final ServerPlayer player;
 public CommandSourceStack(ServerPlayer p){player=p;}public Entity getEntity(){return player;}public ServerPlayer getPlayerOrException(){return player;}}
''',
'net/minecraft/commands/Commands.java': '''package net.minecraft.commands;
import com.mojang.brigadier.builder.*;import com.mojang.brigadier.arguments.ArgumentType;
public class Commands {public static LiteralArgumentBuilder<CommandSourceStack> literal(String n){return LiteralArgumentBuilder.literal(n);}
 public static <T> RequiredArgumentBuilder<CommandSourceStack,T> argument(String n,ArgumentType<T> type){return RequiredArgumentBuilder.argument(n,type);}}
''',
'net/neoforged/neoforge/event/RegisterCommandsEvent.java': '''package net.neoforged.neoforge.event;
import net.minecraft.commands.CommandSourceStack;import com.mojang.brigadier.CommandDispatcher;
public class RegisterCommandsEvent {public final CommandDispatcher<CommandSourceStack> dispatcher=new CommandDispatcher<>();public CommandDispatcher<CommandSourceStack> getDispatcher(){return dispatcher;}}
'''
}
if '--real-dialogue' in sys.argv:
    from extend_dialogue_doubles import extend
    extend(files)
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
for name,text in files.items():
    p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
print(f'Generated {len(files)} API doubles; production classes are not copied or rewritten.')
