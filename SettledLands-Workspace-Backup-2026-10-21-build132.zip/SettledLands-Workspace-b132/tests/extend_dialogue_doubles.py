"""Additional test doubles for running the actual GuideDialogue bytecode headlessly."""

def extend(files):
    files.pop('dev/settledlands/npc/GuideDialogue.java') # Use the production class instead.
    def add_after(name, before, after):
        if before not in files[name]: raise ValueError(name + ': API double anchor not found')
        files[name] = files[name].replace(before, after)
    files['net/minecraft/resources/ResourceKey.java']='''package net.minecraft.resources;
public class ResourceKey<T>{public final String name;public ResourceKey(String name){this.name=name;}public boolean equals(Object other){return other instanceof ResourceKey<?> k&&name.equals(k.name);}public int hashCode(){return name.hashCode();}}\n'''
    files['net/minecraft/world/damagesource/DamageSource.java']='''package net.minecraft.world.damagesource;
import net.minecraft.world.entity.Entity;
public class DamageSource {
    private final Entity entity;
    private final Entity directEntity;
    public DamageSource(Entity entity, Entity directEntity) { this.entity = entity; this.directEntity = directEntity; }
    public DamageSource(Entity entity) { this(entity, entity); }
    public Entity getEntity() { return entity; }
    public Entity getDirectEntity() { return directEntity; }
}\n'''
    files['net/minecraft/world/entity/monster/Enemy.java']='package net.minecraft.world.entity.monster;\npublic interface Enemy {}\n'
    add_after('net/minecraft/world/entity/player/Player.java', 'public class Player extends Entity {', 'public class Player extends Entity { public boolean isSpectator(){return false;} ')
    add_after('net/minecraft/world/level/Level.java', 'public class Level {', '''public class Level {
 public final net.minecraft.resources.ResourceKey<Level> dimension=new net.minecraft.resources.ResourceKey<>(java.util.UUID.randomUUID().toString());
 public net.minecraft.resources.ResourceKey<Level> dimension(){return dimension;}
 public boolean isClientSide(){return false;}
 public long gameTime=0;
 public long getGameTime(){return gameTime;}
 public long dayTime=0;
 public long getDayTime(){return dayTime;}
 public net.minecraft.world.entity.player.Player getNearestPlayer(net.minecraft.world.entity.Entity e, double maxDist){
    if (this instanceof net.minecraft.server.level.ServerLevel sl) {
       for (net.minecraft.world.entity.Entity ent : sl.entities) {
          if (ent instanceof net.minecraft.world.entity.player.Player p && !p.isSpectator() && p.isAlive() && e.distanceToSqr(ent) <= maxDist * maxDist) return p;
       }
    }
    return null;
 }''')
    add_after('net/minecraft/server/level/ServerPlayer.java', 'server.players.players.put(uuid,this);', 'server.players.players.put(uuid,this);level.entities.add(this);')
    add_after('net/minecraft/server/MinecraftServer.java', 'public class MinecraftServer {', '''public class MinecraftServer {
 public final java.util.Map<net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level>,net.minecraft.server.level.ServerLevel> levels=new java.util.HashMap<>();
 public net.minecraft.server.level.ServerLevel getLevel(net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level> key){return levels.get(key);}''')
    add_after('net/minecraft/server/level/ServerLevel.java', 'public ServerLevel(MinecraftServer s){server=s;}', 'public ServerLevel(MinecraftServer s){server=s;s.levels.put(dimension,this);}')
    add_after('net/minecraft/server/level/ServerLevel.java', 'public MinecraftServer getServer(){return server;}', '''public MinecraftServer getServer(){return server;}
 public Entity getEntity(int id){for(Entity e:entities)if(e instanceof dev.settledlands.npc.GuideNpc npc&&npc.id==id)return e;return null;}''')
    add_after('net/minecraft/world/entity/Entity.java', 'public class Entity {', '''public class Entity {
 public float xxa,yya,zza;
 public boolean hurt(net.minecraft.world.damagesource.DamageSource s, float a){return true;}
 public net.minecraft.world.phys.Vec3 getDeltaMovement(){return new net.minecraft.world.phys.Vec3(0,0,0);}
 public void setDeltaMovement(double x,double y,double z){}''')
    add_after('dev/settledlands/npc/GuideNpc.java', 'public boolean isTalking(){return talking;}', '''public boolean isTalking(){return talking;}
 public void setTalking(boolean value){talking=value;}
 public float health = 20.0f;
 public float maxHealth = 20.0f;
 public float getHealth(){return health;}
 public float getMaxHealth(){return maxHealth;}
 public void setHealth(float h){health=Math.min(maxHealth, Math.max(0, h));}
 public void heal(float amount){if(amount>0)setHealth(health+amount);}
 public int relation;
 public int relationTo(ServerPlayer player){return relation;}
 public static void addRelation(ServerPlayer player,GuideNpc npc,int delta){npc.relation+=delta;}
 public net.minecraft.world.entity.ai.control.LookControl getLookControl(){return new net.minecraft.world.entity.ai.control.LookControl();}
 public Component getDisplayName(){return getName();}
 public int checkScanTimer=0;
 public int tickCount=0;
 public String customAnimName = "";
 public boolean customAnimLoop = false;
 public String customAnimBone = "";
 public int customAnimStartTick = 0;
 public void playCustomAnimation(String anim, boolean loop, String bone){customAnimName=anim;customAnimLoop=loop;customAnimBone=bone;customAnimStartTick=tickCount;}
 public void playCustomAnimation(String anim, boolean loop){playCustomAnimation(anim, loop, "");}
 public String getCustomAnimName(){return customAnimName;}
 public boolean isCustomAnimLoop(){return customAnimLoop;}
 public String getCustomAnimBone(){return customAnimBone;}
 public int getCustomAnimStartTick(){return customAnimStartTick;}
 public net.minecraft.world.phys.Vec3 customMoveTarget;
 public double customMoveSpeed = 1.0;
 public int mobilityWatchNodeId = -1;
 public BlockPos mobilityWatchFirstPoint = null;
 public void beginMobilityWatch(int nodeId, BlockPos firstPoint) { this.mobilityWatchNodeId = nodeId; this.mobilityWatchFirstPoint = firstPoint; }
 public void beginMobilityWatch(int nodeId) { beginMobilityWatch(nodeId, null); }
 public boolean isWatchingMobilityArrival() { return mobilityWatchNodeId >= 0; }
 public void triggerMobilityArrival() {
    if (this.mobilityWatchNodeId >= 0) {
       int nId = this.mobilityWatchNodeId;
       this.mobilityWatchNodeId = -1;
       this.mobilityWatchFirstPoint = null;
       net.minecraft.server.level.ServerPlayer p = null;
       if (this.level() instanceof net.minecraft.server.level.ServerLevel sl && !sl.entities.isEmpty()) {
          for (net.minecraft.world.entity.Entity e : sl.entities) {
             if (e instanceof net.minecraft.server.level.ServerPlayer sp) { p = sp; break; }
          }
       }
       if (this.profile != null && this.profile.dialogueGraph != null) {
          dev.settledlands.npc.NpcDialogueGraph.Node node = this.profile.dialogueGraph.get(nId);
          if (node != null) {
             dev.settledlands.npc.GuideDialogue.triggerMobilityChain(this, p, node);
          }
       }
    }
 }
 public boolean walkTo(double x, double y, double z, double speedMultiplier) {
    this.customMoveTarget = new net.minecraft.world.phys.Vec3(x, y, z);
    this.customMoveSpeed = speedMultiplier;
    return this.getNavigation().moveTo(x, y, z, speedMultiplier);
 }
 public boolean isMovingToCustomTarget() { return customMoveTarget != null; }
 public void stopCustomMovement() { customMoveTarget = null; }
 public BlockPos findStablePosition(net.minecraft.server.level.ServerLevel level, BlockPos origin) { return origin != null ? origin : new BlockPos(0, 64, 0); }
 public int resolveNextMobilityPoint(java.util.List<dev.settledlands.npc.NpcProfile.MobilityPoint> points, int startIdx, int depth) {
    if (depth > 20 || startIdx < 0 || startIdx >= points.size()) return -1;
    dev.settledlands.npc.NpcProfile.MobilityPoint node = points.get(startIdx);
    if (node == null) return -1;
    if (node.type == dev.settledlands.npc.NpcProfile.MobilityPoint.TYPE_POINT) return startIdx;
    if (node.type == dev.settledlands.npc.NpcProfile.MobilityPoint.TYPE_RANDOM) {
       int min = Math.max(1, node.randomMin);
       int max = Math.max(min, node.randomMax);
       int picked = min + new java.util.Random().nextInt(max - min + 1);
       int port = picked - 1;
       if (port >= 0 && port < node.randomBranches.size()) {
          int branchTarget = node.randomBranches.get(port);
          if (branchTarget >= 0) return resolveNextMobilityPoint(points, branchTarget, depth + 1);
       }
       return -1;
    }
    if (node.type == dev.settledlands.npc.NpcProfile.MobilityPoint.TYPE_IF) {
       boolean success = new java.util.Random().nextInt(100) < Math.max(0, Math.min(100, node.chance));
       int branchTarget = success ? node.next : node.falseNext;
       if (branchTarget >= 0) return resolveNextMobilityPoint(points, branchTarget, depth + 1);
       return -1;
    }
    return -1;
 }
 public final java.util.Map<Integer, java.util.Map<java.util.UUID, Long>> checkCooldowns = new java.util.HashMap<>();
 public final java.util.Map<Integer, Long> damageCooldowns = new java.util.HashMap<>();
 public final java.util.Map<Integer, Long> timeLastTriggerDays = new java.util.HashMap<>();
 public final java.util.Map<Integer, Long> timerLastTriggerTicks = new java.util.HashMap<>();
 public final java.util.Map<Integer, java.util.Map<java.util.UUID, Long>> walkCheckCooldowns = new java.util.HashMap<>();
 public final java.util.Map<Integer, java.util.Map<java.util.UUID, Long>> animCheckCooldowns = new java.util.HashMap<>();
 public final java.util.Map<Integer, Long> walkDamageCooldowns = new java.util.HashMap<>();
 public final java.util.Map<Integer, Long> animDamageCooldowns = new java.util.HashMap<>();
 public final java.util.Map<Integer, Long> walkTimeLastTriggerDays = new java.util.HashMap<>();
 public final java.util.Map<Integer, Long> animTimeLastTriggerDays = new java.util.HashMap<>();
 public final java.util.Map<Integer, Long> walkTimerLastTriggerTicks = new java.util.HashMap<>();
 public final java.util.Map<Integer, Long> animTimerLastTriggerTicks = new java.util.HashMap<>();
 public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
    if (!this.level().isClientSide()) {
       dev.settledlands.npc.GuideDialogue.handleNpcDamaged(this, source, amount, this.damageCooldowns);
       dev.settledlands.npc.GuideDialogue.handleNpcDamaged(this, source, amount, this.walkDamageCooldowns, this.profile.walkGraph);
       dev.settledlands.npc.GuideDialogue.handleNpcDamaged(this, source, amount, this.animDamageCooldowns, this.profile.animGraph);
    }
    return super.hurt(source, amount);
 }
 public void tickCheckNodes(){tickCheckNodes(false);}
 public void tickCheckNodes(boolean force){
    if (this.level().isClientSide() || this.isTalking() || !this.isAlive()) return;
    if (!force && ++this.checkScanTimer < 10) return;
    this.checkScanTimer = 0;
    if (GuideDialogue.graphActive(this.profile)) {
       dev.settledlands.npc.NpcDialogueGraph graph = this.profile.dialogueGraph;
       if (graph != null) {
          GuideDialogue.tickGraphCheckNodes(this, graph, this.checkCooldowns);
          GuideDialogue.tickGraphTimeNodes(this, graph, this.timeLastTriggerDays);
          GuideDialogue.tickGraphTimerNodes(this, graph, this.timerLastTriggerTicks);
       }
    }
    tickSubGraph(this.profile.walkGraph, this.walkCheckCooldowns, this.walkTimeLastTriggerDays, this.walkTimerLastTriggerTicks);
    tickSubGraph(this.profile.animGraph, this.animCheckCooldowns, this.animTimeLastTriggerDays, this.animTimerLastTriggerTicks);
 }
 private void tickSubGraph(dev.settledlands.npc.NpcDialogueGraph graph, java.util.Map<Integer, java.util.Map<java.util.UUID, Long>> checkCd, java.util.Map<Integer, Long> timeCd, java.util.Map<Integer, Long> timerCd){
    if (graph == null) return;
    GuideDialogue.tickGraphCheckNodes(this, graph, checkCd);
    GuideDialogue.tickGraphTimeNodes(this, graph, timeCd);
    GuideDialogue.tickGraphTimerNodes(this, graph, timerCd);
 }''')
    add_after('dev/settledlands/npc/GuideNpc.java', 'public void beginEscort(ServerPlayer p,String code,BlockPos target){escort=NpcEscort.begin(this,p,code,target);}',
              'public void beginEscort(ServerPlayer p,String code,BlockPos target){escort=NpcEscort.begin(this,p,code,target);GuideDialogue.closeNpcDialogues(this);}')
    add_after('dev/settledlands/npc/GuideNpc.java', 'public void finishEscort(){finished++;escort=null;navigation.stop();}',
              'public void finishEscort(){GuideDialogue.closeNpcDialogues(this);finished++;escort=null;navigation.stop();}')
    files['net/minecraft/world/entity/ai/control/LookControl.java']='''package net.minecraft.world.entity.ai.control;
public class LookControl {public void setLookAt(net.minecraft.world.entity.Entity entity,float yaw,float pitch){}}\n'''
    add_after('dev/settledlands/npc/NpcProfile.java', 'public class NpcProfile {', '''public class NpcProfile {
 public dev.settledlands.npc.NpcDialogueGraph dialogueGraph;
 public dev.settledlands.npc.NpcDialogueGraph walkGraph,animGraph;
 public int defaultTab;
 public boolean showDialogueTab=true,showTradeTab=false,showQuestTab=false,showPhrasesTab=false;
 public boolean hasShop(){return false;}
 public static final class Variant {public int minRelation;public String text;public Variant(int min,String text){minRelation=min;this.text=text;}}
 public String name="",title="",voice="",escortTravelLine="Мы почти пришли",escortArrivalLine="Мы пришли";
 public boolean lookAtPlayer=true,showSpeaker=true,keyHints=true,answerNumbers=false,cameraOnFace=false,blockMouseLook=false,muteHud=true,vignette=true,blockMovement=true,pauseWorld=false;
 public int style=0,textColor=0,nameColor=1,typingSpeed=30,zoom=100,offsetX=0,offsetY=0,dim=45,blur=0,exitKey=0,voicePitch=0,radius=4;
 public final java.util.List<Quest> quests=new java.util.ArrayList<>();
 public String reputationLabel(int relation){return "Neutral";}
 public static int clamp(int value,int minimum,int maximum){return Math.max(minimum,Math.min(maximum,value));}
 public static String fillQuest(String text,net.minecraft.world.entity.player.Player player,int relation,Quest quest){return text;}
''')
    files['net/minecraft/network/protocol/common/custom/CustomPacketPayload.java']='''package net.minecraft.network.protocol.common.custom; public interface CustomPacketPayload {}\n'''
    files['dev/settledlands/npc/NpcNet.java']='''package dev.settledlands.npc;
import java.util.*;import net.minecraft.server.level.ServerPlayer;import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
public class NpcNet {
 public record Sent(ServerPlayer player,CustomPacketPayload payload){}
 public static final List<Sent> sent=new ArrayList<>();
 public static void sendTo(ServerPlayer player,CustomPacketPayload packet){sent.add(new Sent(player,packet));}
 public static void sendRaw(ServerPlayer player,CustomPacketPayload packet){sendTo(player,packet);}
 public record DlgStyle(int style,int textColor,int nameColor,int typingSpeed,boolean speakerName,boolean keyHints,boolean answerNumbers,String reputation,
 boolean dialogueTab,boolean tradeTab,boolean questTab,boolean phrasesTab,int defaultTab,int zoom,int offsetX,int offsetY,boolean cameraOnFace,boolean blockMouseLook,
 int dim,int blur,boolean muteHud,boolean vignette,int exitKey,boolean blockMovement,boolean pauseWorld,String voice,int voicePitch){}
 public record DlgView(int entityId,String speaker,String title,String text,List<String> options,List<String> hints,int relation,int state,boolean shop,DlgStyle style,boolean observer) implements CustomPacketPayload{
 public DlgView(int id,String speaker,String title,String text,List<String> options,List<String> hints,int relation,int state,boolean shop,DlgStyle style){this(id,speaker,title,text,options,hints,relation,state,shop,style,false);}
 public DlgView asObserver(){return new DlgView(entityId,speaker,title,text,options,hints,relation,state,shop,style,true);}}
 public record DlgEnd(int entityId) implements CustomPacketPayload{}
 public record DlgFocus(int entityId,int focusEntityId,String speaker,String title,int nameColor) implements CustomPacketPayload{}
 public record ShopView(int entityId,int relation,int maxPerPurchase,List<?> entries,boolean observer) implements CustomPacketPayload{
 public ShopView asObserver(){return new ShopView(entityId,relation,maxPerPurchase,entries,true);}}
 public static DlgView lastView(ServerPlayer player){for(int i=sent.size()-1;i>=0;i--){Sent item=sent.get(i);if(item.player==player&&item.payload instanceof DlgView view)return view;}return null;}
}\n'''
    files['net/neoforged/neoforge/event/tick/ServerTickEvent.java']='''package net.neoforged.neoforge.event.tick;
import net.minecraft.server.MinecraftServer;public class ServerTickEvent {public static class Post {final MinecraftServer server;public Post(MinecraftServer server){this.server=server;}public MinecraftServer getServer(){return server;}}}\n'''

    files['dev/settledlands/npc/NpcPoints.java']='''package dev.settledlands.npc;
public class NpcPoints {
    public static final int MAX_VALUE=1000000000;
    public static int balance;
    public static java.util.Map<String,Integer> pointsStore = new java.util.HashMap<>();
    public static NpcPoints get(net.minecraft.server.MinecraftServer server){return new NpcPoints();}
    public int get(java.util.UUID player,String name,boolean shared){
        return pointsStore.getOrDefault(name, balance);
    }
    public void set(java.util.UUID player,String name,boolean shared,int value){
        pointsStore.put(name, value);
    }
    public int add(java.util.UUID player,String name,boolean shared,int delta){
        int cur = get(player, name, shared);
        int next = Math.max(0, Math.min(MAX_VALUE, cur + delta));
        pointsStore.put(name, next);
        balance = next;
        return next;
    }
}\n'''
