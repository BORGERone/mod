#!/usr/bin/env python3
"""Regression for the real inherited Minecraft Screen pipeline, using actual compiled bytecode.
This is a bytecode test, NOT a real OpenGL/client render test.
"""
import argparse,json,re,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--java-home',type=Path,required=True);p.add_argument('--cache',type=Path,required=True);p.add_argument('--jar',type=Path,required=True);a=p.parse_args()
checks=0

def check(value,label):
 global checks
 checks+=1
 if not value:raise AssertionError(label)

def inspect(name,cp):
 return subprocess.check_output([str(a.java_home/'bin/javap'),'-J-Xmx128m','-J-XX:ActiveProcessorCount=1','-c','-p','-classpath',str(cp),name],text=True)

def method(text,start):
 lines=text.splitlines();i=next(i for i,s in enumerate(lines) if s.startswith(start))
 j=next((j for j in range(i+2,len(lines)) if lines[j].startswith('  ') and not lines[j].startswith('    ') and lines[j].endswith(';')),len(lines))
 return '\n'.join(lines[i:j])

mc_jar = a.cache/'minecraft-compile.jar' if (a.cache/'minecraft-compile.jar').exists() else a.cache/'toolchain/minecraft-compile.jar'
screen=inspect('net.minecraft.client.gui.screens.Screen', mc_jar)
graph=inspect('dev.settledlands.npc.client.NpcDialogueGraphScreen',a.jar)
s=method(screen,'  public void render(net.minecraft.client.gui.GuiGraphics,')
bg=method(graph,'  public void renderBackground(')
r=method(graph,'  public void render(net.minecraft.client.gui.GuiGraphics,')
check('Method renderBackground:' in s,'Minecraft Screen.render really dispatches the virtual background')
check(s.index('Method renderBackground:')<s.index('InterfaceMethod net/minecraft/client/gui/components/Renderable.render:'),'native background executes before widget draw')
check('Method drawNode:' in bg,'canvas nodes drawn in the native background phase')
check('Method grid:' in bg and 'Method wires:' in bg,'grid and cables drawn in same background phase')
check('Method net/minecraft/client/gui/screens/Screen.render:' in r,'widget pipeline retained')
check('Method drawNode:' not in r and 'Method grid:' not in r and 'Method wires:' not in r,'no canvas drawing before a late super background')
check('Method net/minecraft/client/gui/screens/Screen.render:' not in bg,'background does not recurse into Screen.render')
check(r.index('Method net/minecraft/client/gui/screens/Screen.render:')<r.index('Method drawContextMenu:'),'popup is an overlay after native widgets/background')
check('Method drawContextMenu:' in r,'context menu render is integrated')
check('Field canvasPanMoved:Z' in graph,'canvas pan focus persistence flag exists in bytecode')
check('Method calcTextLines:(Ljava/lang/String;I)I' in graph,'adaptive multiline text line calculator exists in bytecode')
check('Method calcBoxHeight:(III)I' in graph,'adaptive multiline text box height calculator exists in bytecode')
check('Method multiLineTextBox:(Ljava/lang/String;IIIIIILjava/util/function/Consumer;)Lnet/minecraft/client/gui/components/MultiLineEditBox;' in graph,'MultiLineEditBox factory method exists in bytecode')
# Preserve a concise real-bytecode proof, not a full Minecraft disassembly.
guide=inspect('dev.settledlands.npc.GuideNpc',a.jar)
check('getPickResult' not in guide,'client-side vanilla pick fabrication removed (set_creative_mode_slot crash regression)')
cp=inspect('dev.settledlands.npc.NpcCopyPickPayload',a.jar)
check('npc_copy_pick' in cp,'copy payload registered on the settledlands channel')
hd=method(cp,'  private static void handle(')
check('hasPermissions' in hd,'copy requires operator permission level 2')
check('Inventory.add' in hd,'copy egg is placed server-side into the player inventory')
egg=method(cp,'  public static net.minecraft.world.item.ItemStack buildCopyEgg(')
check('String sl_copy_src' in egg,'copy egg carries only the tiny source-NPC marker')
check('Method net/minecraft/nbt/CompoundTag.putUUID' in egg,'marker stores the source npc uuid')
check('String Profile' not in egg,'no bulky full-profile NBT in the copy egg packet')
check('Field net/minecraft/core/component/DataComponents.ENTITY_DATA' in egg,'copy egg stores the vanilla entity_data component')
check('Field net/minecraft/core/component/DataComponents.CUSTOM_NAME' in egg,'copy egg carries a readable custom name')
pc=inspect('dev.settledlands.npc.client.NpcPickCopy',a.jar)
check('InteractionKeyMappingTriggered' in pc and 'sendToServer' in pc,'middle click is captured client-side and forwarded to the server')
ctc=inspect('dev.settledlands.npc.client.CommandTabCompleter',a.jar)
check('sanitizeNpcSelectors' in ctc,'@npc selectors are shadow-substituted before vanilla brigadier completion')
check('String getText' in ctc and 'String apply' not in ctc,'vanilla completions applied via token replacement (reflection-safe, no shifted ranges)')
check('injectArgHints' in ctc,'vanilla-style argument-name hints for numeric tails exist and are non-destructive')
ccam=inspect('dev.settledlands.npc.CutsceneCamera',a.jar)
check('Field net/minecraft/world/level/GameType.SPECTATOR' in ccam.replace('\n',' ').replace('  ',' ') or 'SPECTATOR' in ccam,'camera session switches the player to spectator (vanilla noclip flight)')
check('SavedData' in ccam and 'String settledlands_cutscene_cam' in ccam and 'byId:(I)' in ccam,'previous game mode persisted in world SavedData and restored on exit/relog')
check('void tick' in ccam and 'teleport' in ccam and 'getEyePosition' in ccam,'server tick: record eye keys and step playback teleports')
check('play(net.minecraft.server.level.ServerPlayer' in ccam and 'String message.settledlands.cutscene.play_missing' in ccam,'node-triggered playback entry point with missing-scene message')
cs=inspect('dev.settledlands.npc.CutsceneStorage',a.jar)
check('String settledlands_cutscenes' in cs and 'store(' in cs,'recorded scenes stored in world SavedData with auto names')
cg=inspect('dev.settledlands.npc.NpcDialogueGraph',a.jar)
check('CUTSCENE;' in cg.replace(' ',''),'CUTSCENE node type exists')
check('String CutsceneName' in cg,'cutscene name serialized into graph NBT')
cexit=inspect('dev.settledlands.npc.CutsceneCamExitPayload',a.jar)
check('cutscene_cam_exit' in cexit,'client RMB-in-spectator exit request payload registered')
rs=method(guide,'  public void readAdditionalSaveData(')
check('String sl_copy_src' in rs,'spawn-time copy branch reads the marker on the server')
check('Method net/minecraft/server/level/ServerLevel.getEntity' in rs,'copy resolves the source npc in the server world')
check('Method dev/settledlands/npc/NpcProfile.load' in rs,'copy applies a deserialized snapshot (no reference aliasing)')
wand=inspect('dev.settledlands.npc.client.MobilityWandScreen',a.jar)
kp=method(wand,'  public boolean keyPressed(')
check('261' in kp and 'String wand.point.del' in kp,'Delete key removes the selected wand-graph node')

root=Path(__file__).resolve().parents[1]
(root/'diagnostics/render-order-bytecode.txt').write_text('ACTUAL COMPILED BYTECODE REGRESSION; not a game/OpenGL test.\n\n'+s+'\n\n'+bg+'\n\n'+r+'\n\n'+hd+'\n\n'+egg+'\n\n'+rs+'\n\n'+kp+'\n')
(root/'tests/render-order-test.log').write_text(f'PASS: {checks} assertions on real Screen/graph render bytecode\nNo Minecraft client, GUI, OpenGL or renderer was started.\n')
print(f'PASS: {checks} assertions on real Screen/graph render bytecode')
print('No Minecraft client, GUI, OpenGL or renderer was started.')
