#!/usr/bin/env python3
"""Sequential bounded headless tests of the built mod; never starts Minecraft.
ProfileHarness uses real Minecraft NBT and production NpcProfile/NpcEdit (no doubles).
EscortHarness and DialogueHarness use explicitly generated/capture-only API doubles.
"""
import argparse, hashlib, json, os, re, shutil, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while block := f.read(1024 * 1024): h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cache', type=Path, required=True)
    parser.add_argument('--java-home', type=Path, required=True)
    args = parser.parse_args()
    cache, jdk = args.cache.resolve(), args.java_home.resolve()
    cp = (cache / 'classpath.txt').read_text().strip()
    report_data = json.loads((ROOT / 'build-report.json').read_text())
    jar = ROOT / report_data['jar']
    if sha256(jar) != report_data['sha256']:
        raise ValueError('JAR/build-report mismatch; build_patch.py must be run first')
    logging = '-Dlog4j2.configurationFile=' + str(ROOT / 'tests/log4j-headless.xml')
    stages = []
    started = time.monotonic()
    for name, harness, mode, heap in [
        ('escort', 'EscortHarness', 'default', 128),
        ('profile', 'ProfileHarness', None, 256),
        ('graph', 'GraphHarness', None, 256),
        ('context-menu', 'ContextMenuHarness', None, 128),
        ('dialogue', 'DialogueHarness', 'real-dialogue', 128),
        ('graph-runtime', 'GraphRuntimeHarness', 'real-dialogue', 128),
        ('audio', 'AudioHarness', None, 128),
        ('bbmodel', 'BbModelHarness', None, 128),
    ]:
        out = cache / (name + '-test')
        doubles = cache / (name + '-doubles')
        if out.exists(): shutil.rmtree(out)
        out.mkdir(parents=True)
        sources = []
        if mode:
            if doubles.exists(): shutil.rmtree(doubles)
            command = [sys.executable, str(ROOT / 'tests/create_test_doubles.py'), str(doubles)]
            if mode == 'real-dialogue': command.append('--real-dialogue')
            subprocess.run(command, check=True)
            sources.extend(sorted(doubles.rglob('*.java')))
        sources.append(ROOT / 'tests' / (harness + '.java'))
        compile_log = ROOT / 'tests' / (name + '-compile.log')
        with compile_log.open('w') as log:
            subprocess.run([str(jdk / 'bin/javac'), '-J-Xmx256m', '-J-XX:ActiveProcessorCount=1',
                '-J-XX:+UseSerialGC', '-proc:none', '--release', '21', '-encoding', 'UTF-8',
                '-classpath', str(jar) + os.pathsep + cp, '-d', str(out), *map(str, sources)],
                stdout=log, stderr=subprocess.STDOUT, check=True)
        runtime_log = ROOT / 'tests' / (name + '-test.log')
        with runtime_log.open('w') as log:
            result = subprocess.run([str(jdk / 'bin/java'), '-Xmx' + str(heap) + 'm',
                '-XX:ActiveProcessorCount=1', '-XX:+UseSerialGC', logging, '-cp',
                str(out) + os.pathsep + str(jar) + os.pathsep + cp, harness],
                stdout=log, stderr=subprocess.STDOUT)
        output = runtime_log.read_text()
        print(output, end='')
        result.check_returncode()
        match = re.search(r'PASS:\s*(\d+)\s+assertions', output)
        if not match: raise ValueError('Missing assertion count in ' + name)
        stages.append({'name': name, 'harness': harness, 'assertions': int(match.group(1)),
                       'api_doubles': mode is not None, 'max_runtime_heap_mib': heap,
                       'exit_code': result.returncode})
    audit = subprocess.run([sys.executable, str(ROOT/'tests/render_order_audit.py'), '--java-home', str(jdk),
        '--cache', str(cache), '--jar', str(jar)], text=True, capture_output=True, check=True)
    print(audit.stdout, end='')
    match = re.search(r'PASS:\s*(\d+)\s+assertions', audit.stdout)
    stages.append({'name':'render-order','harness':'render_order_audit.py','assertions':int(match.group(1)),
        'api_doubles':False,'bytecode_audit':True,'max_runtime_heap_mib':128,'exit_code':0})
    report = {'jar_sha256': sha256(jar), 'stages': stages,
        'total_assertions': sum(s['assertions'] for s in stages),
        'elapsed_seconds': round(time.monotonic() - started, 3),
        'max_test_compiler_heap_mib': 256, 'active_processors': 1,
        'minecraft_launch_test': False, 'gui_render_test': False,
        'performance_claim': 'Budget/retry policy only; not an FPS or real-server benchmark'}
    (ROOT / 'tests/test-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print('ALL PASS:', report['total_assertions'], 'assertions; no Minecraft launch')


if __name__ == '__main__': main()
