SettledLands Music (.minecraft/settledlands/music/)
===================================================
Поместите сюда фоновую музыку (.mp3, .ogg, .wav).
Файлы из этой папки ЗАГЛУШАЮТ ванильную музыку Minecraft при воспроизведении!

Команда воспроизведения:
  /play <имя_файла> [радиус] [громкость: 0.1-1.0] [loop: true/false] [fade_sec: 1-5] [pitch]
  /play stop [fade_sec]

Примеры:
  /play tavern.mp3 50 1.0 true 2.0
  /play epic_battle 0 0.8 false 1.0
  /play stop 2.0
